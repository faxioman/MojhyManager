'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Players
    Public Class PlayerEventSet
        Inherits System.Collections.CollectionBase

        Default Property Item(ByVal index As Integer) As PlayerEvent
            Get
                Return CType(InnerList.Item(index), PlayerEvent)
            End Get
            Set(ByVal Value As PlayerEvent)
                InnerList.Item(index) = Value
            End Set
        End Property

        Sub Add(ByVal value As PlayerEvent)
            InnerList.Add(value)
        End Sub

        Sub Create(ByVal PlayerID As Integer, ByVal EventDate As Date, _
            ByVal Description As String, ByVal PlayerEventID As Integer)

            Dim objItem As New PlayerEvent()
            With objItem
                .EventDate = EventDate
                .Description = Description
                .PlayerID = PlayerID
                .PlayerEventID = PlayerEventID
            End With
            Me.Add(objItem)
        End Sub

        Sub Load(ByVal PlayerID As Integer)
            Dim ds As New DataServices.PlayerTables()
            Dim dr As OleDb.OleDbDataReader = ds.GetPlayerEvents(PlayerID)

            Me.InnerList.Clear()

            Do While dr.Read()
                With dr
                    Me.Create(PlayerID, dr.Item("EventDate"), dr.Item("Description"), dr.Item("PlayerEventID"))
                End With
            Loop
            dr.Close()
        End Sub

        Function GetHighlight() As String
            Dim Result As String
            If Me.Count > 0 Then
                Dim pe As PlayerEvent

                For Each pe In Me.InnerList
                    Result = Result & pe.Description & " - " & Format(pe.EventDate, "MM/dd/yyyy") & vbCrLf
                Next
            Else
                Result = "No highlights available."
            End If
            Return Result
        End Function
    End Class
End Namespace
