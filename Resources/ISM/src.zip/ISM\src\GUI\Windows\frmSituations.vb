'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.Tactical

Public Class frmSituations
	Inherits System.Windows.Forms.Form

	Private mblnLoading As Boolean
	Private mblnDirty As Boolean = False
	Private mintLastIndex As Integer
	Private mblnValid As Boolean = True
    Dim Sim As Simulation = Simulation.GetInstance()
    Dim gs As GUIService = GUIService.GetInstance
    Dim vs As ValidationService = ValidationService.GetInstance

#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		Call SetScreen()


	End Sub


	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Public WithEvents grpFinish As System.Windows.Forms.GroupBox
	Public WithEvents tipLeague As System.Windows.Forms.ToolTip
	Public WithEvents btnOK As System.Windows.Forms.Button
	Public WithEvents GroupBox1 As System.Windows.Forms.GroupBox
	Public WithEvents btnSave As System.Windows.Forms.Button
	Public WithEvents lstSituations As System.Windows.Forms.ListBox
	Public WithEvents grpNetPoints As System.Windows.Forms.GroupBox
	Public WithEvents Label10 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents GroupBox2 As System.Windows.Forms.GroupBox
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents txtAbbr As System.Windows.Forms.TextBox
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents txtName As System.Windows.Forms.TextBox
	Public WithEvents btnNewSituation As System.Windows.Forms.Button
	Public WithEvents cmbNetLow As System.Windows.Forms.ComboBox
	Public WithEvents cmbMultiNetLow As System.Windows.Forms.ComboBox
	Public WithEvents cmbNetHigh As System.Windows.Forms.ComboBox
	Public WithEvents cmbMultiNetHigh As System.Windows.Forms.ComboBox
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents cmbSpecial As System.Windows.Forms.ComboBox
	Public WithEvents GroupBox3 As System.Windows.Forms.GroupBox
	Public WithEvents Label9 As System.Windows.Forms.Label
	Public WithEvents cmbHalf As System.Windows.Forms.ComboBox
	Public WithEvents txtMinuteLeftTo As System.Windows.Forms.TextBox
	Public WithEvents txtMinuteLeftFrom As System.Windows.Forms.TextBox
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Me.btnOK = New System.Windows.Forms.Button()
		Me.grpFinish = New System.Windows.Forms.GroupBox()
		Me.btnNewSituation = New System.Windows.Forms.Button()
		Me.GroupBox1 = New System.Windows.Forms.GroupBox()
		Me.GroupBox3 = New System.Windows.Forms.GroupBox()
		Me.Label9 = New System.Windows.Forms.Label()
		Me.cmbHalf = New System.Windows.Forms.ComboBox()
		Me.txtMinuteLeftTo = New System.Windows.Forms.TextBox()
		Me.txtMinuteLeftFrom = New System.Windows.Forms.TextBox()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.Label5 = New System.Windows.Forms.Label()
		Me.GroupBox2 = New System.Windows.Forms.GroupBox()
		Me.cmbSpecial = New System.Windows.Forms.ComboBox()
		Me.Label8 = New System.Windows.Forms.Label()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.txtAbbr = New System.Windows.Forms.TextBox()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.txtName = New System.Windows.Forms.TextBox()
		Me.grpNetPoints = New System.Windows.Forms.GroupBox()
		Me.Label7 = New System.Windows.Forms.Label()
		Me.Label6 = New System.Windows.Forms.Label()
		Me.cmbMultiNetHigh = New System.Windows.Forms.ComboBox()
		Me.cmbNetHigh = New System.Windows.Forms.ComboBox()
		Me.cmbMultiNetLow = New System.Windows.Forms.ComboBox()
		Me.cmbNetLow = New System.Windows.Forms.ComboBox()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.Label10 = New System.Windows.Forms.Label()
		Me.lstSituations = New System.Windows.Forms.ListBox()
		Me.tipLeague = New System.Windows.Forms.ToolTip(Me.components)
		Me.btnSave = New System.Windows.Forms.Button()
		Me.grpFinish.SuspendLayout()
		Me.GroupBox1.SuspendLayout()
		Me.GroupBox3.SuspendLayout()
		Me.GroupBox2.SuspendLayout()
		Me.grpNetPoints.SuspendLayout()
		Me.SuspendLayout()
		'
		'btnOK
		'
		Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnOK.Location = New System.Drawing.Point(352, 320)
		Me.btnOK.Name = "btnOK"
		Me.btnOK.Size = New System.Drawing.Size(112, 24)
		Me.btnOK.TabIndex = 1
		Me.btnOK.Text = "&OK"
		'
		'grpFinish
		'
		Me.grpFinish.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnNewSituation, Me.GroupBox1, Me.lstSituations})
		Me.grpFinish.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.grpFinish.Location = New System.Drawing.Point(8, 8)
		Me.grpFinish.Name = "grpFinish"
		Me.grpFinish.Size = New System.Drawing.Size(456, 304)
		Me.grpFinish.TabIndex = 11
		Me.grpFinish.TabStop = False
		Me.grpFinish.Text = "Situations"
		'
		'btnNewSituation
		'
		Me.btnNewSituation.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)
		Me.btnNewSituation.Location = New System.Drawing.Point(16, 272)
		Me.btnNewSituation.Name = "btnNewSituation"
		Me.btnNewSituation.Size = New System.Drawing.Size(96, 24)
		Me.btnNewSituation.TabIndex = 15
		Me.btnNewSituation.TabStop = False
		Me.btnNewSituation.Text = "&New Situation"
		'
		'GroupBox1
		'
		Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox3, Me.GroupBox2, Me.grpNetPoints})
		Me.GroupBox1.Location = New System.Drawing.Point(120, 16)
		Me.GroupBox1.Name = "GroupBox1"
		Me.GroupBox1.Size = New System.Drawing.Size(328, 280)
		Me.GroupBox1.TabIndex = 1
		Me.GroupBox1.TabStop = False
		Me.GroupBox1.Text = "Details"
		'
		'GroupBox3
		'
		Me.GroupBox3.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label9, Me.cmbHalf, Me.txtMinuteLeftTo, Me.txtMinuteLeftFrom, Me.Label4, Me.Label5})
		Me.GroupBox3.Location = New System.Drawing.Point(16, 200)
		Me.GroupBox3.Name = "GroupBox3"
		Me.GroupBox3.Size = New System.Drawing.Size(304, 72)
		Me.GroupBox3.TabIndex = 3
		Me.GroupBox3.TabStop = False
		Me.GroupBox3.Text = "Time"
		'
		'Label9
		'
		Me.Label9.Location = New System.Drawing.Point(120, 40)
		Me.Label9.Name = "Label9"
		Me.Label9.Size = New System.Drawing.Size(24, 16)
		Me.Label9.TabIndex = 78
		Me.Label9.Text = "to"
		Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopCenter
		'
		'cmbHalf
		'
		Me.cmbHalf.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbHalf.Items.AddRange(New Object() {"First Half", "Second Half"})
		Me.cmbHalf.Location = New System.Drawing.Point(80, 16)
		Me.cmbHalf.Name = "cmbHalf"
		Me.cmbHalf.Size = New System.Drawing.Size(104, 22)
		Me.cmbHalf.TabIndex = 0
		'
		'txtMinuteLeftTo
		'
		Me.txtMinuteLeftTo.Location = New System.Drawing.Point(144, 40)
		Me.txtMinuteLeftTo.Name = "txtMinuteLeftTo"
		Me.txtMinuteLeftTo.Size = New System.Drawing.Size(40, 20)
		Me.txtMinuteLeftTo.TabIndex = 2
		Me.txtMinuteLeftTo.Text = ""
		'
		'txtMinuteLeftFrom
		'
		Me.txtMinuteLeftFrom.Location = New System.Drawing.Point(80, 40)
		Me.txtMinuteLeftFrom.Name = "txtMinuteLeftFrom"
		Me.txtMinuteLeftFrom.Size = New System.Drawing.Size(40, 20)
		Me.txtMinuteLeftFrom.TabIndex = 1
		Me.txtMinuteLeftFrom.Text = ""
		'
		'Label4
		'
		Me.Label4.Location = New System.Drawing.Point(8, 40)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(80, 16)
		Me.Label4.TabIndex = 77
		Me.Label4.Text = "Minutes Left:"
		'
		'Label5
		'
		Me.Label5.Location = New System.Drawing.Point(8, 16)
		Me.Label5.Name = "Label5"
		Me.Label5.Size = New System.Drawing.Size(80, 16)
		Me.Label5.TabIndex = 74
		Me.Label5.Text = "Half:"
		'
		'GroupBox2
		'
		Me.GroupBox2.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmbSpecial, Me.Label8, Me.Label2, Me.txtAbbr, Me.Label1, Me.txtName})
		Me.GroupBox2.Location = New System.Drawing.Point(16, 16)
		Me.GroupBox2.Name = "GroupBox2"
		Me.GroupBox2.Size = New System.Drawing.Size(304, 96)
		Me.GroupBox2.TabIndex = 0
		Me.GroupBox2.TabStop = False
		Me.GroupBox2.Text = "General"
		'
		'cmbSpecial
		'
		Me.cmbSpecial.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbSpecial.Items.AddRange(New Object() {"None", "Power Play", "Penalty Kill"})
		Me.cmbSpecial.Location = New System.Drawing.Point(80, 64)
		Me.cmbSpecial.Name = "cmbSpecial"
		Me.cmbSpecial.Size = New System.Drawing.Size(136, 22)
		Me.cmbSpecial.TabIndex = 2
		'
		'Label8
		'
		Me.Label8.Location = New System.Drawing.Point(8, 64)
		Me.Label8.Name = "Label8"
		Me.Label8.Size = New System.Drawing.Size(72, 16)
		Me.Label8.TabIndex = 23
		Me.Label8.Text = "Special:"
		'
		'Label2
		'
		Me.Label2.Location = New System.Drawing.Point(8, 40)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(72, 16)
		Me.Label2.TabIndex = 22
		Me.Label2.Text = "Abbreviation:"
		'
		'txtAbbr
		'
		Me.txtAbbr.Location = New System.Drawing.Point(80, 40)
		Me.txtAbbr.MaxLength = 10
		Me.txtAbbr.Name = "txtAbbr"
		Me.txtAbbr.Size = New System.Drawing.Size(136, 20)
		Me.txtAbbr.TabIndex = 1
		Me.txtAbbr.Text = ""
		'
		'Label1
		'
		Me.Label1.Location = New System.Drawing.Point(8, 16)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(40, 16)
		Me.Label1.TabIndex = 20
		Me.Label1.Text = "Name:"
		'
		'txtName
		'
		Me.txtName.Location = New System.Drawing.Point(80, 16)
		Me.txtName.MaxLength = 50
		Me.txtName.Name = "txtName"
		Me.txtName.Size = New System.Drawing.Size(216, 20)
		Me.txtName.TabIndex = 0
		Me.txtName.Text = ""
		'
		'grpNetPoints
		'
		Me.grpNetPoints.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label7, Me.Label6, Me.cmbMultiNetHigh, Me.cmbNetHigh, Me.cmbMultiNetLow, Me.cmbNetLow, Me.Label3, Me.Label10})
		Me.grpNetPoints.Location = New System.Drawing.Point(16, 120)
		Me.grpNetPoints.Name = "grpNetPoints"
		Me.grpNetPoints.Size = New System.Drawing.Size(304, 72)
		Me.grpNetPoints.TabIndex = 1
		Me.grpNetPoints.TabStop = False
		Me.grpNetPoints.Text = "Net Points"
		'
		'Label7
		'
		Me.Label7.Location = New System.Drawing.Point(176, 40)
		Me.Label7.Name = "Label7"
		Me.Label7.Size = New System.Drawing.Size(24, 16)
		Me.Label7.TabIndex = 3
		Me.Label7.Text = "to"
		Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopCenter
		'
		'Label6
		'
		Me.Label6.Location = New System.Drawing.Point(176, 16)
		Me.Label6.Name = "Label6"
		Me.Label6.Size = New System.Drawing.Size(24, 16)
		Me.Label6.TabIndex = 1
		Me.Label6.Text = "to"
		Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopCenter
		'
		'cmbMultiNetHigh
		'
		Me.cmbMultiNetHigh.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbMultiNetHigh.Location = New System.Drawing.Point(200, 40)
		Me.cmbMultiNetHigh.Name = "cmbMultiNetHigh"
		Me.cmbMultiNetHigh.Size = New System.Drawing.Size(96, 22)
		Me.cmbMultiNetHigh.TabIndex = 83
		'
		'cmbNetHigh
		'
		Me.cmbNetHigh.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbNetHigh.Location = New System.Drawing.Point(200, 16)
		Me.cmbNetHigh.Name = "cmbNetHigh"
		Me.cmbNetHigh.Size = New System.Drawing.Size(96, 22)
		Me.cmbNetHigh.TabIndex = 82
		'
		'cmbMultiNetLow
		'
		Me.cmbMultiNetLow.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbMultiNetLow.Location = New System.Drawing.Point(80, 40)
		Me.cmbMultiNetLow.Name = "cmbMultiNetLow"
		Me.cmbMultiNetLow.Size = New System.Drawing.Size(96, 22)
		Me.cmbMultiNetLow.TabIndex = 2
		'
		'cmbNetLow
		'
		Me.cmbNetLow.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbNetLow.Location = New System.Drawing.Point(80, 16)
		Me.cmbNetLow.Name = "cmbNetLow"
		Me.cmbNetLow.Size = New System.Drawing.Size(96, 22)
		Me.cmbNetLow.TabIndex = 0
		'
		'Label3
		'
		Me.Label3.Location = New System.Drawing.Point(8, 40)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(64, 16)
		Me.Label3.TabIndex = 77
		Me.Label3.Text = "Multi Point:"
		'
		'Label10
		'
		Me.Label10.Location = New System.Drawing.Point(8, 16)
		Me.Label10.Name = "Label10"
		Me.Label10.Size = New System.Drawing.Size(72, 16)
		Me.Label10.TabIndex = 74
		Me.Label10.Text = "Single Point:"
		'
		'lstSituations
		'
		Me.lstSituations.ItemHeight = 14
		Me.lstSituations.Location = New System.Drawing.Point(16, 24)
		Me.lstSituations.Name = "lstSituations"
		Me.lstSituations.Size = New System.Drawing.Size(96, 242)
		Me.lstSituations.TabIndex = 0
		'
		'btnSave
		'
		Me.btnSave.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnSave.Location = New System.Drawing.Point(232, 320)
		Me.btnSave.Name = "btnSave"
		Me.btnSave.Size = New System.Drawing.Size(112, 24)
		Me.btnSave.TabIndex = 0
		Me.btnSave.Text = "&Save"
		'
		'frmSituations
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(470, 355)
		Me.ControlBox = False
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnSave, Me.btnOK, Me.grpFinish})
		Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
		Me.Name = "frmSituations"
		Me.ShowInTaskbar = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.Text = "Situations"
		Me.grpFinish.ResumeLayout(False)
		Me.GroupBox1.ResumeLayout(False)
		Me.GroupBox3.ResumeLayout(False)
		Me.GroupBox2.ResumeLayout(False)
		Me.grpNetPoints.ResumeLayout(False)
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		Me.Close()
	End Sub

#Region "CustomSetup"

	Private Sub SetScreen()
		Call InitializeDefaults()
        Call gs.SetCursor(Me)
        gs.SkinForm(Me)
		Me.lstSituations.SelectedIndex = 1
		Me.lstSituations.SelectedIndex = 0

	End Sub

	Private Sub InitializeDefaults()
		Dim Item As New Situation()
		Me.lstSituations.Items.Clear()
        For Each Item In Sim.SituationSet
            Me.lstSituations.Items.Add(Item)
        Next
        Me.lstSituations.Sorted = True
        Me.lstSituations.SelectedIndex = 0
        mintLastIndex = 0
        Me.btnSave.Enabled = False

        Call LoadScoringCombo(Me.cmbMultiNetHigh)
        Call LoadScoringCombo(Me.cmbMultiNetLow)
        Call LoadScoringCombo(Me.cmbNetHigh)
        Call LoadScoringCombo(Me.cmbNetLow)

    End Sub

    Private Sub LoadScoringCombo(ByVal cmbGeneric As ComboBox)
        Dim Item As New SituationComboItem()
        Dim sls As New SituationComboItemSet
        sls.Load()
        cmbGeneric.DisplayMember = "Display"
        cmbGeneric.ValueMember = "Value"
        For Each Item In sls
            With cmbGeneric
                .Items.Add(Item)
            End With
        Next

    End Sub


#End Region

    Private Sub LoadSituation()
        Dim Item As New Situation()
        Item = CType(Me.lstSituations.SelectedItem, Situation)

        With Item
            mblnLoading = True
            Me.txtName.Text = .Name
            Me.txtAbbr.Text = .Abbreviation

            Me.txtMinuteLeftFrom.Text = .MinuteFrom
            Me.txtMinuteLeftTo.Text = .MinuteTo
            Call SetSelectedCombo(Me.cmbMultiNetHigh, .MultiNetHigh)
            Call SetSelectedCombo(Me.cmbMultiNetLow, .MultiNetLow)
            Call SetSelectedCombo(Me.cmbNetHigh, .NetHigh)
            Call SetSelectedCombo(Me.cmbNetLow, .NetLow)

            If .Half = 1 Then
                Me.cmbHalf.SelectedIndex = 0
            Else
                Me.cmbHalf.SelectedIndex = 1
            End If

            If .IsPenaltyKill Then
                Me.cmbSpecial.SelectedIndex = 2
            ElseIf .IsPowerPlay Then
                Me.cmbSpecial.SelectedIndex = 1
            Else
                Me.cmbSpecial.SelectedIndex = 0
            End If

            mblnLoading = False
        End With

    End Sub

    Private Sub SetSelectedCombo(ByVal cmbGeneric As ComboBox, ByVal intValue As Integer)
        Dim Item As SituationComboItem
        For Each Item In cmbGeneric.Items
            If Item.Value = intValue Then
                cmbGeneric.SelectedItem = Item
                Exit Sub
            End If
        Next
    End Sub

    Private Sub ListBoxChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstSituations.SelectedIndexChanged
        If Not mblnLoading Then
            CheckForSave()
            Call LoadSituation()
            mintLastIndex = Me.lstSituations.SelectedIndex
        End If
    End Sub

    Private Sub CheckForSave()
        If mblnDirty Then
            If MsgBox("Do you wish to save your changes?", MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton1, "ISM") = MsgBoxResult.Yes Then
                Call Save()
                mblnDirty = False
            End If
        End If
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If mblnDirty Then
            Call Save()
            mblnDirty = False
        End If
    End Sub

    Private Sub Save()
        gs.SetCursor(True, Me)
        Dim UpdateItem As New Situation()
        UpdateItem = CType(Me.lstSituations.Items(mintLastIndex), Situation)

        With UpdateItem
            .Abbreviation = Me.txtAbbr.Text
            .BuiltIn = UpdateItem.BuiltIn
            If Me.cmbHalf.SelectedIndex = 0 Then
                .Half = 1
            Else
                .Half = 2
            End If

            If Me.cmbSpecial.SelectedIndex = 0 Then
                .IsPenaltyKill = False
                .IsPowerPlay = False
            ElseIf Me.cmbSpecial.SelectedIndex = 1 Then
                .IsPenaltyKill = False
                .IsPowerPlay = True
            Else
                .IsPenaltyKill = True
                .IsPowerPlay = False
            End If

            .MinuteFrom = Val(Me.txtMinuteLeftFrom.Text)
            .MinuteTo = Val(Me.txtMinuteLeftTo.Text)
            .MultiNetHigh = CType(Me.cmbMultiNetHigh.SelectedItem, SituationComboItem).Value
            .MultiNetLow = CType(Me.cmbMultiNetLow.SelectedItem, SituationComboItem).Value
            .Name = Me.txtName.Text
            .NetHigh = CType(Me.cmbNetHigh.SelectedItem, SituationComboItem).Value
            .NetLow = CType(Me.cmbNetLow.SelectedItem, SituationComboItem).Value
            .SituationID = UpdateItem.SituationID
        End With

        UpdateItem.Update()

        Dim FindItem As Situation
        For Each FindItem In Sim.SituationSet
            If FindItem.SituationID = UpdateItem.SituationID Then
                FindItem = UpdateItem.Clone
            End If
        Next
        Call ReloadList(UpdateItem)
        gs.SetCursor(False, Me)

    End Sub

    Public Sub ReloadList(ByVal UpdateItem As Situation)
        'Reload list...
        Dim Item As New Situation()
        mblnLoading = True
        Me.lstSituations.Items.Clear()
        For Each Item In Sim.SituationSet
            Me.lstSituations.Items.Add(Item)
            If Item.SituationID = UpdateItem.SituationID Then
                Me.lstSituations.SelectedItem = Item
            End If
        Next
        Me.lstSituations.Sorted = True
        Me.btnSave.Enabled = False
        mblnLoading = False

    End Sub


    Private Sub TextDirty(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtAbbr.TextChanged, txtMinuteLeftFrom.TextChanged, txtMinuteLeftTo.TextChanged, txtName.TextChanged
        If Not mblnLoading Then
            mblnDirty = True
            Me.btnSave.Enabled = True
        End If

    End Sub

    Private Sub AddNewSituation()
        Dim Item As New Situation()
        Item.SetDefault(Sim.SituationSet.GetNewID)
        Sim.SituationSet.Add(Item)
        Call ReloadList(Item)
        Me.lstSituations.SelectedItem = Item
        Call LoadSituation()
        mintLastIndex = Me.lstSituations.SelectedIndex
        Me.txtName.Focus()
    End Sub

    'Validation...

    Private Sub txtName_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtName.Leave
        If Not mblnLoading Then
            If Not (vs.IsStringValid(Me.txtName.Text, 1, 30)) Then
                MsgBox("Your name for this situation is either too short or too long.  Please change before saving.")
                Me.txtName.Focus()
            End If
        End If
    End Sub

    Private Sub txtAbbr_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Not mblnLoading Then
            If Not (vs.IsStringValid(Me.txtAbbr.Text, 1, 5)) Then
                MsgBox("Your abbreviation for this situation is either too short or too long.  Please change before saving.")
                Me.txtAbbr.Focus()
            End If
        End If
    End Sub

    Private Sub Minute_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtMinuteLeftFrom.Leave, txtMinuteLeftTo.Leave
        If Not mblnLoading Then
            If Not vs.IsValidNumericRange(Val(Me.txtMinuteLeftFrom.Text), Val(Me.txtMinuteLeftTo.Text), 0, 30) Then
                MsgBox("Your minutes must be between 0 and 30 and your minute from has to be less than your minute to.  Please change before saving.")
                CType(sender, TextBox).Focus()
            End If
        End If
    End Sub

    Private Sub SinglePoints_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbNetLow.Leave, cmbNetHigh.Leave
        If Not mblnLoading Then
            If Not vs.IsValidNumericRange(CType(Me.cmbNetLow.SelectedItem, SituationComboItem).Value, CType(Me.cmbNetHigh.SelectedItem, SituationComboItem).Value) Then
                MsgBox("Your scoring range needs to be from a lower value to a higher value.  Please change before saving.")
                CType(sender, ComboBox).Focus()
            End If
        End If
    End Sub

    Private Sub MultiPoints_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbMultiNetLow.Leave, cmbMultiNetHigh.Leave
        If Not mblnLoading Then
            If Not vs.IsValidNumericRange(CType(Me.cmbMultiNetLow.SelectedItem, SituationComboItem).Value, CType(Me.cmbMultiNetHigh.SelectedItem, SituationComboItem).Value) Then
                MsgBox("Your scoring range needs to be from a lower value to a higher value.  Please change before saving.")
                CType(sender, ComboBox).Focus()
            End If
        End If
    End Sub

    Private Sub btnNewSituation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewSituation.Click
        Call AddNewSituation()
    End Sub
End Class
