'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports System.IO
Imports Microsoft.VisualBasic


Namespace Reporting

	Public Enum ISMReportFormat
		Text = 0
		HTML = 1
		CSV = 2
	End Enum

	Public Class Report
		Inherits CollectionBase

		Public Header As String
		Public Subheader As String
		Public ReportWidth As Integer = 80
		Public Output As String

		Sub Add(ByVal objItem As ReportTable)
			Me.InnerList.Add(objItem)
		End Sub

		Default Public Property Item(ByVal Index As Integer) As ReportTable
			Get
				Return CType(Me.InnerList.Item(Index), ReportTable)
			End Get
			Set(ByVal Value As ReportTable)
				Me.InnerList.Item(Index) = Value
			End Set
		End Property

		Sub Create(ByVal Header As String)
			Dim Item As New ReportTable()
			With Item
				.Header = Header
			End With
			Me.Add(Item)
		End Sub

        Sub Generate(ByVal Format As ReportFormatService)
            Dim objFormatter As ReportFormatService = Format
            With objFormatter
                .Report = Me
                .ReportWidth = Me.ReportWidth
                .Generate()
                Me.Output = .GetOutput
            End With
        End Sub
        Sub Generate()
            Call Generate(New HTMLReportFormatService)
        End Sub

        Public Overridable Sub Save(ByVal Filename As String)
            Dim Writer As StreamWriter = File.CreateText(Filename)
            Writer.Write(Me.Output)
            Writer.Close()
        End Sub

    End Class
End Namespace