'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.Data.OleDb
Imports ISoccerSim.Statistics

Namespace DataServices.AdvancedStats

	Public Class Leaderboard
		Inherits AdvancedStatService


        Overrides Function GetBaseLeagueStat(ByVal SeasonID As Integer) As DataSet
            Dim SQL As String
            Dim DS As DataSet
            Dim Table As DataTable


            SQL = GetBaseLeagueQuery(" AND SeasonID = " & SeasonID)
            DS = Me.GetDataSet(SQL, "Stats")
            Return DS
        End Function


        Overrides Function GetBaseLeagueStatForTeam(ByVal Stat As ISMStat, ByVal TeamID As Integer, ByVal SeasonID As Integer) As DataSet
            Dim SQL As String
            Dim DS As DataSet
            Dim Table As DataTable

            SQL = GetBaseLeagueQuery(" AND t.TeamID = " & TeamID & " AND SeasonID = " & SeasonID)
            DS = Me.GetDataSet(SQL, "Stats")
            Return DS
        End Function

        Overrides Function GetBaseLeagueStatForConference(ByVal Stat As ISMStat, ByVal ConferenceID As Integer, ByVal SeasonID As Integer) As DataSet
            Dim SQL As String
            Dim DS As DataSet
            Dim Table As DataTable

            SQL = GetBaseLeagueQuery(" AND t.ConferenceID = " & ConferenceID & " AND SeasonID = " & SeasonID)
            DS = Me.GetDataSet(SQL, "Stats")
            Return DS
        End Function

        Overrides Function GetBaseLeagueStatForDivision(ByVal Stat As ISMStat, ByVal DivisionID As Integer, ByVal SeasonID As Integer) As DataSet
            Dim SQL As String = GetBaseLeagueQuery(" AND t.DivisionID = " & DivisionID & " AND SeasonID = " & SeasonID)
            Dim DS As DataSet
            Dim Table As DataTable

            DS = Me.GetDataSet(SQL, "Stats")
            Return DS
        End Function


        Overrides Function GetBaseTeamStat(ByVal Stat As ISMStat, ByVal SeasonID As Integer) As DataSet
            Dim SQL As String = GetBaseTeamQuery("AND SeasonID = " & SeasonID)
            Dim DS As DataSet
            Dim Table As DataTable

            DS = Me.GetDataSet(SQL, "Stats")
            Return DS
        End Function

        Overrides Function GetBaseTeamStatForConference(ByVal Stat As ISMStat, ByVal ConferenceID As Integer, ByVal SeasonID As Integer) As DataSet
            Dim SQL As String = GetBaseTeamQuery(" AND t.ConferenceID = " & ConferenceID & " AND SeasonID = " & SeasonID)
            Dim DS As DataSet
            Dim Table As DataTable

            DS = Me.GetDataSet(SQL, "Stats")
            Return DS
        End Function

        Overrides Function GetBaseTeamStatForDivision(ByVal Stat As ISMStat, ByVal DivisionID As Integer, ByVal SeasonID As Integer) As DataSet
            Dim SQL As String = GetBaseTeamQuery(" AND t.DivisionID = " & DivisionID & " AND SeasonID = " & SeasonID)
            Dim DS As DataSet
            Dim Table As DataTable

            DS = Me.GetDataSet(SQL, "Stats")
            Return DS
        End Function

        Private Function GetBaseLeagueQuery(ByVal strWhere As String) As String

            Dim SQLData As String
            SQLData = "TRANSFORM Sum(gs.Value) AS [Value] " & _
                    " SELECT pl.FirstName, t.TeamID, pl.LastName, t.Abbreviation AS Team, Positions.Abbr AS POS, pl.PlayerID " & _
                    " FROM ((Teams AS t INNER JOIN Rosters AS r ON t.TeamID = r.TeamID) INNER JOIN (Statistics AS s INNER JOIN (Players AS pl INNER JOIN GameStats AS gs ON pl.PlayerID = gs.PlayerID) ON s.StatID = gs.StatisticID) ON r.PlayerID = pl.PlayerID) INNER JOIN Positions ON pl.PositionID = Positions.PositionID " & _
                    " WHERE (((s.StatID) = 15 Or (s.StatID) = 2) " & strWhere & ") " & _
                    " GROUP BY pl.FirstName, pl.LastName, t.Abbreviation, Positions.Abbr, pl.PlayerID, t.TeamID " & _
                    " PIVOT s.StatID "

            Me.CreateTempTable(SQLData)
            Return "SELECT * FROM StatTemp ORDER BY [Total] DESC"
        End Function


        Private Function GetBaseTeamQuery(ByVal strWhere As String) As String
            Dim SQLData As String
            SQLData = "TRANSFORM Sum(gs.Value) AS [Value]" & _
            " SELECT t.Name AS Team, t.TeamID, -1 AS PlayerID, '' AS LastName, '' AS FirstName, '' AS POS " & _
            " FROM Teams AS t INNER JOIN (Statistics AS s INNER JOIN GameStats AS gs ON s.StatID = gs.StatisticID) ON t.TeamID = gs.TeamID " & _
            " WHERE (((s.StatID)=15 Or (s.StatID)=2) " & strWhere & ")" & _
            " GROUP BY t.Name, t.TeamID " & _
            " PIVOT s.StatID; "

            Me.CreateTempTable(SQLData)
            Return "SELECT * FROM StatTemp ORDER BY [Total] DESC"
        End Function

        Private Sub CreateTempTable(ByVal SQLData As String)
            Dim SQL As String
            Dim Commands As New ArrayList
            Dim i As Integer

            SQL = "DROP TABLE StatTemp"
            Me.RunCommand(SQL, True)

            SQL = "CREATE TABLE StatTemp (PlayerID integer, PlayerName varchar(50), LastName varchar(50), FirstName varchar (50), " & _
                        "Team varchar(50), TeamID integer, POS varchar(5), [G] integer, [A] integer, [Total] integer)"

            Me.RunCommand(SQL)

            Dim dr As Data.OleDb.OleDbDataReader = Me.GetDataReader(SQLData)

            Do While dr.Read()
                SQL = "INSERT INTO StatTemp(PlayerID, PlayerName, LastName, FirstName, Team, TeamID, [POS], [G], [A], [TOTAL]) VALUES (" & _
                    FormatField(dr.Item("PlayerID"), True, True) & _
                    FormatField(dr.Item("LastName") & ", " & dr.Item("FirstName"), True, True) & _
                    FormatField(dr.Item("LastName"), True, True) & _
                    FormatField(dr.Item("FirstName"), True, True) & _
                    FormatField(dr.Item("Team"), True, True) & _
                    FormatField(dr.Item("TeamID"), False, True) & _
                    FormatField(SafeValue(dr.Item("POS"), False), True, True) & _
                    FormatField(SafeValue(dr.Item("2"), True), False, True) & _
                    FormatField(SafeValue(dr.Item("15"), True), False, True) & _
                    FormatField(SafeValue(dr.Item("2"), True) + SafeValue(dr.Item("15"), True), False, False) & ")"
                Commands.Add(SQL)
            Loop
            dr.Close()

            For i = 0 To Commands.Count - 1
                Me.RunCommand(Commands(i))
            Next
        End Sub


    End Class

End Namespace
