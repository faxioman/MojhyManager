'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Leagues
Imports ISoccerSim.Utility.GUI

Public Class frmMain
	Inherits System.Windows.Forms.Form

    Private WithEvents mobjLeague As New League()
    Dim Sim As Simulation = Simulation.GetInstance()
    Dim gs As GUIService = GuiService.GetInstance

#Region " Windows Form Designer generated code "

    Sub New()

        MyBase.New()
        IsLoading = True

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Call SetScreen()
        IsLoading = False
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Public WithEvents mnuFile As System.Windows.Forms.MenuItem
    Public WithEvents mnuFileExit As System.Windows.Forms.MenuItem
    Public WithEvents mnuMain As System.Windows.Forms.MainMenu
    Public WithEvents stbMain As System.Windows.Forms.StatusBar
    Public WithEvents stbMainPanel As System.Windows.Forms.StatusBarPanel
    Public WithEvents mnuHelp As System.Windows.Forms.MenuItem
    Public WithEvents mnuHelpAbout As System.Windows.Forms.MenuItem
    Public WithEvents tmrFade As System.Windows.Forms.Timer
    Public WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem10 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuLeague As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTeam As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOptions As System.Windows.Forms.MenuItem
    Friend WithEvents mnuLeagueStandings As System.Windows.Forms.MenuItem
    Friend WithEvents mnuLeagueSchedule As System.Windows.Forms.MenuItem
    Friend WithEvents mnuLeagueSettings As System.Windows.Forms.MenuItem
    Friend WithEvents mnuLeagueSituations As System.Windows.Forms.MenuItem
    Friend WithEvents mnuLeagueTactics As System.Windows.Forms.MenuItem
    Friend WithEvents mnuLeagueExhibition As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTeamCoaching As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTeamFinances As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTeamRosters As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTeamSubs As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTeamSettings As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTeamTrades As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOptionsActiveSkin As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOptionsProgram As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOptionsPlayByPlay As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFileNewLeague As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFileOpenLeague As System.Windows.Forms.MenuItem
    Friend WithEvents lblBanner As System.Windows.Forms.Label
    Friend WithEvents tcmbDefaultTeam As TeamCombo
    Friend WithEvents mnuLeagueStatistics As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTeamNews As System.Windows.Forms.MenuItem
    Friend WithEvents picTeamLogo As System.Windows.Forms.PictureBox
    Friend WithEvents lblBannerNoLogo As System.Windows.Forms.Label
    Friend WithEvents lblDefaultTeam As System.Windows.Forms.Label
    Friend WithEvents lblTeamInfo As System.Windows.Forms.Label
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFileExport As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMain))
        Me.mnuMain = New System.Windows.Forms.MainMenu
        Me.mnuFile = New System.Windows.Forms.MenuItem
        Me.mnuFileNewLeague = New System.Windows.Forms.MenuItem
        Me.mnuFileOpenLeague = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.mnuFileExport = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.mnuFileExit = New System.Windows.Forms.MenuItem
        Me.mnuLeague = New System.Windows.Forms.MenuItem
        Me.mnuLeagueStandings = New System.Windows.Forms.MenuItem
        Me.mnuLeagueSchedule = New System.Windows.Forms.MenuItem
        Me.mnuLeagueSettings = New System.Windows.Forms.MenuItem
        Me.mnuLeagueSituations = New System.Windows.Forms.MenuItem
        Me.mnuLeagueStatistics = New System.Windows.Forms.MenuItem
        Me.mnuLeagueTactics = New System.Windows.Forms.MenuItem
        Me.MenuItem10 = New System.Windows.Forms.MenuItem
        Me.mnuLeagueExhibition = New System.Windows.Forms.MenuItem
        Me.mnuTeam = New System.Windows.Forms.MenuItem
        Me.mnuTeamCoaching = New System.Windows.Forms.MenuItem
        Me.mnuTeamNews = New System.Windows.Forms.MenuItem
        Me.mnuTeamFinances = New System.Windows.Forms.MenuItem
        Me.mnuTeamRosters = New System.Windows.Forms.MenuItem
        Me.mnuTeamSubs = New System.Windows.Forms.MenuItem
        Me.mnuTeamSettings = New System.Windows.Forms.MenuItem
        Me.mnuTeamTrades = New System.Windows.Forms.MenuItem
        Me.mnuOptions = New System.Windows.Forms.MenuItem
        Me.mnuOptionsActiveSkin = New System.Windows.Forms.MenuItem
        Me.mnuOptionsProgram = New System.Windows.Forms.MenuItem
        Me.mnuOptionsPlayByPlay = New System.Windows.Forms.MenuItem
        Me.mnuHelp = New System.Windows.Forms.MenuItem
        Me.mnuHelpAbout = New System.Windows.Forms.MenuItem
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.stbMain = New System.Windows.Forms.StatusBar
        Me.stbMainPanel = New System.Windows.Forms.StatusBarPanel
        Me.tmrFade = New System.Windows.Forms.Timer(Me.components)
        Me.lblBanner = New System.Windows.Forms.Label
        Me.tcmbDefaultTeam = New ISM.TeamCombo
        Me.picTeamLogo = New System.Windows.Forms.PictureBox
        Me.lblBannerNoLogo = New System.Windows.Forms.Label
        Me.lblDefaultTeam = New System.Windows.Forms.Label
        Me.lblTeamInfo = New System.Windows.Forms.Label
        CType(Me.stbMainPanel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mnuMain
        '
        Me.mnuMain.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile, Me.mnuLeague, Me.mnuTeam, Me.mnuOptions, Me.mnuHelp})
        '
        'mnuFile
        '
        Me.mnuFile.Index = 0
        Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFileNewLeague, Me.mnuFileOpenLeague, Me.MenuItem5, Me.mnuFileExport, Me.MenuItem2, Me.mnuFileExit})
        Me.mnuFile.Text = "&File"
        '
        'mnuFileNewLeague
        '
        Me.mnuFileNewLeague.Index = 0
        Me.mnuFileNewLeague.Text = "New League"
        '
        'mnuFileOpenLeague
        '
        Me.mnuFileOpenLeague.Index = 1
        Me.mnuFileOpenLeague.Text = "Open League"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 2
        Me.MenuItem5.Text = "-"
        '
        'mnuFileExport
        '
        Me.mnuFileExport.Index = 3
        Me.mnuFileExport.Text = "Import/Export"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 4
        Me.MenuItem2.Text = "-"
        '
        'mnuFileExit
        '
        Me.mnuFileExit.Index = 5
        Me.mnuFileExit.Text = "Exit"
        '
        'mnuLeague
        '
        Me.mnuLeague.Index = 1
        Me.mnuLeague.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuLeagueStandings, Me.mnuLeagueSchedule, Me.mnuLeagueSettings, Me.mnuLeagueSituations, Me.mnuLeagueStatistics, Me.mnuLeagueTactics, Me.MenuItem10, Me.mnuLeagueExhibition})
        Me.mnuLeague.Text = "&League"
        '
        'mnuLeagueStandings
        '
        Me.mnuLeagueStandings.Index = 0
        Me.mnuLeagueStandings.Text = "Standings"
        '
        'mnuLeagueSchedule
        '
        Me.mnuLeagueSchedule.Index = 1
        Me.mnuLeagueSchedule.Text = "Schedule"
        '
        'mnuLeagueSettings
        '
        Me.mnuLeagueSettings.Index = 2
        Me.mnuLeagueSettings.Text = "Settings"
        '
        'mnuLeagueSituations
        '
        Me.mnuLeagueSituations.Index = 3
        Me.mnuLeagueSituations.Text = "Situations"
        '
        'mnuLeagueStatistics
        '
        Me.mnuLeagueStatistics.Index = 4
        Me.mnuLeagueStatistics.Text = "Statistics"
        '
        'mnuLeagueTactics
        '
        Me.mnuLeagueTactics.Index = 5
        Me.mnuLeagueTactics.Text = "Tactics"
        '
        'MenuItem10
        '
        Me.MenuItem10.Index = 6
        Me.MenuItem10.Text = "-"
        '
        'mnuLeagueExhibition
        '
        Me.mnuLeagueExhibition.Index = 7
        Me.mnuLeagueExhibition.Text = "Exhibition"
        '
        'mnuTeam
        '
        Me.mnuTeam.Index = 2
        Me.mnuTeam.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuTeamCoaching, Me.mnuTeamNews, Me.mnuTeamFinances, Me.mnuTeamRosters, Me.mnuTeamSubs, Me.mnuTeamSettings, Me.mnuTeamTrades})
        Me.mnuTeam.Text = "&Team"
        '
        'mnuTeamCoaching
        '
        Me.mnuTeamCoaching.Index = 0
        Me.mnuTeamCoaching.Text = "Coaching"
        '
        'mnuTeamNews
        '
        Me.mnuTeamNews.Index = 1
        Me.mnuTeamNews.Text = "Email"
        '
        'mnuTeamFinances
        '
        Me.mnuTeamFinances.Index = 2
        Me.mnuTeamFinances.Text = "Finances"
        '
        'mnuTeamRosters
        '
        Me.mnuTeamRosters.Index = 3
        Me.mnuTeamRosters.Text = "Rosters"
        '
        'mnuTeamSubs
        '
        Me.mnuTeamSubs.Index = 4
        Me.mnuTeamSubs.Text = "Subs"
        '
        'mnuTeamSettings
        '
        Me.mnuTeamSettings.Index = 5
        Me.mnuTeamSettings.Text = "Settings"
        '
        'mnuTeamTrades
        '
        Me.mnuTeamTrades.Index = 6
        Me.mnuTeamTrades.Text = "Trades"
        '
        'mnuOptions
        '
        Me.mnuOptions.Index = 3
        Me.mnuOptions.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuOptionsActiveSkin, Me.mnuOptionsProgram, Me.mnuOptionsPlayByPlay})
        Me.mnuOptions.Text = "&Options"
        '
        'mnuOptionsActiveSkin
        '
        Me.mnuOptionsActiveSkin.Index = 0
        Me.mnuOptionsActiveSkin.Text = "Active Skin"
        '
        'mnuOptionsProgram
        '
        Me.mnuOptionsProgram.Index = 1
        Me.mnuOptionsProgram.Text = "Defaults"
        '
        'mnuOptionsPlayByPlay
        '
        Me.mnuOptionsPlayByPlay.Index = 2
        Me.mnuOptionsPlayByPlay.Text = "Play By Play"
        '
        'mnuHelp
        '
        Me.mnuHelp.Index = 4
        Me.mnuHelp.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuHelpAbout, Me.MenuItem1})
        Me.mnuHelp.Text = "&Help"
        '
        'mnuHelpAbout
        '
        Me.mnuHelpAbout.Index = 0
        Me.mnuHelpAbout.Text = "About"
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 1
        Me.MenuItem1.Text = "Quick Test"
        '
        'stbMain
        '
        Me.stbMain.Location = New System.Drawing.Point(0, 483)
        Me.stbMain.Name = "stbMain"
        Me.stbMain.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.stbMainPanel})
        Me.stbMain.Size = New System.Drawing.Size(664, 22)
        Me.stbMain.TabIndex = 1
        '
        'stbMainPanel
        '
        Me.stbMainPanel.Text = "Ready"
        '
        'tmrFade
        '
        Me.tmrFade.Interval = 10
        '
        'lblBanner
        '
        Me.lblBanner.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblBanner.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBanner.Location = New System.Drawing.Point(104, 376)
        Me.lblBanner.Name = "lblBanner"
        Me.lblBanner.Size = New System.Drawing.Size(560, 104)
        Me.lblBanner.TabIndex = 2
        '
        'tcmbDefaultTeam
        '
        Me.tcmbDefaultTeam.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tcmbDefaultTeam.Location = New System.Drawing.Point(392, 456)
        Me.tcmbDefaultTeam.Name = "tcmbDefaultTeam"
        Me.tcmbDefaultTeam.Size = New System.Drawing.Size(272, 24)
        Me.tcmbDefaultTeam.TabIndex = 3
        Me.tcmbDefaultTeam.TeamID = -1
        '
        'picTeamLogo
        '
        Me.picTeamLogo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picTeamLogo.Location = New System.Drawing.Point(0, 376)
        Me.picTeamLogo.Name = "picTeamLogo"
        Me.picTeamLogo.Size = New System.Drawing.Size(104, 104)
        Me.picTeamLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picTeamLogo.TabIndex = 4
        Me.picTeamLogo.TabStop = False
        '
        'lblBannerNoLogo
        '
        Me.lblBannerNoLogo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblBannerNoLogo.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBannerNoLogo.Location = New System.Drawing.Point(0, 376)
        Me.lblBannerNoLogo.Name = "lblBannerNoLogo"
        Me.lblBannerNoLogo.Size = New System.Drawing.Size(128, 104)
        Me.lblBannerNoLogo.TabIndex = 5
        '
        'lblDefaultTeam
        '
        Me.lblDefaultTeam.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblDefaultTeam.Location = New System.Drawing.Point(392, 440)
        Me.lblDefaultTeam.Name = "lblDefaultTeam"
        Me.lblDefaultTeam.Size = New System.Drawing.Size(264, 23)
        Me.lblDefaultTeam.TabIndex = 6
        Me.lblDefaultTeam.Text = "Select a default team:"
        '
        'lblTeamInfo
        '
        Me.lblTeamInfo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblTeamInfo.Location = New System.Drawing.Point(104, 408)
        Me.lblTeamInfo.Name = "lblTeamInfo"
        Me.lblTeamInfo.Size = New System.Drawing.Size(264, 64)
        Me.lblTeamInfo.TabIndex = 7
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(664, 505)
        Me.Controls.Add(Me.lblTeamInfo)
        Me.Controls.Add(Me.tcmbDefaultTeam)
        Me.Controls.Add(Me.lblDefaultTeam)
        Me.Controls.Add(Me.picTeamLogo)
        Me.Controls.Add(Me.lblBanner)
        Me.Controls.Add(Me.stbMain)
        Me.Controls.Add(Me.lblBannerNoLogo)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Menu = Me.mnuMain
        Me.Name = "frmMain"
        Me.Text = "[Indoor Soccer Manager]"
        CType(Me.stbMainPanel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private IsLoading As Boolean

    Private Sub SetScreen()
        If Me.WindowState = FormWindowState.Normal Then
            Me.WindowState = FormWindowState.Maximized
        End If
        IsLoading = True
        mobjLeague = Sim.League
        If Sim.League.Name <> "" Then
            Me.stbMain.Text = Sim.League.Name & "loaded."
            Me.tcmbDefaultTeam.LoadTeams(Sim.League.DefaultTeamID)
            Me.tcmbDefaultTeam.Visible = True
            Call LoadTeamInfo(Sim.League.DefaultTeamID)
            Me.lblDefaultTeam.Text = "Default Team:"
        Else
            Me.stbMain.Text = "No league loaded."
            Me.lblDefaultTeam.Text = ""
            Me.tcmbDefaultTeam.Visible = False
        End If
        Call SetMenuStatus()
        Call gs.SkinForm(Me)
        Call gs.SetCursor(Me)
        If Sim.UserSettings.ShowGuideAtStartup Then ShowGuide()
        IsLoading = False
    End Sub

    Private Sub ShowGuide()
        Dim objGuide As New ProgramGuideService(ISMGuideServiceContext.MainMenu)
        Dim frmGuide As New frmGuide(objGuide)
        frmGuide.Left = 0    'Me.Width - frmGuide.Width - 10
        frmGuide.Top = 0    'Me.Height - frmGuide.Height - 10
        frmGuide.Owner = Me
        frmGuide.Show()
    End Sub

    Private Sub frmMain_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Dim mBaseTable As New DataServices.BaseTables()
        Sim.League.UpdateDefaultTeamID()
        mBaseTable.Close()
    End Sub

    Private Sub mobjLeague_Loaded(ByVal sender As Object, ByVal e As ISoccerSim.Leagues.LeagueLoadedEventArgs) Handles mobjLeague.Loaded
        Call RefreshStatusText()
    End Sub

    Sub RefreshStatusText()
        If Sim Is Nothing Then
            Me.stbMain.Text = "No league loaded."
        ElseIf Sim.League.Name = "" Then
            Me.stbMain.Text = "No league loaded."
        Else
            Me.stbMain.Text = Sim.League.Name & " loaded."
            mobjLeague = Sim.League
        End If

    End Sub


    Private Sub frmMain_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        Call RefreshStatusText()
    End Sub

    Private Sub OpenForm(ByVal f As Form)
        Try
            gs.SkinForm(f)
            f.ShowDialog(Me.ParentForm)
            Call Me.LoadTeamInfo(Me.tcmbDefaultTeam.TeamID)
            Me.Refresh()
        Catch ex As Exception
            Call HandleException(Me, ex)
        Finally
            Call SetMenuStatus()
        End Try
    End Sub

    Private Sub SetMenuStatus()
        Dim ShowLeagueItems As Boolean
        Select Case Sim.GetSimState
            Case Sim.ISM_SIM_State.Empty
                ShowLeagueItems = False

            Case Sim.ISM_SIM_State.LeagueLoaded
                ShowLeagueItems = True
        End Select

        Me.mnuLeague.Enabled = ShowLeagueItems
        Me.mnuTeam.Enabled = ShowLeagueItems
        'Me.mnuFileSaveLeague.Enabled = ShowLeagueItems
        Me.mnuOptionsPlayByPlay.Enabled = ShowLeagueItems
    End Sub

    Private Sub mnuHelpAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuHelpAbout.Click
        Dim f As New frmAbout
        Call OpenForm(f)
    End Sub

    Private Sub mnuFileOpenLeague_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileOpenLeague.Click
        Dim f As New frmOpenLeague
        Call OpenForm(f)
        Me.tcmbDefaultTeam.LoadTeams(Sim.League.DefaultTeamID)
        Me.tcmbDefaultTeam.Visible = True
        Call LoadTeamInfo(Me.tcmbDefaultTeam.TeamID)
    End Sub

    Private Sub mnuFileNewLeague_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileNewLeague.Click
        Dim f As New frmLeagueWizard
        Call OpenForm(f)
        Me.tcmbDefaultTeam.LoadTeams(Sim.League.DefaultTeamID)
        Me.tcmbDefaultTeam.Visible = True
    End Sub

    Private Sub mnuFileExit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuFileExit.Click
        Me.Close()
    End Sub

    Private Sub mnuLeagueStandings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuLeagueStandings.Click
        Dim f As New frmStandings
        Call OpenForm(f)
    End Sub

    Private Sub mnuLeagueSchedule_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuLeagueSchedule.Click
        Dim f As New frmLeagueSchedule
        Call OpenForm(f)
    End Sub

    Private Sub mnuLeagueSettings_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuLeagueSettings.Click
        Dim f As New frmLeagueSettings
        Call OpenForm(f)
    End Sub

    Private Sub mnuLeagueSituations_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuLeagueSituations.Click
        Dim f As New frmSituations
        Call OpenForm(f)
    End Sub

    Private Sub mnuLeagueTactics_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuLeagueTactics.Click
        Dim f As New frmTactics
        Call OpenForm(f)
    End Sub

    Private Sub mnuLeagueExhibition_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuLeagueExhibition.Click
        Dim f As New frmLeagueExhibition
        Call OpenForm(f)
    End Sub

    Private Sub mnuTeamCoaching_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuTeamCoaching.Click
        Dim f As New frmTeamCoaching
        Call OpenForm(f)
    End Sub


    Private Sub mnuTeamFinances_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuTeamFinances.Click
        Dim f As New frmTeamFinance
        Call OpenForm(f)
    End Sub


    Private Sub mnuTeamRosters_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuTeamRosters.Click
        Dim f As New frmTeamRoster
        Call OpenForm(f)
    End Sub


    Private Sub mnuTeamSubs_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuTeamSubs.Click
        Dim f As New frmTeamSublines
        Call OpenForm(f)
    End Sub

    Private Sub mnuTeamSettings_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuTeamSettings.Click
        Dim f As New frmTeamSettings
        Call OpenForm(f)
        Me.tcmbDefaultTeam.LoadTeams(Sim.League.DefaultTeamID)
        Me.tcmbDefaultTeam.Visible = True
    End Sub

    Private Sub mnuTeamTrades_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuTeamTrades.Click
        Dim f As New frmTeamTrade
        Call OpenForm(f)
    End Sub

    Private Sub mnuOptionsActiveSkin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuOptionsActiveSkin.Click
        Dim f As New frmOpenSkin
        Call OpenForm(f)
    End Sub


    Private Sub mnuOptionsProgram_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuOptionsProgram.Click
        Dim f As New frmProgramOptions
        Call OpenForm(f)
    End Sub

    Private Sub mnuOptionsPlayByPlay_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuOptionsPlayByPlay.Click
        Dim f As New frmPBP
        Call OpenForm(f)
    End Sub

    Private Sub mnuLeagueStatistics_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuLeagueStatistics.Click
        Dim f As New frmLeagueStats
        Call OpenForm(f)
    End Sub

    Private Sub LoadTeamInfo(ByVal TeamID As Integer)
        Dim TeamName As String
        Dim CurrentRecord As String
        Dim NextOpponent As String
        Dim ScoringRank As String
        Dim UnreadEmails As Integer
        Dim UnreadMsg As String

        Dim photo As PhotoService = PhotoService.GetInstance
        Dim math As MathService = MathService.GetInstance
        Dim ds As New DataServices.BaseTables

        Sim = Simulation.GetInstance()
        Sim.League.DefaultTeamID = IIf(TeamID = 0, 1, TeamID)
        Sim.League.Standings.Load()
        Sim.League.Schedule.Load()

        If TeamID > 0 Then
            TeamName = tcmbDefaultTeam.SelectedTeam.Name & " " & tcmbDefaultTeam.SelectedTeam.Nickname
            NextOpponent = Sim.League.Schedule.GetNextOpponentDateLocation(TeamID, Sim.League.Schedule.GetCurrentDate.AddDays(-1)) & _
                           Sim.League.GetTeamByID(Sim.League.Schedule.GetNextOpponent(TeamID, Sim.League.Schedule.GetCurrentDate.AddDays(-1))).Name & " on " & _
                           Sim.League.Schedule.GetNextOpponentDate(TeamID, Sim.League.Schedule.GetCurrentDate.AddDays(-1))
            CurrentRecord = Sim.League.Standings.GetWins(TeamID, Schedules.Standings.enuPhase.Season, 0) & " - " & _
                            Sim.League.Standings.GetLosses(TeamID, Schedules.Standings.enuPhase.Season, 0)
            ScoringRank = math.GetOrdinal(Sim.League.Standings.GetPointsForRank(TeamID)) & "/" & _
                          math.GetOrdinal(Sim.League.Standings.GetPointsAgainstRank(TeamID))
            UnreadEmails = ds.GetUnreadEmails(TeamID)

            If Not Sim.League.GetTeamByID(TeamID).IsCPUOwned Then
                If UnreadEmails = 0 Then
                    UnreadMsg = "No new messages."
                Else
                    UnreadMsg = math.GetPlural(UnreadEmails, "unread message")
                End If
            End If

            If Sim.League.Standings.GetFirstGameOfSeason = Sim.League.Standings.GetCurrentDate Then
                ScoringRank = "- / -"
            End If

            Me.lblBanner.Text = TeamName
            Dim Filename As String = photo.GetTeamPicture(TeamName)
            If Filename = "" Then
                Me.picTeamLogo.Visible = False
                Me.lblBannerNoLogo.Visible = True
            Else
                Me.picTeamLogo.Visible = True
                Me.lblBannerNoLogo.Visible = False
                Me.picTeamLogo.Image = Image.FromFile(Filename)
            End If
            Me.lblTeamInfo.Text = "Current Record: " & CurrentRecord & vbCrLf & _
                                  "Next Opponent: " & NextOpponent & vbCrLf & _
                                  "Scoring Rank: " & ScoringRank & vbCrLf & _
                                  UnreadMsg
        End If
    End Sub

    Private Sub tcmbDefaultTeam_SelectionChanged(ByVal sender As Object, ByVal e As TeamSelectedEventArgs) Handles tcmbDefaultTeam.SelectionChanged
        Call LoadTeamInfo(e.TeamID)
        Sim.League.DefaultTeamID = e.TeamID
        Sim.League.UpdateDefaultTeamID()
    End Sub

    Private Sub mnuTeamNews_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuTeamNews.Click
        Dim f As New frmTeamEmail
        Call OpenForm(f)

    End Sub

    Private Sub mnuFileExport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileExport.Click
        Dim f As New frmDataExchange
        Call OpenForm(f)
    End Sub

    Private Sub MenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem1.Click
        Dim Sim As Simulation = Simulation.GetInstance
        Call Sim.LoadGlobalAppSettings(False)
        Call Sim.LoadDefaultLeague()

        'Dim r As New ISoccerSim.Multiplayer.ExportManager(1)
        'r.Export()

        Dim r As New ISoccerSim.Multiplayer.ImportManager
        r.Import("C:\code\ISM\bin\leagues\My Soccer League\remote\")
        MsgBox("Done")
    End Sub
End Class
