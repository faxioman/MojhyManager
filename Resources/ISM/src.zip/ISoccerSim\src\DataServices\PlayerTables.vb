
'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
Imports System.Data.OleDb
Imports ISoccerSim.Ratings
Imports ISoccerSim.Players

Namespace DataServices

	Public Class PlayerTables
		Inherits DataServices.DataService

		Function InsertReferee(ByVal objRef As Referee) As Integer
			Dim SQL As String
			With objRef
				SQL = "INSERT INTO Referees (FirstName, LastName, Age, HomeTown, Knowledge, Vision, Respect)" & _
				 "VALUES (" & _
				FormatField(.FirstName, True, True) & _
				FormatField(.LastName, True, True) & _
				FormatField(.Age, False, True) & _
				FormatField(.Hometown, True, True) & _
				FormatField(.Knowledge, False, True) & _
				FormatField(.Vision, False, True) & _
				FormatField(.Respect, False, False) & ")"

			End With

			RunCommand(SQL)
			Return GetID("Referees", "RefereeID")

		End Function

		Function InsertPlayer(ByVal objPlayer As Player) As Integer

			Dim SQL As String
			With objPlayer
                SQL = "INSERT INTO Players (FirstName, LastName, Jersey, " & _
                "HighSchool, College, Hometown, Age, StarPlayer, PositionID)" & _
                 "VALUES (" & _
                 FormatField(.FirstName, True, True) & _
                 FormatField(.LastName, True, True) & _
                FormatField(.Jersey, False, True) & _
                FormatField(.HighSchool, True, True) & _
                FormatField(.College, True, True) & _
                FormatField(.Hometown, True, True) & _
                FormatField(.Age, False, True) & _
                FormatField(.StarPlayer, False, True) & _
                FormatField(.Position, False, False) & ")"
			End With

			RunCommand(SQL)
			Return GetID("Players", "PlayerID")

        End Function

        Function InsertPlayerAttribute(ByVal objPlayerAttrib As PlayerAttribute) As Integer
            Dim SQL As String
            With objPlayerAttrib
                SQL = "INSERT INTO PlayerAttributes " & _
                "(PlayerID, ACT_DUR, ACT_DEF, ACT_END, ACT_GK, ACT_MOB, ACT_PAS, ACT_AGR," & _
                "ACT_SHO, ACT_DRI, ACT_TAC, ACT_FK, ACT_DET, ACT_INF, ACT_PSN, POT_DUR, " & _
                "POT_DEF, POT_END, POT_GK, POT_MOB, POT_PAS, POT_AGR, POT_SHO, POT_DRI, " & _
                "POT_TAC, POT_FK, POT_DET, POT_INF, POT_PSN)" & _
                 "VALUES ("
                SQL = SQL & FormatField(.PlayerID, False, True) & _
                FormatField(.ACT_DUR, False, True) & FormatField(.ACT_DEF, False, True) & _
                FormatField(.ACT_END, False, True) & FormatField(.ACT_GK, False, True) & _
                FormatField(.ACT_MOB, False, True) & FormatField(.ACT_PAS, False, True) & _
                FormatField(.ACT_AGR, False, True) & FormatField(.ACT_SHO, False, True) & _
                FormatField(.ACT_DRI, False, True) & FormatField(.ACT_TAC, False, True) & _
                FormatField(.ACT_FK, False, True) & FormatField(.ACT_DET, False, True) & _
                FormatField(.ACT_INF, False, True) & FormatField(.ACT_PSN, False, True)
                SQL = SQL & FormatField(.POT_DUR, False, True) & FormatField(.POT_DEF, False, True) & _
                FormatField(.POT_END, False, True) & FormatField(.POT_GK, False, True) & _
                FormatField(.POT_MOB, False, True) & FormatField(.POT_PAS, False, True) & _
                FormatField(.POT_AGR, False, True) & FormatField(.POT_SHO, False, True) & _
                FormatField(.POT_DRI, False, True) & FormatField(.POT_TAC, False, True) & _
                FormatField(.POT_FK, False, True) & FormatField(.POT_DET, False, True) & _
                FormatField(.POT_INF, False, True) & FormatField(.POT_PSN, False, False)
                SQL = SQL & ")"
            End With
            RunCommand(SQL)
            Return GetID("PlayerAttributes", "PlayerAttributeID")
        End Function

        Function InsertPlayerEvent(ByVal PlayerEvent As PlayerEvent) As Integer
            Dim SQL As String
            With PlayerEvent
                SQL = "INSERT INTO PlayerEvents (PlayerID, Description, EventDate) VALUES ( " & _
                FormatField(.PlayerID, False, True) & _
                FormatField(.Description, True, True) & _
                FormatField(.EventDate, True, False) & ")"
            End With
            RunCommand(SQL)
            Return GetID("PlayerEvents", "PlayerEventID")
        End Function

        Function GetPlayerCardRatings(ByVal intPlayerID As Integer) As DataSet
            Dim SQL As String
            Dim Where As String
            Dim ds As New DataSet
            Dim dr As OleDbDataReader = Me.GetPlayerAttributesForPlayerCard(intPlayerID)
            Dim dt As New DataTable("Player Ratings")
            Dim pa As New PlayerAttribute

            dt.Columns.Add("PlayerID", System.Type.GetType("System.Int16"))
            dt.Columns.Add("PositionID", System.Type.GetType("System.Int16"))
            dt.Columns.Add("RatingID", System.Type.GetType("System.Int16"))
            dt.Columns.Add("Name", System.Type.GetType("System.String"))
            dt.Columns.Add("0", System.Type.GetType("System.Int16"))
            dt.Columns.Add("128", System.Type.GetType("System.Int16"))
            dt.Columns.Add("Grade", System.Type.GetType("System.String"))
            dt.Columns.Add("Graph", System.Type.GetType("System.String"))

            Do While dr.Read
                Dim i As Integer
                Dim o(7) As Object

                For i = 1 To 14
                    o(0) = intPlayerID
                    o(1) = dr.Item("PositionID")
                    o(2) = i
                    o(3) = pa.GetRatingName(i)
                    o(4) = dr.Item(pa.GetDBColumnName(i, ISS_RatingType.Actual))
                    o(5) = dr.Item(pa.GetDBColumnName(i, ISS_RatingType.Potential))
                    o(6) = ""
                    o(7) = ""
                    dt.Rows.Add(o)
                Next
            Loop
            dr.Close()
            ds.Tables.Add(dt)
            ds = Me.AddPlayerCardGradeToRatings(ds)

            Return ds

        End Function

        Function AddPlayerCardGradeToRatings(ByVal ds As DataSet) As DataSet
            Dim rs As New RatingDistributionSet
            Dim rsd As RatingDistribution
            Dim i As Integer
            Dim PositionID As Integer
            Dim RatingID As Integer
            Dim Rating As Integer
            Dim Grade As String

            rs.Load()
            For i = 0 To ds.Tables(0).Rows.Count - 1
                If i = 0 Then
                    PositionID = ds.Tables(0).Rows(i).Item("PositionID")
                    RatingID = ds.Tables(0).Rows(i).Item("RatingID")
                End If
                Rating = ds.Tables(0).Rows(i).Item("0")
                rsd = rs.GetRatingDistribution(PositionID, RatingID)
                Grade = rsd.GetRatingGrade(Rating)
                ds.Tables(0).Rows(i).Item("Grade") = Grade
            Next
            Return ds
        End Function

        Function GetPlayer(ByVal intPlayerID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT p.*, t.Name " & _
                                " FROM Teams AS t RIGHT JOIN (pLAYERS AS p LEFT JOIN Rosters AS r ON p.PlayerID = r.PlayerID) ON t.TeamID = r.TeamID " & _
                                " WHERE p.PlayerID=" & intPlayerID
            Return GetDataReader(SQL)
        End Function

        Function GetReferee(ByVal intRefereeID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT * FROM Referees Where RefereeID=" & intRefereeID
            Return GetDataReader(SQL)
        End Function

        Function GetReferees() As OleDbDataReader
            Dim SQL As String = "SELECT * FROM Referees"
            Return GetDataReader(SQL)
        End Function

        Function GetPlayerRatings(ByVal intPlayerID As Integer) As OleDbDataReader
            Dim SQL As String = _
             "SELECT * FROM PlayerRatings WHERE PlayerID= " & intPlayerID
            Return GetDataReader(SQL)
        End Function

        Function GetPlayerAttributes(ByVal intPlayerID As Integer) As OleDbDataReader
            Dim SQL As String = _
             "SELECT * FROM PlayerAttributes WHERE PlayerID= " & intPlayerID
            Return GetDataReader(SQL)
        End Function

        Function GetPlayerAttributesForPlayerCard(ByVal intPlayerID As Integer) As OleDbDataReader
            Dim SQL As String = _
             "SELECT pl.PlayerID, pl.PositionID, pa.* FROM PlayerAttributes pa INNER JOIN Players pl ON pa.PlayerID = pl.PlayerID WHERE pl.PlayerID= " & intPlayerID
            Return GetDataReader(SQL)
        End Function


        Sub UpdatePlayerCard(ByVal objPlayer As Player)
            Dim SQL As String
            With objPlayer
                SQL = "UPDATE Players SET " & _
                " LastName = " & FormatField(objPlayer.LastName, True, True) & _
                " FirstName = " & FormatField(objPlayer.FirstName, True, True) & _
                " Hometown = " & FormatField(objPlayer.Hometown, True, True) & _
                " College = " & FormatField(objPlayer.College, True, True) & _
                " HighSchool = " & FormatField(objPlayer.HighSchool, True, True) & _
                " Jersey = " & FormatField(objPlayer.Jersey, False, True) & _
                " Age = " & FormatField(objPlayer.Age, False, False) & _
                 " WHERE PlayerID = " & objPlayer.ID
            End With

            RunCommand(SQL)
        End Sub

        Function GetPlayerEvents(ByVal intPlayerID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT * FROM PlayerEvents WHERE PlayerID = " & intPlayerID & " ORDER BY EventDate ASC"
            Return GetDataReader(SQL)
        End Function

    End Class
End Namespace