'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Ratings
Imports ISoccerSim.Positions
Imports ISoccerSim.Statistics


Namespace Players

	Public Class Player
		Inherits Person
		Implements IComparable

        Public Jersey As Byte
        Public College As String
        Public HighSchool As String
        Public Position As ISMPlayerPosition
        Public Foot As ISMPlayerFavors
        Public BuildWeak As Boolean
        Public Ratings As New PlayerAttribute
        Public GamePosition As ISoccerSim.SimEngine.ISMGamePosition
        Public Stats As New StatSet()
        Public StarPlayer As Integer

        Public CurrentEnergy As Integer = 100
        Public Health As Integer = 0
        Public FoulsPerHalf As Integer
        Public TimePenaltyFoulsInGame As Integer
        Public TimePenaltySet As New SimEngine.Penalty.TimePenaltySet

        Dim Sim As Simulation = Simulation.GetInstance()
        Dim r As MathService = MathService.GetInstance

        Dim CurrentTeam As String

        Public Enum ISMPlayerFavors
            RightFoot = 0
            LeftFoot = 1
            BothFeet = 2
        End Enum


        Sub CreateByPosition(ByVal PositionID As ISMPlayerPosition, ByVal x As Integer)
            MyBase.Create()
            Call SetJersey(x)
            If Me.Age > 21 Then
                Me.College = Sim.Colleges.GetRandomItem.Value
            Else
                Me.College = "None"
            End If

            Dim y As Integer = r.RandomNumber(1, 10)
            Select Case y
                Case 1 To 5
                    Me.HighSchool = Me.Hometown
                Case 6 To 7
                    Me.HighSchool = Sim.LastNames.GetRandomItem.Value
                Case 8 To 9
                    Me.HighSchool = Sim.FirstNames.GetRandomItem.Value & " " & Sim.LastNames.GetRandomItem.Value
                Case 10
                    Me.HighSchool = Sim.LastNames.GetRandomItem.Value & " " & Sim.LastNames.GetRandomItem.Value
            End Select
            Me.HighSchool = Me.HighSchool & " H.S."

            If r.RandomNumber(1, 10) < 8 Then
                Me.Foot = ISMPlayerFavors.RightFoot
            Else
                Me.Foot = ISMPlayerFavors.LeftFoot
            End If

            Me.Position = PositionID
            Me.Insert()

            'Set up player specific random details...
            'Pick up weak players if asked for by base class...
            Dim RateSet As New PlayerAttribute
            Dim Age As New PlayerAge
            Age = Sim.PlayerAgeSet.GetRandomItemByProbability

            Dim Skill As New PlayerSkillLevel
            If Me.BuildWeak Then
                Skill = Sim.PlayerSkillSet.Item(0)
            Else
                Skill = Sim.PlayerSkillSet.GetRandomItemByProbability
            End If
            Call SetStarPlayer(Skill)
            Me.Ratings = RateSet.CreateAttributeSet(Me, Age, Skill)

        End Sub

        Public Sub SetStarPlayer(ByVal objSkill As PlayerSkillLevel)
            Select Case objSkill.PlayerSkillID
                Case 1
                    Me.StarPlayer = 3
                Case 2
                    Me.StarPlayer = 2
                Case 3
                    Me.StarPlayer = 1
                Case Else
                    Me.StarPlayer = 0
            End Select
        End Sub

        Shadows Sub Create(ByVal x As Integer)

            MyBase.Create()
            Me.Position = Sim.PositionSet.GetRandomStockPositionByProbability.PositionID
            Call Me.CreateByPosition(Me.Position, x)

        End Sub

        Sub Insert()
            Dim Data As New DataServices.PlayerTables
            Me.ID = Data.InsertPlayer(Me)
            Data.Close()
        End Sub

        Sub Save()
            Dim Data As New DataServices.PlayerTables
            Data.InsertPlayer(Me)
            Data.Close()
        End Sub

        Sub Load(ByVal intPlayerID As Integer)
            Me.ID = intPlayerID
            Me.Load()
        End Sub

        Sub Update()
            Dim Data As New DataServices.PlayerTables
            Data.UpdatePlayerCard(Me)
        End Sub

        Sub Load()
            Dim Data As New DataServices.PlayerTables
            Dim DR As OleDb.OleDbDataReader = Data.GetPlayer(Me.ID)
            Dim Pos As New Position

            Do While DR.Read()
                With DR
                    Me.LastName = .Item("LastName")
                    Me.Age = .Item("Age")
                    Me.College = .Item("College") & ""
                    Me.FirstName = .Item("FirstName")
                    Me.HighSchool = .Item("HighSchool") & ""
                    Me.Jersey = .Item("Jersey")
                    Me.Position = .Item("PositionID")
                    Me.Hometown = .Item("Hometown") & ""
                    Me.StarPlayer = .Item("starPlayer")
                    Me.CurrentTeam = .Item("Name")
                End With
            Loop
            DR.Close()
            Data.Close()

            Me.Ratings.Load(Me.ID)


        End Sub

        Overrides Function DisplayName()
            Dim Out As New System.Text.StringBuilder(64)
            With Out
                .Append("#")
                .Append(Me.Jersey)
                .Append(" ")
                .Append(Me.LastName)

                If Me.FirstName <> "" Then
                    .Append(", ")
                    .Append(Me.FirstName)
                End If
                .Append(" (")
                .Append(Me.GetPositionText())
                .Append(")")
            End With

            Return Out.ToString
        End Function

        Function ShortName()
            If Me.FirstName <> "" Then
                Return Me.FirstName.Chars(0) & ". " & Me.LastName
            Else
                Return Me.LastName
            End If
        End Function

        Private Function GetPositionText() As String
            Select Case Me.Position
                Case ISMPlayerPosition.Defenseman
                    Return "DF"
                Case ISMPlayerPosition.Forward
                    Return "FW"
                Case ISMPlayerPosition.Goalie
                    Return "GK"
                Case ISMPlayerPosition.Midfielder
                    Return "MF"
            End Select
        End Function

        Public Property DisplayMember() As String
            Get
                Return Me.DisplayName
            End Get
            Set(ByVal Value As String)

            End Set
        End Property

        Public Property ValueMember() As Integer
            Get
                Return Me.ID
            End Get
            Set(ByVal Value As Integer)

            End Set
        End Property

        Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
            If obj Is Nothing Then Return 1

            Dim other As Player = CType(obj, Player)
            Return StrComp(Me.LastName & " " & Me.FirstName, other.LastName & " " & other.FirstName, CompareMethod.Text)
        End Function

        Private Sub SetJersey(ByVal x As Integer)
            If x = 0 Then
                Me.Jersey = 0
            Else
                Me.Jersey = r.RandomNumber((x - 1) * 5, ((x - 1) * 5) + 4)
            End If

        End Sub

        Public Overrides Function ToString() As String
            Return Me.DisplayName
        End Function

        Public Function TooManyTimeFoulsInGame() As Boolean
            Return IIf(Me.TimePenaltyFoulsInGame >= 3, True, False)
        End Function

        Public Function IsFourFoulsPerHalf() As Boolean
            Select Case Me.FoulsPerHalf
                Case 4, 8, 12, 16, 20, 24, 28, 32
                    Return True
                Case Else
                    Return False
            End Select
        End Function

        Sub Fatigue()

            If Me.Health = 0 Then
                If r.RandomNumber(0, 105) >= Me.Ratings.Item(ISS_Rating.Endurance) Then
                    Select Case Me.Position
                        Case ISMPlayerPosition.Goalie
                            If r.RandomNumber(0, 100) > 50 Then
                                ProcessFatigue()
                            End If
                        Case Else
                            ProcessFatigue()
                    End Select
                End If
            End If


        End Sub

        Private Sub ProcessFatigue()
            Dim pdblMultiplier As Double

            Me.CurrentEnergy = Me.CurrentEnergy - r.RandomNumber(0, 2)
            If Me.CurrentEnergy <= 0 Then Me.CurrentEnergy = 1
            pdblMultiplier = (Me.CurrentEnergy / 100)
            Me.Ratings.ChangeRatingBasedOnEnergy(pdblMultiplier)
        End Sub

        Sub Rejuvinate()
            Dim pdblMultiplier As Double

            If Me.Health = 0 Then
                If r.RandomNumber(0, 105) <= Me.Ratings.Item(ISS_Rating.Endurance) Then
                    Me.CurrentEnergy = Me.CurrentEnergy + 1
                    If Me.CurrentEnergy >= 100 Then Me.CurrentEnergy = 100
                    pdblMultiplier = (Me.CurrentEnergy / 100)
                    Me.Ratings.ChangeRatingBasedOnEnergy(pdblMultiplier)
                End If
            End If
        End Sub

        Public Function GetCurrentTeam() As String
            Return Me.CurrentTeam
        End Function

        Public Sub SetNewJersey(ByVal x As Byte)
            Me.Jersey = x
            Me.Update()
        End Sub

        Public Function CanPlayGamePosition(ByVal intGamePosition As ISoccerSim.SimEngine.ISMGamePosition) As Boolean
            Select Case intGamePosition
                Case SimEngine.ISMGamePosition.GK
                    If Me.Position = ISMPlayerPosition.Goalie Then
                        Return True
                    End If
                Case SimEngine.ISMGamePosition.LD, SimEngine.ISMGamePosition.RD
                    If Me.Position = ISMPlayerPosition.Defenseman Then
                        Return True
                    End If
                Case SimEngine.ISMGamePosition.LF, SimEngine.ISMGamePosition.RF
                    If Me.Position = ISMPlayerPosition.Forward Then
                        Return True
                    End If
                Case SimEngine.ISMGamePosition.MF
                    If Me.Position = ISMPlayerPosition.Midfielder Then
                        Return True
                    End If
                Case Else
                    Throw New Exception("Unknown player type.")
            End Select
        End Function
    End Class
End Namespace