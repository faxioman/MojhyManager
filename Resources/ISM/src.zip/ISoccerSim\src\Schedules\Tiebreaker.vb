'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Teams

Namespace Schedules
    Public Class Tiebreaker

        Dim Sim As Simulation = Simulation.GetInstance
        Public TieBreaker As TieBreakLevel

        Public Enum TieBreakLevel
            HeadToHead = 0
            HeadToHeadPoints = 1
            CoinFlip = 2
        End Enum


        Public Function GetAdvantage(ByVal Team1 As Integer, ByVal Team2 As Integer, ByVal Team3 As Integer)
            Dim WinningTeam As Integer = 0
            WinningTeam = GetTotalAdvantage(Team1, Team2, Team3)
            If WinningTeam > 0 Then Return WinningTeam



        End Function

        Public Function GetAdvantage(ByVal Team1 As Integer, ByVal Team2 As Integer)
            Dim WinningTeam As Integer = 0

            WinningTeam = GetTotalAdvantage(Team1, Team2)
            If WinningTeam > 0 Then Return WinningTeam

            WinningTeam = GetPointAdvantage(Team1, Team2)
            If WinningTeam > 0 Then Return WinningTeam


        End Function

        Public Function GetTotalAdvantage(ByVal Team1 As Integer, ByVal Team2 As Integer) As Integer
            Dim W1 As Integer = Sim.League.Standings.GetWins(Team1, Standings.enuPhase.Season, 0)
            Dim W2 As Integer = Sim.League.Standings.GetWins(Team2, Standings.enuPhase.Season, 0)

            If W1 > W2 Then
                Me.TieBreaker = TieBreakLevel.HeadToHead
                Return Team1
            ElseIf W2 > W1 Then
                Me.TieBreaker = TieBreakLevel.HeadToHead
                Return Team2
            Else
                Return 0
            End If
        End Function

        Public Function GetTotalAdvantage(ByVal Team1 As Integer, ByVal Team2 As Integer, ByVal Team3 As Integer) As Integer
            Dim W1 As Integer = Sim.League.Standings.GetWins(Team1, Standings.enuPhase.Season, 0)
            Dim W2 As Integer = Sim.League.Standings.GetWins(Team2, Standings.enuPhase.Season, 0)
            Dim W3 As Integer = Sim.League.Standings.GetWins(Team3, Standings.enuPhase.Season, 0)
            Dim ArrList As New ArrayList(3)
            ArrList.Add(New Utility.GUI.ComboItem(CStr(Team1), W1))
            ArrList.Add(New Utility.GUI.ComboItem(CStr(Team2), W2))
            ArrList.Add(New Utility.GUI.ComboItem(CStr(Team3), W3))
            ArrList.Sort()

            If CType(ArrList.Item(0), Utility.GUI.ComboItem).Value > CType(ArrList.Item(1), Utility.GUI.ComboItem).Value Then
                Return CType(ArrList(0), Utility.GUI.ComboItem).Value
            End If
        End Function

        Public Function GetPointAdvantage(ByVal team1 As Integer, ByVal team2 As Integer) As Integer
            Dim Advantage As Integer = Sim.League.Standings.GetPointMargin(team1, Standings.enuPhase.Season, team2)
            If Advantage > 0 Then
                Me.TieBreaker = TieBreakLevel.HeadToHeadPoints
                Return team1
            ElseIf Advantage < 0 Then
                Me.TieBreaker = TieBreakLevel.HeadToHeadPoints
                Return team2
            Else
                Return 0
            End If
        End Function

        Public Function GetCoinFlip(ByVal team1 As Integer, ByVal team2 As Integer) As Integer
            Dim ms As MathService = MathService.GetInstance

            Dim Coin As Integer = ms.GetRoll(MathService.ISMRollType.Percentage)
            Me.TieBreaker = TieBreakLevel.CoinFlip
            If Coin <= 50 Then
                Return team1
            Else
                Return team2
            End If
        End Function

        'Public Function GetDivAdvantage(ByVal Team1 As Integer, ByVal Team2 As Integer) As Integer
        '    Dim W1 As Integer = Sim.League.Standings.GetDivisionRecord(Team1, True)
        '    Dim W2 As Integer = Sim.League.Standings.GetDivisionRecord(Team2, True)

        '    If W1 > W2 Then
        '        Return Team1
        '    ElseIf W2 > W1 Then
        '        Return Team2
        '    Else
        '        Return 0
        '    End If
        'End Function

        'Public Function GetConfAdvantage(ByVal Team1 As Integer, ByVal Team2 As Integer) As Integer
        '    Dim W1 As Integer = Sim.League.Standings.GetConferenceRecord(Team1, True)
        '    Dim W2 As Integer = Sim.League.Standings.GetConferenceRecord(Team2, True)

        '    If W1 > W2 Then
        '        Return Team1
        '    ElseIf W2 > W1 Then
        '        Return Team2
        '    Else
        '        Return 0
        '    End If
        'End Function

    End Class
End Namespace

