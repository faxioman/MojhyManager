'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports System.IO

Public Class frmProgramOptions
	Inherits System.Windows.Forms.Form
    Dim Sim As Simulation = Simulation.GetInstance()
    Dim fs As FileService = FileService.GetInstance()
    Dim gs As GUIService = GuiService.GetInstance

#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		Call SetScreen()
	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
    Friend WithEvents grpContent As System.Windows.Forms.GroupBox
    Friend WithEvents lblText As System.Windows.Forms.Label
    Friend WithEvents cmbLeagues As System.Windows.Forms.ComboBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.grpContent = New System.Windows.Forms.GroupBox()
        Me.cmbLeagues = New System.Windows.Forms.ComboBox()
        Me.lblText = New System.Windows.Forms.Label()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.grpContent.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpContent
        '
        Me.grpContent.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmbLeagues, Me.lblText})
        Me.grpContent.Location = New System.Drawing.Point(8, 8)
        Me.grpContent.Name = "grpContent"
        Me.grpContent.Size = New System.Drawing.Size(504, 48)
        Me.grpContent.TabIndex = 2
        Me.grpContent.TabStop = False
        '
        'cmbLeagues
        '
        Me.cmbLeagues.Location = New System.Drawing.Point(160, 16)
        Me.cmbLeagues.Name = "cmbLeagues"
        Me.cmbLeagues.Size = New System.Drawing.Size(328, 22)
        Me.cmbLeagues.TabIndex = 2
        '
        'lblText
        '
        Me.lblText.Location = New System.Drawing.Point(16, 16)
        Me.lblText.Name = "lblText"
        Me.lblText.Size = New System.Drawing.Size(136, 24)
        Me.lblText.TabIndex = 1
        Me.lblText.Text = "Default League To Open:"
        '
        'btnOK
        '
        Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnOK.Location = New System.Drawing.Point(400, 64)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(112, 24)
        Me.btnOK.TabIndex = 1
        Me.btnOK.Text = "&OK"
        '
        'frmProgramOptions
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.FromArgb(CType(43, Byte), CType(72, Byte), CType(142, Byte))
        Me.ClientSize = New System.Drawing.Size(528, 101)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnOK, Me.grpContent})
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Gainsboro
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmProgramOptions"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Program Options"
        Me.grpContent.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	Private Sub frmDialogBase_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
		'Add standard error handler
		AddHandler Application.ThreadException, New ThreadExceptionEventHandler(AddressOf HandleException)
	End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Sim.UserSettings.DefaultLeague = Me.cmbLeagues.Text
        Sim.UserSettings.Save()
        Me.Close()
    End Sub

    Sub SetMainFrameText(ByVal strText As String)
        Me.grpContent.Text = strText
    End Sub

    Private Sub SetScreen()
        Dim Dir As New DirectoryInfo(fs.GetCurrentDirectory() & "\leagues\")
        Dim pdirInfo As DirectoryInfo

        gs.SetCursor(Me)
        gs.SkinForm(Me)

        If Dir.Exists Then
            For Each pdirInfo In Dir.GetDirectories
                Me.cmbLeagues.Items.Add(pdirInfo.Name)
            Next
        Else
            ShowMessageBox("Error", "Your league directory does not exist or does not contain any existing leagues." & vbCrLf & vbCrLf & _
             "Please create a new league or open an existing league.", Me)
        End If

    End Sub

    Private Sub lstLeagues_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.cmbLeagues.SelectedIndex <> -1 Then
            gs.SetCursor(True, Me)
            Sim.League.Load(Me.cmbLeagues.SelectedItem)
            Sim.LoadGlobalAppSettings(False)
            gs.SetCursor(False, Me)
        End If
        Me.Close()
    End Sub

    Private Sub lstLeagues_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Cursor = System.Windows.Forms.Cursors.Hand
    End Sub

    Private Sub lstLeagues_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Cursor = System.Windows.Forms.Cursors.Default
    End Sub
End Class
