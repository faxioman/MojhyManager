'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.Leagues
Imports ISoccerSim.Utility.DataGrid

Public Class frmStandings
	Inherits System.Windows.Forms.Form

	Dim LeagueTree As New LeagueTree()
    Dim Sim As Simulation = Simulation.GetInstance()
    Dim gs As GUIService = GuiService.GetInstance
#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		Call SetScreen()
	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Public WithEvents grpContent As System.Windows.Forms.GroupBox
	Public WithEvents btnOK As System.Windows.Forms.Button
	Public WithEvents dgConference1 As System.Windows.Forms.DataGrid
	Public WithEvents lstDivisions As System.Windows.Forms.ListBox
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.grpContent = New System.Windows.Forms.GroupBox()
		Me.lstDivisions = New System.Windows.Forms.ListBox()
		Me.dgConference1 = New System.Windows.Forms.DataGrid()
		Me.btnOK = New System.Windows.Forms.Button()
		Me.grpContent.SuspendLayout()
		CType(Me.dgConference1, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'grpContent
		'
		Me.grpContent.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
					Or System.Windows.Forms.AnchorStyles.Left) _
					Or System.Windows.Forms.AnchorStyles.Right)
		Me.grpContent.Controls.AddRange(New System.Windows.Forms.Control() {Me.lstDivisions, Me.dgConference1})
		Me.grpContent.Location = New System.Drawing.Point(8, 8)
		Me.grpContent.Name = "grpContent"
		Me.grpContent.Size = New System.Drawing.Size(760, 192)
		Me.grpContent.TabIndex = 0
		Me.grpContent.TabStop = False
		Me.grpContent.Text = "Standings"
		'
		'lstDivisions
		'
		Me.lstDivisions.ItemHeight = 14
		Me.lstDivisions.Location = New System.Drawing.Point(16, 24)
		Me.lstDivisions.Name = "lstDivisions"
		Me.lstDivisions.Size = New System.Drawing.Size(128, 158)
		Me.lstDivisions.TabIndex = 1
		'
		'dgConference1
		'
		Me.dgConference1.DataMember = ""
		Me.dgConference1.HeaderForeColor = System.Drawing.SystemColors.ControlText
		Me.dgConference1.Location = New System.Drawing.Point(160, 24)
		Me.dgConference1.Name = "dgConference1"
		Me.dgConference1.Size = New System.Drawing.Size(592, 160)
		Me.dgConference1.TabIndex = 0
		'
		'btnOK
		'
		Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnOK.Location = New System.Drawing.Point(656, 208)
		Me.btnOK.Name = "btnOK"
		Me.btnOK.Size = New System.Drawing.Size(112, 24)
		Me.btnOK.TabIndex = 2
		Me.btnOK.Text = "&OK"
		'
		'frmStandings
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.BackColor = System.Drawing.Color.FromArgb(CType(43, Byte), CType(72, Byte), CType(142, Byte))
		Me.ClientSize = New System.Drawing.Size(776, 245)
		Me.ControlBox = False
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.grpContent, Me.btnOK})
		Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.ForeColor = System.Drawing.Color.Gainsboro
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.Name = "frmStandings"
		Me.ShowInTaskbar = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.Text = "League Standings"
		Me.grpContent.ResumeLayout(False)
		CType(Me.dgConference1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub frmDialogBase_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
		'Add standard error handler
		AddHandler Application.ThreadException, New ThreadExceptionEventHandler(AddressOf HandleException)
	End Sub

	Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		Me.Close()
	End Sub

	Private Sub SetScreen()

        gs.SetCursor(Me)
        gs.SkinForm(Me)
		Sim.League.Standings.Load()
		Call LoadDivisions()
        Me.lstDivisions.SelectedIndex = 1

	End Sub

	Private Sub LoadDivisions()
		Me.LeagueTree = New LeagueTree()
		Me.LeagueTree.GetTree(False)
		Me.lstDivisions.DataSource = Me.LeagueTree
	End Sub


	Private Sub LoadStandings(ByRef dg As DataGrid, ByVal intDivisionID As Integer, ByVal GridTitle As String)
		gs.SetCursor(True, Me)
		Dim View As New DataViewUtility()
		View.Standardize(Sim.League.Standings.GetDivisionStandings(intDivisionID))
        View.Sort = "GB ASC, Team ASC"
		With dg
			.DataSource = View
			.CaptionText = GridTitle
		End With

		Dim Helper As New DataGridUtility(dg, "Standings")
		With Helper
			.SetStandingGrid()
			.Commit()
		End With
		gs.SetCursor(False, Me)
	End Sub

	Private Sub btnTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
		Me.dgConference1.BackgroundColor = System.Drawing.Color.BlanchedAlmond
	End Sub

	Private Sub lstDivisions_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstDivisions.SelectedIndexChanged
		Dim Item As LeagueTreeNode = CType(Me.lstDivisions.SelectedItem, LeagueTreeNode)

		If Me.lstDivisions.SelectedIndex <> -1 Then
			If Item.DivisionID > 0 Then
				Me.dgConference1.Visible = True
				Call Me.LoadStandings(Me.dgConference1, Item.DivisionID, Item.ToString)
			End If
		End If
	End Sub

End Class
