'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.Data.OleDb


Imports ISoccerSim.Tactical
Imports ISoccerSim.Statistics
Imports ISoccerSim.Utility.DataGrid

Namespace DataServices.AdvancedStats

	Public Class LeadingGoalkeepersMPS
		Inherits AdvancedStatService


        Overrides Function GetBaseLeagueStat(ByVal SeasonID As Integer) As DataSet
            Dim SQL As String
            Dim DS As DataSet
            Dim Table As DataTable


            SQL = GetBaseLeagueQuery("SeasonID = " & SeasonID)
            DS = AddCalculatedColumns(Me.GetDataSet(SQL, "Stats"), False)
            Return DS
        End Function

        Overrides Function GetBaseLeagueStatForTeam(ByVal Stat As ISMStat, ByVal TeamID As Integer, ByVal SeasonID As Integer) As DataSet
            Dim SQL As String
            Dim DS As DataSet
            Dim Table As DataTable

            SQL = GetBaseLeagueQuery(" AND t.TeamID = " & TeamID & " AND SeasonID = " & SeasonID)
            DS = AddCalculatedColumns(Me.GetDataSet(SQL, "Stats"), False)
            Return DS
        End Function

        Overrides Function GetBaseLeagueStatForConference(ByVal Stat As ISMStat, ByVal ConferenceID As Integer, ByVal SeasonID As Integer) As DataSet
            Dim SQL As String
            Dim DS As DataSet
            Dim Table As DataTable

            SQL = GetBaseLeagueQuery(" AND t.ConferenceID = " & ConferenceID & " AND SeasonID = " & SeasonID)
            DS = AddCalculatedColumns(Me.GetDataSet(SQL, "Stats"), False)
            Return DS
        End Function

        Overrides Function GetBaseLeagueStatForDivision(ByVal Stat As ISMStat, ByVal DivisionID As Integer, ByVal SeasonID As Integer) As DataSet
            Dim SQL As String = GetBaseLeagueQuery(" AND t.DivisionID = " & DivisionID & " AND SeasonID = " & SeasonID)
            Dim DS As DataSet
            Dim Table As DataTable

            DS = AddCalculatedColumns(Me.GetDataSet(SQL, "Stats"), False)
            Return DS
        End Function


        Overrides Function GetBaseTeamStat(ByVal Stat As ISMStat, ByVal SeasonID As Integer) As DataSet
            Dim SQL As String = GetBaseTeamQuery(" AND SeasonID = " & SeasonID)
            Dim DS As DataSet
            Dim Table As DataTable

            DS = AddCalculatedColumns(Me.GetDataSet(SQL, "Stats"), True)
            Return DS
        End Function

        Overrides Function GetBaseTeamStatForConference(ByVal Stat As ISMStat, ByVal ConferenceID As Integer, ByVal SeasonID As Integer) As DataSet
            Dim SQL As String = GetBaseTeamQuery(" AND t.ConferenceID = " & ConferenceID & " AND SeasonID = " & SeasonID)
            Dim DS As DataSet
            Dim Table As DataTable

            DS = AddCalculatedColumns(Me.GetDataSet(SQL, "Stats"), True)
            Return DS
        End Function

        Overrides Function GetBaseTeamStatForDivision(ByVal Stat As ISMStat, ByVal DivisionID As Integer, ByVal SeasonID As Integer) As DataSet
            Dim SQL As String = GetBaseTeamQuery(" AND t.DivisionID = " & DivisionID & " AND SeasonID = " & SeasonID)
            Dim DS As DataSet
            Dim Table As DataTable

            DS = AddCalculatedColumns(Me.GetDataSet(SQL, "Stats"), True)
            Return DS
        End Function

        Private Function GetBaseLeagueQuery(ByVal strWhere As String) As String

            Return "TRANSFORM Sum(gs.Value) AS [Value] " & _
              " SELECT pl.FirstName, pl.LastName, t.Abbreviation AS Team, Positions.Abbr AS POS, pl.PlayerID " & _
              " FROM ((Teams AS t INNER JOIN Rosters AS r ON t.TeamID = r.TeamID) INNER JOIN (Statistics AS s INNER JOIN (Players AS pl INNER JOIN GameStats AS gs ON pl.PlayerID = gs.PlayerID) ON s.StatID = gs.StatisticID) ON r.PlayerID = pl.PlayerID) INNER JOIN Positions ON pl.PositionID = Positions.PositionID " & _
              " WHERE ((s.StatID) IN (1, 17, 33, 32, 31, 35, 37, 38, 39, 40, 43, 44, 45) AND (pl.PositionID = 1) " & strWhere & ")" & _
              " GROUP BY pl.FirstName, pl.LastName, t.Abbreviation, Positions.Abbr, pl.PlayerID " & _
              " PIVOT s.StatID "
        End Function


        Private Function GetBaseTeamQuery(ByVal strWhere As String) As String
            Return "TRANSFORM Sum(gs.Value) AS [Value]" & _
            " SELECT t.Name AS Team, t.TeamID " & _
            " FROM Teams AS t INNER JOIN (Statistics AS s INNER JOIN GameStats AS gs ON s.StatID = gs.StatisticID) ON t.TeamID = gs.TeamID " & _
            " WHERE ((s.StatID) IN (1, 17, 33, 32, 31, 35, 37, 38, 39, 40, 43, 44, 45) " & strWhere & ")" & _
            " GROUP BY t.Name, t.TeamID " & _
            " PIVOT s.StatID; "

        End Function


        Private Function AddCalculatedColumns(ByVal DS As DataSet, ByVal blnTeam As Boolean) As DataSet

            SafelyAddColumn(DS, "1", System.Type.GetType("System.Int32"), "0")
            SafelyAddColumn(DS, "17", System.Type.GetType("System.Int32"), "0")
            SafelyAddColumn(DS, "33", System.Type.GetType("System.Int32"), "0")
            SafelyAddColumn(DS, "32", System.Type.GetType("System.Int32"), "0")
            SafelyAddColumn(DS, "31", System.Type.GetType("System.Int32"), "0")
            SafelyAddColumn(DS, "35", System.Type.GetType("System.Int32"), "0")
            SafelyAddColumn(DS, "37", System.Type.GetType("System.Int32"), "0")
            SafelyAddColumn(DS, "38", System.Type.GetType("System.Int32"), "0")
            SafelyAddColumn(DS, "39", System.Type.GetType("System.Int32"), "0")
            SafelyAddColumn(DS, "40", System.Type.GetType("System.Int32"), "0")
            SafelyAddColumn(DS, "43", System.Type.GetType("System.Int32"), "0")
            SafelyAddColumn(DS, "44", System.Type.GetType("System.Int32"), "0")
            SafelyAddColumn(DS, "45", System.Type.GetType("System.Int32"), "0")


            SafelyAddColumn(DS, "LastName", System.Type.GetType("System.String"), "''")
            SafelyAddColumn(DS, "FirstName", System.Type.GetType("System.String"), "''")
            SafelyAddColumn(DS, "PlayerName", System.Type.GetType("System.String"), "[LastName] + ', ' + [FirstName]")

            SafelyAddColumn(DS, "GP", System.Type.GetType("System.Int32"), "IsNull([1], 0)")
            SafelyAddColumn(DS, "3PG", System.Type.GetType("System.Int32"), "IsNull([40], 0)")
            SafelyAddColumn(DS, "2PG", System.Type.GetType("System.Int32"), "IsNull([39], 0)")
            SafelyAddColumn(DS, "1PG", System.Type.GetType("System.Int32"), "IsNull([38], 0)")
            SafelyAddColumn(DS, "w", System.Type.GetType("System.Int32"), "IsNull([43], 0)")
            SafelyAddColumn(DS, "L", System.Type.GetType("System.Int32"), "IsNull([44], 0)")
            SafelyAddColumn(DS, "MIN", System.Type.GetType("System.Int32"), "IsNull([17], 0) / 60")
            SafelyAddColumn(DS, "SV", System.Type.GetType("System.Int32"), "IsNull([35], 0)")
            SafelyAddColumn(DS, "SF", System.Type.GetType("System.Int32"), "IsNull([45], 0)")

            SafelyAddColumn(DS, "PTS", System.Type.GetType("System.Int32"), "([3PG] * 3) + ([2PG] * 2) + [1PG]")
            If blnTeam = True Then
                SafelyAddColumn(DS, "Avg", System.Type.GetType("System.Single"), "[PTS]/([W] + [L])")
            Else
                SafelyAddColumn(DS, "Avg", System.Type.GetType("System.Single"), "[PTS]/[GP]")
            End If



            Return DS
        End Function

    End Class

End Namespace