'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports NUnit.Framework

<TestFixture()> Public Class TestRosterMovement
    Public Sub TestDumpToFA()
        Dim rm As New Rosters.RosterManager
        Dim l As New Leagues.League
        Dim t As New Teams.Team
        Dim Sim As Simulation = Simulation.GetInstance

        Sim.LoadGlobalAppSettings(False)
        Sim.League.Load("My Soccer League")

        l = Sim.League

        t = l.GetTeamByID(1)
        Assert.AreEqual(t.Name <> "", "Team should be loaded")
        t.Roster.Load(t.TeamID)

        rm.DumpToFA(t.TeamID, 1)
        t.Roster.Load(t.TeamID)
        Assert.AreEqual(False, t.Roster.IsPlayerOnRoster(1))

        rm.SignFA(1, t.TeamID)
        t.Roster.Load(t.TeamID)
        Assert.AreEqual(t.Roster.IsPlayerOnRoster(1), True)

        rm.DumpToFA(2, 21)
        rm.TradePlayer(1, 1, 2)

        Dim t2 As New Teams.Team
        t2 = l.GetTeamByID(2)
        t.Roster.Load(t.TeamID)
        t2.Roster.Load(t2.TeamID)
        Assert.AreEqual(t.Roster.IsPlayerOnRoster(1), "Player should be off team #1")
        Assert.AreEqual(t2.Roster.IsPlayerOnRoster(1), "Player should be on team #2")

        rm.TradePlayer(1, 2, 1)
        t.Roster.Load(t.TeamID)
        t2.Roster.Load(t2.TeamID)
        Assert.AreEqual(t.Roster.IsPlayerOnRoster(1), "Player should be back on team #1")
        Assert.AreEqual(t2.Roster.IsPlayerOnRoster(1), "Player should be removed from team #2")
    End Sub
End Class
