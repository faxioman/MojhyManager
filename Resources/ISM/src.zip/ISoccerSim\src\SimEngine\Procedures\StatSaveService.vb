'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.SimEngine.Actions
Imports ISoccerSim.SimEngine.Actions.Plays
Imports ISoccerSim.SimEngine.Actions.Sequence
Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports Microsoft.VisualBasic
Imports ISoccerSim.Players
Imports ISoccerSim.SimEngine
Imports ISoccerSim.Statistics
Imports ISoccerSim.Finances.Team

Namespace SimEngine.Procedures
	Public Class StatSaveService
		Public WithEvents GameEngine As GameEngine
        Dim Sim As Simulation = Simulation.GetInstance()
		Public Sub New()

		End Sub

		Public Sub New(ByVal GameEngine As GameEngine)
			Me.GameEngine = GameEngine
		End Sub


		Public Sub Commit()

			Call CalculateGameWinningGoal()
			Call CommitPlayerStats(Me.GameEngine.HomeTeam)
			Call CommitPlayerStats(Me.GameEngine.AwayTeam)
            Call CommitToSchedule()
            Call SaveResults()
            Call SavePlayerEvents()
		End Sub

		Private Sub SaveResults()
			Dim Rpt As New SimEngine.Results.GameResultService()
			Rpt.GameEngine = Me.GameEngine
			Rpt.Create()
        End Sub

        Private Sub SavePlayerEvents()
            Call SavePlayerEvents(Me.GameEngine.HomeTeam, Me.GameEngine.AwayTeam)
            Call SavePlayerEvents(Me.GameEngine.AwayTeam, Me.GameEngine.HomeTeam)
        End Sub

        Private Sub SavePlayerEvents(ByVal fromTeam As Teams.Team, ByVal otherteam As Teams.Team)
            Dim p As Player
            Dim ps As GamePlayerSet = fromTeam.FieldManager.PlayerSet
            Dim pe As New PlayerEvent()

            For Each p In ps
                If p.Stats.GetValue(ISMStat.ShotMade) >= 3 Then
                    Call AddPlayerEventToDB(p.ID, "Hat trick of " & p.Stats.GetValue(ISMStat.ShotMade) & " against " & otherteam.Name & ".")
                End If

                If p.Stats.GetValue(ISMStat.Saves) >= 20 Then
                    Call AddPlayerEventToDB(p.ID, "Recorded " & p.Stats.GetValue(ISMStat.Saves) & " " & " against " & otherteam.Name & ".")
                End If
            Next
        End Sub

        Private Sub AddPlayerEventToDB(ByVal PlayerID As Integer, ByVal Description As String)
            Dim pe As New PlayerEvent()
            pe = New PlayerEvent()
            pe.PlayerID = PlayerID
            pe.EventDate = Me.GameEngine.GameDate
            pe.Description = Description
            pe.Insert()

        End Sub

        Private Sub CommitToSchedule()
            If Me.GameEngine.ScheduleID > 0 Then
                Dim Game As Schedules.Game = Sim.League.Schedule.GetGameByID(Me.GameEngine.ScheduleID)
                With Game
                    .AwayScore = Me.GameEngine.AwayTeam.Scoreboard.Score
                    .HomeScore = Me.GameEngine.HomeTeam.Scoreboard.Score
                    .Overtime = IIf(Me.GameEngine.Clock.Quarter >= 5, True, False)
                    .Status = Schedules.ISMGameScheduleStatus.Played
                    .Attendance = GetGameAttendance(.GameID)
                    Me.GameEngine.Attendance = .Attendance
                    .UpdateResult()
                End With
            End If
        End Sub

        Private Function GetGameAttendance(ByVal GameID) As Integer
            Dim ms As New MediaSet()
            ms.Load(Me.GameEngine.HomeTeam.TeamID)
            Dim att As New Finances.Team.AttendanceManager(ms)
            att.LeagueAverageAttendance = Me.GameEngine.HomeTeam.ExpectedAttendance
            att.SetAmounts(False, GetConferenceRivals, GetDivisionRivals, IsFirstHomeGame(GameID), _
                           IsAwayTeamDivLeader, False, False, GetStarPlayers, Finances.Team.AttendanceManager.HomeTeamRecord.MiddlePack, Me.GameEngine.HomeTeam.GetExpectedAttendancePct)
            Return att.Compute
        End Function

        Private Function GetConferenceRivals() As Boolean
            Return IIf(Me.GameEngine.HomeTeam.ConferenceID = Me.GameEngine.AwayTeam.ConferenceID, True, False)
        End Function

        Private Function GetDivisionRivals() As Boolean
            Return IIf(Me.GameEngine.HomeTeam.DivisionID = Me.GameEngine.AwayTeam.DivisionID, True, False)
        End Function

        Private Function IsFirstHomeGame(ByVal GameID As Integer) As Boolean
            Return IIf(Sim.League.Schedule.IsGameHomeOpener(Me.GameEngine.HomeTeam.TeamID, GameID), True, False)
        End Function

        Private Function IsAwayTeamDivLeader()
            Return IIf(Sim.League.Standings.GetLeaderInDivision(Me.GameEngine.HomeTeam.DivisionID) = Me.GameEngine.HomeTeam.DivisionID, True, False)
        End Function

        Private Function GetTeamWinStatus() As Finances.Team.AttendanceManager.HomeTeamRecord
            Return Sim.League.Standings.GetTeamStanding(Me.GameEngine.HomeTeam.TeamID)
        End Function

        Private Function GetStarPlayers()
            Dim objPlayer As Player
            Dim Result As Integer
            For Each objPlayer In Me.GameEngine.HomeTeam.FieldManager.PlayerSet
                If objPlayer.Health > 0 Then
                    Result = Result + objPlayer.StarPlayer
                End If
            Next

            For Each objPlayer In Me.GameEngine.AwayTeam.FieldManager.PlayerSet
                If objPlayer.Health > 0 Then
                    If objPlayer.StarPlayer > 1 Then
                        Result = Result + 1
                    End If
                End If
            Next
            Return Result
        End Function

        Private Sub CommitPlayerStats(ByVal objTeam As Teams.Team)
            Dim ps As GamePlayerSet = objTeam.FieldManager.PlayerSet
            Dim objStat As New GameStat
            Dim Player As Player
            Dim Stat As Stat

            With objStat
                .ScheduleID = Me.GameEngine.ScheduleID
                .SeasonID = Me.GameEngine.SeasonID
                .TeamID = objTeam.TeamID

            End With

            For Each Player In objTeam.FieldManager.PlayerSet
                For Each Stat In Player.Stats
                    With objStat
                        If Stat.Value > 0 Then
                            .StatisticID = Stat.StatID
                            .PlayerID = Player.ID
                            .Value = Stat.Value
                            .Insert()
                        End If
                    End With
                Next
            Next
            objStat.DataClose()
        End Sub

        Private Sub CalculateGameWinningGoal()

            If Me.GameEngine.HomeTeam.FieldManager.GameWinningPlayer Is Nothing Then
                Me.GameEngine.AwayTeam.FieldManager.GameWinningPlayer.Stats.Augment(ISMStat.GameWinningGoal)
                Me.GameEngine.AwayTeam.FieldManager.WinningGoalie.Stats.Augment(ISMStat.GoalieWin)
                If Me.GameEngine.HomeTeam.FieldManager.LosingGoalie Is Nothing Then
                    Debug.Assert(True, "Should not happen.")
                Else
                    Me.GameEngine.HomeTeam.FieldManager.LosingGoalie.Stats.Augment(ISMStat.GoalieLoss)
                End If
            Else
                Me.GameEngine.HomeTeam.FieldManager.GameWinningPlayer.Stats.Augment(ISMStat.GameWinningGoal)
                Me.GameEngine.HomeTeam.FieldManager.WinningGoalie.Stats.Augment(ISMStat.GoalieWin)
                If Me.GameEngine.AwayTeam.FieldManager.LosingGoalie Is Nothing Then
                    Debug.Assert(True, "Should not happen.")
                Else
                    Me.GameEngine.AwayTeam.FieldManager.LosingGoalie.Stats.Augment(ISMStat.GoalieLoss)
                End If

            End If

        End Sub

    End Class
End Namespace
