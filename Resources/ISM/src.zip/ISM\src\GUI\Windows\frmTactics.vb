'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.Tactical

Public Class frmTactics
	Inherits System.Windows.Forms.Form

	Private mblnLoading As Boolean
	Private mblnDirty As Boolean = False
	Private mintLastIndex As Integer
	Private mintPlayerID As Integer
    Dim Sim As Simulation = Simulation.GetInstance()
    Dim gs As GUIService = GUIService.GetInstance
    Dim vs As ValidationService = ValidationService.GetInstance

#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		Call SetScreen()


	End Sub


	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Public WithEvents grpFinish As System.Windows.Forms.GroupBox
	Public WithEvents tipLeague As System.Windows.Forms.ToolTip
	Public WithEvents btnOK As System.Windows.Forms.Button
	Public WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Public WithEvents iscrZoneToMan As ISMScrollBar
    Public WithEvents iscrPosture As ISMScrollBar
    Public WithEvents iscrParamShooting As ISMScrollBar
    Public WithEvents iscrRegroup As ISMScrollBar
    Public WithEvents iscrLongBall As ISMScrollBar
    Public WithEvents iscrCreasePlay As ISMScrollBar
    Public WithEvents iscrDefEngagement As ISMScrollBar
    Public WithEvents iscrGoalieRoving As ISMScrollBar
    Public WithEvents iscrCrossPassing As ISMScrollBar
    Public WithEvents iscrForwardPassing As ISMScrollBar
    Public WithEvents lblFwd As System.Windows.Forms.Label
    Public WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Public WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents Label1 As System.Windows.Forms.Label
    Public WithEvents txtName As System.Windows.Forms.TextBox
    Public WithEvents lstTactics As System.Windows.Forms.ListBox
    Public WithEvents Label12 As System.Windows.Forms.Label
    Public WithEvents txtDescription As System.Windows.Forms.TextBox
    Public WithEvents txtAbbr As System.Windows.Forms.TextBox
    Public WithEvents Label13 As System.Windows.Forms.Label
    Public WithEvents lblExplanation As System.Windows.Forms.Label
    Public WithEvents btnSave As System.Windows.Forms.Button
    Public WithEvents btnNewTactic As System.Windows.Forms.Button
    Public WithEvents hlpProvider As System.Windows.Forms.HelpProvider
    Public WithEvents lblZoneToMan As System.Windows.Forms.Label
    Public WithEvents lblPosture As System.Windows.Forms.Label
    Public WithEvents lblParameterShooting As System.Windows.Forms.Label
    Public WithEvents lblRegroup As System.Windows.Forms.Label
    Public WithEvents lblLongBall As System.Windows.Forms.Label
    Public WithEvents lblCreasePlay As System.Windows.Forms.Label
    Public WithEvents lblDefEngagement As System.Windows.Forms.Label
    Public WithEvents lblGoalieRoving As System.Windows.Forms.Label
    Public WithEvents lblCrossPassing As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.btnOK = New System.Windows.Forms.Button
        Me.grpFinish = New System.Windows.Forms.GroupBox
        Me.btnNewTactic = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.txtDescription = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtAbbr = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtName = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lblExplanation = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.iscrZoneToMan = New ISM.ISMScrollBar
        Me.lblZoneToMan = New System.Windows.Forms.Label
        Me.iscrPosture = New ISM.ISMScrollBar
        Me.lblPosture = New System.Windows.Forms.Label
        Me.iscrParamShooting = New ISM.ISMScrollBar
        Me.lblParameterShooting = New System.Windows.Forms.Label
        Me.iscrRegroup = New ISM.ISMScrollBar
        Me.lblRegroup = New System.Windows.Forms.Label
        Me.iscrLongBall = New ISM.ISMScrollBar
        Me.lblLongBall = New System.Windows.Forms.Label
        Me.iscrCreasePlay = New ISM.ISMScrollBar
        Me.lblCreasePlay = New System.Windows.Forms.Label
        Me.iscrDefEngagement = New ISM.ISMScrollBar
        Me.lblDefEngagement = New System.Windows.Forms.Label
        Me.iscrGoalieRoving = New ISM.ISMScrollBar
        Me.lblGoalieRoving = New System.Windows.Forms.Label
        Me.iscrCrossPassing = New ISM.ISMScrollBar
        Me.lblCrossPassing = New System.Windows.Forms.Label
        Me.iscrForwardPassing = New ISM.ISMScrollBar
        Me.lblFwd = New System.Windows.Forms.Label
        Me.lstTactics = New System.Windows.Forms.ListBox
        Me.tipLeague = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnSave = New System.Windows.Forms.Button
        Me.hlpProvider = New System.Windows.Forms.HelpProvider
        Me.grpFinish.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnOK
        '
        Me.btnOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnOK.Location = New System.Drawing.Point(536, 464)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(112, 24)
        Me.btnOK.TabIndex = 4
        Me.btnOK.Text = "&OK"
        '
        'grpFinish
        '
        Me.grpFinish.Controls.Add(Me.btnNewTactic)
        Me.grpFinish.Controls.Add(Me.GroupBox2)
        Me.grpFinish.Controls.Add(Me.GroupBox1)
        Me.grpFinish.Controls.Add(Me.lstTactics)
        Me.grpFinish.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpFinish.Location = New System.Drawing.Point(8, 8)
        Me.grpFinish.Name = "grpFinish"
        Me.grpFinish.Size = New System.Drawing.Size(638, 448)
        Me.grpFinish.TabIndex = 11
        Me.grpFinish.TabStop = False
        Me.grpFinish.Text = "Tactics"
        '
        'btnNewTactic
        '
        Me.btnNewTactic.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnNewTactic.Location = New System.Drawing.Point(16, 416)
        Me.btnNewTactic.Name = "btnNewTactic"
        Me.btnNewTactic.Size = New System.Drawing.Size(96, 24)
        Me.btnNewTactic.TabIndex = 15
        Me.btnNewTactic.TabStop = False
        Me.btnNewTactic.Text = "&New Tactic"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.txtDescription)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.txtAbbr)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.txtName)
        Me.GroupBox2.Location = New System.Drawing.Point(120, 16)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(504, 112)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "General"
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(8, 64)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(72, 16)
        Me.Label12.TabIndex = 24
        Me.Label12.Text = "Description:"
        '
        'txtDescription
        '
        Me.hlpProvider.SetHelpNavigator(Me.txtDescription, System.Windows.Forms.HelpNavigator.Topic)
        Me.txtDescription.Location = New System.Drawing.Point(96, 64)
        Me.txtDescription.MaxLength = 255
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.hlpProvider.SetShowHelp(Me.txtDescription, True)
        Me.txtDescription.Size = New System.Drawing.Size(392, 40)
        Me.txtDescription.TabIndex = 2
        Me.txtDescription.Text = ""
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 16)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "Abbreviation:"
        '
        'txtAbbr
        '
        Me.txtAbbr.Location = New System.Drawing.Point(96, 40)
        Me.txtAbbr.MaxLength = 10
        Me.txtAbbr.Name = "txtAbbr"
        Me.txtAbbr.Size = New System.Drawing.Size(56, 20)
        Me.txtAbbr.TabIndex = 1
        Me.txtAbbr.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 16)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "Name:"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(96, 16)
        Me.txtName.MaxLength = 50
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(336, 20)
        Me.txtName.TabIndex = 0
        Me.txtName.Text = ""
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblExplanation)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.iscrZoneToMan)
        Me.GroupBox1.Controls.Add(Me.lblZoneToMan)
        Me.GroupBox1.Controls.Add(Me.iscrPosture)
        Me.GroupBox1.Controls.Add(Me.lblPosture)
        Me.GroupBox1.Controls.Add(Me.iscrParamShooting)
        Me.GroupBox1.Controls.Add(Me.lblParameterShooting)
        Me.GroupBox1.Controls.Add(Me.iscrRegroup)
        Me.GroupBox1.Controls.Add(Me.lblRegroup)
        Me.GroupBox1.Controls.Add(Me.iscrLongBall)
        Me.GroupBox1.Controls.Add(Me.lblLongBall)
        Me.GroupBox1.Controls.Add(Me.iscrCreasePlay)
        Me.GroupBox1.Controls.Add(Me.lblCreasePlay)
        Me.GroupBox1.Controls.Add(Me.iscrDefEngagement)
        Me.GroupBox1.Controls.Add(Me.lblDefEngagement)
        Me.GroupBox1.Controls.Add(Me.iscrGoalieRoving)
        Me.GroupBox1.Controls.Add(Me.lblGoalieRoving)
        Me.GroupBox1.Controls.Add(Me.iscrCrossPassing)
        Me.GroupBox1.Controls.Add(Me.lblCrossPassing)
        Me.GroupBox1.Controls.Add(Me.iscrForwardPassing)
        Me.GroupBox1.Controls.Add(Me.lblFwd)
        Me.GroupBox1.Location = New System.Drawing.Point(120, 136)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(504, 304)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Tendencies"
        '
        'lblExplanation
        '
        Me.lblExplanation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblExplanation.Location = New System.Drawing.Point(112, 256)
        Me.lblExplanation.Name = "lblExplanation"
        Me.lblExplanation.Size = New System.Drawing.Size(376, 40)
        Me.lblExplanation.TabIndex = 71
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(8, 256)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(120, 16)
        Me.Label13.TabIndex = 70
        Me.Label13.Text = "Explanation:"
        '
        'iscrZoneToMan
        '
        Me.iscrZoneToMan.Description = Nothing
        Me.iscrZoneToMan.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iscrZoneToMan.Location = New System.Drawing.Point(104, 232)
        Me.iscrZoneToMan.Name = "iscrZoneToMan"
        Me.iscrZoneToMan.Size = New System.Drawing.Size(392, 24)
        Me.iscrZoneToMan.TabIndex = 10
        Me.iscrZoneToMan.Tag = "Tendency to play tight man coverage (100) to loose zone (0)."
        Me.tipLeague.SetToolTip(Me.iscrZoneToMan, "Tendency to play tight man coverage (100) to loose zone (0).")
        Me.iscrZoneToMan.Value = 50
        '
        'lblZoneToMan
        '
        Me.lblZoneToMan.Location = New System.Drawing.Point(8, 232)
        Me.lblZoneToMan.Name = "lblZoneToMan"
        Me.lblZoneToMan.Size = New System.Drawing.Size(80, 16)
        Me.lblZoneToMan.TabIndex = 69
        Me.lblZoneToMan.Text = "Zone to Man Tendency:"
        Me.tipLeague.SetToolTip(Me.lblZoneToMan, "Tendency to play tight man coverage (100) to loose zone (0).")
        '
        'iscrPosture
        '
        Me.iscrPosture.Description = Nothing
        Me.iscrPosture.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iscrPosture.Location = New System.Drawing.Point(104, 184)
        Me.iscrPosture.Name = "iscrPosture"
        Me.iscrPosture.Size = New System.Drawing.Size(392, 24)
        Me.iscrPosture.TabIndex = 7
        Me.iscrPosture.Tag = "Tendency to focus on attacking (100) versus defending (0)."
        Me.tipLeague.SetToolTip(Me.iscrPosture, "Tendency to focus on attacking (100) versus defending (0).")
        Me.iscrPosture.Value = 50
        '
        'lblPosture
        '
        Me.lblPosture.Location = New System.Drawing.Point(8, 184)
        Me.lblPosture.Name = "lblPosture"
        Me.lblPosture.Size = New System.Drawing.Size(88, 16)
        Me.lblPosture.TabIndex = 67
        Me.lblPosture.Text = "Posture:"
        Me.tipLeague.SetToolTip(Me.lblPosture, "Tendency to focus on attacking (100) versus defending (0).")
        '
        'iscrParamShooting
        '
        Me.iscrParamShooting.Description = Nothing
        Me.iscrParamShooting.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iscrParamShooting.Location = New System.Drawing.Point(104, 160)
        Me.iscrParamShooting.Name = "iscrParamShooting"
        Me.iscrParamShooting.Size = New System.Drawing.Size(392, 24)
        Me.iscrParamShooting.TabIndex = 6
        Me.iscrParamShooting.Tag = "Tendency for taking shots closer to goal (100) versus red line (0)."
        Me.tipLeague.SetToolTip(Me.iscrParamShooting, "Tendency for taking shots closer to goal (100) versus red line (0).")
        Me.iscrParamShooting.Value = 50
        '
        'lblParameterShooting
        '
        Me.lblParameterShooting.Location = New System.Drawing.Point(8, 160)
        Me.lblParameterShooting.Name = "lblParameterShooting"
        Me.lblParameterShooting.Size = New System.Drawing.Size(112, 16)
        Me.lblParameterShooting.TabIndex = 65
        Me.lblParameterShooting.Text = "Parameter Shooting:"
        Me.tipLeague.SetToolTip(Me.lblParameterShooting, "Tendency for taking shots closer to goal (100) versus red line (0).")
        '
        'iscrRegroup
        '
        Me.iscrRegroup.Description = Nothing
        Me.iscrRegroup.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iscrRegroup.Location = New System.Drawing.Point(104, 208)
        Me.iscrRegroup.Name = "iscrRegroup"
        Me.iscrRegroup.Size = New System.Drawing.Size(392, 24)
        Me.iscrRegroup.TabIndex = 8
        Me.iscrRegroup.Tag = "Tendency for offense to force a shot (100) versus passing back to center field (0" & _
        ")."
        Me.tipLeague.SetToolTip(Me.iscrRegroup, "Tendency for offense to force a shot (100) versus passing back to center field (0" & _
        ").")
        Me.iscrRegroup.Value = 50
        '
        'lblRegroup
        '
        Me.lblRegroup.Location = New System.Drawing.Point(8, 208)
        Me.lblRegroup.Name = "lblRegroup"
        Me.lblRegroup.Size = New System.Drawing.Size(96, 16)
        Me.lblRegroup.TabIndex = 63
        Me.lblRegroup.Text = "Regroup:"
        Me.tipLeague.SetToolTip(Me.lblRegroup, "Tendency for offense to force a shot (100) versus passing back to center field (0" & _
        ").")
        '
        'iscrLongBall
        '
        Me.iscrLongBall.Description = Nothing
        Me.iscrLongBall.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iscrLongBall.Location = New System.Drawing.Point(104, 136)
        Me.iscrLongBall.Name = "iscrLongBall"
        Me.iscrLongBall.Size = New System.Drawing.Size(392, 24)
        Me.iscrLongBall.TabIndex = 5
        Me.iscrLongBall.Tag = "Tendency to throw long balls down field versus rolling out to immediate defenders" & _
        "."
        Me.tipLeague.SetToolTip(Me.iscrLongBall, "Tendency to throw long balls down field versus rolling out to immediate defenders" & _
        ".")
        Me.iscrLongBall.Value = 50
        '
        'lblLongBall
        '
        Me.lblLongBall.Location = New System.Drawing.Point(8, 136)
        Me.lblLongBall.Name = "lblLongBall"
        Me.lblLongBall.Size = New System.Drawing.Size(72, 16)
        Me.lblLongBall.TabIndex = 61
        Me.lblLongBall.Text = "Long ball:"
        Me.tipLeague.SetToolTip(Me.lblLongBall, "Tendency to throw long balls down field versus rolling out to immediate defenders" & _
        ".")
        '
        'iscrCreasePlay
        '
        Me.iscrCreasePlay.Description = Nothing
        Me.iscrCreasePlay.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iscrCreasePlay.Location = New System.Drawing.Point(104, 16)
        Me.iscrCreasePlay.Name = "iscrCreasePlay"
        Me.iscrCreasePlay.Size = New System.Drawing.Size(392, 24)
        Me.iscrCreasePlay.TabIndex = 0
        Me.iscrCreasePlay.Tag = "Tendency for offense to force a shot (100) versus passing back to center field (0" & _
        ")."
        Me.tipLeague.SetToolTip(Me.iscrCreasePlay, "Tendency for offense to force a shot (100) versus passing back to center field (0" & _
        ").")
        Me.iscrCreasePlay.Value = 50
        '
        'lblCreasePlay
        '
        Me.lblCreasePlay.Location = New System.Drawing.Point(8, 16)
        Me.lblCreasePlay.Name = "lblCreasePlay"
        Me.lblCreasePlay.Size = New System.Drawing.Size(120, 16)
        Me.lblCreasePlay.TabIndex = 59
        Me.lblCreasePlay.Text = "Crease Play:"
        Me.tipLeague.SetToolTip(Me.lblCreasePlay, "Tendency for offense to force a shot (100) versus passing back to center field (0" & _
        ").")
        '
        'iscrDefEngagement
        '
        Me.iscrDefEngagement.Description = Nothing
        Me.iscrDefEngagement.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iscrDefEngagement.Location = New System.Drawing.Point(104, 64)
        Me.iscrDefEngagement.Name = "iscrDefEngagement"
        Me.iscrDefEngagement.Size = New System.Drawing.Size(392, 24)
        Me.iscrDefEngagement.TabIndex = 2
        Me.iscrDefEngagement.Tag = "Tendency to engage opposing team in their third (100) versus defensive third(0)."
        Me.tipLeague.SetToolTip(Me.iscrDefEngagement, "Tendency to engage opposing team in their third (100) versus defensive third(0).")
        Me.iscrDefEngagement.Value = 50
        '
        'lblDefEngagement
        '
        Me.lblDefEngagement.Location = New System.Drawing.Point(8, 64)
        Me.lblDefEngagement.Name = "lblDefEngagement"
        Me.lblDefEngagement.Size = New System.Drawing.Size(120, 16)
        Me.lblDefEngagement.TabIndex = 57
        Me.lblDefEngagement.Text = "Def. Engagement:"
        Me.tipLeague.SetToolTip(Me.lblDefEngagement, "Tendency to engage opposing team in their third (100) versus defensive third(0).")
        '
        'iscrGoalieRoving
        '
        Me.iscrGoalieRoving.Description = Nothing
        Me.iscrGoalieRoving.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iscrGoalieRoving.Location = New System.Drawing.Point(104, 112)
        Me.iscrGoalieRoving.Name = "iscrGoalieRoving"
        Me.iscrGoalieRoving.Size = New System.Drawing.Size(392, 24)
        Me.iscrGoalieRoving.TabIndex = 4
        Me.iscrGoalieRoving.Tag = "Tendency for goalie to leave box and participate in offensive."
        Me.tipLeague.SetToolTip(Me.iscrGoalieRoving, "Tendency for goalie to leave box and participate in offensive.")
        Me.iscrGoalieRoving.Value = 50
        '
        'lblGoalieRoving
        '
        Me.lblGoalieRoving.Location = New System.Drawing.Point(8, 112)
        Me.lblGoalieRoving.Name = "lblGoalieRoving"
        Me.lblGoalieRoving.Size = New System.Drawing.Size(88, 16)
        Me.lblGoalieRoving.TabIndex = 55
        Me.lblGoalieRoving.Text = "Goalie Roving:"
        Me.tipLeague.SetToolTip(Me.lblGoalieRoving, "Tendency for goalie to leave box and participate in offensive.")
        '
        'iscrCrossPassing
        '
        Me.iscrCrossPassing.Description = Nothing
        Me.iscrCrossPassing.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iscrCrossPassing.Location = New System.Drawing.Point(104, 40)
        Me.iscrCrossPassing.Name = "iscrCrossPassing"
        Me.iscrCrossPassing.Size = New System.Drawing.Size(392, 24)
        Me.iscrCrossPassing.TabIndex = 1
        Me.iscrCrossPassing.Tag = "Tendency to pass laterally across the field."
        Me.tipLeague.SetToolTip(Me.iscrCrossPassing, "Tendency to pass laterally across the field.")
        Me.iscrCrossPassing.Value = 50
        '
        'lblCrossPassing
        '
        Me.lblCrossPassing.Location = New System.Drawing.Point(8, 40)
        Me.lblCrossPassing.Name = "lblCrossPassing"
        Me.lblCrossPassing.Size = New System.Drawing.Size(88, 16)
        Me.lblCrossPassing.TabIndex = 53
        Me.lblCrossPassing.Text = "Cross Passing:"
        Me.tipLeague.SetToolTip(Me.lblCrossPassing, "Tendency to pass laterally across the field.")
        '
        'iscrForwardPassing
        '
        Me.iscrForwardPassing.Description = Nothing
        Me.iscrForwardPassing.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iscrForwardPassing.Location = New System.Drawing.Point(104, 88)
        Me.iscrForwardPassing.Name = "iscrForwardPassing"
        Me.iscrForwardPassing.Size = New System.Drawing.Size(392, 24)
        Me.iscrForwardPassing.TabIndex = 3
        Me.iscrForwardPassing.Tag = "Tendency to force forward passes (100) versus back passing (0)"
        Me.tipLeague.SetToolTip(Me.iscrForwardPassing, "Tendency to force forward passes (100) versus back passing (0)")
        Me.iscrForwardPassing.Value = 50
        '
        'lblFwd
        '
        Me.lblFwd.Location = New System.Drawing.Point(8, 88)
        Me.lblFwd.Name = "lblFwd"
        Me.lblFwd.Size = New System.Drawing.Size(96, 16)
        Me.lblFwd.TabIndex = 51
        Me.lblFwd.Text = "Forward Passing:"
        Me.tipLeague.SetToolTip(Me.lblFwd, "Tendency to force forward passes (100) versus back passing (0)")
        '
        'lstTactics
        '
        Me.lstTactics.ItemHeight = 14
        Me.lstTactics.Location = New System.Drawing.Point(16, 16)
        Me.lstTactics.Name = "lstTactics"
        Me.lstTactics.Size = New System.Drawing.Size(96, 396)
        Me.lstTactics.TabIndex = 14
        '
        'btnSave
        '
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSave.Location = New System.Drawing.Point(416, 464)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(112, 24)
        Me.btnSave.TabIndex = 12
        Me.btnSave.Text = "&Save"
        '
        'hlpProvider
        '
        Me.hlpProvider.HelpNamespace = "..\help\league_tactics.html"
        '
        'frmTactics
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(654, 499)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.grpFinish)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.hlpProvider.SetHelpNavigator(Me, System.Windows.Forms.HelpNavigator.Topic)
        Me.Name = "frmTactics"
        Me.hlpProvider.SetShowHelp(Me, True)
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.grpFinish.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		Me.Close()
	End Sub

#Region "CustomSetup"

	Private Sub SetScreen()
		Call InitializeDefaults()
        Call gs.SetCursor(Me)
        gs.SkinForm(Me)

	End Sub

	Private Sub InitializeDefaults()
		Dim Item As New Tactic()
		Me.lstTactics.Items.Clear()
        For Each Item In Sim.TacticSet
            Me.lstTactics.Items.Add(Item)
        Next

        Call MakeAddItemEntry()
        Me.lstTactics.Sorted = True
        Me.lstTactics.SelectedIndex = 0
        mintLastIndex = 0
        Me.btnSave.Enabled = False
    End Sub

    Private Sub MakeAddItemEntry()


    End Sub

#End Region

    Private Sub LoadTactic()
        Dim Item As New Tactic()
        Item = CType(Me.lstTactics.SelectedItem, Tactic)

        With Item
            mblnLoading = True
            Me.txtName.Text = .Name
            Me.txtAbbr.Text = .Abbreviation
            Me.txtDescription.Text = .Description

            Me.iscrCreasePlay.Value = .CreasePlay
            Me.iscrCrossPassing.Value = .CrossPassing
            Me.iscrDefEngagement.Value = .DefensiveEngagement
            Me.iscrForwardPassing.Value = .ForwardPassing
            Me.iscrGoalieRoving.Value = .GoalieRoving
            Me.iscrLongBall.Value = .LongBall
            Me.iscrParamShooting.Value = .Parameter
            Me.iscrPosture.Value = .Posture
            Me.iscrRegroup.Value = .Regroup
            Me.iscrZoneToMan.Value = .ZoneToMan
            mblnLoading = False


        End With

    End Sub


    Private Sub Scrollbarchanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles iscrCreasePlay.TextChanged, _
    iscrCrossPassing.TextChanged, iscrDefEngagement.TextChanged, iscrForwardPassing.TextChanged, iscrGoalieRoving.TextChanged, iscrLongBall.TextChanged, _
    iscrParamShooting.TextChanged, iscrPosture.TextChanged, iscrRegroup.TextChanged, iscrZoneToMan.TextChanged

        If Not mblnLoading Then
            mblnDirty = True
            Me.lblExplanation.Text = CType(sender, Control).Tag
            Me.btnSave.Enabled = True
        End If

    End Sub

    Private Sub ChangeDescription(ByVal sender As Object, ByVal e As System.EventArgs) Handles iscrCreasePlay.Enter, _
    iscrCrossPassing.Enter, iscrDefEngagement.Enter, iscrForwardPassing.Enter, iscrGoalieRoving.Enter, iscrLongBall.Enter, _
    iscrParamShooting.Enter, iscrPosture.Enter, iscrRegroup.Enter, iscrZoneToMan.Enter

        Me.lblExplanation.Text = CType(sender, Control).Tag

    End Sub

    Private Sub lstSublines_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstTactics.SelectedIndexChanged
        If Not mblnLoading Then
            CheckForSave()
            Call LoadTactic()
            mintLastIndex = Me.lstTactics.SelectedIndex
        End If
    End Sub

    Private Sub CheckForSave()
        If mblnDirty Then
            If MsgBox("Do you wish to save your changes?", MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton1, "ISM") = MsgBoxResult.Yes Then
                Call Save()
                mblnDirty = False
            End If
        End If
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If mblnDirty Then
            Call Save()
            mblnDirty = False
        End If
    End Sub

    Private Sub Save()
        gs.SetCursor(True, Me)
        Dim UpdateItem As New Tactic()
        UpdateItem = CType(Me.lstTactics.Items(mintLastIndex), Tactic)

        With UpdateItem
            .Abbreviation = Me.txtAbbr.Text
            .CreasePlay = Me.iscrCreasePlay.Value
            .CrossPassing = Me.iscrCrossPassing.Value
            .DefensiveEngagement = Me.iscrDefEngagement.Value
            .Description = Me.txtDescription.Text
            .ForwardPassing = Me.iscrForwardPassing.Value
            .GoalieRoving = Me.iscrGoalieRoving.Value
            .LongBall = Me.iscrLongBall.Value
            .Name = Me.txtName.Text
            .Parameter = Me.iscrParamShooting.Value
            .Posture = Me.iscrPosture.Value
            .Regroup = Me.iscrRegroup.Value
            .ZoneToMan = Me.iscrZoneToMan.Value
        End With

        UpdateItem.Update()

        Dim FindItem As Tactic
        For Each FindItem In Sim.TacticSet
            If FindItem.TacticID = UpdateItem.TacticID Then
                FindItem = UpdateItem.Clone
            End If
        Next
        Call ReloadList(UpdateItem)
        gs.SetCursor(False, Me)

    End Sub

    Public Sub ReloadList(ByVal UpdateItem As Tactic)
        'Reload list...
        Dim Item As New Tactic()
        mblnLoading = True
        Me.lstTactics.Items.Clear()
        For Each Item In Sim.TacticSet
            Me.lstTactics.Items.Add(Item)
            If Item.TacticID = UpdateItem.TacticID Then
                Me.lstTactics.SelectedItem = Item
            End If
        Next
        Me.lstTactics.Sorted = True
        Me.btnSave.Enabled = False
        mblnLoading = False

    End Sub


    Private Sub TextDirty(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtName.TextChanged, txtAbbr.TextChanged, txtDescription.TextChanged
        If Not mblnLoading Then
            mblnDirty = True
            Me.btnSave.Enabled = True
        End If

    End Sub

    Private Sub txtName_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtName.Leave
        If Not mblnLoading Then
            If Not (vs.IsStringValid(Me.txtName.Text, 1, 50)) Then
                MsgBox("Your Name for this tactic is either too short or too long.  Please change before saving.")
                Me.txtName.Focus()
            End If
        End If
    End Sub

    Private Sub txtAbbr_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtAbbr.Leave
        If Not mblnLoading Then
            If Not (vs.IsStringValid(Me.txtAbbr.Text, 1, 5)) Then
                MsgBox("Your abbreviation for this tactic is either too short or too long.  Please change before saving.")
                Me.txtAbbr.Focus()
            End If
        End If
    End Sub

    Private Sub btnNewTactic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewTactic.Click
        Call AddNewTactic()
    End Sub

    Private Sub AddNewTactic()
        Dim Item As New Tactic()
        Item.SetDefault(Sim.TacticSet.GetNewID)
        Sim.TacticSet.Add(Item)
        Call ReloadList(Item)
        Me.lstTactics.SelectedItem = Item
        Me.txtName.Focus()
    End Sub

    Private Sub lblCaption_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblCreasePlay.MouseHover, lblCrossPassing.MouseHover, _
        lblDefEngagement.MouseHover, lblExplanation.MouseHover, lblFwd.MouseHover, lblGoalieRoving.MouseHover, lblLongBall.MouseHover, lblParameterShooting.MouseHover, _
        lblPosture.MouseHover, lblRegroup.MouseHover, lblZoneToMan.MouseHover

        Me.lblExplanation.Text = Me.tipLeague.GetToolTip(sender)
        'CType(sender, Label).Tool
    End Sub
End Class
