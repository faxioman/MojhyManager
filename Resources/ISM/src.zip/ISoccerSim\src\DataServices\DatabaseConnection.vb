'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports System.ComponentModel
Imports System.Data.OleDb


Public Class DatabaseConnection
	Private Shared blnCreated As Boolean = False
	Private Shared DBConnection As DatabaseConnection
	Private blnLegal As Boolean

	Public TotalCalls As Integer = 0

	Public ConnectionString As String
    Public cn As New OleDbConnection()
    Dim fs As FileService = FileService.GetInstance


	Sub New()
        blnCreated = False
        'DBConnection = Me
	End Sub

	Sub Pause()
		Me.cn.Close()
	End Sub

	Public Shared Function GetInstance() As DatabaseConnection
		If Not blnCreated Then
            DBConnection = New DatabaseConnection()
            blnCreated = True
		End If
		Return DBConnection
	End Function

	Sub Reconnect()
		Me.cn.Close()
		Call Connect()
	End Sub

	Sub Connect(ByVal LeagueDir As String)
		Me.TotalCalls = Me.TotalCalls + 1
		If cn Is Nothing Then
			Dim cn As New OleDbConnection()
		End If

		If cn.State = ConnectionState.Open Then
			Exit Sub
			'cn.Close()
		End If

		Me.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Password="""";User ID=Admin;Data Source=" & LeagueDir & "\base.mdb;Mode=Share Deny None;Extended Properties="""";Jet OLEDB:System database="""";Jet OLEDB:Registry Path="""";Jet OLEDB:Database Password="""";Jet OLEDB:Engine Type=5;Jet OLEDB:Database Locking Mode=0;Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Global Bulk Transactions=1;Jet OLEDB:New Database Password="""";Jet OLEDB:Create System Database=False;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=False;Jet OLEDB:SFP=False"

		'Finally, connect the fucker...
		Try
			cn.ConnectionString = Me.ConnectionString
			cn.Open()
		Catch ex As Exception
            Throw ex
		End Try
	End Sub

	Sub Connect()
        Me.TotalCalls = Me.TotalCalls + 1
        Dim Sim As Simulation = Simulation.GetInstance()

		If cn Is Nothing Then
			Dim cn As New OleDbConnection()
		End If

		If cn.State = ConnectionState.Open Then
			Exit Sub
			'cn.Close()
        End If


        If Not (Sim Is Nothing) Then
            If Sim.League.Name <> "" Then
                Me.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Password="""";User ID=Admin;Data Source=" & fs.GetCurrentDirectory() & "\leagues\" & Sim.League.Name & "\base.mdb;Mode=Share Deny None;Extended Properties="""";Jet OLEDB:System database="""";Jet OLEDB:Registry Path="""";Jet OLEDB:Database Password="""";Jet OLEDB:Engine Type=5;Jet OLEDB:Database Locking Mode=0;Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Global Bulk Transactions=1;Jet OLEDB:New Database Password="""";Jet OLEDB:Create System Database=False;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=False;Jet OLEDB:SFP=False"
            Else
                Me.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Password="""";User ID=Admin;Data Source=" & fs.GetCurrentDirectory() & "\data\base.mdb;Mode=Share Deny None;Extended Properties="""";Jet OLEDB:System database="""";Jet OLEDB:Registry Path="""";Jet OLEDB:Database Password="""";Jet OLEDB:Engine Type=5;Jet OLEDB:Database Locking Mode=0;Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Global Bulk Transactions=1;Jet OLEDB:New Database Password="""";Jet OLEDB:Create System Database=False;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=False;Jet OLEDB:SFP=False"
            End If
        Else
            Me.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Password="""";User ID=Admin;Data Source=" & fs.GetCurrentDirectory() & "\data\base.mdb;Mode=Share Deny None;Extended Properties="""";Jet OLEDB:System database="""";Jet OLEDB:Registry Path="""";Jet OLEDB:Database Password="""";Jet OLEDB:Engine Type=5;Jet OLEDB:Database Locking Mode=0;Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Global Bulk Transactions=1;Jet OLEDB:New Database Password="""";Jet OLEDB:Create System Database=False;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=False;Jet OLEDB:SFP=False"
        End If
        'Finally, connect the fucker...
        Try
            cn.ConnectionString = Me.ConnectionString
            cn.Open()
        Catch ex As Exception
            Throw ex
        End Try
	End Sub

	Sub Close()
		'cn.Close()
	End Sub


End Class