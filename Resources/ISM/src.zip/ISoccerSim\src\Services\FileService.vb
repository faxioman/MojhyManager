Imports System.IO

Public Class FileService
    Private Shared myFS As FileService

    Dim TestDirectory As String

    Public Shared Function GetInstance() As FileService
        If myFS Is Nothing Then
            myFS = New FileService()
        End If
        Return myFS
    End Function

    Function IsFileNameLegal(ByVal strFileName As String) As Boolean

        Dim IllegalChars As String = "!@#$%^&*()';:{}[]"
        Dim c As Char

        For Each c In IllegalChars
            If strFileName.IndexOfAny(c.ToString) <> -1 Then
                Return False
            End If
        Next

        If strFileName.Trim.Replace(" ", "").Length = 0 Then
            Return False
        End If
        Return True

    End Function

    Function GetErrorFileName() As String
        Return Me.GetCurrentDirectory() & "\error" & Format(Now, "yyyymmdd") & ".txt"
    End Function

    Function GetCurrentDirectory() As String
        Dim strOut As String

        strOut = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly.Location)
        If Dir(strOut & "settings.xml") = "" Then
            If InStr(strOut, "nunit") > 0 Then
                strOut = "C:\code\ISM\bin"
            End If
        End If
        Return strOut
    End Function

    Function SetCurrentDirectory(ByVal strDirectory As String) As String
        Me.TestDirectory = strDirectory
    End Function

    Function GetSkinDirectory() As String
        Dim Sim As Simulation = Simulation.GetInstance
        Dim Out As String = GetCurrentDirectory() & "\skins\" & Sim.Skin.SkinDir & "\"
        Return Out
    End Function

    Private Function GetTempDirectory(ByVal LeagueName As String) As String
        Return Me.GetCurrentDirectory() & "\leagues\" & LeagueName & "\temp\"
    End Function

    Function GetTempBoxScoreFilePath(ByVal LeagueName As String) As String
        Return Me.GetTempDirectory(LeagueName) & "box.html"
    End Function

    Function GetTempGameLogFilePath(ByVal LeagueName As String) As String
        Return Me.GetTempDirectory(LeagueName) & "log.html"
    End Function

    Function GetScheduledGameBoxFileName(ByVal LeagueName As String, ByVal ID As Integer) As String
        Return Me.GetCurrentDirectory() & "\leagues\" & LeagueName & "\box\box" & Format(ID, "0000") & ".html"
    End Function

    Function GetScheduledEventLogFileName(ByVal LeagueName As String, ByVal ID As Integer) As String
        Return Me.GetCurrentDirectory() & "\leagues\" & LeagueName & "\games\log" & Format(ID, "0000") & ".html"
    End Function

    Function GetLeagueOutputPath(ByVal LeagueName As String) As String
        Return Me.GetCurrentDirectory() & "\leagues\" & LeagueName & "\web\"
    End Function

    Function GetLeagueFacePath(ByVal LeagueName As String) As String
        Return Me.GetCurrentDirectory() & "\leagues\" & LeagueName & "\images\faces\"
    End Function

    Function GetLeagueLogoPath(ByVal LeagueName As String) As String
        Return Me.GetCurrentDirectory() & "\leagues\" & LeagueName & "\images\logos\"
    End Function

    Function GetBaseFacePath() As String
        Return Me.GetCurrentDirectory() & "\images\faces\"
    End Function

    Function GetBaseLogoPath() As String
        Return Me.GetCurrentDirectory() & "\images\logos\"
    End Function

    Function GetBaseLogoTemplatePath() As String
        Return Me.GetCurrentDirectory() & "\images\logos\template\"
    End Function

    Function GetWebFilename(ByVal Filename As String) As String
        Return LCase(Replace(Filename, " ", "_"))
    End Function

    Function GetScheduledPBPFileName(ByVal LeagueName As String, ByVal ID As Integer) As String
        Return Me.GetCurrentDirectory() & "\leagues\" & LeagueName & "\log\pbp" & Format(ID, "0000") & ".html"
    End Function

    Function GetStyleSheetTemplateFilePath(ByVal LeagueName As String) As String
        Return Me.GetCurrentDirectory() & "\leagues\" & LeagueName & "\ism.css"
    End Function

    Function GetTempGameEventLogFilePath(ByVal LeagueName As String) As String
        Return Me.GetTempDirectory(LeagueName) & "event.html"
    End Function

    Function GetLeagueName()
        Dim Sim As Simulation = Simulation.GetInstance()
        If Not Sim Is Nothing Then
            If Sim.League.Name <> "" Then
                Return Sim.League.Name
            End If
        End If
    End Function

    Function Exists(ByVal FileName) As Boolean
        If Dir(FileName, FileAttribute.Normal) <> "" Then
            Return True
        End If
    End Function

    Function IsValidGraphicFile(ByVal Filename As String) As Boolean
        If Filename.ToLower.EndsWith(".png") Or _
           Filename.ToLower.EndsWith(".jpg") Or _
           Filename.ToLower.EndsWith(".bmp") Or _
           Filename.ToLower.EndsWith(".gif") Then
            Return True
        End If
    End Function

End Class
