'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.Leagues
Imports ISoccerSim.Statistics
Imports ISoccerSim.Utility.DataGrid
Imports ISoccerSim
Imports System.Threading


Public Class frmLeagueStats
	Inherits System.Windows.Forms.Form


	Dim StatManager As New StatisticManager()
	Dim LeagueTree As New LeagueTree()
    Dim mblnLoading As Boolean
    Dim gs As GUIService = GuiService.GetInstance

#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		Call SetScreen()
	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Public WithEvents btnOK As System.Windows.Forms.Button
	Public WithEvents btnExport As System.Windows.Forms.Button
	Public WithEvents cmbType As System.Windows.Forms.ComboBox
	Public WithEvents lstScope As System.Windows.Forms.ListBox
	Public WithEvents grpStatistics As System.Windows.Forms.GroupBox
	Public WithEvents cmbStatReport As System.Windows.Forms.ComboBox
	Public WithEvents dgResults As System.Windows.Forms.DataGrid
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.grpStatistics = New System.Windows.Forms.GroupBox
        Me.cmbStatReport = New System.Windows.Forms.ComboBox
        Me.cmbType = New System.Windows.Forms.ComboBox
        Me.lstScope = New System.Windows.Forms.ListBox
        Me.dgResults = New System.Windows.Forms.DataGrid
        Me.btnOK = New System.Windows.Forms.Button
        Me.btnExport = New System.Windows.Forms.Button
        Me.grpStatistics.SuspendLayout()
        CType(Me.dgResults, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grpStatistics
        '
        Me.grpStatistics.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpStatistics.Controls.Add(Me.cmbStatReport)
        Me.grpStatistics.Controls.Add(Me.cmbType)
        Me.grpStatistics.Controls.Add(Me.lstScope)
        Me.grpStatistics.Controls.Add(Me.dgResults)
        Me.grpStatistics.Location = New System.Drawing.Point(8, 8)
        Me.grpStatistics.Name = "grpStatistics"
        Me.grpStatistics.Size = New System.Drawing.Size(688, 350)
        Me.grpStatistics.TabIndex = 0
        Me.grpStatistics.TabStop = False
        Me.grpStatistics.Text = "Statistics"
        '
        'cmbStatReport
        '
        Me.cmbStatReport.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStatReport.Location = New System.Drawing.Point(160, 48)
        Me.cmbStatReport.Name = "cmbStatReport"
        Me.cmbStatReport.Size = New System.Drawing.Size(160, 22)
        Me.cmbStatReport.TabIndex = 3
        '
        'cmbType
        '
        Me.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbType.Items.AddRange(New Object() {"Individual", "Team"})
        Me.cmbType.Location = New System.Drawing.Point(160, 24)
        Me.cmbType.Name = "cmbType"
        Me.cmbType.Size = New System.Drawing.Size(160, 22)
        Me.cmbType.TabIndex = 2
        '
        'lstScope
        '
        Me.lstScope.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lstScope.ItemHeight = 14
        Me.lstScope.Location = New System.Drawing.Point(16, 24)
        Me.lstScope.Name = "lstScope"
        Me.lstScope.Size = New System.Drawing.Size(128, 312)
        Me.lstScope.TabIndex = 1
        '
        'dgResults
        '
        Me.dgResults.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgResults.DataMember = ""
        Me.dgResults.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgResults.Location = New System.Drawing.Point(160, 72)
        Me.dgResults.Name = "dgResults"
        Me.dgResults.Size = New System.Drawing.Size(520, 264)
        Me.dgResults.TabIndex = 0
        '
        'btnOK
        '
        Me.btnOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnOK.Location = New System.Drawing.Point(584, 366)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(112, 24)
        Me.btnOK.TabIndex = 2
        Me.btnOK.Text = "&OK"
        '
        'btnExport
        '
        Me.btnExport.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnExport.Location = New System.Drawing.Point(8, 368)
        Me.btnExport.Name = "btnExport"
        Me.btnExport.Size = New System.Drawing.Size(112, 24)
        Me.btnExport.TabIndex = 12
        Me.btnExport.Text = "&Export"
        '
        'frmLeagueStats
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.FromArgb(CType(43, Byte), CType(72, Byte), CType(142, Byte))
        Me.ClientSize = New System.Drawing.Size(704, 395)
        Me.Controls.Add(Me.btnExport)
        Me.Controls.Add(Me.grpStatistics)
        Me.Controls.Add(Me.btnOK)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Gainsboro
        Me.MinimizeBox = False
        Me.Name = "frmLeagueStats"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "League Statistics"
        Me.grpStatistics.ResumeLayout(False)
        CType(Me.dgResults, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

	Private Sub frmDialogBase_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
		'Add standard error handler
		AddHandler Application.ThreadException, New ThreadExceptionEventHandler(AddressOf HandleException)
	End Sub

	Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		Me.Close()
	End Sub

	Private Sub SetScreen()
		mblnLoading = True
        gs.SetCursor(Me)
        gs.SkinForm(Me)
		Call SetSideList()
		Call SetStatReportCombo()
		Call SetIndexes()
		mblnLoading = False
	End Sub

	Private Sub SetStatReportCombo()
		Dim Item As StatReportItem

		For Each Item In Me.StatManager.StatReports
			Me.cmbStatReport.Items.Add(Item)
		Next
	End Sub

	Private Sub SetLeagueTree()
		Me.LeagueTree = New LeagueTree()
		Me.LeagueTree.GetTree()
	End Sub

	Private Sub SetIndexes()
		Me.lstScope.SelectedIndex = 0
		Me.cmbStatReport.SelectedIndex = 0
        Me.cmbType.SelectedIndex = 0
        Call FetchData()
	End Sub

	Private Sub SetSideList()
		Call SetLeagueTree()
		Me.lstScope.DataSource = Me.LeagueTree


	End Sub

	Private Sub AddItem()
	End Sub


	Private Sub btnFetch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
		Call FetchData()
	End Sub

	Private Sub SetScope(ByVal Item As LeagueTreeNode)

		If Me.cmbType.SelectedIndex = 0 Then
			Me.StatManager.StatType = ISMStatType.Individual
		Else
			Me.StatManager.StatType = ISMStatType.League
		End If

		With Me.StatManager
			Select Case Item.Indent
				Case Leagues.LeagueTreeNode.ISMIndentLevel.Team
					.TeamID = Item.ID
					.Scope = ISMStatScope.Team
				Case Leagues.LeagueTreeNode.ISMIndentLevel.Conference
					.ConferenceID = Item.ID
					.Scope = ISMStatScope.Conference
				Case Leagues.LeagueTreeNode.ISMIndentLevel.Division
					.DivisionID = Item.ID
					.Scope = ISMStatScope.League
				Case Leagues.LeagueTreeNode.ISMIndentLevel.League
					.Scope = ISMStatScope.League
			End Select
		End With
	End Sub

	Private Sub FetchData()
		Dim Item As LeagueTreeNode = CType(Me.lstScope.SelectedItem, LeagueTreeNode)
		Dim Report As StatReportItem = Me.cmbStatReport.SelectedItem
		Dim DS As New DataSet()

		'Grab data first....
		Call SetScope(Item)

		'Format the grid...
		gs.SetCursor(True, Me)
		Dim View As New DataViewUtility()
		View.Standardize(Me.StatManager.GetData(Report))
		With Me.dgResults
			.DataSource = View
			.CaptionText = Report.Description
		End With

		Dim Helper As New DataGridUtility(Me.dgResults, "Stats")
		With Helper
			If Me.StatManager.Report.IsBase Then
				If Me.cmbType.SelectedIndex = 0 Then
					.SetBasePlayerStatGrid(Report.Description)
				Else
					.SetBaseTeamStatGrid(Report.Description)
				End If
				.Commit()
			Else
				Call SetAdvancedGrid(Helper, View)
			End If
		End With
		gs.SetCursor(False, Me)

	End Sub

	Private Sub SetAdvancedGrid(ByVal DGUtility As DataGridUtility, ByVal dvDataView As DataView)

		Select Case Me.StatManager.Report.ID
			Case ISMStatReport.ScoringLeaders
				If Me.StatManager.StatType = ISMStatType.League Then
					DGUtility.SetLeagueLeaderGridTeam()
					dvDataView.Sort = "Total DESC, Team ASC"
				Else
					DGUtility.SetLeagueLeaderGridIndividual()
					dvDataView.Sort = "Total DESC, LastName ASC, FirstName ASC"
				End If
			Case ISMStatReport.MPS_ScoringLeaders
				If Me.StatManager.StatType = ISMStatType.League Then
					DGUtility.SetLeagueLeaderGridTeamMPS()
					dvDataView.Sort = "Total DESC, Team ASC"
					dvDataView.RowFilter = "[Total] > 0"
				Else
					DGUtility.SetLeagueLeaderGridIndividualMPS()
                    'dvDataView.Sort = "Total DESC, LastName ASC, FirstName ASC"
                    '               dvDataView.RowFilter = "[Total] > 0"
                End If
			Case ISMStatReport.MPS_GoalieLeaders
				If Me.StatManager.StatType = ISMStatType.League Then
					DGUtility.SetLeagueLeaderGoaliesTeamMPS()
					dvDataView.Sort = "[AVG] ASC, Team ASC"
					dvDataView.RowFilter = "[GP] > 0"
				Else
					DGUtility.SetLeagueLeaderGoaliesIndividualMPS()
					dvDataView.Sort = "[AVG] ASC, LastName ASC, FirstName ASC"
					dvDataView.RowFilter = "[GP] > 0"
				End If
			Case ISMStatReport.GoalieLeaders
				If Me.StatManager.StatType = ISMStatType.League Then
					DGUtility.SetLeagueLeaderGoaliesTeam()
					dvDataView.Sort = "[AVG] ASC, Team ASC"
					dvDataView.RowFilter = "[GP] > 0"
				Else
					DGUtility.SetLeagueLeaderGoaliesIndividual()
					dvDataView.Sort = "[AVG] ASC, LastName ASC, FirstName ASC"
					dvDataView.RowFilter = "[GP] > 0"
				End If
		End Select
		DGUtility.Commit()
	End Sub

	Private Sub RequestForStat(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstScope.SelectedIndexChanged, cmbStatReport.SelectedIndexChanged, cmbType.SelectedIndexChanged
		If Not mblnLoading Then
			Call FetchData()
		End If
	End Sub

	Private Sub dgRoster_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgResults.MouseUp

        If Me.cmbType.Text = "Individual" Then
            Dim pt As New Point(e.X, e.Y)
            Dim hti As DataGrid.HitTestInfo = Me.dgResults.HitTest(pt)
            Dim PlayerID As Integer

            If hti.Type = DataGrid.HitTestType.Cell Or hti.Type = DataGrid.HitTestType.RowHeader Then
                Me.dgResults.CurrentCell = New DataGridCell(hti.Row, hti.Column)
                Me.dgResults.Select(hti.Row)
                PlayerID = Int(Me.dgResults(hti.Row, 0))
                If PlayerID > 0 Then
                    Dim f As New frmPlayerCard(PlayerID, GetPlayersInGrid())
                    f.ShowDialog()
                End If
            End If
        End If
	End Sub

	Private Function GetPlayersInGrid() As ArrayList
		Dim parrOut As New ArrayList()
		Dim cm As CurrencyManager = CType(Me.BindingContext(Me.dgResults.DataSource), CurrencyManager)
		Dim rowCount As Integer = cm.Count

		Dim i As Integer
		For i = 0 To rowCount - 1
			parrOut.Add(Me.dgResults(i, 0))
		Next
		Return parrOut
	End Function

    Private Sub btnExport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExport.Click
        Dim s As New Reporting.StatReportService
        Dim Sim As Simulation = Simulation.GetInstance
        Dim dv As Data.DataView = Me.dgResults.DataSource
        Dim fs As FileService = FileService.GetInstance

        Dim StatTitle As String = Me.cmbType.Text & " " & Me.cmbStatReport.Text
        Dim PageTitle As String = CType(Me.lstScope.SelectedItem, LeagueTreeNode).ToString & " " & StatTitle
        Dim BaseFileName As String = fs.GetLeagueOutputPath(Sim.League.Name) & fs.GetWebFilename(PageTitle)

        s.Create(PageTitle, StatTitle, Me.dgResults, BaseFileName & ".txt", New Reporting.TextReportFormatService)
        s.Create(PageTitle, StatTitle, Me.dgResults, BaseFileName & ".html", New Reporting.HTMLReportFormatService)

        MsgBox("Reports have been exported to this league's \web\ folder.")

    End Sub


End Class

