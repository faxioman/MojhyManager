'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Teams
Imports ISoccerSim.Utility.DataGrid
Imports ISoccerSim.Finances.Team

Namespace Schedules
	Public Class Standings
		Inherits Schedule

		Private mintTotalGames As Integer
        Dim Sim As Simulation = Simulation.GetInstance()

		Public Enum enuPhase
			Season = 0
			Preseason = -1
			PostSeason = 1
		End Enum

        Function GetWinPercentage(ByVal TeamID As Integer, ByVal intPhase As enuPhase, ByVal OpponentID As Integer) As Double
            Dim Result As Double
            Dim Wins As Integer
            Dim Losses As Integer

            Wins = GetWins(TeamID, intPhase, OpponentID)
            Losses = GetLosses(TeamID, intPhase, OpponentID)

            If Wins + Losses = 0 Then
                Result = 0
            Else
                Result = Wins / (Wins + Losses)
            End If

            GetWinPercentage = Result


        End Function

        Function GetWinPercentage(ByVal TeamID As Integer, ByVal intPhase As enuPhase, ByVal Opponents As ArrayList) As Double
            Dim Result As Double
            Dim Wins As Integer
            Dim Losses As Integer
            Dim OpponentID As Integer
            Dim i As Integer

            For i = 0 To Opponents.Count - 1
                OpponentID = Val(Opponents(i))
                Wins = Wins + GetWins(TeamID, intPhase, OpponentID)
                Losses = Losses + GetLosses(TeamID, intPhase, OpponentID)
            Next

            If Wins + Losses = 0 Then
                Result = 0
            Else
                Result = Wins / (Wins + Losses)
            End If

            GetWinPercentage = Result


        End Function


        Function GetWins(ByVal TeamID As Integer, ByVal intPhase As enuPhase, ByVal OpponentID As Integer) As Integer
            Dim I As Integer
            Dim Result As Integer
            Dim Game As Game

            For Each Game In Me.InnerList
                With Game
                    If .AwayTeamID = TeamID Then
                        If OpponentID = 0 Or .HomeTeamID = OpponentID Then
                            If .AwayScore > .HomeScore Then
                                If .Phase = intPhase Then
                                    Result = Result + 1
                                End If
                            End If
                        End If
                    End If

                    If .HomeTeamID = TeamID Then
                        If OpponentID = 0 Or .AwayTeamID = OpponentID Then
                            If .HomeScore > .AwayScore Then
                                If .Phase = intPhase Then
                                    Result = Result + 1
                                End If
                            End If
                        End If
                    End If
                End With
            Next
            GetWins = Result
        End Function


        Function GetLosses(ByVal TeamID As Integer, ByVal intPhase As enuPhase, ByVal OpponentID As Integer) As Integer
            Dim I As Integer
            Dim Result As Integer
            Dim Game As Game
            For Each Game In Me.InnerList
                With Game
                    If .AwayTeamID = TeamID Then
                        If OpponentID = 0 Or .HomeTeamID = OpponentID Then
                            If .AwayScore < .HomeScore Then
                                If .Phase = intPhase Then
                                    Result = Result + 1
                                End If
                            End If
                        End If
                    End If

                    If .HomeTeamID = TeamID Then
                        If OpponentID = 0 Or .AwayTeamID = OpponentID Then
                            If .HomeScore < .AwayScore Then
                                If .Phase = intPhase Then
                                    Result = Result + 1
                                End If
                            End If
                        End If
                    End If
                End With
            Next
            GetLosses = Result
        End Function

        Function GetPointsForRank(ByVal TeamID As Integer) As Integer
            Dim Sim As Simulation = Simulation.GetInstance
            Dim i As Integer

            Dim arr As New ArrayList    '(Sim.League.Count - 1)
            Dim Amount As Integer = GetPointsFor(TeamID, enuPhase.Season, 0)
            Dim Rank As Integer = 1
            Dim x As Team

            For i = 0 To Sim.League.Count - 1
                x = Sim.League.Item(i)
                If GetPointsFor(x.TeamID, enuPhase.Season, 0) > Amount Then
                    Rank = Rank + 1
                End If
            Next

            Return Rank
        End Function

        Function GetPointsAgainstRank(ByVal TeamID As Integer) As Integer
            Dim Sim As Simulation = Simulation.GetInstance
            Dim i As Integer
            Dim arr As New ArrayList  '(Sim.League.Count - 1)
            Dim Amount As Integer = GetPointsAgainst(TeamID, enuPhase.Season, 0)
            Dim Rank As Integer = 1
            Dim x As Team

            For i = 0 To Sim.League.Count - 1
                x = Sim.League.Item(i)
                If GetPointsAgainst(x.TeamID, enuPhase.Season, 0) < Amount Then
                    Rank = Rank + 1
                End If
            Next

            Return Rank
        End Function

        Function GetPointsFor(ByVal TeamID As Integer, ByVal intPhase As enuPhase, ByVal OpponentID As Integer) As Integer
            Dim I As Integer
            Dim Result As Integer
            Dim Game As Game

            For Each Game In Me.InnerList
                With Game
                    If .AwayTeamID = TeamID Then
                        If OpponentID = 0 Or .HomeTeamID = OpponentID Then
                            If .Phase = intPhase Then
                                Result = Result + .AwayScore
                            End If
                        End If
                    End If

                    If .HomeTeamID = TeamID Then
                        If OpponentID = 0 Or .AwayTeamID = OpponentID Then
                            If .Phase = intPhase Then
                                Result = Result + .HomeScore
                            End If
                        End If
                    End If
                End With
            Next
            GetPointsFor = Result

        End Function

        Function GetPointMargin(ByVal TeamID As Integer, ByVal intPhase As enuPhase, ByVal OpponentID As Integer) As Integer
            Dim I As Integer
            Dim Result As Integer
            Dim Game As Game

            For Each Game In Me.InnerList
                With Game
                    If .AwayTeamID = TeamID Then
                        If OpponentID = 0 Or .HomeTeamID = OpponentID Then
                            If .Phase = intPhase Then
                                Result = Result + .AwayScore - .HomeScore
                            End If
                        End If
                    End If

                    If .HomeTeamID = TeamID Then
                        If OpponentID = 0 Or .AwayTeamID = OpponentID Then
                            If .Phase = intPhase Then
                                Result = Result + .HomeScore - .AwayScore
                            End If
                        End If
                    End If
                End With
            Next
            GetPointMargin = Result

        End Function

        Function GetPointMargin(ByVal TeamID As Integer, ByVal intPhase As enuPhase, ByVal Opponents As ArrayList) As Integer
            Dim I As Integer
            Dim Result As Integer
            Dim Game As Game
            Dim x As Integer
            Dim OpponentID As Integer

            For x = 0 To Opponents.Count - 1
                OpponentID = Opponents(x)
                For Each Game In Me.InnerList
                    With Game
                        If .AwayTeamID = TeamID Then
                            If OpponentID = 0 Or .HomeTeamID = OpponentID Then
                                If .Phase = intPhase Then
                                    Result = Result + .AwayScore - .HomeScore
                                End If
                            End If
                        End If

                        If .HomeTeamID = TeamID Then
                            If OpponentID = 0 Or .AwayTeamID = OpponentID Then
                                If .Phase = intPhase Then
                                    Result = Result + .HomeScore - .AwayScore
                                End If
                            End If
                        End If
                    End With
                Next
            Next
            GetPointMargin = Result

        End Function



        Function GetPointsAgainst(ByVal TeamID As Integer, ByVal intPhase As enuPhase, ByVal OpponentID As Integer) As Integer
            Dim I As Integer
            Dim Result As Integer
            Dim Game As Game

            For Each Game In Me.InnerList
                With Game
                    If .AwayTeamID = TeamID Then
                        If OpponentID = 0 Or .HomeTeamID = OpponentID Then
                            If .Phase = intPhase Then
                                Result = Result + .HomeScore
                            End If
                        End If
                    End If

                    If .HomeTeamID = TeamID Then
                        If OpponentID = 0 Or .AwayTeamID = OpponentID Then
                            If .Phase = intPhase Then
                                Result = Result + .AwayScore
                            End If
                        End If
                    End If
                End With
            Next
            GetPointsAgainst = Result

        End Function

        Function GetPointsAgainst(ByVal TeamID As Integer, ByVal intPhase As enuPhase, ByVal Opponents As ArrayList) As Integer
            Dim I As Integer
            Dim Result As Integer
            Dim Game As Game
            Dim OpponentID As Integer
            Dim x As Integer

            For x = 0 To Opponents.Count - 1
                If TeamID <> Opponents(x) Then
                    OpponentID = Opponents(x)
                    For Each Game In Me.InnerList
                        With Game
                            If .AwayTeamID = TeamID Then
                                If OpponentID = 0 Or .HomeTeamID = OpponentID Then
                                    If .Phase = intPhase Then
                                        Result = Result + .HomeScore
                                    End If
                                End If
                            End If

                            If .HomeTeamID = TeamID Then
                                If OpponentID = 0 Or .AwayTeamID = OpponentID Then
                                    If .Phase = intPhase Then
                                        Result = Result + .AwayScore
                                    End If
                                End If
                            End If
                        End With
                    Next
                End If
            Next
            GetPointsAgainst = Result

        End Function


        Function GetWinningStreak(ByVal TeamID As Integer, ByVal intPhase As enuPhase, ByVal OpponentID As Integer) As Integer
            Dim Schedule As New Schedule
            Dim Game As Game
            Dim Total As Integer

            Schedule = Me.GetReverseGameList(TeamID)
            For Each Game In Schedule
                If Game.AwayTeamID = TeamID Then
                    If Game.AwayScore > Game.HomeScore Then
                        Total = Total + 1
                    Else
                        Return Total
                    End If
                Else
                    If Game.HomeScore > Game.AwayScore Then
                        Total = Total + 1
                    Else
                        Return Total
                    End If
                End If
            Next
            Return Total

        End Function

        Function GetLastXGames(ByVal TeamID As Integer) As String
            Return GetLastXGames(TeamID, 10)
        End Function

        Function GetLastXGames(ByVal TeamID As Integer, ByVal GamesToUse As Integer) As String
            Dim Schedule As New Schedule
            Dim Game As Game
            Dim Win As Integer
            Dim Loss As Integer
            Dim Out As String
            Dim Count As Integer

            Schedule = Me.GetReverseGameList(TeamID)
            For Each Game In Schedule
                If Game.AwayTeamID = TeamID Then
                    If Game.AwayScore > Game.HomeScore Then
                        Win += 1
                        Count += 1
                    Else
                        Loss += 1
                        Count += 1
                    End If
                Else
                    If Game.HomeScore > Game.AwayScore Then
                        Win += 1
                        Count += 1
                    Else
                        Loss += 1
                        Count += 1
                    End If
                End If
                If Count = GamesToUse Then Exit For
            Next
            Out = Win & " - " & Loss
            Return FixSort(Win, Out)
        End Function

        Function GetHomeRecord(ByVal TeamID As Integer)
            Dim Schedule As New Schedule
            Dim Game As Game
            Dim Win As Integer
            Dim Loss As Integer
            Dim Out As String
            Dim Count As Integer

            Schedule = Me.GetReverseGameList(TeamID)
            For Each Game In Schedule
                If Game.HomeTeamID = TeamID Then
                    If Game.HomeScore > Game.AwayScore Then
                        Win += 1
                        Count += 1
                    Else
                        Loss += 1
                        Count += 1
                    End If
                End If
            Next
            Out = Win & " - " & Loss
            Return FixSort(Win, Out)
        End Function

        Function GetHomeAttendance(ByVal TeamID As Integer) As Integer
            Dim Schedule As New Schedule
            Dim Game As Game
            Dim Fans As Integer
            Dim Out As String

            Schedule = Me.GetReverseGameList(TeamID)
            For Each Game In Schedule
                If Game.HomeTeamID = TeamID Then
                    Fans = Fans + Game.Attendance
                End If
            Next
            Return Fans
        End Function

        Function GetAttendanceRank(ByVal TeamID As Integer) As Integer
            Dim Sim As Simulation = Simulation.GetInstance
            Dim i As Integer
            Dim arr As New ArrayList(Sim.League.Count - 1)
            Dim Amount As Integer = GetHomeAttendance(TeamID)
            Dim Rank As Integer = 1
            Dim x As Team

            For i = 0 To Sim.League.Count - 1
                x = Sim.League.Item(i)
                If Me.GetHomeAttendance(x.TeamID) > Amount Then
                    Rank = Rank + 1
                End If
            Next

            Return Rank
        End Function

        Function GetHomeGames(ByVal TeamID As Integer) As Integer
            Dim Schedule As New Schedule
            Dim Game As Game
            Dim Count As Integer
            Dim Out As String

            Schedule = Me.GetReverseGameList(TeamID)
            For Each Game In Schedule
                If Game.HomeTeamID = TeamID Then
                    Count = Count + 1
                End If
            Next
            Return Count
        End Function

        Function GetHomeAttendanceAvg(ByVal TeamID As Integer) As Integer
            If Me.GetHomeGames(TeamID) > 0 Then
                Return Me.GetHomeAttendance(TeamID) / Me.GetHomeGames(TeamID)
            End If
        End Function

        Function GetAwayRecord(ByVal TeamID As Integer)
            Dim Schedule As New Schedule
            Dim Game As Game
            Dim Win As Integer
            Dim Loss As Integer
            Dim Out As String
            Dim Count As Integer

            Schedule = Me.GetReverseGameList(TeamID)
            For Each Game In Schedule
                If Game.AwayTeamID = TeamID Then
                    If Game.AwayScore > Game.HomeScore Then
                        Win += 1
                        Count += 1
                    Else
                        Loss += 1
                        Count += 1
                    End If
                End If
            Next
            Out = Win & " - " & Loss
            Return FixSort(Win, Out)

        End Function

        Function GetDivisionRecord(ByVal TeamID As Integer)
            Return GetDivisionRecord(TeamID, False)
        End Function

        Function GetDivisionRecord(ByVal TeamID As Integer, ByVal WinsOnly As Boolean)
            Dim Schedule As New Schedule
            Dim Game As Game
            Dim Win As Integer
            Dim Loss As Integer
            Dim Out As String
            Dim Count As Integer
            Dim DivisionID As Integer = GetDivisionFromTeamID(TeamID)

            Schedule = Me.GetReverseGameList(TeamID)
            For Each Game In Schedule
                If Game.HomeTeamID = TeamID Then
                    If GetDivisionFromTeamID(Game.AwayTeamID) = DivisionID Then
                        If Game.HomeScore > Game.AwayScore Then
                            Win += 1
                            Count += 1
                        Else
                            Loss += 1
                            Count += 1
                        End If
                    End If
                ElseIf Game.AwayTeamID = TeamID Then
                    If GetDivisionFromTeamID(Game.HomeTeamID) = DivisionID Then
                        If Game.AwayScore > Game.HomeScore Then
                            Win += 1
                            Count += 1
                        Else
                            Loss += 1
                            Count += 1
                        End If
                    End If
                End If
            Next
            If WinsOnly Then
                Return Win
            Else
                Out = Win & " - " & Loss
                Return FixSort(Win, Out)
            End If

        End Function

        Function GetConferenceRecord(ByVal TeamID As Integer)
            Return GetConferenceRecord(TeamID, False)
        End Function

        Function GetConferenceRecord(ByVal TeamID As Integer, ByVal WinsOnly As Boolean)
            Dim Schedule As New Schedule
            Dim Game As Game
            Dim Win As Integer
            Dim Loss As Integer
            Dim Out As String
            Dim Count As Integer
            Dim ConferenceID As Integer = GetConferenceFromTeamID(TeamID)

            Schedule = Me.GetReverseGameList(TeamID)
            For Each Game In Schedule
                If Game.HomeTeamID = TeamID Then
                    If GetConferenceFromTeamID(Game.AwayTeamID) = ConferenceID Then
                        If Game.HomeScore > Game.AwayScore Then
                            Win += 1
                            Count += 1
                        Else
                            Loss += 1
                            Count += 1
                        End If
                    End If
                ElseIf Game.AwayTeamID = TeamID Then
                    If GetConferenceFromTeamID(Game.HomeTeamID) = ConferenceID Then
                        If Game.AwayScore > Game.HomeScore Then
                            Win += 1
                            Count += 1
                        Else
                            Loss += 1
                            Count += 1
                        End If
                    End If
                End If
            Next

            If WinsOnly Then
                Return Win
            Else
                Out = Win & " - " & Loss
                Return FixSort(Win, Out)
            End If

        End Function


        Function GetLosingStreak(ByVal TeamID As Integer, ByVal intPhase As enuPhase, ByVal OpponentID As Integer) As Integer
            Dim Schedule As New Schedule
            Dim Game As Game
            Dim Total As Integer

            Schedule = Me.GetReverseGameList(TeamID)
            For Each Game In Schedule
                If Game.AwayTeamID = TeamID Then
                    If Game.AwayScore < Game.HomeScore Then
                        Total = Total + 1
                    Else
                        Return Total
                    End If
                Else
                    If Game.HomeScore < Game.AwayScore Then
                        Total = Total + 1
                    Else
                        Return Total
                    End If
                End If
            Next
            Return Total

        End Function

        Function GetStreakText(ByVal TeamID As Integer, ByVal intPhase As enuPhase, ByVal OpponentID As Integer) As String

            Dim Out As String
            Dim W As Integer
            Dim L As Integer

            'If TeamID = 7 Then Stop
            W = GetWinningStreak(TeamID, intPhase, OpponentID)
            L = GetLosingStreak(TeamID, intPhase, OpponentID)

            If W > 0 Then
                Out = "W" & W
            End If

            If L > 0 Then
                Out = "L" & L
            End If

            If Out = "" Then Out = "W0"

            GetStreakText = Out

            Exit Function

        End Function

        Function GetStreakNarrative(ByVal TeamID As Integer, ByVal intPhase As enuPhase, ByVal OpponentID As Integer) As String

            Dim Out As String
            Dim W As Integer
            Dim L As Integer

            W = GetWinningStreak(TeamID, intPhase, OpponentID)
            L = GetLosingStreak(TeamID, intPhase, OpponentID)

            If W > 0 Then
                Out = W & " game winning streak"
            End If

            If L > 0 Then
                Out = L & " game losing streak"
            End If

            If Out = "" Then Out = "fresh season in front of them"

            Return Out

            Exit Function

        End Function



        Function GetTotalGames(ByVal TeamID As Integer, ByVal intPhase As enuPhase) As Integer
            Dim I As Integer
            Dim Result As Integer
            Dim Game As Game

            For Each Game In Me.InnerList
                With Game
                    If .Phase = intPhase Then
                        If .HomeTeamID = TeamID Or .AwayTeamID = TeamID Then
                            'MsgBox .HomeTeamID & " v " & .AwayTeamID
                            Result = Result + 1
                        End If
                    End If
                End With
            Next

            GetTotalGames = Result

        End Function

        Function GetDivisionStandings(ByVal intDivisionID As Integer) As DataTable
            Dim DTUtility As New DataTableUtility
            Dim I As Integer
            Dim LeaderID As Integer = Me.GetLeaderInDivision(intDivisionID)

            Dim Table As New DataTable
            Table = DTUtility.GetStandingStructure()

            Dim Team As New Team
            For Each Team In mobjLeague
                If Team.DivisionID = intDivisionID Then
                    I = Team.TeamID
                    Dim Row As DataRow = Table.NewRow()
                    With Row
                        .Item("ID") = I
                        .Item("Team") = Team.Name
                        .Item("W") = Me.GetWins(I, enuPhase.Season, 0)
                        .Item("L") = Me.GetLosses(I, enuPhase.Season, 0)
                        .Item("PF") = Me.GetPointsFor(I, enuPhase.Season, 0)
                        .Item("PA") = Me.GetPointsAgainst(I, enuPhase.Season, 0)
                        .Item("Streak") = Me.GetStreakText(I, enuPhase.Season, 0)
                        .Item("GB") = Me.GetGamesBehind(Team.TeamID, LeaderID)
                        .Item("PCT") = Format(Me.GetWinPercentage(I, enuPhase.Season, 0), "0.000")
                        .Item("Last10") = Me.GetLastXGames(I)
                        .Item("Home") = Me.GetHomeRecord(I)
                        .Item("Away") = Me.GetAwayRecord(I)
                        .Item("DIV") = Me.GetDivisionRecord(I)
                        .Item("CONF") = Me.GetConferenceRecord(I)
                    End With
                    Table.Rows.Add(Row)
                End If
            Next
            Table.TableName = "Standings"
            Return Table
        End Function

        Private Function GetGamesBehind(ByVal W1 As Integer, ByVal L1 As Integer, ByVal W2 As Integer, ByVal L2 As Integer) As Double
            Dim Result As Double

            Result = ((-(W1 + L2) / 2 + Math.Sqrt((W1 + L2) ^ 2 - (4 * W1 * L2) + (4 * W2 * L1)) / 2))

            Return Result
        End Function

        Private Function GetGamesBehind(ByVal LeaderID As Integer, ByVal OtherID As Integer) As Double
            Dim Result As Double

            If LeaderID = OtherID Then
                Return 0
            Else
                Result = GetGamesBehind(GetWins(LeaderID, enuPhase.Season, 0), GetLosses(LeaderID, enuPhase.Season, 0), _
                 GetWins(OtherID, enuPhase.Season, 0), GetLosses(OtherID, enuPhase.Season, 0))
                Return (RoundGamesBehind(Result))
            End If
        End Function

        Private Function RoundGamesBehind(ByVal GamesBehind As Double) As Double
            Dim FirstPart As Integer = Int(GamesBehind)
            Dim SecondPart As Double = Math.Round(GamesBehind, 1) - FirstPart

            If SecondPart >= 0.5 Then
                Return FirstPart + 0.5
            Else
                Return FirstPart
            End If


        End Function

        Public Function GetLeaderInLeague() As Integer
            Dim Team As New Team
            Dim Out As Integer

            Dim W As Integer
            Dim L As Integer
            Dim ID As Integer
            Dim Pct As Double

            Dim WThreshold As Double
            Dim Total As Integer
            Dim TotalThreshold As Integer = 1000000

            For Each Team In mobjLeague
                ID = Team.TeamID
                W = Me.GetWins(ID, enuPhase.Season, 0)
                L = Me.GetLosses(ID, enuPhase.Season, 0)

                If L + W > 0 Then
                    Pct = W / (W + L)
                Else
                    Pct = 0
                End If

                Total = W + L

                If Pct > WThreshold Then
                    'If Total <= TotalThreshold Then
                    Out = ID
                    WThreshold = Pct
                    TotalThreshold = Total
                    'End If
                End If
            Next

            Return Out
        End Function

        Public Function GetLeaderInDivision(ByVal intDivisionID As Integer) As Integer
            Dim Team As New Team
            Dim Out As Integer

            Dim W As Integer
            Dim L As Integer
            Dim ID As Integer
            Dim Pct As Double

            Dim WThreshold As Double
            Dim Total As Integer
            Dim TotalThreshold As Integer = 1000000

            For Each Team In mobjLeague
                If Team.DivisionID = intDivisionID Then
                    ID = Team.TeamID
                    W = Me.GetWins(ID, enuPhase.Season, 0)
                    L = Me.GetLosses(ID, enuPhase.Season, 0)

                    If L + W > 0 Then
                        Pct = W / (W + L)
                    Else
                        Pct = 0
                    End If

                    Total = W + L

                    If Pct > WThreshold Then
                        'If Total <= TotalThreshold Then
                        Out = ID
                        WThreshold = Pct
                        TotalThreshold = Total
                        'End If
                    End If
                End If
            Next

            Return Out

        End Function

        Private Function GetReverseGameList(ByVal TeamID As Integer) As Schedule
            Dim Schedule As New Schedule
            Dim Game As Game

            For Each Game In Me.InnerList
                If Game.AwayTeamID = TeamID Or Game.HomeTeamID = TeamID Then
                    If Game.Status = ISMGameScheduleStatus.Played Then
                        Schedule.Add(Game)
                    End If
                End If
            Next
            Schedule.ReverseSort()
            Return Schedule
        End Function

        Private Function FixSort(ByVal SortValue As Integer, ByVal Output As String)
            If SortValue < 10 Then
                Return " " & Output
            Else
                Return Output
            End If
        End Function

        Private Function GetDivisionFromTeamID(ByVal TeamID As Integer) As Integer
            Return Sim.League.GetTeamByID(TeamID).DivisionID
        End Function

        Private Function GetConferenceFromTeamID(ByVal TeamID As Integer) As Integer
            Return Sim.League.GetTeamByID(TeamID).ConferenceID
        End Function

        Public Function GetTeamStanding(ByVal TeamID As Integer) As ISoccerSim.Finances.Team.AttendanceManager.HomeTeamRecord
            If Me.GetWins(TeamID, enuPhase.Season, 0) + Me.GetLosses(TeamID, enuPhase.Season, 0) / Me.GetTotalGames(TeamID, enuPhase.Season) <= 0.33 Then
                Return Finances.Team.AttendanceManager.HomeTeamRecord.EarlySeason
            End If

            Dim WinPercentage As Double
            If WinPercentage < 0.4 Then
                Return Finances.Team.AttendanceManager.HomeTeamRecord.LosingTeam
            ElseIf WinPercentage >= 0.4 And WinPercentage <= 0.6 Then
                Return Finances.Team.AttendanceManager.HomeTeamRecord.MiddlePack
            ElseIf WinPercentage > 0.6 Then
                Return Finances.Team.AttendanceManager.HomeTeamRecord.Winning
            End If

            If Me.GetLeaderInLeague() = TeamID Then
                Return Finances.Team.AttendanceManager.HomeTeamRecord.Leading
            End If
        End Function

        Public Function GetStandingText(ByVal TeamID As Integer) As String
            Return Me.GetWins(TeamID, enuPhase.Season, 0) & " - " & Me.GetLosses(TeamID, enuPhase.Season, 0)
        End Function

    End Class
End Namespace