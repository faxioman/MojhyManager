'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Option Strict Off
Option Explicit On 

'Imports Microsoft.VisualBasic
'Imports System
'Imports System.Drawing
'Imports System.Windows.Forms

Namespace Utility.DataGrid


Public Class DataGridGraphColumn
    Inherits DataGridTextBoxColumn

    Private _col As Integer
    Dim Sim As Simulation = Simulation.GetInstance()

    Public Delegate Sub EnableCellEventHandler(ByVal sender As Object, ByVal e As DataGridEnableEventArgs)

    Sub New(ByVal column As Integer)
        MyBase.New()
        _col = column
        End Sub

        Public IsGraphColumn As Boolean
        Public ActualRatingColumn As Integer
        Public PotentialRatingColumn As Integer

        Public ParentDataGrid As System.Windows.Forms.DataGrid


        Public Event CheckCellEnabled As EnableCellEventHandler
        Protected Overloads Overrides Sub Paint(ByVal g As Graphics, ByVal bounds As Rectangle, ByVal source As CurrencyManager, ByVal rowNum As Integer, ByVal backBrush As Brush, ByVal foreBrush As Brush, ByVal alignToRight As Boolean)

            MyBase.Paint(g, bounds, source, rowNum, backBrush, foreBrush, alignToRight)
            If Me.IsGraphColumn Then
                Dim act As New SolidBrush(Sim.Skin.ActualRatingColor)
                Dim pot As New SolidBrush(Sim.Skin.PotentialRatingColor)
                Dim graph As New SolidBrush(Sim.Skin.RatingGraphColor)
                Dim back As New SolidBrush(Sim.Skin.RatingGridBackColor)
                Dim actBar As Integer
                Dim potBar As Integer
                Dim graphBar As Integer = 100
                Dim graphLine As Integer

                If Not (Me.ParentDataGrid Is Nothing) Then
                    graphBar = bounds.Width - 2 '8
                    actBar = (Me.ParentDataGrid(rowNum, Me.ActualRatingColumn) / 100) * graphBar
                    potBar = (Me.ParentDataGrid(rowNum, Me.PotentialRatingColumn) / 100) * graphBar
                    graphLine = (bounds.Width / 4)
                End If

                g.FillRectangle(back, bounds.X, bounds.Y, bounds.Width, bounds.Height)
                g.FillRectangle(graph, bounds.X + 1, bounds.Y + 1, graphBar, bounds.Height - 2)
                g.FillRectangle(pot, bounds.X + 1, bounds.Y + 1, potBar, bounds.Height - 2) '2/2/4
                g.FillRectangle(act, bounds.X + 1, bounds.Y + 1, actBar, bounds.Height - 2)



                back.Dispose()
                act.Dispose()
                pot.Dispose()
                graph.Dispose()
            End If

        End Sub
        Protected Overloads Overrides Sub Edit(ByVal source As CurrencyManager, ByVal rowNum As Integer, ByVal bounds As Rectangle, ByVal [readOnly] As Boolean, ByVal instantText As String, ByVal cellIsVisible As Boolean)

            Dim enabled As Boolean
            enabled = True
            Dim e As DataGridEnableEventArgs
            e = New DataGridEnableEventArgs(rowNum, _col, enabled)
            RaiseEvent CheckCellEnabled(Me, e)
            If e.EnableValue Then
                MyBase.Edit(source, rowNum, bounds, [readOnly], instantText, cellIsVisible)
            End If

        End Sub
End Class

Public Class DataGridEnableEventArgs
    Inherits EventArgs
    Private _column As Integer
    Private _row As Integer
    Private _enablevalue As Boolean
    'Fields
    'Constructors
    'Methods
    Sub New(ByVal row As Integer, ByVal col As Integer, ByVal val As Boolean)
        MyBase.New()
        _row = row
        _column = col
        _enablevalue = val

    End Sub
    Public Property Column() As Integer
        Get

            Return _column

        End Get
        Set(ByVal Value As Integer)

            _column = Value

        End Set
    End Property
    Public Property Row() As Integer
        Get

            Return _row

        End Get
        Set(ByVal Value As Integer)

            _row = Value

        End Set
    End Property
    Public Property EnableValue() As Boolean
        Get

            Return _enablevalue

        End Get
        Set(ByVal Value As Boolean)

            _enablevalue = Value

        End Set
    End Property
End Class

End Namespace