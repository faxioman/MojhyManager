Option Explicit On 
Imports System
Imports NUnit.Framework

Namespace Tests

    <TestFixture()> Public Class VBTest

        <SetUp()> Public Sub SetUp()
        End Sub

        <TearDown()> Public Sub TearDown()
        End Sub

        <Test()> Public Sub TestMe()
            'Assert.Fail("failing test", False)
        End Sub

        <Test()> Public Sub TestTrace()
            'Trace/Debug messages won't be output when running all tests in assembly.
            'Trace.WriteLine("Trace...")
            'Trace.Assert(True = False, "true is not false", "- more detail")
            'Trace.WriteLine("Hello World!", "Trace")
        End Sub


        '<Test(), ExpectedException(GetType(NullReferenceException))> Public Sub TestExpectedException()
        '    Throw New NullReferenceException("expected")
        'End Sub

        '<Test(), Ignore("ignored test")> Public Sub TestIgnore()
        '    Throw New NullReferenceException("expected")
        'End Sub

    End Class
End Namespace