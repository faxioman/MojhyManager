'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
Imports ISoccerSim.Leagues
Imports ISoccerSim.Rosters

Namespace Substitution
    Public Class SubstitutionLineSet
        Inherits System.Collections.CollectionBase
        Implements ICloneable

        Public SubstitutionLineID As Integer
        Public TeamID As Integer
        Public SubLineTypeID As ISMSublineType

        Default Property Item(ByVal index As ISMSublineType) As SubstitutionLine
            Get
                Return CType(InnerList.Item(index), SubstitutionLine)
            End Get
            Set(ByVal Value As SubstitutionLine)
                InnerList.Item(index) = Value
            End Set
        End Property


        Sub Add(ByVal value As SubstitutionLine)
            InnerList.Add(value)
        End Sub

        Sub Create(ByVal SublinetypeID As ISMSublineType, ByVal SubstitutionLineID As Integer, ByVal TeamID As Integer)
            Dim Item As New SubstitutionLine()
            With Item
                .SubLineTypeID = SublinetypeID
                .SubstitutionLineID = SubstitutionLineID
                .TeamID = TeamID
            End With
            InnerList.Add(Item)

        End Sub


        Sub Load(ByVal TeamID As Integer)
            Dim DS As New DataServices.TeamTables()
            Dim DR As OleDb.OleDbDataReader = DS.GetSubstitutionSet(TeamID)
            Me.InnerList.Clear()

            Do While DR.Read()
                With DR
                    Call Create(.Item("SubLineTypeID"), .Item("SubstitutionLineID"), .Item("teamID"))
                End With
            Loop
            DR.Close()
            DS.Close()

            If Not InnerListValid() Then
                Throw New Exception("Substitution set does not meet minimum requirements.")
            Else
                Dim objLine As SubstitutionLine
                For Each objLine In Me.InnerList
                    objLine.Load(objLine.SubstitutionLineID)
                Next
            End If


        End Sub

        Sub Insert()
            Dim Subline As SubstitutionLine
            Dim SubSlot As SubstitutionSlot
            If InnerListValid() Then
                For Each Subline In Me.InnerList
                    Subline.TeamID = Me.TeamID
                    Subline.Insert()
                    For Each SubSlot In Subline
                        SubSlot.SublineID = Subline.SubstitutionLineID
                        SubSlot.Insert()
                    Next
                Next
            Else
                Throw New Exception("Substitution set does not meet minimum requirements.")
            End If
        End Sub

        Function Clone() As Object Implements ICloneable.Clone
            Dim Subline As New SubstitutionLineSet()
            Subline = Me
            Return Subline
        End Function

        Private Function InnerListValid() As Boolean
            If Me.InnerList.Count >= 5 Then
                Return True
            Else
                Return False
            End If
        End Function

        Public Sub SwapPlayerAfterEjection(ByVal objTeam As Teams.Team, ByVal objPlayer As Players.Player)
            Dim Line As SubstitutionLine
            Dim gps As SimEngine.GamePlayerSet = objTeam.FieldManager.GetSubstitutionCandidates(objPlayer)
            Dim SwapPlayer As Players.Player

            For Each Line In Me.InnerList
                If Line.IsPlayerOnLine(objPlayer) Then
                    For Each SwapPlayer In gps
                        If Not Line.IsPlayerOnLine(SwapPlayer) Then
                            Line.SwapPlayer(objPlayer, SwapPlayer)
                            Exit For
                        End If
                    Next
                End If
            Next
        End Sub


        Public Function IsLegal(ByVal TeamID As Integer) As Boolean
            Dim i As Integer
            Dim PlayerID As Integer
            Dim r As Roster = Simulation.GetInstance.League.GetTeamByID(TeamID).Roster

            If Not Me.InnerListValid Then
                Try
                    Me.Load(TeamID)
                Catch
                    Return False
                End Try
            End If

            If Me.InnerListValid Then
                Dim Item As SubstitutionLine
                For Each Item In Me.InnerList
                    If Item.Count <> 6 Then
                        Return False
                        Exit For
                    End If

                    'Verify players are on team if they are in substitution list...
                    For i = 0 To Item.Count
                        PlayerID = Item.GetPlayerIDForPosition(i)
                        If PlayerID > 0 Then
                            If Not r Is Nothing Then
                                If Not r.IsPlayerOnRoster(PlayerID) Then
                                    Return False
                                End If
                            End If
                        End If
                    Next
                Next
            End If

            Return True
        End Function
    End Class
End Namespace