Namespace Reporting.Narrative
    Public Interface INarrative
        Property Name() As String
        Function Generate(ByVal TeamID As Integer) As String
        Sub Save(ByVal TeamID As Integer, ByVal OpponentID As Integer, ByVal GameDate As Date)
    End Interface
End Namespace

