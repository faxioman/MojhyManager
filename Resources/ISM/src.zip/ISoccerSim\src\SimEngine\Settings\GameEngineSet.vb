'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Players
Imports ISoccerSim.SimEngine
Imports ISoccerSim.SimEngine.Actions


Namespace SimEngine.Settings

	Public Enum ISM_GameSettingType
		Dribble = 1
		Pass = 2
		PassReception = 3
		CheckOverGlass = 4
		KickOff = 5
		Penalty = 6
		ShotAttempt = 7
		ShotInGoal = 8
		ScrambleForBall = 9
		ShotOnTarget = 10
		DribbleVersusPass = 11
		ShotSetupActions = 12

		PassSequence = 100
		DribbleSequence = 101
		ShotSequence = 102
	End Enum

	Public Enum ISM_GameSetting
		OffensiveAdj = 1
		DefensiveAdj = 2
		OffensiveRatingMult = 3
		DefensiveRatingMult = 4
		PassToAdj = 5
		PassToRatingMult = 6
		GenericAdj = 7
		GenericRatingMult = 8
		Failure = 9
		FieldPenalty = 10
		OffensiveSecRatingMult = 11
		DefensiveSecRatingMult = 12
		MaxAmount = 13
		OptForDribble = 14
		OptForPass = 15
		MinAmount = 16
	End Enum

	Public Class GameEngineSet
		Inherits CollectionBase

		Sub Add(ByVal objItem As GameEngineSetting)
			Me.InnerList.Add(objItem)
		End Sub

		Default Public Property Item(ByVal Index As Integer) As GameEngineSetting
			Get
				Return CType(Me.InnerList.Item(Index), GameEngineSetting)
			End Get
			Set(ByVal Value As GameEngineSetting)
				Me.InnerList.Item(Index) = Value
			End Set
		End Property

		Sub Create(ByVal Type As ISM_GameSettingType, ByVal Setting As ISM_GameSetting, ByVal Value As Double)
			Dim Item As New GameEngineSetting()
			With Item
				.Value = Value
				.Type = Type
				.Setting = Setting
				.FieldPenalty = ISMBallVertical.None
			End With
			Me.Add(Item)
		End Sub

		Sub Create(ByVal Type As ISM_GameSettingType, ByVal Setting As ISM_GameSetting, ByVal Value As Double, ByVal FieldPenalty As ISMBallVertical)
			Dim Item As New GameEngineSetting()
			With Item
				.Value = Value
				.Type = Type
				.Setting = Setting
				.FieldPenalty = FieldPenalty
			End With
			Me.Add(Item)
		End Sub

		Function GetValue(ByVal Type As ISM_GameSettingType, ByVal Setting As ISM_GameSetting) As Double
			Dim Item As GameEngineSetting
			For Each Item In Me.InnerList
				If Item.Type = Type Then
					If Item.Setting = Setting Then
						Return Item.Value
					End If
				End If
			Next
			Debug.Assert(False, "Unknown setting requested")
		End Function

		Function GetFieldPenalty(ByVal Type As ISM_GameSettingType, ByVal FieldPenalty As ISMBallVertical) As Double
			Dim Item As GameEngineSetting
			For Each Item In Me.InnerList
				If Item.FieldPenalty = FieldPenalty Then
					If Item.Type = Type Then
						Return Item.Value
					End If
				End If
			Next
			Return 0
		End Function

	End Class
End Namespace