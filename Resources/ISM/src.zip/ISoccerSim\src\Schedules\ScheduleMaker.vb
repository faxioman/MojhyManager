'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.Collections
Imports ISoccerSim.Teams
Imports ISoccerSim.Leagues

Namespace Schedules
	Public Enum ISS_GameGenerationType
		Divisional
		Conference
		OtherConference
	End Enum

	Public Class ScheduleMaker
		Inherits CollectionBase


		' This class produces a schedule by first generating matchups.  After that 
		' is done, matchups are strung together into a matchup line (analagous to a
		' week's worth of games in football - this number is setable for the class
		' to indicate the maximum number of games for any given date.  Days of the 
		' week may also be specified.  The return value for this class is a completed
		' schedule of games.
		'
		' This class supercedes the old CSchedule class since the requirements of
		' multiple conferences, divisions, etc., killed the hell out of it.  That, and
		' it was hard-wired.  :-)
		'
		' Now, on with the show....

		Private TeamList As New ArrayList()

		Public MaxGamesOnSunday As Integer = 0
		Public MaxGamesOnMonday As Integer = 3
		Public MaxGamesOnTuesday As Integer = 0
		Public MaxGamesOnWednesday As Integer = 3
		Public MaxGamesOnThursday As Integer = 0
		Public MaxGamesOnFriday As Integer = 5
		Public MaxGamesOnSaturday As Integer = 5
		Public Shuffles As Integer = 100
		Public StartDate As Date

		Public League As League
        Public GamesFilled As Integer

        Dim r As MathService = MathService.GetInstance

		Default Property Item(ByVal index As Integer) As Game
			Get
				Return CType(InnerList.Item(index), Game)
			End Get
			Set(ByVal Value As Game)
				InnerList.Item(index) = Value
			End Set
		End Property

		Sub Add(ByVal value As Game)
			InnerList.Add(value)
		End Sub

		Sub New(ByVal objLeague As League)
			Dim objTeam As Team
			Me.League = objLeague
			For Each objTeam In Me.League
                Dim Shell As New TeamShell
                With Shell
                    .TeamID = objTeam.TeamID
                    .ConferenceID = objTeam.ConferenceID
                    .DivisionID = objTeam.DivisionID
                End With
                Me.TeamList.Add(Shell)
            Next
        End Sub

        Sub Create()
            Call GetSeasonOpener()
            Call LoadMatchups()
            Call CreateSchedule()
        End Sub

        Function GetGames() As ArrayList
            Return Me.InnerList
        End Function

        Private Sub LoadMatchups()
            Dim Teams As New ArrayList
            Dim Division As Division
            Dim Conference As Conference


            'Add division games...
            For Each Division In Me.League.Divisions
                Teams = LoadDivisionTeams(Division)
                Me.AddMatchupsForDivisions(Teams)
            Next

            'Add conference games, if required...
            'Note:  This is hardcoded at two conferences for the moment
            If Me.League.Conferences.Count = 2 Then
                Call Me.AddMatchupsBetweenConferences()
            End If

            'Add interconference games...
            Call AddMatchupsBetweenConferenceOpponents()

        End Sub

        Private Function GetRandomMatchup() As Game

            Dim x As Integer
            Do
                If Me.Count = Me.GamesFilled Then
                    Exit Function
                Else
                    x = r.RandomNumber(0, Me.InnerList.Count)

                    If CType(Me.InnerList.Item(x), Game).Used = False Then
                        Return CType(Me.InnerList.Item(x), Game)
                    End If
                End If
            Loop
        End Function

        Private Function GetGamesForDay(ByVal intMax As Integer, ByVal pdatGameDate As Date) As GamesOnDay
            Dim GamesOnDay As New GamesOnDay
            Dim Game As Game

            Do Until GetLegalBreak(GamesOnDay, intMax)
                Game = GetRandomMatchup()
                If GamesOnDay.IsGameValid(Game) Then
                    Game.Used = True
                    Game.GameDate = pdatGameDate
                    GamesOnDay.Add(Game)
                    Me.GamesFilled = Me.GamesFilled + 1
                End If
            Loop

            Return GamesOnDay
        End Function


        Private Function GetLegalBreak(ByVal GamesOnDay As GamesOnDay, ByVal intMax As Integer) As Boolean
            If GamesOnDay.Count = intMax Or _
             GamesOnDay.Count = Me.TeamList.Count / 2 Or _
             GamesOnDay.IsThresholdReached Or _
             Me.Count = Me.GamesFilled Then
                Return True
            End If
            Return False

        End Function

        Private Sub CreateSchedule()
            Dim pdatGameDate As DateTime = Me.StartDate
            Me.GamesFilled = 0

            Do Until Me.GamesFilled >= Me.Count
                Dim Games As Integer = Me.MaxGamesForDate(pdatGameDate)
                If Games > 0 Then
                    Dim GamesOnDay As New GamesOnDay
                    GamesOnDay = Me.GetGamesForDay(Games, pdatGameDate)
                    'Console.WriteLine(pdatGameDate & ":" & Me.GamesFilled & " of " & Me.Count)
                End If
                pdatGameDate = pdatGameDate.AddDays(1)
            Loop
        End Sub

        Private Function MaxGamesForDate(ByVal datDate As Date) As Integer
            Dim Out As Integer
            Select Case datDate.DayOfWeek
                Case DayOfWeek.Sunday
                    Out = Me.MaxGamesOnSunday
                Case DayOfWeek.Monday
                    Out = Me.MaxGamesOnMonday
                Case DayOfWeek.Tuesday
                    Out = Me.MaxGamesOnTuesday
                Case DayOfWeek.Wednesday
                    Out = Me.MaxGamesOnWednesday
                Case DayOfWeek.Thursday
                    Out = Me.MaxGamesOnThursday
                Case DayOfWeek.Friday
                    Out = Me.MaxGamesOnFriday
                Case DayOfWeek.Saturday
                    Out = Me.MaxGamesOnSaturday
            End Select
            If Out > Me.TeamList.Count / 2 Then
                Out = Me.TeamList.Count / 2
            End If

            Return Out
        End Function


        Private Function LoadDivisionTeams(ByVal objDivision As Division) As ArrayList
            Dim List As New ArrayList
            Dim Shell As New TeamShell

            For Each Shell In Me.TeamList
                If Shell.DivisionID = objDivision.ID Then
                    List.Add(Shell)
                End If
            Next
            Return List
        End Function

        Private Sub AddMatchupsBetweenConferenceOpponents()
            Dim Conference As Conference
            For Each Conference In Me.League.Conferences
                Call GetIntraConferenceDivisionMatchups(Conference.ID)
            Next
        End Sub

        Private Sub GetIntraConferenceDivisionMatchups(ByVal objConferenceID As Integer)
            Dim x As Integer
            Dim y As Integer

            For x = 0 To Me.League.Divisions.Count - 1
                For y = x + 1 To Me.League.Divisions.Count - 1
                    Call AddMatchupsBetweenDivisions(Me.League.Divisions(x), Me.League.Divisions(y))
                Next
            Next
        End Sub

        Private Sub AddMatchupsBetweenDivisions(ByVal objDivision1 As Division, ByVal objDivision2 As Division)
            Dim intTotal As Integer = Me.League.InterdivisionMatchups

            If intTotal = 0 Then Exit Sub

            Dim T As TeamShell
            Dim objTeams As ArrayList = Me.TeamList

            Dim i As Integer
            Dim x As Integer
            Dim y As Integer

            For i = 1 To intTotal / 2
                For x = 0 To objTeams.Count - 1
                    For y = x + 1 To objTeams.Count - 1
                        If CType(objTeams.Item(x), TeamShell).DivisionID = objDivision1.ID And _
                         CType(objTeams.Item(y), TeamShell).DivisionID = objDivision2.ID Then

                            Dim Game As New Game
                            With Game
                                .AwayTeamID = CType(objTeams.Item(x), TeamShell).TeamID
                                .HomeTeamID = CType(objTeams.Item(y), TeamShell).TeamID
                            End With
                            Me.InnerList.Add(Game)

                            Game = New Game
                            With Game
                                .AwayTeamID = CType(objTeams.Item(y), TeamShell).TeamID
                                .HomeTeamID = CType(objTeams.Item(x), TeamShell).TeamID
                            End With
                            Me.InnerList.Add(Game)
                        End If
                    Next
                Next
            Next

        End Sub

        Private Sub AddMatchupsForDivisions(ByVal objTeams As ArrayList)

            Dim intTotal As Integer = Me.League.InterdivisionMatchups

            If intTotal = 0 Then Exit Sub

            Dim T As TeamShell

            Dim i As Integer
            Dim x As Integer
            Dim y As Integer

            For i = 1 To intTotal / 2
                For x = 0 To objTeams.Count - 1
                    For y = x + 1 To objTeams.Count - 1
                        Dim Game As New Game
                        With Game
                            .AwayTeamID = CType(objTeams.Item(x), TeamShell).TeamID
                            .HomeTeamID = CType(objTeams.Item(y), TeamShell).TeamID
                        End With
                        Me.InnerList.Add(Game)

                        Game = New Game
                        With Game
                            .AwayTeamID = CType(objTeams.Item(y), TeamShell).TeamID
                            .HomeTeamID = CType(objTeams.Item(x), TeamShell).TeamID
                        End With
                        Me.InnerList.Add(Game)
                    Next
                Next
            Next

        End Sub

        Private Sub AddMatchupsBetweenConferences()

            Dim intTotal As Integer = Me.League.InterconferenceMatchups

            If intTotal = 0 Then Exit Sub


            Dim i As Integer
            Dim x As Integer
            Dim y As Integer
            Dim objTeams As ArrayList = Me.TeamList

            For i = 1 To intTotal / 2
                For x = 0 To objTeams.Count - 1
                    For y = x + 1 To objTeams.Count - 1
                        If CType(objTeams.Item(x), TeamShell).ConferenceID <> CType(objTeams.Item(y), TeamShell).ConferenceID Then
                            Dim Game As New Game

                            With Game
                                .AwayTeamID = CType(objTeams.Item(x), TeamShell).TeamID
                                .HomeTeamID = CType(objTeams.Item(y), TeamShell).TeamID
                            End With
                            Me.InnerList.Add(Game)

                            Game = New Game
                            With Game
                                .AwayTeamID = CType(objTeams.Item(y), TeamShell).TeamID
                                .HomeTeamID = CType(objTeams.Item(x), TeamShell).TeamID
                            End With
                            Me.InnerList.Add(Game)
                        End If
                    Next
                Next
            Next

        End Sub

        Private Sub GetSeasonOpener()
            Dim pvarStartDate As Date = "10/01/" & Trim(CStr(Me.League.Season))
            pvarStartDate = DateAdd("ww", 2, pvarStartDate)
            pvarStartDate = DateAdd("d", (-(Weekday(pvarStartDate)) + 1), pvarStartDate)
            Me.StartDate = pvarStartDate
        End Sub


    End Class


End Namespace