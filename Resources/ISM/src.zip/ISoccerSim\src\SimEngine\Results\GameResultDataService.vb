'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.IO
Imports ISoccerSim.Teams
Imports ISoccerSim.Reporting
Imports ISoccerSim.SimEngine.PlayByPlay


Namespace SimEngine.Results
	Public Class GameResultDataService
		Function GetPlayerArray(ByVal objTeam As Team) As GameResultSet
			Dim Array As New GameResultSet()
			Dim Item As Players.Player

			For Each Item In objTeam.FieldManager.PlayerSet
				If Item.Stats.GetValue(Statistics.ISMStat.Minutes) > 0 Then
					Array.Create(Item.DisplayName, -1, False)
				End If
			Next

			Return Array

		End Function

		Function GetUnusedPlayers(ByVal objTeam As Team) As GameResultSet
			Dim Array As New GameResultSet()
			Dim Item As Players.Player

			For Each Item In objTeam.FieldManager.PlayerSet
				If Item.Stats.GetValue(Statistics.ISMStat.Minutes) = 0 Then
					Array.Create(Item.DisplayName, -1, False)
				End If
			Next

			Return Array
		End Function

		Function GetReferees(ByVal objRefSet As Players.RefereeSet) As GameResultSet
			Dim Array As New GameResultSet()
			Dim Item As Players.Referee

			For Each Item In objRefSet
				Array.Create(Item.DisplayName, -1, False)
			Next
			Return Array
        End Function


        Function GetShotsMade(ByVal objTeam As Team) As GameResultSet
            Dim ResultSet As New GameResultSet()
            Dim Item As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each Item In objTeam.FieldManager.PlayerSet
                Value = Item.Stats.GetValue(Statistics.ISMStat.ShotMade)
                If Value > 0 Then
                    ResultSet.Create(Item.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            ResultSet.Create("Total", Total, True)
            Return ResultSet

        End Function


        Function GetPointsMade(ByVal objTeam As Team) As GameResultSet
            Dim ResultSet As New GameResultSet()
            Dim Item As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each Item In objTeam.FieldManager.PlayerSet
                Value = Item.Stats.GetValue(Statistics.ISMStat.Points)
                If Value > 0 Then
                    ResultSet.Create(Item.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            ResultSet.Create("Total", Total, True)
            Return ResultSet

        End Function

        Function GetAssists(ByVal objTeam As Team) As GameResultSet
            Dim ResultSet As New GameResultSet()
            Dim Item As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each Item In objTeam.FieldManager.PlayerSet
                Value = Item.Stats.GetValue(Statistics.ISMStat.Assists)
                If Value > 0 Then
                    ResultSet.Create(Item.DisplayName, Value, False)
                    Total = Total + 1
                End If
            Next
            ResultSet.Create("Total", Total, True)
            Return ResultSet
        End Function

        Function GetShotsAttempted(ByVal objTeam As Team) As GameResultSet
            Dim ResultSet As New GameResultSet()
            Dim Item As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each Item In objTeam.FieldManager.PlayerSet
                Value = Item.Stats.GetValue(Statistics.ISMStat.ShotAttempted) + Item.Stats.GetValue(Statistics.ISMStat.ShotMade)
                If Value > 0 Then
                    ResultSet.Create(Item.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            ResultSet.Create("Total", Total, True)
            Return ResultSet
        End Function

        Function GetSaves(ByVal objTeam As Team) As GameResultSet
            Dim ResultSet As New GameResultSet()
            Dim Item As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each Item In objTeam.FieldManager.PlayerSet
                Value = Item.Stats.GetValue(Statistics.ISMStat.ShotStopped)
                If Value > 0 Then
                    ResultSet.Create(Item.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            ResultSet.Create("Total", Total, True)
            Return ResultSet
        End Function

        Function GetBlocks(ByVal objTeam As Team) As GameResultSet
            Dim ResultSet As New GameResultSet()
            Dim Item As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each Item In objTeam.FieldManager.PlayerSet
                Value = Item.Stats.GetValue(Statistics.ISMStat.Block)
                If Value > 0 Then
                    ResultSet.Create(Item.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            ResultSet.Create("Total", Total, True)
            Return ResultSet
        End Function

        Function GetFouls(ByVal objTeam As Team) As GameResultSet
            Dim ResultSet As New GameResultSet()
            Dim Item As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each Item In objTeam.FieldManager.PlayerSet
                Value = Item.Stats.GetValue(Statistics.ISMStat.Fouls)
                If Value > 0 Then
                    ResultSet.Create(Item.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            ResultSet.Create("Total", Total, True)
            Return ResultSet
        End Function

        Function GetPenaltyMinutes(ByVal objTeam As Team) As GameResultSet
            Dim ResultSet As New GameResultSet()
            Dim Item As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each Item In objTeam.FieldManager.PlayerSet
                Value = Item.Stats.GetValue(Statistics.ISMStat.PenaltyMinutes)
                If Value > 0 Then
                    ResultSet.Create(Item.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            ResultSet.Create("Total", Total, True)
            Return ResultSet
        End Function

        Function GetPowerPlayGoals(ByVal objTeam As Team) As GameResultSet
            Dim ResultSet As New GameResultSet()
            Dim Item As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each Item In objTeam.FieldManager.PlayerSet
                Value = Item.Stats.GetValue(Statistics.ISMStat.PowerPlayGoal)
                If Value > 0 Then
                    ResultSet.Create(Item.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            ResultSet.Create("Total", Total, True)
            Return ResultSet
        End Function

        Function GetPenaltyKillGoals(ByVal objTeam As Team) As GameResultSet
            Dim ResultSet As New GameResultSet()
            Dim Item As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each Item In objTeam.FieldManager.PlayerSet
                Value = Item.Stats.GetValue(Statistics.ISMStat.ShortHandedGoal)
                If Value > 0 Then
                    ResultSet.Create(Item.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            ResultSet.Create("Total", Total, True)
            Return ResultSet
        End Function

        Function GetBoxScoreArray(ByVal objTeam As Team) As ArrayList
            Dim Array As New ArrayList()
            With Array
                .Add(objTeam.Name)
                .Add(objTeam.Scoreboard.Q1Score)
                .Add(objTeam.Scoreboard.Q2Score)
                .Add(objTeam.Scoreboard.Q3Score)
                .Add(objTeam.Scoreboard.Q4Score)
                .Add(objTeam.Scoreboard.OTScore)
                .Add(objTeam.Scoreboard.Score)
            End With
            Return Array

        End Function

        Function GetPlayByPlay(ByVal GameLog As GameLog) As ArrayList
            Dim Array As New ArrayList()
            Dim Item As GameLogItem

            With Array
                For Each Item In GameLog
                    .Add(Item.Description)
                Next
            End With

            Return Array
        End Function
    End Class
End Namespace
