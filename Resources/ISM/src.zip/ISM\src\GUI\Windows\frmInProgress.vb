'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.Teams

Public Class frmInProgress
    Inherits System.Windows.Forms.Form

    Dim gs As GUIService = GUIService.GetInstance

    Public Event StopSimulating()
    Public ReturnToMain As Boolean

#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		SetScreen()
	End Sub

	Sub New(ByVal WindowText As String, ByVal Message As String)
		MyBase.New()
		InitializeComponent()
		Me.Text = WindowText
		'Me.lblMessage.Text = Message
		SetScreen()
	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Public WithEvents grpContent As System.Windows.Forms.GroupBox
	Public WithEvents imgBack As System.Windows.Forms.PictureBox
	Public WithEvents lblHomeTeam As System.Windows.Forms.Label
	Public WithEvents lblAwayTeam As System.Windows.Forms.Label
	Public WithEvents lblHome1Q As System.Windows.Forms.Label
	Public WithEvents lblAway1Q As System.Windows.Forms.Label
	Public WithEvents lblAway2Q As System.Windows.Forms.Label
	Public WithEvents lblHome2Q As System.Windows.Forms.Label
	Public WithEvents lblAway3Q As System.Windows.Forms.Label
	Public WithEvents lblHome3Q As System.Windows.Forms.Label
	Public WithEvents lblAway4Q As System.Windows.Forms.Label
	Public WithEvents lblHome4Q As System.Windows.Forms.Label
	Public WithEvents lblAwayOT As System.Windows.Forms.Label
	Public WithEvents lblHomeOT As System.Windows.Forms.Label
	Public WithEvents lblAwayScore As System.Windows.Forms.Label
	Public WithEvents lblHomeScore As System.Windows.Forms.Label
	Public WithEvents lblQuarter As System.Windows.Forms.Label
	Public WithEvents lblTime As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents lblDate As System.Windows.Forms.Label
    Public WithEvents btnReturn As System.Windows.Forms.Button
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.grpContent = New System.Windows.Forms.GroupBox
        Me.lblDate = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.lblTime = New System.Windows.Forms.Label
        Me.lblQuarter = New System.Windows.Forms.Label
        Me.lblAwayScore = New System.Windows.Forms.Label
        Me.lblHomeScore = New System.Windows.Forms.Label
        Me.lblAwayOT = New System.Windows.Forms.Label
        Me.lblHomeOT = New System.Windows.Forms.Label
        Me.lblAway4Q = New System.Windows.Forms.Label
        Me.lblHome4Q = New System.Windows.Forms.Label
        Me.lblAway3Q = New System.Windows.Forms.Label
        Me.lblHome3Q = New System.Windows.Forms.Label
        Me.lblAway2Q = New System.Windows.Forms.Label
        Me.lblHome2Q = New System.Windows.Forms.Label
        Me.lblAway1Q = New System.Windows.Forms.Label
        Me.lblHome1Q = New System.Windows.Forms.Label
        Me.lblAwayTeam = New System.Windows.Forms.Label
        Me.lblHomeTeam = New System.Windows.Forms.Label
        Me.imgBack = New System.Windows.Forms.PictureBox
        Me.btnReturn = New System.Windows.Forms.Button
        Me.lblStatus = New System.Windows.Forms.Label
        Me.grpContent.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpContent
        '
        Me.grpContent.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpContent.Controls.Add(Me.lblDate)
        Me.grpContent.Controls.Add(Me.Label1)
        Me.grpContent.Controls.Add(Me.Label2)
        Me.grpContent.Controls.Add(Me.Label3)
        Me.grpContent.Controls.Add(Me.Label4)
        Me.grpContent.Controls.Add(Me.Label5)
        Me.grpContent.Controls.Add(Me.Label6)
        Me.grpContent.Controls.Add(Me.Label7)
        Me.grpContent.Controls.Add(Me.lblTime)
        Me.grpContent.Controls.Add(Me.lblQuarter)
        Me.grpContent.Controls.Add(Me.lblAwayScore)
        Me.grpContent.Controls.Add(Me.lblHomeScore)
        Me.grpContent.Controls.Add(Me.lblAwayOT)
        Me.grpContent.Controls.Add(Me.lblHomeOT)
        Me.grpContent.Controls.Add(Me.lblAway4Q)
        Me.grpContent.Controls.Add(Me.lblHome4Q)
        Me.grpContent.Controls.Add(Me.lblAway3Q)
        Me.grpContent.Controls.Add(Me.lblHome3Q)
        Me.grpContent.Controls.Add(Me.lblAway2Q)
        Me.grpContent.Controls.Add(Me.lblHome2Q)
        Me.grpContent.Controls.Add(Me.lblAway1Q)
        Me.grpContent.Controls.Add(Me.lblHome1Q)
        Me.grpContent.Controls.Add(Me.lblAwayTeam)
        Me.grpContent.Controls.Add(Me.lblHomeTeam)
        Me.grpContent.Location = New System.Drawing.Point(8, 8)
        Me.grpContent.Name = "grpContent"
        Me.grpContent.Size = New System.Drawing.Size(416, 88)
        Me.grpContent.TabIndex = 0
        Me.grpContent.TabStop = False
        '
        'lblDate
        '
        Me.lblDate.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.Location = New System.Drawing.Point(8, 16)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(136, 16)
        Me.lblDate.TabIndex = 23
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Yellow
        Me.Label1.Location = New System.Drawing.Point(368, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 16)
        Me.Label1.TabIndex = 22
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Yellow
        Me.Label2.Location = New System.Drawing.Point(328, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(24, 16)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "F"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Yellow
        Me.Label3.Location = New System.Drawing.Point(288, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(24, 16)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "OT"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Yellow
        Me.Label4.Location = New System.Drawing.Point(256, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(24, 16)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "4"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Yellow
        Me.Label5.Location = New System.Drawing.Point(224, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(24, 16)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "3"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Yellow
        Me.Label6.Location = New System.Drawing.Point(192, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(24, 16)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "2"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Yellow
        Me.Label7.Location = New System.Drawing.Point(160, 16)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(24, 16)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "1"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblTime
        '
        Me.lblTime.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTime.Location = New System.Drawing.Point(368, 40)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(40, 16)
        Me.lblTime.TabIndex = 15
        Me.lblTime.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblQuarter
        '
        Me.lblQuarter.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuarter.Location = New System.Drawing.Point(368, 64)
        Me.lblQuarter.Name = "lblQuarter"
        Me.lblQuarter.Size = New System.Drawing.Size(40, 16)
        Me.lblQuarter.TabIndex = 14
        Me.lblQuarter.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblAwayScore
        '
        Me.lblAwayScore.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAwayScore.Location = New System.Drawing.Point(328, 40)
        Me.lblAwayScore.Name = "lblAwayScore"
        Me.lblAwayScore.Size = New System.Drawing.Size(24, 16)
        Me.lblAwayScore.TabIndex = 13
        Me.lblAwayScore.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblHomeScore
        '
        Me.lblHomeScore.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHomeScore.Location = New System.Drawing.Point(328, 64)
        Me.lblHomeScore.Name = "lblHomeScore"
        Me.lblHomeScore.Size = New System.Drawing.Size(24, 16)
        Me.lblHomeScore.TabIndex = 12
        Me.lblHomeScore.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblAwayOT
        '
        Me.lblAwayOT.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAwayOT.Location = New System.Drawing.Point(288, 40)
        Me.lblAwayOT.Name = "lblAwayOT"
        Me.lblAwayOT.Size = New System.Drawing.Size(24, 16)
        Me.lblAwayOT.TabIndex = 11
        Me.lblAwayOT.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblHomeOT
        '
        Me.lblHomeOT.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHomeOT.Location = New System.Drawing.Point(288, 64)
        Me.lblHomeOT.Name = "lblHomeOT"
        Me.lblHomeOT.Size = New System.Drawing.Size(24, 16)
        Me.lblHomeOT.TabIndex = 10
        Me.lblHomeOT.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblAway4Q
        '
        Me.lblAway4Q.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAway4Q.Location = New System.Drawing.Point(256, 40)
        Me.lblAway4Q.Name = "lblAway4Q"
        Me.lblAway4Q.Size = New System.Drawing.Size(24, 16)
        Me.lblAway4Q.TabIndex = 9
        Me.lblAway4Q.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblHome4Q
        '
        Me.lblHome4Q.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHome4Q.Location = New System.Drawing.Point(256, 64)
        Me.lblHome4Q.Name = "lblHome4Q"
        Me.lblHome4Q.Size = New System.Drawing.Size(24, 16)
        Me.lblHome4Q.TabIndex = 8
        Me.lblHome4Q.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblAway3Q
        '
        Me.lblAway3Q.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAway3Q.Location = New System.Drawing.Point(224, 40)
        Me.lblAway3Q.Name = "lblAway3Q"
        Me.lblAway3Q.Size = New System.Drawing.Size(24, 16)
        Me.lblAway3Q.TabIndex = 7
        Me.lblAway3Q.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblHome3Q
        '
        Me.lblHome3Q.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHome3Q.Location = New System.Drawing.Point(224, 64)
        Me.lblHome3Q.Name = "lblHome3Q"
        Me.lblHome3Q.Size = New System.Drawing.Size(24, 16)
        Me.lblHome3Q.TabIndex = 6
        Me.lblHome3Q.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblAway2Q
        '
        Me.lblAway2Q.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAway2Q.Location = New System.Drawing.Point(192, 40)
        Me.lblAway2Q.Name = "lblAway2Q"
        Me.lblAway2Q.Size = New System.Drawing.Size(24, 16)
        Me.lblAway2Q.TabIndex = 5
        Me.lblAway2Q.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblHome2Q
        '
        Me.lblHome2Q.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHome2Q.Location = New System.Drawing.Point(192, 64)
        Me.lblHome2Q.Name = "lblHome2Q"
        Me.lblHome2Q.Size = New System.Drawing.Size(24, 16)
        Me.lblHome2Q.TabIndex = 4
        Me.lblHome2Q.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblAway1Q
        '
        Me.lblAway1Q.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAway1Q.Location = New System.Drawing.Point(160, 40)
        Me.lblAway1Q.Name = "lblAway1Q"
        Me.lblAway1Q.Size = New System.Drawing.Size(24, 16)
        Me.lblAway1Q.TabIndex = 3
        Me.lblAway1Q.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblHome1Q
        '
        Me.lblHome1Q.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHome1Q.Location = New System.Drawing.Point(160, 64)
        Me.lblHome1Q.Name = "lblHome1Q"
        Me.lblHome1Q.Size = New System.Drawing.Size(24, 16)
        Me.lblHome1Q.TabIndex = 2
        Me.lblHome1Q.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblAwayTeam
        '
        Me.lblAwayTeam.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAwayTeam.Location = New System.Drawing.Point(8, 40)
        Me.lblAwayTeam.Name = "lblAwayTeam"
        Me.lblAwayTeam.Size = New System.Drawing.Size(136, 16)
        Me.lblAwayTeam.TabIndex = 1
        '
        'lblHomeTeam
        '
        Me.lblHomeTeam.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHomeTeam.Location = New System.Drawing.Point(8, 64)
        Me.lblHomeTeam.Name = "lblHomeTeam"
        Me.lblHomeTeam.Size = New System.Drawing.Size(136, 16)
        Me.lblHomeTeam.TabIndex = 0
        '
        'imgBack
        '
        Me.imgBack.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.imgBack.Location = New System.Drawing.Point(0, 0)
        Me.imgBack.Name = "imgBack"
        Me.imgBack.Size = New System.Drawing.Size(624, 312)
        Me.imgBack.TabIndex = 11
        Me.imgBack.TabStop = False
        '
        'btnReturn
        '
        Me.btnReturn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnReturn.Location = New System.Drawing.Point(312, 104)
        Me.btnReturn.Name = "btnReturn"
        Me.btnReturn.Size = New System.Drawing.Size(112, 24)
        Me.btnReturn.TabIndex = 12
        Me.btnReturn.Text = "Cancel"
        '
        'lblStatus
        '
        Me.lblStatus.Location = New System.Drawing.Point(8, 104)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(288, 24)
        Me.lblStatus.TabIndex = 13
        '
        'frmInProgress
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.FromArgb(CType(43, Byte), CType(72, Byte), CType(142, Byte))
        Me.ClientSize = New System.Drawing.Size(432, 141)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.btnReturn)
        Me.Controls.Add(Me.grpContent)
        Me.Controls.Add(Me.imgBack)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Gainsboro
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmInProgress"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Simulating..."
        Me.grpContent.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	Private Sub frmDialog_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
		'Add standard error handler
		AddHandler Application.ThreadException, New ThreadExceptionEventHandler(AddressOf HandleException)
	End Sub


	Sub SetScreen()
        Call Reset()
    End Sub

    Public Sub Reset()
        Call gs.SetCursor(Me)
        Me.lblStatus.Text = "Simulating..."
        Me.btnReturn.Enabled = True
        ReturnToMain = False
    End Sub

    Public Sub UpdateBoard(ByVal x As SimEngine.GameEngine)
        With x.HomeTeam
            Me.lblHomeTeam.Text = .Name
            Me.lblHome1Q.Text = .Scoreboard.Q1Score
            Me.lblHome2Q.Text = .Scoreboard.Q2Score
            Me.lblHome3Q.Text = .Scoreboard.Q3Score
            Me.lblHome4Q.Text = .Scoreboard.Q4Score
            Me.lblHomeOT.Text = .Scoreboard.OTScore
            Me.lblHomeScore.Text = .Scoreboard.Score

        End With

        With x.AwayTeam
            Me.lblAwayTeam.Text = .Name
            Me.lblAway1Q.Text = .Scoreboard.Q1Score
            Me.lblAway2Q.Text = .Scoreboard.Q2Score
            Me.lblAway3Q.Text = .Scoreboard.Q3Score
            Me.lblAway4Q.Text = .Scoreboard.Q4Score
            Me.lblAwayOT.Text = .Scoreboard.OTScore
            Me.lblAwayScore.Text = .Scoreboard.Score
        End With

        If x.Clock.IsEndOfGame Then
            Me.lblQuarter.Text = "FINAL"
            Me.lblTime.Text = ""
        ElseIf x.Clock.Quarter <= 4 Then
            Me.lblQuarter.Text = x.Clock.Quarter
            Me.lblTime.Text = x.Clock.ToString
        Else
            Me.lblQuarter.Text = "OT"
            Me.lblTime.Text = x.Clock.ToString
        End If

        Me.lblDate.Text = Format(x.GameDate, "M/d/yy")
        Me.Refresh()

    End Sub

    Private Sub btnReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnReturn.Click
        ReturnToMain = True
        Me.lblStatus.Text = "Will return after current game is done..."
        Me.btnReturn.Enabled = False
        RaiseEvent StopSimulating()
    End Sub

    Public Sub SetStatusText(ByVal Text As String)
        Me.lblStatus.Text = Text
        Me.Refresh()
    End Sub


End Class
