'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.  

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
'
'
'

Namespace Statistics
    Public Class DefenseCareerStatHolder
        Public A As Integer
        Public Season As Integer
        Public GP As Integer
        Public M As Integer
        Public SF As Integer
        Public S As Integer
        Public W As Integer
        Public L As Integer
        Public Team As String
        Public SA As Integer


        Public Function GetArray() As Object
            Dim Result(7) As Object

            Result(0) = Me.Season
            Result(1) = Me.Team
            Result(2) = Me.GP
            Result(3) = Me.SF
            Result(4) = Me.S
            Result(5) = Me.W
            Result(6) = Me.L
            If Me.GP > 0 Then
                Result(7) = Format((Me.SA / Me.GP), "#0.00")
            Else
                Result(7) = "0.00"
            End If

            Return Result

        End Function

        Public Function GetArray(ByVal Season As Integer, ByVal Team As String) As Object
            Me.Season = Season
            Me.Team = Team
            Return GetArray()
        End Function

    End Class
End Namespace
