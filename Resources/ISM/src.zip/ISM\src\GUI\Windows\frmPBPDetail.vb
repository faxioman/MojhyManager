'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.SimEngine.PlayByPlay

Public Class frmPBPDetail
	Inherits System.Windows.Forms.Form

	Dim mobjComment As New PlayByPlayComment()
	Dim mblnDirty As Boolean
    Dim mblnLoading As Boolean
    Dim gs As GUIService = GuiService.GetInstance

	Public Event FormClosed()

#Region " Windows Form Designer generated code "

	Private WithEvents grpDetail As System.Windows.Forms.GroupBox
	Private WithEvents txtProbability As System.Windows.Forms.TextBox
	Private WithEvents lblDesc As System.Windows.Forms.Label
	Private WithEvents btnOK As System.Windows.Forms.Button
	Private WithEvents txtDescription As System.Windows.Forms.TextBox
	Private WithEvents lblProbability As System.Windows.Forms.Label
	Private WithEvents btnSave As System.Windows.Forms.Button

	Public Sub New()
		MyBase.New()
		' Must be called for initialization
		mblnLoading = True
		Me.InitializeComponent()
		gs.SetCursor(me)
		LoadInsertBox()
		mblnLoading = False
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub

	Public Sub New(ByVal CommentID As Integer, ByVal IsParentID As Boolean)
		MyBase.New()
		mblnLoading = True

		Me.InitializeComponent()
		gs.SetCursor(me)

		If IsParentID Then
			mobjComment.PlayByPlayID = CommentID
		Else
			mobjComment.Load(CommentID)
			mobjComment.PlayByPlayCommentID = CommentID
			LoadComment()
		End If
		LoadInsertBox()
		mblnLoading = False
	End Sub
	Public WithEvents GroupBox1 As System.Windows.Forms.GroupBox
	Public WithEvents cmbInsert As System.Windows.Forms.ComboBox
	Public WithEvents btnInsert As System.Windows.Forms.Button

	Private Sub InitializeComponent()
		Me.grpDetail = New System.Windows.Forms.GroupBox()
		Me.GroupBox1 = New System.Windows.Forms.GroupBox()
		Me.cmbInsert = New System.Windows.Forms.ComboBox()
		Me.btnInsert = New System.Windows.Forms.Button()
		Me.txtProbability = New System.Windows.Forms.TextBox()
		Me.lblProbability = New System.Windows.Forms.Label()
		Me.lblDesc = New System.Windows.Forms.Label()
		Me.txtDescription = New System.Windows.Forms.TextBox()
		Me.btnOK = New System.Windows.Forms.Button()
		Me.btnSave = New System.Windows.Forms.Button()
		Me.grpDetail.SuspendLayout()
		Me.GroupBox1.SuspendLayout()
		Me.SuspendLayout()
		'
		'grpDetail
		'
		Me.grpDetail.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox1, Me.txtProbability, Me.lblProbability, Me.lblDesc, Me.txtDescription})
		Me.grpDetail.Location = New System.Drawing.Point(8, 0)
		Me.grpDetail.Name = "grpDetail"
		Me.grpDetail.Size = New System.Drawing.Size(432, 280)
		Me.grpDetail.TabIndex = 4
		Me.grpDetail.TabStop = False
		Me.grpDetail.Text = "Detail"
		'
		'GroupBox1
		'
		Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmbInsert, Me.btnInsert})
		Me.GroupBox1.Location = New System.Drawing.Point(80, 224)
		Me.GroupBox1.Name = "GroupBox1"
		Me.GroupBox1.Size = New System.Drawing.Size(344, 48)
		Me.GroupBox1.TabIndex = 8
		Me.GroupBox1.TabStop = False
		Me.GroupBox1.Text = "Insert..."
		'
		'cmbInsert
		'
		Me.cmbInsert.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbInsert.Location = New System.Drawing.Point(8, 16)
		Me.cmbInsert.Name = "cmbInsert"
		Me.cmbInsert.Size = New System.Drawing.Size(208, 22)
		Me.cmbInsert.TabIndex = 9
		'
		'btnInsert
		'
		Me.btnInsert.Location = New System.Drawing.Point(224, 16)
		Me.btnInsert.Name = "btnInsert"
		Me.btnInsert.Size = New System.Drawing.Size(112, 24)
		Me.btnInsert.TabIndex = 8
		Me.btnInsert.TabStop = False
		Me.btnInsert.Text = "&Insert At Cursor"
		'
		'txtProbability
		'
		Me.txtProbability.Location = New System.Drawing.Point(80, 192)
		Me.txtProbability.MaxLength = 5
		Me.txtProbability.Name = "txtProbability"
		Me.txtProbability.Size = New System.Drawing.Size(56, 20)
		Me.txtProbability.TabIndex = 1
		Me.txtProbability.Text = ""
		'
		'lblProbability
		'
		Me.lblProbability.Location = New System.Drawing.Point(8, 192)
		Me.lblProbability.Name = "lblProbability"
		Me.lblProbability.Size = New System.Drawing.Size(120, 16)
		Me.lblProbability.TabIndex = 2
		Me.lblProbability.Text = "Probability:"
		'
		'lblDesc
		'
		Me.lblDesc.Location = New System.Drawing.Point(8, 24)
		Me.lblDesc.Name = "lblDesc"
		Me.lblDesc.Size = New System.Drawing.Size(64, 16)
		Me.lblDesc.TabIndex = 1
		Me.lblDesc.Text = "Description:"
		'
		'txtDescription
		'
		Me.txtDescription.Location = New System.Drawing.Point(80, 24)
		Me.txtDescription.Multiline = True
		Me.txtDescription.Name = "txtDescription"
		Me.txtDescription.Size = New System.Drawing.Size(344, 160)
		Me.txtDescription.TabIndex = 0
		Me.txtDescription.Text = ""
		'
		'btnOK
		'
		Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnOK.Location = New System.Drawing.Point(328, 288)
		Me.btnOK.Name = "btnOK"
		Me.btnOK.Size = New System.Drawing.Size(112, 24)
		Me.btnOK.TabIndex = 2
		Me.btnOK.Text = "&OK"
		'
		'btnSave
		'
		Me.btnSave.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnSave.Enabled = False
		Me.btnSave.Location = New System.Drawing.Point(200, 288)
		Me.btnSave.Name = "btnSave"
		Me.btnSave.Size = New System.Drawing.Size(112, 24)
		Me.btnSave.TabIndex = 5
		Me.btnSave.Text = "&Save"
		'
		'frmPBPDetail
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(448, 317)
		Me.ControlBox = False
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnSave, Me.grpDetail, Me.btnOK})
		Me.Font = New System.Drawing.Font("Arial", 8.0!)
		Me.Name = "frmPBPDetail"
		Me.ShowInTaskbar = False
		Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
		Me.Text = "Play By Play Detail"
		Me.grpDetail.ResumeLayout(False)
		Me.GroupBox1.ResumeLayout(False)
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub LoadComment()
		With mobjComment
			Me.txtDescription.Text = .Narrative
			Me.txtProbability.Text = Format(.Probability, "#0")
		End With
	End Sub

	Private Sub LoadInsertBox()
		Dim Helper As New PlayByPlayInsert()
		Me.cmbInsert.DataSource = Helper
		Me.cmbInsert.ValueMember = "Slug"
		Me.cmbInsert.DisplayMember = "Text"

	End Sub

	Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		Me.Close()
	End Sub

	Private Sub btnInsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsert.Click
		Me.txtDescription.Text = Me.txtDescription.Text.Insert(Me.txtDescription.SelectionStart, CType(Me.cmbInsert.SelectedItem, PlayByPlayInsertItem).Slug)
	End Sub

	Private Sub Entry_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDescription.TextChanged, txtProbability.TextChanged
		If Not mblnLoading Then
			mblnDirty = True
			Me.btnSave.Enabled = True
		End If
	End Sub

	Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
		mobjComment.Narrative = Me.txtDescription.Text
		mobjComment.Probability = Me.txtProbability.Text
		If mobjComment.PlayByPlayCommentID = 0 Then
			mobjComment.Insert()
		Else
			mobjComment.Update()
		End If
	End Sub
End Class