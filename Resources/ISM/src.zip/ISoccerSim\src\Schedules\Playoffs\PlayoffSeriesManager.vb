Imports ISoccerSim.Leagues


Namespace Schedules.Playoffs
    Public Class PlayoffSeriesManager

        Dim l As League = Simulation.GetInstance.League
        Dim s As Schedule = Simulation.GetInstance.League.Schedule

        Public Sub InsertSeries(ByVal SeriesID As Integer, ByVal TopID As Integer, ByVal BottomID As Integer, ByVal TopSeed As Integer, ByVal BottomSeed As Integer, ByVal LevelID As Integer)
            Dim ds As New DataServices.LeagueTables
            ds.InsertSeries(SeriesID, l.Season, TopID, BottomID, LevelID, TopSeed, BottomSeed)
        End Sub

        Public Sub UpdateSeries(ByVal SeriesID As Integer, ByVal WinnerID As Integer, ByVal LoserID As Integer)
            Dim ds As New DataServices.LeagueTables
            Dim WinnerSeed As Integer
            WinnerSeed = GetWinningSeed(WinnerID, SeriesID)
            ds.UpdateSeries(SeriesID, WinnerID, LoserID, WinnerSeed)
            ds.DeleteUnusedGamesFromSeries(SeriesID)
        End Sub

        Public Sub PutNextGameOnSchedule(ByVal SeriesID As Integer, ByVal WinnerID As Integer, ByVal LoserID As Integer)
            Dim ds As New DataServices.LeagueTables
            If Me.IsAnotherPlayoffGameNeeded(SeriesID, LoserID, WinnerID) Then
                Dim NextGameID As Integer = ds.GetNextTentativePlayoffGame(SeriesID)
                If NextGameID > 0 Then
                    Dim g As Game = s.GetGameByID(NextGameID)
                    g.Status = ISMGameScheduleStatus.NotPlayed
                    g.UpdateResult()
                End If
            End If
        End Sub

        Private Function GetWinningSeed(ByVal WinnerID As Integer, ByVal SeriesID As Integer) As Integer
            Dim ds As New DataServices.LeagueTables
            Dim dr As OleDb.OleDbDataReader = ds.GetSeries(SeriesID)
            Dim Result As Integer

            Do While dr.Read()
                If dr.Item("TopSeedID") = WinnerID Then
                    Result = dr.Item("TopSeed")
                Else
                    Result = dr.Item("BottomSeed")
                End If
            Loop
            dr.Close()
            Return Result
        End Function

        Public Function GetNumberOfPlayoffGamesOnStage(ByVal SeriesID As Integer) As Integer
            Dim psg As New PlayoffScheduleGenerator
            Dim st As New SeriesTemplate
            Dim s As Series
            For Each s In st
                If s.SeriesID = SeriesID Then
                    Return psg.GetNumberOfPlayoffGamesOnStage(s.Round)
                End If
            Next

        End Function

        Public Function IsPlayoffRoundComplete(ByVal SeriesID As Integer) As Boolean
            Dim g As Game
            Dim Result As Integer
            Dim st As New SeriesTemplate
            Dim Sim As Simulation = Simulation.GetInstance
            Dim l As League = Sim.League
            Dim SeriesList As New ArrayList
            Dim i As Integer

            Dim Round As Integer = st.GetRoundFromSeries(SeriesID)
            Dim ss As Series
            For Each ss In st
                If ss.Round = Round Then
                    SeriesList.Add(ss.SeriesID)
                End If
            Next

            For Each g In s
                For i = 0 To SeriesList.Count - 1
                    If g.SeriesID = SeriesList(i) Then
                        If g.Status = ISMGameScheduleStatus.NotPlayed Or g.Status = ISMGameScheduleStatus.IfNeeded Then
                            Return False
                        End If
                    End If
                Next
            Next

            Return True
        End Function

        Public Function IsAnotherPlayoffGameNeeded(ByVal SeriesID As Integer, ByVal LowSeedID As Integer, ByVal HighSeedID As Integer)
            Dim g As Game
            Dim Result As Integer
            Dim psg As New PlayoffScheduleGenerator
            Dim LowSeedWins As Integer
            Dim HighSeedWins As Integer
            Dim GamesInSeries As Integer
            Dim st As New SeriesTemplate
            Dim Round As Integer = st.GetRoundFromSeries(SeriesID)

            Dim GamesToWin As Integer = psg.GetNumberOfGamesToWinStage(Round)
            For Each g In s
                If g.SeriesID = SeriesID Then
                    If g.Status = ISMGameScheduleStatus.Played Then
                        If g.HomeScore > g.AwayScore Then
                            If g.HomeTeamID = LowSeedID Then LowSeedWins = LowSeedWins + 1
                            If g.HomeTeamID = HighSeedID Then HighSeedWins = HighSeedWins + 1
                        End If

                        If g.AwayScore > g.HomeScore Then
                            If g.AwayTeamID = LowSeedID Then LowSeedWins = LowSeedWins + 1
                            If g.AwayTeamID = HighSeedID Then HighSeedWins = HighSeedWins + 1
                        End If

                        GamesInSeries = GamesInSeries + 1
                    End If
                End If
            Next

            If GamesInSeries < GamesToWin Then
                Return False
            Else
                If LowSeedWins >= GamesToWin Or HighSeedWins >= GamesToWin Then
                    Return False
                Else
                    Return True
                End If
            End If

        End Function
    End Class
End Namespace