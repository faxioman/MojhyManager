Public Enum ISMLoadMode
    Edit = 0
    AddNew = 1
End Enum
