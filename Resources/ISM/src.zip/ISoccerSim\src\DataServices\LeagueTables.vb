'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.Data.OleDb
Imports ISoccerSim.Schedules
Imports ISoccerSim.Leagues
Imports ISoccerSim.Cities


Namespace DataServices

	Public Class LeagueTables
		Inherits DataServices.DataService

		Function InsertLeague(ByVal objLeague As League) As Integer
			Dim SQL As String
			With objLeague
				SQL = "INSERT INTO Leagues " & _
				 "(LeagueID, Abbreviation, Championship, ChampionshipSeries, InterconferenceMatchups, " & _
				 " IntraconferenceMatchups, MultiPoint, Name, PlayoffSeries, Season, TeamsInPlayoff, Phase)" & _
				 "VALUES (1, " & _
				 FormatField(.Abbreviation, True, True) & _
				 FormatField(.Championship, True, True) & _
				 FormatField(.ChampionshipSeries, False, True) & _
				 FormatField(.InterconferenceMatchups, False, True) & _
				 FormatField(.IntraconferenceMatchups, False, True) & _
				 FormatField(.MultiPoint, False, True) & _
				 FormatField(.Name, True, True) & _
				 FormatField(.PlayoffSeries, False, True) & _
				 FormatField(.Season, False, True) & _
				 FormatField(.TeamsInPlayoff, False, True) & _
				 FormatField(.Phase, False, False) & ")"

			End With

			RunCommand(SQL)
			Return objLeague.LeagueID

		End Function

		Function UpdateGame(ByVal objGame As Game)
			Dim SQL As String
			With objGame
                SQL = "UPDATE Schedule SET " & _
                " HomeScore = " & FormatField(.HomeScore, False, True) & _
                " AwayScore = " & FormatField(.AwayScore, False, True) & _
                " Status = " & FormatField(.Status, False, True) & _
                " Overtime = " & FormatField(.Overtime, False, True) & _
                " Attendance = " & FormatField(.Attendance, False, True) & _
                " SeriesID = " & FormatField(.SeriesID, False, True) & _
                " Season = " & FormatField(.Season, False, False) & _
                " WHERE ScheduleID = " & .GameID
			End With
			RunCommand(SQL)
		End Function

		Function InsertGame(ByVal objGame As Game) As Integer

			Dim SQL As String
			With objGame
                SQL = "INSERT INTO Schedule " & _
                 "(ScheduleID, GameDate, AwayTeamID, HomeTeamID, AwayScore, HomeScore, " & _
                 " Phase, Overtime, Attendance, Status, SeriesID, Season)" & _
                 "VALUES (" & _
                  FormatField(.GameID, False, True) & _
                  FormatField(.GameDate, True, True) & _
                  FormatField(.AwayTeamID, False, True) & _
                  FormatField(.HomeTeamID, False, True) & _
                  FormatField(.AwayScore, False, True) & _
                  FormatField(.HomeScore, False, True) & _
                  FormatField(.Phase, False, True) & _
                  FormatField(.Overtime, False, True) & _
                  FormatField(.Attendance, False, True) & _
                  FormatField(.Status, False, True) & _
                  FormatField(.SeriesID, False, True) & _
                  FormatField(.Season, False, False) & ")"

			End With

			RunCommand(SQL)
			Return objGame.GameID

		End Function

		Function InsertConference(ByVal objConf As Conference) As Integer
			Dim SQL As String
			With objConf
				SQL = "INSERT INTO Conferences " & _
				  "([Name], [ConferenceID])" & _
				 "VALUES (" & _
				 FormatField(.Name, True, True) & _
				 FormatField(.ID, False, False) & ")"

			End With

			RunCommand(SQL)
			Return objConf.ID

		End Function

		Sub UpdateConference(ByVal objConference As Conference)
			Dim SQL As String
			With objConference
				SQL = "UPDATE Conferences SET Name=" & _
				 FormatField(objConference.Name, True, False) & _
				 " WHERE ConferenceID = " & objConference.ID
			End With

			RunCommand(SQL)
		End Sub

		Sub UpdateDivision(ByVal objDivision As Division)
			Dim SQL As String
			With objDivision
				SQL = "UPDATE Divisions SET " & _
				"Name = " & FormatField(objDivision.Name, True, True) & _
				"ConferenceID = " & FormatField(objDivision.ConferenceID, False, False) & _
				 " WHERE DivisionID = " & objDivision.ID
			End With

			RunCommand(SQL)
        End Sub

        Sub UpdateDefaultTeamID(ByVal DefaultTeamID As Integer)
            Dim SQL As String
            SQL = "UPDATE Leagues SET DefaultTeamID = " & DefaultTeamID
            RunCommand(SQL)
        End Sub

        Sub UpdatePlayoffRound(ByVal Round As Integer)
            Dim SQL As String
            SQL = "UPDATE Leagues SET PlayoffRound = " & Round
            RunCommand(SQL)
        End Sub

        Function InsertDivision(ByVal objDiv As Division) As Integer
            Dim SQL As String
            With objDiv
                SQL = "INSERT INTO Divisions " & _
                  "([Name], [DivisionID], [ConferenceID])" & _
                 "VALUES (" & _
                 FormatField(.Name, True, True) & _
                 FormatField(.ID, False, True) & _
                 FormatField(.ConferenceID, False, False) & ")"
            End With

            RunCommand(SQL)
            Return objDiv.ID

        End Function

        Function InsertSeries(ByVal SeriesID As Integer, ByVal Season As Integer, _
                              ByVal TopSeedID As Integer, ByVal BottomSeedID As Integer, _
                              ByVal Level As Integer, _
                              ByVal TopSeed As Integer, ByVal BottomSeed As Integer)
            Dim SQL As String
            SQL = "INSERT INTO PlayoffSeries ([Level], TopSeed, BottomSeed, SeriesID, Season, TopSeedID, BottomSeedID) VALUES (" & _
            FormatField(Level, False, True) & _
            FormatField(TopSeed, False, True) & _
            FormatField(BottomSeed, False, True) & _
            FormatField(SeriesID, False, True) & _
            FormatField(Season, False, True) & _
            FormatField(TopSeedID, False, True) & _
            FormatField(BottomSeedID, False, False) & ")"
            RunCommand(SQL, False)

        End Function

        Function GetPlayoffLevelComplete(ByVal SeriesID As Integer) As Boolean
            Dim SQL As String = "SELECT ps2.*, ps.SeriesID " & _
                                "FROM PlayoffSeries AS ps INNER JOIN PlayoffSeries AS ps2 ON ps.[Level] = ps2.[Level] " & _
                                "WHERE (((ps2.WinnerID)=0) AND ((ps.SeriesID)=" & SeriesID & "));"

            Dim Result As Boolean

            Dim dr As OleDbDataReader = GetDataReader(SQL)
            If dr.HasRows Then
                dr.Close()
                Return False
            Else
                dr.Close()
                Return True
            End If

        End Function

        Function GetLastPlayoffLevel() As Integer
            Dim SQL As String = "SELECT Top 1 ps.[Level]  " & _
                                "FROM PlayoffSeries ps  " & _
                                "WHERE ps.WinnerID > 0 " & _
                                "ORDER BY SeriesID DESC;"

            Dim Result As Integer

            Dim dr As OleDbDataReader = GetDataReader(SQL)
            Do While dr.Read
                Result = dr.Item("Level")
                dr.Close()
                Return Result
            Loop
            Return 0
        End Function

        Function GetTeamsRemainingInPlayoffs() As OleDbDataReader
            Dim Level As Integer
            Level = Me.GetLastPlayoffLevel()

            Dim SQL As String = " SELECT PlayoffSeries.Level, PlayoffSeries.WinnerID, PlayOffSeries.WinnerSeed" & _
                                "            FROM(PlayoffSeries)" & _
                                " WHERE PlayoffSeries.Level = " & Level & _
                                " GROUP BY PlayoffSeries.Level, PlayOffSeries.WinnerSeed, PlayoffSeries.WinnerID" & _
                                " ORDER BY PlayoffSeries.Level DESC , PlayoffSeries.WinnerSeed, PlayoffSeries.WinnerID;"
            Return GetDataReader(SQL)

        End Function

        Function GetNextTentativePlayoffGame(ByVal SeriesID As Integer) As Integer
            Dim SQL As String
            SQL = "SELECT TOP 1 Schedule.SeriesID, Schedule.Status, Schedule.GameDate, Schedule.ScheduleID " & _
                  "FROM Schedule " & _
                  "WHERE (((Schedule.SeriesID) = " & SeriesID & ")) AND Schedule.Status = 2  " & _
                  "ORDER BY Schedule.GameDate ASC; "

            Dim Result As Integer

            Dim dr As OleDbDataReader = GetDataReader(SQL)
            Do While dr.Read
                If dr.Item("Status") = 2 Then
                    Result = dr.Item("ScheduleID")
                Else
                    Result = 0
                End If
                dr.Close()
                Return Result
            Loop
            Return 0
        End Function

        Function GetLowSeedFromSeries(ByVal Round As Integer) As Integer
            Dim SQL As String
            SQL = "SELECT TOP 1 ps.WinnerID, t.PlayoffSeed " & _
                  "FROM PlayoffSeries AS ps LEFT JOIN Teams AS t ON ps.WinnerID = t.TeamID " & _
                  "WHERE(((ps.Level) = " & Round & ")) " & _
                  "ORDER BY t.PlayoffSeed DESC; "

            Dim Result As Integer

            Dim dr As OleDbDataReader = GetDataReader(SQL)
            Do While dr.Read
                Result = dr.Item("WinnerID")
                dr.Close()
                Return Result
            Loop
            Return 0
        End Function

        Function GetHighSeedFromSeries(ByVal Round As Integer) As Integer
            Dim SQL As String
            SQL = "SELECT TOP 1 ps.WinnerID, t.PlayoffSeed " & _
                  "FROM PlayoffSeries AS ps LEFT JOIN Teams AS t ON ps.WinnerID = t.TeamID " & _
                  "WHERE(((ps.Level) = " & Round & ")) " & _
                  "ORDER BY t.PlayoffSeed ASC; "

            Dim Result As Integer

            Dim dr As OleDbDataReader = GetDataReader(SQL)
            Do While dr.Read
                Result = dr.Item("WinnerID")
                dr.Close()
                Return Result
            Loop
            Return 0
        End Function

        Function GetLastPlayoffRound() As Integer
            Dim SQL As String
            SQL = "SELECT TOP 1 ps.Level FROM PlayoffSeries AS ps ORDER BY ps.Level DESC;"

            Dim Result As Integer

            Dim dr As OleDbDataReader = GetDataReader(SQL)
            Do While dr.Read
                Result = dr.Item("Level")
                dr.Close()
                Return Result
            Loop
            Return 0
        End Function

        Function GetPlayoffsComplete() As Boolean
            Dim SQL As String = "SELECT Count(ps.PlayoffSeriesID) AS Winners, ps.Level " & _
                                "FROM PlayoffSeries AS ps " & _
                                "WHERE(((ps.WinnerID) > 0) And ((ps.LoserID) > 0)) " & _
                                "GROUP BY ps.Level " & _
                                "HAVING(((Count(ps.PlayoffSeriesID)) = 1)) " & _
                                "ORDER BY ps.Level DESC;"

            Dim Result As Boolean

            Dim dr As OleDbDataReader = GetDataReader(SQL)
            Do While dr.Read
                If dr.Item("Winners") = 1 Then
                    dr.Close()
                    Return True
                Else
                    dr.Close()
                    Return False
                End If
            Loop
            dr.Close()
            Return False

        End Function

        Function UpdateSeries(ByVal SeriesID As Integer, ByVal WinnerID As Integer, ByVal LoserID As Integer, ByVal WinnerSeed As Integer)
            Dim SQL As String
            SQL = "UPDATE PlayoffSeries SET WinnerID = " & WinnerID & ", LoserID = " & LoserID & _
                    ", WinnerSeed = " & WinnerSeed & _
                    " WHERE SeriesID = " & SeriesID
            RunCommand(SQL)
        End Function

        Function GetSeries(ByVal SeriesID As Integer) As OleDbDataReader
            Dim SQL As String
            SQL = "SELECT * FROM PlayoffSeries WHERE SeriesID = " & SeriesID
            Return GetDataReader(SQL)
        End Function

        Function DeleteUnusedGamesFromSeries(ByVal SeriesID As Integer)
            Dim SQL As String
            SQL = "DELETE FROM Schedule WHERE SeriesID = " & SeriesID & " AND Status = 2"
            RunCommand(SQL)
        End Function

        Function GetLeague() As OleDbDataReader
            Dim SQL As String = "SELECT * FROM Leagues Where LeagueID = 1"
            Return GetDataReader(SQL)
        End Function

        Function GetConference(ByVal ConferenceID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT * FROM Conferences WHERE ConferenceID = " & ConferenceID
            Return GetDataReader(SQL)
        End Function

        Function GetConferences() As OleDbDataReader
            Dim SQL As String = "SELECT * FROM Conferences ORDER BY ConferenceID"
            Return GetDataReader(SQL)
        End Function

        Function GetDivisions() As OleDbDataReader
            Dim SQL As String = "SELECT * FROM Divisions ORDER BY DivisionID"
            Return GetDataReader(SQL)
        End Function

        Function GetSchedule()
            Dim SQL As String = "SELECT * FROM Schedule ORDER BY GameDate, ScheduleID"
            Return GetDataReader(SQL)
        End Function

        Function GetLastSeriesID() As Integer
            Dim SQL As String = "SELECT TOP 1 SeriesID FROM Schedule ORDER BY SeriesID DESC"
            Dim Result As Integer

            Dim dr As OleDbDataReader = GetDataReader(SQL)
            Do While dr.Read()
                Result = dr.Item("SeriesID")
                Exit Do
            Loop
            dr.Close()
            Return Result
        End Function

        Function GetConferenceDivisionNames()
            Dim SQL As String = "SELECT c.Name AS ConferenceName, d.Name as DivisionName, d.DivisionID " & _
             " FROM Conferences c INNER JOIN Divisions d ON c.ConferenceID = d.ConferenceID " & _
             " ORDER BY d.ConferenceID, d.DivisionID"
            Return GetDataReader(SQL)
        End Function


    End Class

End Namespace
