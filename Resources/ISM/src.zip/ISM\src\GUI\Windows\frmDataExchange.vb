Public Class frmDataExchange
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        'Call Me.ToggleValidImport()
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents ofdTarget As System.Windows.Forms.OpenFileDialog
    Public WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents grpMain As System.Windows.Forms.GroupBox
    Public WithEvents btnExport As System.Windows.Forms.Button
    Public WithEvents btnImport As System.Windows.Forms.Button
    Friend WithEvents cmbTable As System.Windows.Forms.ComboBox
    Friend WithEvents lblTable As System.Windows.Forms.Label
    Friend WithEvents lblFile As System.Windows.Forms.Label
    Friend WithEvents txtFile As System.Windows.Forms.TextBox
    Public WithEvents btnFileFind As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.ofdTarget = New System.Windows.Forms.OpenFileDialog
        Me.btnOK = New System.Windows.Forms.Button
        Me.grpMain = New System.Windows.Forms.GroupBox
        Me.btnFileFind = New System.Windows.Forms.Button
        Me.txtFile = New System.Windows.Forms.TextBox
        Me.lblFile = New System.Windows.Forms.Label
        Me.lblTable = New System.Windows.Forms.Label
        Me.cmbTable = New System.Windows.Forms.ComboBox
        Me.btnExport = New System.Windows.Forms.Button
        Me.btnImport = New System.Windows.Forms.Button
        Me.grpMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'ofdTarget
        '
        Me.ofdTarget.DefaultExt = "*.txt"
        Me.ofdTarget.Filter = "Text Files|*.txt"
        '
        'btnOK
        '
        Me.btnOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnOK.Location = New System.Drawing.Point(352, 96)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(112, 24)
        Me.btnOK.TabIndex = 3
        Me.btnOK.Text = "OK"
        '
        'grpMain
        '
        Me.grpMain.Controls.Add(Me.btnFileFind)
        Me.grpMain.Controls.Add(Me.txtFile)
        Me.grpMain.Controls.Add(Me.lblFile)
        Me.grpMain.Controls.Add(Me.lblTable)
        Me.grpMain.Controls.Add(Me.cmbTable)
        Me.grpMain.Location = New System.Drawing.Point(8, 8)
        Me.grpMain.Name = "grpMain"
        Me.grpMain.Size = New System.Drawing.Size(456, 80)
        Me.grpMain.TabIndex = 5
        Me.grpMain.TabStop = False
        Me.grpMain.Text = "Options"
        '
        'btnFileFind
        '
        Me.btnFileFind.Location = New System.Drawing.Point(416, 48)
        Me.btnFileFind.Name = "btnFileFind"
        Me.btnFileFind.Size = New System.Drawing.Size(32, 20)
        Me.btnFileFind.TabIndex = 4
        Me.btnFileFind.Text = ". . ."
        '
        'txtFile
        '
        Me.txtFile.Location = New System.Drawing.Point(104, 48)
        Me.txtFile.Name = "txtFile"
        Me.txtFile.Size = New System.Drawing.Size(304, 20)
        Me.txtFile.TabIndex = 3
        Me.txtFile.Text = ""
        '
        'lblFile
        '
        Me.lblFile.Location = New System.Drawing.Point(16, 48)
        Me.lblFile.Name = "lblFile"
        Me.lblFile.Size = New System.Drawing.Size(80, 23)
        Me.lblFile.TabIndex = 2
        Me.lblFile.Text = "File Location:"
        '
        'lblTable
        '
        Me.lblTable.Location = New System.Drawing.Point(16, 24)
        Me.lblTable.Name = "lblTable"
        Me.lblTable.Size = New System.Drawing.Size(40, 23)
        Me.lblTable.TabIndex = 1
        Me.lblTable.Text = "Table:"
        '
        'cmbTable
        '
        Me.cmbTable.Items.AddRange(New Object() {"Cities", "Colleges", "Conferences", "Divisions", "Emails", "Facilities", "FirstNames", "GameStats", "LastNames", "Leagues", "MainRegions", "Mascots", "Nicknames", "PlayByPlay", "PlayByPlayItems", "Players", "PlayerSkills", "RatingDistributions", "Regions", "Rosters", "Schedule", "States", "SubstitutionLines", "Teams"})
        Me.cmbTable.Location = New System.Drawing.Point(104, 24)
        Me.cmbTable.Name = "cmbTable"
        Me.cmbTable.Size = New System.Drawing.Size(184, 22)
        Me.cmbTable.TabIndex = 0
        Me.cmbTable.Text = "Players"
        '
        'btnExport
        '
        Me.btnExport.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnExport.Location = New System.Drawing.Point(8, 96)
        Me.btnExport.Name = "btnExport"
        Me.btnExport.Size = New System.Drawing.Size(112, 24)
        Me.btnExport.TabIndex = 6
        Me.btnExport.Text = "Export"
        '
        'btnImport
        '
        Me.btnImport.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnImport.Enabled = False
        Me.btnImport.Location = New System.Drawing.Point(128, 96)
        Me.btnImport.Name = "btnImport"
        Me.btnImport.Size = New System.Drawing.Size(112, 24)
        Me.btnImport.TabIndex = 7
        Me.btnImport.Text = "Import"
        '
        'frmDataExchange
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(472, 125)
        Me.Controls.Add(Me.btnImport)
        Me.Controls.Add(Me.btnExport)
        Me.Controls.Add(Me.grpMain)
        Me.Controls.Add(Me.btnOK)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmDataExchange"
        Me.Text = "frmDataExchange"
        Me.grpMain.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim dts As New ISoccerSim.DataServices.DataTransferService
    Dim gui As GUIService = GUIService.GetInstance

    Private Sub btnExport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExport.Click
        gui.SetCursor(True, Me)
        dts.Export(Me.cmbTable.Text, Me.txtFile.Text)
        gui.SetCursor(False, Me)
        MsgBox("Export complete.")
    End Sub

    Private Sub btnImport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnImport.Click
        If Dir(Me.txtFile.Text) <> "" Then
            gui.SetCursor(True, Me)
            dts.Import(Me.cmbTable.Text, Me.txtFile.Text)
            gui.SetCursor(False, Me)
        End If
        MsgBox("Import complete.")
    End Sub

    Private Sub btnFileFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFileFind.Click
        Me.ofdTarget.ShowDialog()
        Me.txtFile.Text = Me.ofdTarget.FileName
        Call ToggleValidImport()
    End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Me.Close()
    End Sub

    Private Sub txtFile_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFile.TextChanged
        Call ToggleValidImport()
    End Sub

    Private Sub ToggleValidImport()
        Try
            If Dir(Me.txtFile.Text) = "" Or Me.txtFile.Text.Trim.Length < 3 Then
                Me.btnImport.Enabled = False
            Else
                Me.btnImport.Enabled = True
            End If
        Catch ex As Exception
            Me.btnImport.Enabled = False
        End Try
    End Sub
End Class
