Imports ISoccerSim.Players.Player

Namespace SimEngine.Actions.Sequence
    Public Class PenaltyRaisedEventArgs
        Inherits System.EventArgs

        Public Player As ISoccerSim.Players.Player

        Sub New(ByVal Player As ISoccerSim.Players.Player)
            Me.Player = Player
        End Sub

    End Class
End Namespace