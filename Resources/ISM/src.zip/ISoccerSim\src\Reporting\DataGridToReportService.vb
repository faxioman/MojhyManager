Imports System.Collections
Imports ISoccerSim.Utility.DataGrid

Namespace Reporting

    Public Class DataGridToReportService
        Inherits System.Collections.CollectionBase

        Sub Create(ByVal dg As DataGrid)
            Dim col As DataGridTextBoxColumn
            Dim Result As New ArrayList
            Dim rptcol As DataGridReportColumn
            Dim dt As DataTable = CType(dg.DataSource, DataViewUtility).GetDataTable

            Dim x As Integer
            Dim i As Integer

            Dim ts As DataGridTableStyle = dg.TableStyles(0)
            For Each col In ts.GridColumnStyles
                If col.Width > 0 Then
                    rptcol = New DataGridReportColumn((col.Width / dg.Width) * 80, col.MappingName, col.HeaderText, i)
                    Me.InnerList.Add(rptcol)
                End If
                i = i + 1
            Next

        End Sub

        Function Item(ByVal Index) As DataGridReportColumn
            Return CType(Me.InnerList(Index), DataGridReportColumn)
        End Function
    End Class

    Public Class DataGridReportColumn
        Public Width As Integer
        Public MappingName As String
        Public HeaderText As String
        Public MappingIndex As Integer

        Public Sub New(ByVal Width As String, ByVal MappingName As String, ByVal HeaderText As String, ByVal MappingIndex As Integer)
            Me.Width = Width
            Me.MappingName = MappingName
            Me.HeaderText = HeaderText
            Me.MappingIndex = MappingIndex
        End Sub
    End Class
End Namespace
