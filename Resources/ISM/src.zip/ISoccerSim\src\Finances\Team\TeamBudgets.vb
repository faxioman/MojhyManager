'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Finances.Team
    Public Class TeamBudgets
        Public Tickets As Double
        Public Sponsorship As Double
        Public Merchendise As Double
        Public Concessions As Double
        Public SoccerCamps As Double
        Public TeamID As Integer
        Public Marketing As Double
        Public FrontOffice As Double
        Public Salaries As Double
        Public Insurance As Double
        Public ArenaRental As Double
        Public Events As Double
        Public Promotions As Double
        Public Overhead As Double
        Public LeagueDues As Double
        Public BudgetID As Integer
        Public Travel As Double

        Public Sub Load(ByVal TeamID As Integer)
            Dim ds As New DataServices.TeamTables
            Dim dr As OleDb.OleDbDataReader

            Me.TeamID = TeamID
            dr = ds.GetTeamBudget(TeamID)
            Do While dr.Read
                Me.Tickets = dr("Tickets")
                Me.Concessions = dr("Concessions")
                Me.Merchendise = dr("Merchendise")
                Me.SoccerCamps = dr("SoccerCamps")
                Me.Sponsorship = dr("Sponsorship")
                Me.BudgetID = dr("BudgetID")

                Me.Marketing = dr("Marketing")
                Me.FrontOffice = dr("FrontOffice")
                Me.Salaries = dr("Salaries")
                Me.Insurance = dr("Insurance")
                Me.ArenaRental = dr("ArenaRental")
                Me.Events = dr("Events")
                Me.Promotions = dr("Promotions")
                Me.Overhead = dr("Overhead")
                Me.LeagueDues = dr("LeagueDues")
                Me.Travel = dr("Travel")
            Loop
            dr.Close()
        End Sub

        Public Sub CalculateDefault(ByVal TeamID As Integer, ByVal HomeGames As Integer, ByVal ExpectedAttendance As Integer)
            Dim tf As New TeamFinance
            tf.HomeGames = HomeGames
            tf.AvgAttendance = ExpectedAttendance
            Me.Tickets = tf.GetTicketIncomeForSeason
            Me.Concessions = tf.GetConcessionsForSeason
            Me.Merchendise = tf.GetMerchendiseForSeason
            Me.SoccerCamps = tf.GetSoccerCampIncome
            Me.Sponsorship = tf.Sponsorship
            Me.Marketing = tf.MarketingAndMedia
            Me.FrontOffice = tf.FrontOffice
            Me.Salaries = tf.GetPlayerSalaries
            Me.Insurance = tf.GetPlayerHousingExpenses
            Me.LeagueDues = tf.LeagueDues
            Me.ArenaRental = tf.GetArenaRentalExpenses
            Me.Events = tf.CommunityEventCost
            Me.Promotions = tf.PromotionCost
            Me.Overhead = tf.GetMiscExpenses
            Me.Travel = tf.GetTravelExpenses

            Me.TeamID = TeamID

        End Sub

        Public Function TotalIncome()
            Return Me.Tickets + Me.Concessions + Me.SoccerCamps + Me.Merchendise + Me.Sponsorship
        End Function

        Public Function TotalExpenses()
            Return Me.Marketing + Me.FrontOffice + Me.Salaries + Me.Insurance + Me.LeagueDues + _
                    Me.LeagueDues + Me.ArenaRental + Me.Events + Me.Promotions + Me.Overhead
        End Function

        Public Function NetIncome()
            Return Me.TotalIncome - Me.TotalExpenses
        End Function

        Public Sub Insert()
            Dim ds As New DataServices.TeamTables
            Me.BudgetID = ds.InsertTeamBudget(Me.TeamID, Me)
        End Sub
    End Class
End Namespace
