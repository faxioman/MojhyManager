'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports System.Math
Imports System.Random
Imports Microsoft.VisualBasic
Imports System.Data.OleDb

Public Class BaseSetting
	Public Value As String
	Public Probability As Double
	Public Key As String

End Class

Public Class BaseSettingSet
	Inherits System.Collections.CollectionBase

    Public Text As String
	Public Dataset As Dataset
	Public Total As Double

    Default Property Item(ByVal index As Integer) As BaseSetting
        Get
            Return CType(InnerList.Item(index), BaseSetting)
        End Get
        Set(ByVal Value As BaseSetting)
            InnerList.Item(index) = Value
        End Set
    End Property

    Sub Add(ByVal value As BaseSetting)
        InnerList.Add(value)
    End Sub

    Sub Create(ByVal intGamePosition As ISoccerSim.SimEngine.ISMGamePosition, ByVal Probability As Double)
        Dim lstItem As New BaseSetting
        With lstItem
            .Key = CStr(intGamePosition)
            .Probability = Probability
            .Value = CStr(intGamePosition)
        End With

        If IsNumeric(lstItem.Probability) Then
            Me.Total = Me.Total + CDbl(lstItem.Probability)
        Else
            Me.Total = Me.Total + 1
            lstItem.Probability = 1
        End If

        InnerList.Add(lstItem)
    End Sub
    Sub Create(ByVal Key As String, ByVal Probability As Double, ByVal Value As String)
        Dim lstItem As New BaseSetting
        With lstItem
            .Key = Key
            .Probability = Probability
            .Value = Value
        End With
        If IsNumeric(lstItem.Probability) Then
            Me.Total = Me.Total + CDbl(lstItem.Probability)
        Else
            Me.Total = Me.Total + 1
            lstItem.Probability = 1
        End If

        InnerList.Add(lstItem)
    End Sub

    Sub Create(ByVal Key As String, ByVal Value As String)
        Call Create(Key, 1, Value)
    End Sub


    Function GetRandomItem() As BaseSetting
        Dim Item As New BaseSetting
        Dim m As MathService = MathService.GetInstance()

        Item = InnerList.Item(m.Next(0, InnerList.Count - 1))
        Return Item
    End Function

    Function GetRandomItemByProbability() As BaseSetting
        Dim Item As New BaseSetting
        Dim m As MathService = MathService.GetInstance()
        Dim i As Integer
        Dim pdblTotal As Double
        Dim pdblCheck As Double

        pdblCheck = m.NextDouble() * Me.Total
        For i = 0 To Innerlist.Count - 1
            Item = InnerList.Item(i)
            pdblTotal = pdblTotal + Item.Probability
            If pdblTotal >= pdblCheck Then
                Return Item
            End If
        Next
        Return Item

    End Function

    Function GetItemByKey(ByVal Key As String) As BaseSetting
        Dim Item As New BaseSetting
        Dim i As Integer
        For Each Item In InnerList
            If Item.Key = Key Then
                Return Item
                Exit Function
            End If
        Next
    End Function

    Function GetIntegerValueByKey(ByVal Key As String) As Integer
        Dim Item As New BaseSetting
        Dim i As Integer
        For Each Item In InnerList
            If Item.Key = Key Then
                Return CInt(Item.Value)
                Exit Function
            End If
        Next
    End Function

    Function GetDoubleValueByKey(ByVal Key As String) As Double
        Dim Item As New BaseSetting
        Dim i As Integer
        For Each Item In InnerList
            If Item.Key = Key Then
                Return CDbl(Item.Value)
                Exit Function
            End If
        Next
    End Function

    Sub Load(ByVal dr As OleDbDataReader, ByVal IDField As String, ByVal DescField As String, ByVal ProbField As String)
        Dim drow As DataRow
        Me.Clear()
        Me.Total = 0

        Do While dr.Read()
            Me.Create(dr.Item(IDField), dr.Item(ProbField), dr.Item(DescField))
        Loop
        dr.Close()
    End Sub

    Sub Load(ByVal dr As OleDbDataReader, ByVal IDField As String, ByVal DescField As String)
        Dim drow As DataRow
        Me.Clear()
        Me.Total = 0
        Do While dr.Read()
            Me.Create(dr.Item(IDField) & "", 1, dr.Item(DescField) & "")
        Loop
        dr.Close()

    End Sub
End Class
