'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Positions
Imports ISoccerSim.Players

Namespace Substitution
	Public Class SubstitutionLineRankSet
		Inherits System.Collections.CollectionBase
		Implements ICloneable

		Public SubstitutionLineID As Integer
		Public TeamID As Integer
		Public SubLineTypeID As ISMSublineType

		Default Property Item(ByVal index As Integer) As SubstitutionLineRank
			Get
				Return CType(InnerList.Item(index), SubstitutionLineRank)
			End Get
			Set(ByVal Value As SubstitutionLineRank)
				InnerList.Item(index) = Value
			End Set
		End Property


		Sub Add(ByVal value As SubstitutionLineRank)
			InnerList.Add(value)
		End Sub

		Sub Sort()
			InnerList.Sort()
		End Sub

		Function Clone() As Object Implements ICloneable.Clone
			Dim Subline As New SubstitutionLineRankSet()
			Subline = Me
			Return Subline
		End Function

		Function GetPlayersForLine(ByVal intPosition As ISMPlayerPosition, ByVal intSlot As Integer) As SubstitutionLineRankSet
			Return GetPlayersForLine(intPosition, intSlot, intSlot)
		End Function

		<Bugtrack(1, "Empty roster not expected when creating league", True, "Prefill database with 0's")> _
		Function GetPlayersForLine(ByVal intPosition As ISMPlayerPosition, ByVal intLowSlot As Integer, ByVal intHighSlot As Integer) As SubstitutionLineRankSet
			Dim Subline As New SubstitutionLineRankSet()
			Dim Rank As SubstitutionLineRank
			Dim Count As Integer = intLowSlot - intHighSlot + 1
			Dim PlayersAtPosition As Integer = GetPlayersAtPosition(intPosition)

			Me.InnerList.Sort()
			If Count + intHighSlot > PlayersAtPosition Then
				intHighSlot = PlayersAtPosition - Count
				intLowSlot = intHighSlot + Count
			End If


			For Each Rank In Me.InnerList
				With Rank
					If .Position = intPosition Then
						If .PositionRank >= intHighSlot And .PositionRank <= intLowSlot Then
							Subline.Add(Rank.Clone)
						End If
					End If
				End With
			Next
			Subline.Sort()

			'FIX (1):  If no players are available at a position, then throw blanks.
			'This should also work for not having enough players on a roster.

			If PlayersAtPosition < Subline.Count Then
				Dim i As Integer
				For i = 0 To Count

					Dim Player As New Player()
					Dim Blank As New SubstitutionLineRank()

					Player.ID = 0
					Blank.Player = Player
					Subline.Add(Blank)
				Next
			End If

			Return Subline
		End Function

		Private Function GetPlayersAtPosition(ByVal intPosition As ISMPlayerPosition) As Integer
			Dim Rank As SubstitutionLineRank
			Dim Out As Integer

			For Each Rank In Me.InnerList
				If Rank.Position = intPosition Then
					Out += 1
				End If
			Next
			Return Out
		End Function


	End Class
End Namespace