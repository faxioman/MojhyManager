'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.Data
Imports System.io

Namespace DataServices
    Public Class DataTransferService

        Dim mDatabase As String

        Property Database() As String
            Get
                Return mDatabase
            End Get
            Set(ByVal value As String)
                mDatabase = value
            End Set
        End Property

        Public Sub New()
            Dim Sim As Simulation = Simulation.GetInstance
            Dim fs As FileService = FileService.GetInstance

            If Not (Sim Is Nothing) Then
                If Sim.League.Name <> "" Then
                    mDatabase = fs.GetCurrentDirectory() & "\leagues\" & Sim.League.Name & "\base.mdb"
                Else
                    mDatabase = fs.GetCurrentDirectory() & "\data\base.mdb"
                End If
            Else
                mDatabase = fs.GetCurrentDirectory() & "\data\base.mdb"
            End If
        End Sub

        Public Sub Export(ByVal Table As String, ByVal Filename As String)
            Dim ConnectString As String = String.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Persist Security Info=False", mDatabase)
            Dim sql As String = String.Format("Select * FROM {0}", Table)

            Dim cn As New OleDb.OleDbConnection(ConnectString)
            Dim cm As New OleDb.OleDbCommand(sql, cn)
            cn.Open()
            Dim dr As OleDb.OleDbDataReader = cm.ExecuteReader()
            Dim ts As TextWriter = File.CreateText(Filename)
            Dim i As Integer
            Dim Text As String
            Dim ColumnsWritten As Boolean
            Dim Count As Integer

            Do While dr.Read()
                'RaiseEvent Progress(Me, New ISoccerSim.General.ProgressEventEventArgs("Exporting", (Count / dr.RecordsAffected) * 100))
                Text = ""
                If Not ColumnsWritten Then
                    Dim dt As Data.DataTable = dr.GetSchemaTable()
                    Dim x As Integer
                    For x = 0 To dt.Rows.Count - 1
                        Text = Text & dt.Rows(x).Item(0)
                        If i < dt.Rows.Count - 1 Then
                            Text = Text & vbTab
                        End If
                    Next
                    ts.WriteLine(Text)
                    Text = ""
                    ColumnsWritten = True
                End If

                For i = 0 To dr.FieldCount - 1
                    Text = Text & dr.Item(i)
                    If i < dr.FieldCount - 1 Then
                        Text = Text & vbTab
                    End If
                Next
                ts.WriteLine(Text)
                Count = Count + 1
            Loop

            dr.Close()
            cn.Close()
            ts.Close()
        End Sub

        Public Sub Import(ByVal Table As String, ByVal Filename As String)
            Dim ConnectString As String = String.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Persist Security Info=False", mDatabase)

            Dim cn As New OleDb.OleDbConnection(ConnectString)
            cn.Open()

            Dim ts As TextReader = File.OpenText(Filename)
            Dim i As Integer
            Dim Text As String
            Dim ColumnsRead As Boolean
            Dim Columns As New ArrayList
            Dim Errors As String
            Dim row As Integer
            Dim Count As Integer

            Do While ts.Peek > -1
                row = row + 1
                Text = ts.ReadLine
                If Text.Trim.Length > 0 Then
                    If Not ColumnsRead Then
                        Columns = GetColumns(Text)
                        ColumnsRead = True
                    Else
                        If ImportRow(Table, Text, Columns, cn) = False Then
                            Errors = String.Format("Error importing row #{0}", row)
                        End If
                    End If
                End If
                Count = Count + 1
                If COunt > 98 Then Count = 1
            Loop

            ts.Close()
            cn.Close()

            If Errors <> "" Then
                Throw New Exception(Errors)
            End If
        End Sub

        Private Function GetColumns(ByVal Text As String) As ArrayList
            Dim Result As New ArrayList
            Dim Cols() As String = Text.Split(vbTab)
            Dim i As Integer
            For i = LBound(Cols) To UBound(Cols)
                If Trim(Cols(i)) <> "" Then
                    Result.Add(Cols(i))
                End If
            Next
            Return Result
        End Function

        Private Function ImportRow(ByVal Table As String, ByVal Text As String, ByVal Columns As ArrayList, ByVal cn As OleDb.OleDbConnection) As Boolean

            Dim sql As String = String.Format("Select TOP 1 * FROM {0}", Table)
            Dim Values As String() = Text.Split(vbTab)
            Dim cm As New OleDb.OleDbCommand(sql, cn)
            Dim dr As OleDb.OleDbDataReader = cm.ExecuteReader()
            Dim dt As Data.DataTable = dr.GetSchemaTable()
            dr.Close()

            If IsValidImportFileVersusTable(Values, dt, Columns) Then
                Dim PrimaryKey As String = Columns(0)
                Dim Where As String = Values(0)
                sql = String.Format("SELECT {1} FROM {0} WHERE {1} = {2}", Table, PrimaryKey, Where)
                cm.CommandText = sql
                dr = cm.ExecuteReader
                If dr.HasRows Then
                    dr.Close()
                    Return UpdateRow(cn, Table, Values, Columns, PrimaryKey, Where)
                Else
                    dr.Close()
                    Return InsertRow(cn, Table, Values, Columns, PrimaryKey, Where)
                End If
            Else
                Return False
            End If
        End Function

        Private Function UpdateRow(ByVal cn As OleDb.OleDbConnection, ByVal Table As String, ByVal Values() As String, ByVal Columns As ArrayList, ByVal PrimaryKey As String, ByVal ID As Integer) As Boolean
            Dim sql As String
            Dim Text As String
            Dim i As Integer

            For i = 1 To UBound(Values)
                Text = Text & "[" & Columns(i) & "] = "

                If Values(i).ToUpper = "TRUE" Then Values(i) = -1
                If Values(i).ToUpper = "FALSE" Then Values(i) = 0

                If IsNumeric(Values(i)) Then
                    Text = Text & Values(i)
                Else
                    Text = Text & "'" & Replace(Values(i), "'", "''") & "'"
                End If

                If i < UBound(Values) Then
                    Text = Text & ", "
                End If
            Next
            sql = String.Format("UPDATE {0} SET {3} WHERE {1} = {2}", Table, PrimaryKey, ID, Text)

            Dim cm As New OleDb.OleDbCommand(sql, cn)
            Try
                cm.ExecuteNonQuery()
            Catch ex As System.Exception
                Throw ex
            End Try

            Return True
        End Function

        Private Function InsertRow(ByVal cn As OleDb.OleDbConnection, ByVal Table As String, ByVal Values() As String, ByVal Columns As ArrayList, ByVal PrimaryKey As String, ByVal ID As Integer) As Boolean
            Dim sql As String
            Dim Text As String
            Dim Cols As String

            Dim i As Integer

            For i = 1 To UBound(Values)
                Cols = Cols & "[" & Columns(i) & "]"
                If i < UBound(Values) Then
                    Cols = Cols & ", "
                End If

                If Values(i).ToUpper = "TRUE" Then Values(i) = -1
                If Values(i).ToUpper = "FALSE" Then Values(i) = 0

                If IsNumeric(Values(i)) Then
                    Text = Text & Values(i)
                Else
                    Text = Text & "'" & Replace(Values(i), "'", "''") & "'"
                End If

                If i < UBound(Values) Then
                    Text = Text & ", "
                End If
            Next
            sql = String.Format("INSERT INTO {0} ({1}) VALUES ({2})", Table, Cols, Text)

            Dim cm As New OleDb.OleDbCommand(sql, cn)
            Try
                cm.ExecuteNonQuery()
            Catch ex As System.Exception
                Throw ex
            End Try

            Return True
        End Function

        Private Function IsValidImportFileVersusTable(ByVal Values As String(), ByVal dt As Data.DataTable, ByVal Columns As ArrayList)
            Dim ValidColumn As Boolean
            Dim x As Integer
            Dim y As Integer

            If UBound(Values) + 1 = Columns.Count Then
                For x = 0 To dt.Rows.Count - 1
                    ValidColumn = False
                    For y = 0 To Columns.Count - 1
                        If dt.Rows(x).Item(0) = Columns(y) Then
                            ValidColumn = True
                            Exit For
                        End If
                    Next
                    If ValidColumn = False Then Return False
                Next
            Else
                Return False
            End If

            Return True

        End Function
    End Class
End Namespace
