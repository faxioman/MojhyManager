'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Players

Namespace SimEngine.Settings
	Public Class GameEngineSettingService

		Public Settings As New GameEngineSet()

		Sub Load()
			LoadDribbleActions()
			LoadPassActions()
			LoadPassRecipActions()
			LoadCheckOverGlassActions()
			LoadPenaltyActions()
			LoadShotAttemptActions()
			LoadShotInGoalActions()
			LoadScrambleForBallActions()
			LoadShotOnTargetActions()
			LoadShotSetupActions()
			LoadDribbleVersusPassActions()
			LoadKickoffActions()
			LoadPenaltyActions()

			LoadPassSequence()
			LoadDribbleSequence()
			LoadShotSequence()
		End Sub

		Private Sub LoadDribbleActions()
			With Me.Settings
				.Create(ISM_GameSettingType.Dribble, ISM_GameSetting.OffensiveRatingMult, 0.2)
				.Create(ISM_GameSettingType.Dribble, ISM_GameSetting.DefensiveRatingMult, 0.2)
				.Create(ISM_GameSettingType.Dribble, ISM_GameSetting.OffensiveAdj, 40)
				.Create(ISM_GameSettingType.Dribble, ISM_GameSetting.DefensiveAdj, 0)

				.Create(ISM_GameSettingType.Dribble, ISM_GameSetting.FieldPenalty, 20, Actions.ISMBallVertical.OppCrease)
				.Create(ISM_GameSettingType.Dribble, ISM_GameSetting.FieldPenalty, 10, Actions.ISMBallVertical.OppShortRange)
				.Create(ISM_GameSettingType.Dribble, ISM_GameSetting.FieldPenalty, 5, Actions.ISMBallVertical.OppThird)

			End With
		End Sub

		Private Sub LoadPassActions()
			With Me.Settings
				.Create(ISM_GameSettingType.Pass, ISM_GameSetting.OffensiveAdj, 35)
				.Create(ISM_GameSettingType.Pass, ISM_GameSetting.DefensiveAdj, 0)
				.Create(ISM_GameSettingType.Pass, ISM_GameSetting.OffensiveRatingMult, 0.2)
				.Create(ISM_GameSettingType.Pass, ISM_GameSetting.DefensiveRatingMult, 0.2)
				.Create(ISM_GameSettingType.Pass, ISM_GameSetting.OffensiveSecRatingMult, 0.15)
				.Create(ISM_GameSettingType.Pass, ISM_GameSetting.DefensiveSecRatingMult, 0.1)

				.Create(ISM_GameSettingType.Pass, ISM_GameSetting.FieldPenalty, 20, Actions.ISMBallVertical.OppCrease)
				.Create(ISM_GameSettingType.Pass, ISM_GameSetting.FieldPenalty, 10, Actions.ISMBallVertical.OppShortRange)
				.Create(ISM_GameSettingType.Pass, ISM_GameSetting.FieldPenalty, 5, Actions.ISMBallVertical.OppThird)

			End With
		End Sub


		Private Sub LoadKickoffActions()
			With Me.Settings
				.Create(ISM_GameSettingType.KickOff, ISM_GameSetting.Failure, 3)
				.Create(ISM_GameSettingType.KickOff, ISM_GameSetting.OffensiveRatingMult, 0.02)
				.Create(ISM_GameSettingType.KickOff, ISM_GameSetting.OffensiveAdj, 90)
			End With
		End Sub

		Private Sub LoadPassRecipActions()
			With Me.Settings

				.Create(ISM_GameSettingType.PassReception, ISM_GameSetting.Failure, 4)
				.Create(ISM_GameSettingType.PassReception, ISM_GameSetting.GenericRatingMult, 0.2)

				.Create(ISM_GameSettingType.PassReception, ISM_GameSetting.FieldPenalty, 10, Actions.ISMBallVertical.OppCrease)
				.Create(ISM_GameSettingType.PassReception, ISM_GameSetting.FieldPenalty, 5, Actions.ISMBallVertical.OppShortRange)
			End With
		End Sub

		Private Sub LoadCheckOverGlassActions()
			With Me.Settings
				.Create(ISM_GameSettingType.CheckOverGlass, ISM_GameSetting.Failure, 8)
				.Create(ISM_GameSettingType.CheckOverGlass, ISM_GameSetting.GenericRatingMult, 0.7)
			End With
		End Sub

		Private Sub LoadPenaltyActions()
			With Me.Settings
                .Create(ISM_GameSettingType.Penalty, ISM_GameSetting.Failure, 8) '4/8
				.Create(ISM_GameSettingType.Penalty, ISM_GameSetting.GenericRatingMult, 0.1)
                .Create(ISM_GameSettingType.Penalty, ISM_GameSetting.MaxAmount, 10)
                .Create(ISM_GameSettingType.Penalty, ISM_GameSetting.GenericAdj, 0)
			End With
		End Sub

		Private Sub LoadShotAttemptActions()
			With Me.Settings
				.Create(ISM_GameSettingType.ShotAttempt, ISM_GameSetting.OffensiveRatingMult, 0.2)
				.Create(ISM_GameSettingType.ShotAttempt, ISM_GameSetting.DefensiveRatingMult, 0.2)
				.Create(ISM_GameSettingType.ShotAttempt, ISM_GameSetting.OffensiveAdj, 15)				'3 / 0
				.Create(ISM_GameSettingType.ShotAttempt, ISM_GameSetting.DefensiveAdj, 0)				  '0 / 40 'Fixed for blocks...
			End With
		End Sub

		Private Sub LoadShotInGoalActions()
			With Me.Settings

				.Create(ISM_GameSettingType.ShotInGoal, ISM_GameSetting.OffensiveAdj, 20)				  '0
				.Create(ISM_GameSettingType.ShotInGoal, ISM_GameSetting.DefensiveAdj, 0)
				.Create(ISM_GameSettingType.ShotInGoal, ISM_GameSetting.OffensiveRatingMult, 0.25)
				.Create(ISM_GameSettingType.ShotInGoal, ISM_GameSetting.DefensiveRatingMult, 0.25)

				.Create(ISM_GameSettingType.ShotInGoal, ISM_GameSetting.FieldPenalty, 30, Actions.ISMBallVertical.OppCrease)
				.Create(ISM_GameSettingType.ShotInGoal, ISM_GameSetting.FieldPenalty, 15, Actions.ISMBallVertical.OppShortRange)
				.Create(ISM_GameSettingType.ShotInGoal, ISM_GameSetting.FieldPenalty, 8, Actions.ISMBallVertical.OppThird)
				.Create(ISM_GameSettingType.ShotInGoal, ISM_GameSetting.FieldPenalty, 5, Actions.ISMBallVertical.MidField)
				.Create(ISM_GameSettingType.ShotInGoal, ISM_GameSetting.FieldPenalty, 3, Actions.ISMBallVertical.OwnThird)
				.Create(ISM_GameSettingType.ShotInGoal, ISM_GameSetting.FieldPenalty, 3, Actions.ISMBallVertical.OwnShortRange)
				.Create(ISM_GameSettingType.ShotInGoal, ISM_GameSetting.FieldPenalty, 3, Actions.ISMBallVertical.OwnCrease)

			End With
		End Sub

		Private Sub LoadShotOnTargetActions()
			With Me.Settings

				.Create(ISM_GameSettingType.ShotOnTarget, ISM_GameSetting.OffensiveAdj, 10)				  '10 / 0
				.Create(ISM_GameSettingType.ShotOnTarget, ISM_GameSetting.DefensiveAdj, 0)				'0 / 40
				.Create(ISM_GameSettingType.ShotOnTarget, ISM_GameSetting.OffensiveRatingMult, 0.25)
				.Create(ISM_GameSettingType.ShotOnTarget, ISM_GameSetting.DefensiveRatingMult, 0.25)

				.Create(ISM_GameSettingType.ShotOnTarget, ISM_GameSetting.FieldPenalty, 20, Actions.ISMBallVertical.OppCrease)				 '30
				.Create(ISM_GameSettingType.ShotOnTarget, ISM_GameSetting.FieldPenalty, 10, Actions.ISMBallVertical.OppShortRange)				'15
				.Create(ISM_GameSettingType.ShotOnTarget, ISM_GameSetting.FieldPenalty, 5, Actions.ISMBallVertical.OppThird)				'8
				.Create(ISM_GameSettingType.ShotOnTarget, ISM_GameSetting.FieldPenalty, 3, Actions.ISMBallVertical.MidField)				'3
				.Create(ISM_GameSettingType.ShotOnTarget, ISM_GameSetting.FieldPenalty, 2, Actions.ISMBallVertical.OwnThird)				  '3
				.Create(ISM_GameSettingType.ShotOnTarget, ISM_GameSetting.FieldPenalty, 1, Actions.ISMBallVertical.OwnShortRange)				  '3
				.Create(ISM_GameSettingType.ShotOnTarget, ISM_GameSetting.FieldPenalty, 1, Actions.ISMBallVertical.OwnCrease)				  '3

			End With
		End Sub

		Private Sub LoadScrambleForBallActions()
			With Me.Settings
				.Create(ISM_GameSettingType.ScrambleForBall, ISM_GameSetting.Failure, 50)
			End With
		End Sub

		Private Sub LoadDribbleVersusPassActions()
			With Me.Settings
				.Create(ISM_GameSettingType.DribbleVersusPass, ISM_GameSetting.OptForPass, 25)
			End With
		End Sub

		Private Sub LoadShotSetupActions()
			With Me.Settings
				.Create(ISM_GameSettingType.ShotSetupActions, ISM_GameSetting.MaxAmount, 8)
				.Create(ISM_GameSettingType.ShotSetupActions, ISM_GameSetting.MinAmount, 2)
			End With
		End Sub
		''''''''''''''''''''
		'SEQUENCE SETTINGS '
		''''''''''''''''''''

		Private Sub LoadPassSequence()
			With Me.Settings
				.Create(ISM_GameSettingType.PassSequence, ISM_GameSetting.FieldPenalty, 0, Actions.ISMBallVertical.OppCrease)
				.Create(ISM_GameSettingType.PassSequence, ISM_GameSetting.FieldPenalty, 10, Actions.ISMBallVertical.OppShortRange)
				.Create(ISM_GameSettingType.PassSequence, ISM_GameSetting.FieldPenalty, 20, Actions.ISMBallVertical.OppThird)
				.Create(ISM_GameSettingType.PassSequence, ISM_GameSetting.FieldPenalty, 70, Actions.ISMBallVertical.MidField)
				.Create(ISM_GameSettingType.PassSequence, ISM_GameSetting.FieldPenalty, 90, Actions.ISMBallVertical.OwnThird)
				.Create(ISM_GameSettingType.PassSequence, ISM_GameSetting.FieldPenalty, 95, Actions.ISMBallVertical.OwnShortRange)
				.Create(ISM_GameSettingType.PassSequence, ISM_GameSetting.FieldPenalty, 99, Actions.ISMBallVertical.OwnCrease)
			End With
		End Sub

		Private Sub LoadDribbleSequence()
			With Me.Settings
				.Create(ISM_GameSettingType.DribbleSequence, ISM_GameSetting.FieldPenalty, 0, Actions.ISMBallVertical.OppCrease)
				.Create(ISM_GameSettingType.DribbleSequence, ISM_GameSetting.FieldPenalty, 10, Actions.ISMBallVertical.OppShortRange)
				.Create(ISM_GameSettingType.DribbleSequence, ISM_GameSetting.FieldPenalty, 20, Actions.ISMBallVertical.OppThird)
				.Create(ISM_GameSettingType.DribbleSequence, ISM_GameSetting.FieldPenalty, 70, Actions.ISMBallVertical.MidField)
				.Create(ISM_GameSettingType.DribbleSequence, ISM_GameSetting.FieldPenalty, 90, Actions.ISMBallVertical.OwnThird)
				.Create(ISM_GameSettingType.DribbleSequence, ISM_GameSetting.FieldPenalty, 95, Actions.ISMBallVertical.OwnShortRange)
				.Create(ISM_GameSettingType.DribbleSequence, ISM_GameSetting.FieldPenalty, 99, Actions.ISMBallVertical.OwnCrease)
			End With
		End Sub

		Private Sub LoadShotSequence()
			With Me.Settings
				'.Create(ISM_GameSettingType.ShotSequence, ISM_GameSetting.GenericAdj, 80)
				.Create(ISM_GameSettingType.ShotSequence, ISM_GameSetting.GenericAdj, 90)
			End With
		End Sub
	End Class
End Namespace