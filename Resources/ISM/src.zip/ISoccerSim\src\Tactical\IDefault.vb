Namespace Tactical
    Public Interface IDefault
        Sub SetDefault(ByVal ID As Integer)
    End Interface
End Namespace