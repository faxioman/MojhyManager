'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Rosters
    Public Class FreeAgentPool
        Inherits System.Collections.CollectionBase
        Implements ICloneable

        Default Property Item(ByVal index As Integer) As FreeAgentSlot
            Get
                Return CType(InnerList.Item(index), FreeAgentSlot)
            End Get
            Set(ByVal Value As FreeAgentSlot)
                InnerList.Item(index) = Value
            End Set
        End Property

        Sub Add(ByVal value As FreeAgentSlot)
            InnerList.Add(value)
        End Sub

        Sub Create(ByVal PlayerID As Integer, ByVal FreeAgentID As Integer)
            Dim Item As New FreeAgentSlot()
            With Item
                .PlayerID = PlayerID
                .FreeAgentID = FreeAgentID
            End With

            Me.InnerList.Add(Item)
        End Sub

        Sub Load()
            Dim DS As New DataServices.TeamTables()
            Dim DR As OleDb.OleDbDataReader = DS.GetFreeAgentPool
            Me.InnerList.Clear()

            Do While DR.Read()
                With DR
                    Call Create(.Item("PlayerID"), .Item("FreeAgentID"))
                End With
            Loop
            DR.Close()
        End Sub

        Function Clone() As Object Implements ICloneable.Clone
            Dim Roster As New FreeAgentPool()
            Roster = Me
            Return Roster
        End Function

        Function IsPlayerOnRoster(ByVal PlayerID As Integer) As Boolean
            Dim p As Players.Player
            Dim rs As FreeAgentSlot

            For Each rs In Me.InnerList
                If rs.PlayerID = PlayerID Then
                    Return True
                End If
            Next
        End Function

        Function IsLegalToRemove(ByVal PlayerID As Integer) As Boolean
            Dim p As New Players.Player()
            p.Load(PlayerID)

            Dim rs As FreeAgentSlot
            Dim op As Players.Player
            Dim Result As Integer

            For Each rs In Me.InnerList
                op.Load(rs.PlayerID)
                If op.Position = p.Position Then
                    If op.ID <> p.ID Then
                        Result = Result + 1
                    End If
                End If
            Next

            Select Case p.Position
                Case Positions.ISMPlayerPosition.Defenseman
                    If Result > 2 Then Return True
                Case Positions.ISMPlayerPosition.Forward
                    If Result > 2 Then Return True
                Case Positions.ISMPlayerPosition.Goalie
                    If Result > 1 Then Return True
                Case Positions.ISMPlayerPosition.Midfielder
                    If Result > 1 Then Return True
            End Select
        End Function

        Public Sub DropPlayer(ByVal PlayerID As Integer)
            Dim ds As New DataServices.TeamTables()
            Dim rs As New FreeAgentSlot()

            For Each rs In Me.InnerList
                If rs.PlayerID = PlayerID Then
                    ds.DeletePlayerFromFreeAgentPool(rs.FreeAgentID)
                    Exit For
                End If
            Next

            Me.Load()
        End Sub

        Public Sub AddPlayer(ByVal PlayerID As Integer)
            Dim ds As New DataServices.TeamTables()
            Dim fs As New FreeAgentSlot()

            fs.Create(ds.InsertPlayerTOFreeAgentPool(PlayerID), PlayerID)
            Me.Add(fs)

        End Sub



    End Class
End Namespace
