'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Players
Imports ISoccerSim.Rosters
Imports ISoccerSim.Teams

Public Class frmTeamTrade
    Inherits System.Windows.Forms.Form

    Public TeamID As Integer
    Dim gs As GUIService = GUIService.GetInstance

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Call SetScreen(2, 1)
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lstTeam1 As System.Windows.Forms.ListBox
    Friend WithEvents lstTeam2 As System.Windows.Forms.ListBox
    Friend WithEvents lstTo As System.Windows.Forms.ListBox
    Friend WithEvents lstFrom As System.Windows.Forms.ListBox
    Friend WithEvents grpFinish As System.Windows.Forms.GroupBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnPropose As System.Windows.Forms.Button
    Friend WithEvents btnAddCashTo As System.Windows.Forms.Button
    Friend WithEvents btnAddPickTo As System.Windows.Forms.Button
    Friend WithEvents btnAddPlayerTo As System.Windows.Forms.Button
    Friend WithEvents btnAddCashFrom As System.Windows.Forms.Button
    Friend WithEvents btnAddPickFrom As System.Windows.Forms.Button
    Friend WithEvents btnAddPlayerFrom As System.Windows.Forms.Button
    Friend WithEvents tcmbFrom As TeamCombo
    Friend WithEvents tcmbTo As TeamCombo
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.grpFinish = New System.Windows.Forms.GroupBox
        Me.btnPropose = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.lstFrom = New System.Windows.Forms.ListBox
        Me.tcmbFrom = New TeamCombo
        Me.lstTeam1 = New System.Windows.Forms.ListBox
        Me.btnAddCashFrom = New System.Windows.Forms.Button
        Me.btnAddPickFrom = New System.Windows.Forms.Button
        Me.btnAddPlayerFrom = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lstTo = New System.Windows.Forms.ListBox
        Me.tcmbTo = New TeamCombo
        Me.lstTeam2 = New System.Windows.Forms.ListBox
        Me.btnAddCashTo = New System.Windows.Forms.Button
        Me.btnAddPickTo = New System.Windows.Forms.Button
        Me.btnAddPlayerTo = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.btnOK = New System.Windows.Forms.Button
        Me.grpFinish.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpFinish
        '
        Me.grpFinish.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpFinish.Controls.Add(Me.btnPropose)
        Me.grpFinish.Controls.Add(Me.GroupBox2)
        Me.grpFinish.Controls.Add(Me.GroupBox1)
        Me.grpFinish.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpFinish.Location = New System.Drawing.Point(8, 16)
        Me.grpFinish.Name = "grpFinish"
        Me.grpFinish.Size = New System.Drawing.Size(618, 320)
        Me.grpFinish.TabIndex = 12
        Me.grpFinish.TabStop = False
        Me.grpFinish.Text = "Trade Details..."
        '
        'btnPropose
        '
        Me.btnPropose.Location = New System.Drawing.Point(520, 288)
        Me.btnPropose.Name = "btnPropose"
        Me.btnPropose.Size = New System.Drawing.Size(86, 24)
        Me.btnPropose.TabIndex = 33
        Me.btnPropose.Text = "&Propose"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lstFrom)
        Me.GroupBox2.Controls.Add(Me.tcmbFrom)
        Me.GroupBox2.Controls.Add(Me.lstTeam1)
        Me.GroupBox2.Controls.Add(Me.btnAddCashFrom)
        Me.GroupBox2.Controls.Add(Me.btnAddPickFrom)
        Me.GroupBox2.Controls.Add(Me.btnAddPlayerFrom)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 16)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(296, 264)
        Me.GroupBox2.TabIndex = 29
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Team:"
        '
        'lstFrom
        '
        Me.lstFrom.ItemHeight = 14
        Me.lstFrom.Location = New System.Drawing.Point(8, 192)
        Me.lstFrom.Name = "lstFrom"
        Me.lstFrom.Size = New System.Drawing.Size(280, 60)
        Me.lstFrom.TabIndex = 37
        '
        'tcmbFrom
        '
        Me.tcmbFrom.Location = New System.Drawing.Point(8, 32)
        Me.tcmbFrom.Name = "tcmbFrom"
        Me.tcmbFrom.Size = New System.Drawing.Size(280, 24)
        Me.tcmbFrom.TabIndex = 34
        Me.tcmbFrom.TeamID = -1
        '
        'lstTeam1
        '
        Me.lstTeam1.ItemHeight = 14
        Me.lstTeam1.Location = New System.Drawing.Point(8, 96)
        Me.lstTeam1.Name = "lstTeam1"
        Me.lstTeam1.Size = New System.Drawing.Size(280, 88)
        Me.lstTeam1.TabIndex = 33
        '
        'btnAddCashFrom
        '
        Me.btnAddCashFrom.Enabled = False
        Me.btnAddCashFrom.Location = New System.Drawing.Point(200, 64)
        Me.btnAddCashFrom.Name = "btnAddCashFrom"
        Me.btnAddCashFrom.Size = New System.Drawing.Size(86, 24)
        Me.btnAddCashFrom.TabIndex = 32
        Me.btnAddCashFrom.Text = "&Add Cash"
        '
        'btnAddPickFrom
        '
        Me.btnAddPickFrom.Enabled = False
        Me.btnAddPickFrom.Location = New System.Drawing.Point(104, 64)
        Me.btnAddPickFrom.Name = "btnAddPickFrom"
        Me.btnAddPickFrom.Size = New System.Drawing.Size(86, 24)
        Me.btnAddPickFrom.TabIndex = 31
        Me.btnAddPickFrom.Text = "&Add Pick"
        '
        'btnAddPlayerFrom
        '
        Me.btnAddPlayerFrom.Location = New System.Drawing.Point(8, 64)
        Me.btnAddPlayerFrom.Name = "btnAddPlayerFrom"
        Me.btnAddPlayerFrom.Size = New System.Drawing.Size(86, 24)
        Me.btnAddPlayerFrom.TabIndex = 30
        Me.btnAddPlayerFrom.Text = "&Add Player"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(112, 24)
        Me.Label2.TabIndex = 28
        Me.Label2.Text = "Team:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lstTo)
        Me.GroupBox1.Controls.Add(Me.tcmbTo)
        Me.GroupBox1.Controls.Add(Me.lstTeam2)
        Me.GroupBox1.Controls.Add(Me.btnAddCashTo)
        Me.GroupBox1.Controls.Add(Me.btnAddPickTo)
        Me.GroupBox1.Controls.Add(Me.btnAddPlayerTo)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(312, 16)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(296, 264)
        Me.GroupBox1.TabIndex = 28
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Trade Team:"
        '
        'lstTo
        '
        Me.lstTo.ItemHeight = 14
        Me.lstTo.Location = New System.Drawing.Point(8, 192)
        Me.lstTo.Name = "lstTo"
        Me.lstTo.Size = New System.Drawing.Size(280, 60)
        Me.lstTo.TabIndex = 36
        '
        'tcmbTo
        '
        Me.tcmbTo.Location = New System.Drawing.Point(8, 32)
        Me.tcmbTo.Name = "tcmbTo"
        Me.tcmbTo.Size = New System.Drawing.Size(280, 24)
        Me.tcmbTo.TabIndex = 35
        Me.tcmbTo.TeamID = -1
        '
        'lstTeam2
        '
        Me.lstTeam2.ItemHeight = 14
        Me.lstTeam2.Location = New System.Drawing.Point(8, 96)
        Me.lstTeam2.Name = "lstTeam2"
        Me.lstTeam2.Size = New System.Drawing.Size(280, 88)
        Me.lstTeam2.TabIndex = 33
        '
        'btnAddCashTo
        '
        Me.btnAddCashTo.Enabled = False
        Me.btnAddCashTo.Location = New System.Drawing.Point(200, 64)
        Me.btnAddCashTo.Name = "btnAddCashTo"
        Me.btnAddCashTo.Size = New System.Drawing.Size(86, 24)
        Me.btnAddCashTo.TabIndex = 32
        Me.btnAddCashTo.Text = "&Add Cash"
        '
        'btnAddPickTo
        '
        Me.btnAddPickTo.Enabled = False
        Me.btnAddPickTo.Location = New System.Drawing.Point(104, 64)
        Me.btnAddPickTo.Name = "btnAddPickTo"
        Me.btnAddPickTo.Size = New System.Drawing.Size(86, 24)
        Me.btnAddPickTo.TabIndex = 31
        Me.btnAddPickTo.Text = "&Add Pick"
        '
        'btnAddPlayerTo
        '
        Me.btnAddPlayerTo.Location = New System.Drawing.Point(8, 64)
        Me.btnAddPlayerTo.Name = "btnAddPlayerTo"
        Me.btnAddPlayerTo.Size = New System.Drawing.Size(86, 24)
        Me.btnAddPlayerTo.TabIndex = 30
        Me.btnAddPlayerTo.Text = "&Add Player"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 24)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "Team To Trade With:"
        '
        'btnOK
        '
        Me.btnOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnOK.Location = New System.Drawing.Point(514, 355)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(112, 24)
        Me.btnOK.TabIndex = 13
        Me.btnOK.Text = "&OK"
        '
        'frmTeamTrade
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(634, 384)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.grpFinish)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmTeamTrade"
        Me.Text = "Propose Trade"
        Me.grpFinish.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public Sub SetScreen(ByVal TeamID As Integer)

        Call gs.SetCursor(Me)
        Me.tcmbFrom.LoadTeams(1)
        Me.tcmbTo.LoadTeams(2)
        Me.LoadPlayers(Me.tcmbFrom.TeamID(), 1)
        Me.LoadPlayers(Me.tcmbTo.TeamID(), 2)
    End Sub

    Public Sub SetScreen(ByVal TeamID As Integer, ByVal OtherTeamID As Integer)
        Call gs.SetCursor(Me)
        Me.tcmbFrom.LoadTeams(1)
        Me.tcmbTo.LoadTeams(2)
        Me.LoadPlayers(Me.tcmbFrom.TeamID(), 1)
        Me.LoadPlayers(Me.tcmbTo.TeamID(), 2)
    End Sub


    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Me.Close()
    End Sub

    Private Sub btnAddPlayerFrom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddPlayerFrom.Click
        Dim Sim As Simulation = Simulation.GetInstance
        Dim t As Team = Sim.League.GetTeamByID(tcmbFrom.TeamID)
        Dim rosterSlotID As Integer
        Dim rs As RosterSlot
        Dim p As Player
        Dim x As Integer

        rosterSlotID = lstTeam1.SelectedIndex
        t.Roster.Load(tcmbFrom.TeamID)
        rs = t.Roster.Item(rosterSlotID)
        rs.Player.Load(rosterSlotID)
        For x = 0 To lstFrom.Items.Count - 1
            If rs.Player.DisplayName = lstFrom.Items.Item(x) Then
                MsgBox("Player already in proposal", MsgBoxStyle.Exclamation, "Trade Proposal")
                Exit Sub
            End If
        Next
        lstFrom.Items.Add(rs.Player.DisplayName)
    End Sub

    Private Sub btnAddPlayerTo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddPlayerTo.Click
        Dim Sim As Simulation = Simulation.GetInstance
        Dim t As Team = Sim.League.GetTeamByID(tcmbTo.TeamID)
        Dim rosterSlotID As Integer
        Dim rs As RosterSlot
        Dim p As Player
        Dim x As Integer

        rosterSlotID = lstTeam2.SelectedIndex
        t.Roster.Load(tcmbTo.TeamID)
        rs = t.Roster.Item(rosterSlotID)
        rs.Player.Load(rosterSlotID)
        For x = 0 To lstTo.Items.Count - 1
            If rs.Player.DisplayName = lstTo.Items.Item(x) Then
                MsgBox("Player already in proposal", MsgBoxStyle.Exclamation, "Trade Proposal")
                Exit Sub
            End If
        Next
        lstTo.Items.Add(rs.Player.DisplayName)
    End Sub

    Private Sub lstFrom_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lstFrom.MouseUp
        If e.Button = MouseButtons.Right Then
            'Dim n As Integer = Me.lstFrom.IndexFromPoint(e.X, e.Y)
            'If n <> ListBox.NoMatches Then
            'MsgBox(Me.lstFrom.Items(n))
            'End If
            'MsgBox(lstFrom.SelectedItem)
            lstFrom.Items.Remove(lstFrom.SelectedItem)
        End If
    End Sub

    Private Sub lstTo_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lstTo.MouseUp
        If e.Button = MouseButtons.Right Then
            lstTo.Items.Remove(lstTo.SelectedItem)
        End If
    End Sub

    Private Sub LoadPlayers(ByVal TeamID As Integer, ByVal x As Integer) 'if x=1, then show players in lstTeam1, else show in lstTeam2
        Dim Sim As Simulation = Simulation.GetInstance
        Dim t As Team = Sim.League.GetTeamByID(TeamID)
        Dim i As Integer
        Dim rs As RosterSlot
        Dim p As Player

        t.Roster.Load(TeamID)
        For i = 0 To t.Roster.Count - 1
            rs = t.Roster.Item(i)
            rs.Player.Load(i)
            If x = 1 Then
                lstTeam1.Items.Add(rs.Player.DisplayName)
            Else
                lstTeam2.Items.Add(rs.Player.DisplayName)
            End If
        Next
    End Sub

    Private Sub tcmbFrom_SelectedIndexChanged(ByVal sender As Object, ByVal e As TeamSelectedEventArgs) Handles tcmbFrom.SelectionChanged
        If Me.tcmbFrom.TeamID() = Me.tcmbTo.TeamID() Then
            Msgbox("Team already selected")
            Exit Sub
        End If
        lstTeam1.Items.Clear()
        lstFrom.Items.Clear()
        Me.LoadPlayers(Me.tcmbFrom.TeamID(), 1)
    End Sub

    Private Sub tcmbTo_SelectedIndexChanged(ByVal sender As Object, ByVal e As TeamSelectedEventArgs) Handles tcmbTo.SelectionChanged
        If Me.tcmbTo.TeamID() = Me.tcmbFrom.TeamID() Then
            Msgbox("Team already selected")
            Exit Sub
        End If
        lstTeam2.Items.Clear()
        lstTo.Items.Clear()
        Me.LoadPlayers(Me.tcmbTo.TeamID(), 2)
    End Sub

    Private Sub btnPropose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPropose.Click
        Dim Sim As Simulation = Simulation.GetInstance
        Dim t1 As Team
        Dim t2 As Team
        Dim rs1 As RosterSlot
        Dim rs2 As RosterSlot
        Dim x As Integer
        Dim y As Integer
        Dim z As Integer
        Dim NewJersey As Byte

        t1 = Sim.League.GetTeamByID(Me.tcmbFrom.TeamID())
        t1.Roster.Load(Me.tcmbFrom.TeamID())
        t2 = Sim.League.GetTeamByID(Me.tcmbTo.TeamID())
        t2.Roster.Load(Me.tcmbTo.TeamID())

        For x = 0 To lstFrom.Items.Count - 1
            y = 0
            While y <> t1.Roster.Count - 1
                rs1 = t1.Roster.Item(y)
                rs1.Player.Load(y)
                If lstFrom.Items.Item(x) = rs1.Player.DisplayName Then
                    NewJersey = 0
                    For z = 0 To t2.Roster.Count - 1
                        rs2 = t2.Roster.Item(z)
                        rs2.Player.Load(z)
                        While rs1.Player.Jersey = rs2.Player.Jersey
                            rs1.Player.SetNewJersey(NewJersey)
                            NewJersey = NewJersey + 1
                        End While
                    Next
                    t1.Roster.DropPlayer(Me.tcmbFrom.TeamID(), rs1.Player.ID)
                    t2.Roster.AddPlayer(rs1.Player.ID, Me.tcmbTo.TeamID())
                End If
                y = y + 1
            End While
        Next

        For x = 0 To lstTo.Items.Count - 1
            y = 0
            While y <> t2.Roster.Count - 1
                rs2 = t2.Roster.Item(y)
                rs2.Player.Load(y)
                If lstTo.Items.Item(x) = rs2.Player.DisplayName Then
                    NewJersey = 0
                    For z = 0 To t2.Roster.Count - 1
                        rs1 = t1.Roster.Item(z)
                        rs1.Player.Load(z)
                        While rs2.Player.Jersey = rs1.Player.Jersey
                            rs2.Player.SetNewJersey(NewJersey)
                            NewJersey = NewJersey + 1
                        End While
                    Next
                    'rs.Player.Jersey = t1.CheckJersey(rs.Player.Jersey, Me.tcmbFrom.TeamID())
                    t2.Roster.DropPlayer(Me.tcmbTo.TeamID(), rs1.Player.ID)
                    t1.Roster.AddPlayer(rs1.Player.ID, Me.tcmbFrom.TeamID())
                End If
                y = y + 1
            End While
        Next

        lstTeam1.Items.Clear()
        lstFrom.Items.Clear()
        Me.LoadPlayers(Me.tcmbFrom.TeamID(), 1)

        lstTeam2.Items.Clear()
        lstTo.Items.Clear()
        Me.LoadPlayers(Me.tcmbTo.TeamID(), 2)
    End Sub

End Class
