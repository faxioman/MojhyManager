'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Cities
    Public Class CitySet
        Inherits System.Collections.CollectionBase
        Implements ICloneable

        Dim vs As ValidationService

        Public Enum ISMCityMarketSize
            Random = 0
            Small = 1
            Medium = 2
            Large = 3
        End Enum

        Public Enum ISMRegion
            Random = 0
            Eastern = 1
            Central = 2
            Western = 3
            International = 4
        End Enum

        Public Total As Double

        Default Property Item(ByVal index As Integer) As City
            Get
                Return CType(InnerList.Item(index), City)
            End Get
            Set(ByVal Value As City)
                InnerList.Item(index) = Value
            End Set
        End Property

        Sub Add(ByVal value As City)
            InnerList.Add(value)
        End Sub

        Sub Create(ByVal CityID As Integer, ByVal City As String, ByVal Population As Integer, ByVal State As String, ByVal Region As String)
            Dim Item As New City
            With Item
                .CityID = CityID
                .City = City
                .Population = Population
                .State = State
                .Region = Region
            End With
            Me.Total = Me.Total + 1
            InnerList.Add(Item)
        End Sub

        Sub Load()
            Dim mBaseTable As New DataServices.BaseTables
            Dim DR As OleDb.OleDbDataReader = mBaseTable.GetCities

            Me.Clear()
            Me.Total = 0
            With DR
                Do While .Read()
                    Me.Create(.Item("ID"), .Item("City"), .Item("Population"), .Item("State"), .Item("Region"))
                Loop
            End With
            DR.Close()

        End Sub

        Function GetRandomItemByProbability() As City
            Dim Item As New City
            Dim m As MathService = MathService.GetInstance()
            Dim i As Integer
            Dim pdblTotal As Double
            Dim pdblCheck As Double

            Do
                pdblTotal = 0
                pdblCheck = m.NextDouble() * Me.Total
                For i = 0 To Innerlist.Count - 1
                    Item = InnerList.Item(i)
                    pdblTotal = pdblTotal + 1
                    If pdblTotal >= pdblCheck Then
                        Return Item
                    End If
                Next
                Return Item
            Loop
        End Function

        Function GetRandomItemByMarketSize(ByVal MarketSize As ISMCityMarketSize, ByVal Region As String) As City
            Dim Item As New City

LookAgain:
            Do
                Item = GetRandomItemByProbability()
                Select Case MarketSize
                    Case ISMCityMarketSize.Random
                        Exit Do
                    Case ISMCityMarketSize.Small
                        If Item.Population <= 1000000 Then Exit Do
                    Case ISMCityMarketSize.Medium
                        If vs.Between(Item.Population, 700000, 3000000) Then Exit Do
                    Case ISMCityMarketSize.Large
                        If Item.Population > 1500000 Then Exit Do
                End Select
            Loop

            If Not IsRegionalName(Region) Then
                Return Item
            Else
                If Item.Region = Region Then
                    Return Item
                Else
                    GoTo lookagain
                End If
            End If

        End Function

        Function IsRegionalName(ByVal Text As String) As Boolean
            If Text = "Eastern" Or Text = "Western" Or Text = "Central" Or Text = "International" Then Return True
        End Function


        Function GetItemByKey(ByVal Key As String) As City
            Dim Item As New City
            Dim i As Integer
            For Each Item In InnerList
                If Item.City = Key Then
                    Return Item
                    Exit Function
                End If
            Next
        End Function

        Function GetCityByID(ByVal ID As Integer) As City
            Dim Item As City
            For Each Item In Me.InnerList
                If Item.CityID = ID Then
                    Return Item
                End If
            Next

        End Function

        Function Clone() As Object Implements ICloneable.Clone
            Return Me.MemberwiseClone
        End Function

        Public Sub New()
            vs = ValidationService.GetInstance
        End Sub
    End Class

End Namespace