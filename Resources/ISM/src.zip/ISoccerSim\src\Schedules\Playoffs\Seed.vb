Namespace Schedules.Playoffs
    Public Class Seed
        Implements ICloneable

        Public Seed As Integer
        Public TeamID As Integer
        Public ConferenceID As Integer
        Public DivisionID As Integer
        Public Wins As Integer
        Public Name As String

        Public IsTied As Boolean
        Public TieRank As Integer

        Public NetPointsVsMultiple As Integer
        Public LowestPointsGivenUpVsMultiple As Integer
        Public WinPctVsMultiple As Integer
        Public IsTestMode As Boolean

        Public Function Clone() As Object Implements System.ICloneable.Clone
            Return Me.MemberwiseClone
        End Function

        Public Sub SetTestMargins(ByVal Win As Double, ByVal Net As Integer, ByVal Low As Integer)
            Me.IsTestMode = True
            Me.WinPctVsMultiple = Win
            Me.LowestPointsGivenUpVsMultiple = Low
            Me.NetPointsVsMultiple = Net
        End Sub
    End Class

End Namespace