

Namespace Reporting.Narrative
    Public Class AdvanceScoutingReport
        Implements INarrative

        Dim ms As MathService = MathService.GetInstance
        Dim mNarrative As String


        Public Function Generate(ByVal TeamID As Integer) As String Implements INarrative.Generate
            Dim Result As String
            Dim Sim As Simulation = Simulation.GetInstance

            Dim l As Leagues.League = Sim.League
            Dim t As Teams.Team = l.GetTeamByID(TeamID)
            Dim sr As New Statistics.StatLookup(Sim.League.Season)
            Dim OtherScorerRank As Integer = ms.RandomNumber(3, 5)
            Dim ls As Statistics.LeadingScorer = sr.GetLeadingScorerForTeam(TeamID, 1)
            Dim ls2 As Statistics.LeadingScorer = sr.GetLeadingScorerForTeam(TeamID, 2)
            Dim ls3 As Statistics.LeadingScorer = sr.GetLeadingScorerForTeam(TeamID, OtherScorerRank)
            Dim gk As Statistics.LeadingGoalkeeper = sr.GetLeadingGoalieForTeam(TeamID, 1)
            Dim ld As Statistics.LeadingDefender = sr.GetLeadingDefenderForTeam(TeamID, 1)

            Sim.LoadDefaultLeague()
            Result = "The " & t.Nickname & " are currently " & l.Standings.GetStandingText(TeamID)
            Result = Result & " with a " & l.Standings.GetStreakNarrative(TeamID, Schedules.Standings.enuPhase.Season, -1) & ".  "
            Result = Result & "In their last five games, they are " & l.Standings.GetLastXGames(TeamID, 5) & "." & vbCrLf & vbCrLf

            Result = Result & t.Name & " is led offensively by " & GetLeadingScorerText(ls, False)

            If ls2.IsValid Then
                Result = Result & "The number two shooter on the team is " & GetLeadingScorerText(ls2, False)
            End If

            If ls3.IsValid Then
                Result = Result & ls3.Position & " " & ls3.PlayerName & " also contributes positively to the team with " & GetLeadingScorerText(ls3, True)
                Result = Result & "  He is " & ms.GetOrdinal(OtherScorerRank) & " on the team for this category.  "
            End If

            Result = Result & vbCrLf & vbCrLf

            Result = Result & "Defensively, " & t.Name & " is lead by " & gk.Position & " " & gk.PlayerName & ".  "
            Result = Result & gk.LastName & " has a GAA of " & gk.Avg & " and is ranked " & ms.GetOrdinal(gk.LeagueRank) & " in the league.  "
            Result = Result & "His record is " & gk.Wins & "-" & gk.Losses & " with " & gk.Saves & " saves and " & gk.ShotsFaced & " shots faced.  "
            Result = Result & "He has given up " & ms.GetPlural(CInt(gk.Goals), "goal") & " and " & ms.GetPlural(CInt(gk.Points), "point") & ".  "
            Result = Result & "The leading defender is " & ld.Position & " " & ld.PlayerName & " who has " & ms.GetPlural(ld.Blocks, "block") & ".  "

            Result = Result & vbCrLf & vbCrLf

            Result = Result & "Overall, the team has scored " & Sim.League.Standings.GetPointsFor(TeamID, Schedules.Standings.enuPhase.Season, 0) & " points and "
            Result = Result & "and given up " & Sim.League.Standings.GetPointsAgainst(TeamID, Schedules.Standings.enuPhase.Season, 0) & ".  The "
            Result = Result & t.Nickname & " are ranked " & ms.GetOrdinal(Sim.League.Standings.GetPointsForRank(TeamID)) & " and "
            Result = Result & ms.GetOrdinal(Sim.League.Standings.GetPointsAgainstRank(TeamID)) & " respectively in the league."

            Result = Result & vbCrLf & vbCrLf

            If Sim.League.Standings.GetHomeGames(TeamID) > 0 Then
                Result = Result & t.Name & " has had " & Format(Sim.League.Standings.GetHomeAttendance(TeamID), "#,###,000") & " fans for " & ms.GetPlural(Sim.League.Standings.GetHomeGames(TeamID), " home game") & ".  "
                Result = Result & "Their average attendance is " & Format(Sim.League.Standings.GetHomeAttendanceAvg(TeamID), "#,##0,000")
                Result = Result & " and they are currently ranked " & ms.GetOrdinal(Sim.League.Standings.GetAttendanceRank(TeamID)) & " in total attendance thus far."
            Else
                Result = Result & t.Name & " has not played a home game yet this season."
            End If

            mNarrative = Result
            Return Result

        End Function

        Public Function GetLeadingScorerText(ByVal ls As Statistics.LeadingScorer, ByVal ShortDesc As Boolean) As String
            Dim Result As String
            If Not ShortDesc Then
                Result = ls.Position & " " & ls.PlayerName & " who has "
            End If
            Result = Result & ms.GetPlural(ls.Goals, "goal") & " and " & ms.GetPlural(ls.Assists, "assist")
            Result = Result & " for " & ms.GetPlural(ls.Total, "point") & ".  He is ranked " & ms.GetOrdinal(ls.LeagueRank) & ".  "

            Return Result
        End Function

        Public Sub Save(ByVal TeamID As Integer, ByVal OpponentID As Integer, ByVal GameDate As Date) Implements INarrative.Save
            Dim ds As New DataServices.BaseTables
            Dim Sim As Simulation = Simulation.GetInstance
            Dim e As New Email.Email

            e.Message = mNarrative
            e.Subject = "Advanced Scouting Report: Upcoming Game Against " & Sim.League.GetTeamByID(OpponentID).Name & " on " & Format(GameDate, "M/d/yy")
            e.FromName = "Scouting Department"
            e.ToName = Sim.League.GetTeamByID(TeamID).OwnerName
            e.MessageDate = Format(GameDate, "M/d/yy")
            e.Viewed = False
            e.TeamID = TeamID
            ds.InsertEmail(e)
        End Sub

        Public Property Name() As String Implements INarrative.Name
            Get

            End Get
            Set(ByVal Value As String)

            End Set
        End Property
    End Class
End Namespace
