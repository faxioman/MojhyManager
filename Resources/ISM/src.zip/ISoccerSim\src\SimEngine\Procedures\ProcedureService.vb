'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.SimEngine.Actions
Imports ISoccerSim.SimEngine.Actions.Plays
Imports ISoccerSim.SimEngine.Actions.Sequence
Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports Microsoft.VisualBasic
Imports ISoccerSim.Players
Imports ISoccerSim.SimEngine

Namespace SimEngine.Procedures
	Public Class ProcedureService
		Public WithEvents GameEngine As GameEngine
        Dim Sim As Simulation = Simulation.GetInstance()
        Dim r As MathService = MathService.GetInstance
        Dim vs As ValidationService = ValidationService.GetInstance

		Private Regroup As Boolean = False

		Sub New(ByVal GameEngine As GameEngine)
			Me.GameEngine = GameEngine
		End Sub

		Sub ScoreMade()

			Dim pyrGK As Player = Me.GameEngine.Posession.Defense.FieldManager.Field.GetPlayerByGamePosition(ISMGamePosition.GK)
			Dim pyrSH As Player = Me.GameEngine.Posession.Offense.FieldManager.Field.ActivePlayer
            Dim pyrAss As Player = Me.GameEngine.Posession.Offense.FieldManager.Field.AssistPlayer
            Dim Point As Integer

            If Sim.League.MultiPoint Then
                If Me.GameEngine.Ball.Y < ISMBallVertical.OppThird Then
                    Point = 3
                    pyrSH.Stats.Augment(Statistics.ISMStat.ShotMade3, 1)
                    If Not pyrGK Is Nothing Then pyrGK.Stats.Augment(Statistics.ISMStat.ShotAllowed3, 1)
                Else
                    Point = 2
                    pyrSH.Stats.Augment(Statistics.ISMStat.ShotMade2, 1)
                    If Not pyrGK Is Nothing Then pyrGK.Stats.Augment(Statistics.ISMStat.ShotAllowed2, 1)
                End If

                pyrSH.Stats.Augment(Statistics.ISMStat.ShotMade, 1)
            Else
                Point = 1
                pyrSH.Stats.Augment(Statistics.ISMStat.ShotMade, 1)
            End If

            If Me.GameEngine.Posession.Offense.CurrentGameSituation = ISMGameSituation.PowerPlay Then
                pyrSH.Stats.Augment(Statistics.ISMStat.PowerPlayGoal, 1)
            ElseIf Me.GameEngine.Posession.Offense.CurrentGameSituation = ISMGameSituation.PenaltyKill Then
                pyrSH.Stats.Augment(Statistics.ISMStat.ShortHandedGoal, 1)
            End If

            If Me.GameEngine.PenaltyService.ShootOutSituation Then
                pyrSH.Stats.Augment(Statistics.ISMStat.ShootoutGoals, 1)
                pyrSH.Stats.Augment(Statistics.ISMStat.ShootoutAttempts, 1)
                If Not pyrGK Is Nothing Then pyrGK.Stats.Augment(Statistics.ISMStat.ShootoutLosses, 1)
            End If

            Me.GameEngine.Posession.Offense.Scoreboard.Augment(Point, Me.GameEngine.Clock.Quarter)
            Call HandleGameWinningShot(Point)
            If Not pyrGK Is Nothing Then pyrGK.Stats.Augment(Statistics.ISMStat.ShotAllowed, 1)
            pyrSH.Stats.Augment(Statistics.ISMStat.Points, Point)
            pyrSH.Stats.Augment(Statistics.ISMStat.ShotAttempted, 1)
            If Not (pyrAss Is Nothing) Then pyrAss.Stats.Augment(Statistics.ISMStat.Assists, 1)


            Me.GameEngine.FireScoreEvent()
            Me.GameEngine.PenaltyService.HandlePlayerReturnAfterGoal(Me.GameEngine.Posession.Defense)
            Me.GameEngine.Posession.Switch()
            Me.GameEngine.Ball.PlaceAtMidField()
            Me.GameEngine.Status = ISMGameStatus.KickOff
		End Sub

		Sub Kickoff()
			With Me.GameEngine
				Dim pseqKickOff As New KickOff(Me.GameEngine)
				.Ball.PlaceAtMidField()
				pseqKickOff.Execute()
			End With
		End Sub

		Sub GoalieIn()
			'TODO:  Work on goalie throw in...
			Call AdvanceToGoal()
		End Sub

		Sub ThrowIn()
			'TODO:  Work on generic penalty throw in...
			Call AdvanceToGoal()
		End Sub

		Sub AdvanceToGoal()
			With Me.GameEngine
				Dim pseqPass As New Pass(Me.GameEngine)
				Dim pseqDribble As New Dribble(Me.GameEngine)
				Dim OptForPass As New DribbleVersusPassAction(Me.GameEngine)

StartAgain:
                Do Until BallInOtherEndOfField() Or .Clock.IsClockEnd Or .Posession.Changed Or .PenaltyService.InterruptPlay
                    OptForPass.Execute()
                    If OptForPass.Result = ISMActionResult.OptForPass Then
                        pseqPass.Execute()
                    Else
                        pseqDribble.Execute()
                    End If
                Loop

                If Not (.Clock.IsClockEnd Or .Posession.Changed Or .PenaltyService.InterruptPlay) Then
                    Call ShotSetupSequence()
                    If .PenaltyService.InterruptPlay Then
                        Exit Sub
                    End If

                    If Me.GameEngine.Posession.Changed = False Then
                        Call FallBack()
                        GoTo StartAgain
                    End If
                End If
            End With
		End Sub

		Private Function BallInOtherEndOfField()
			With Me.GameEngine
				Return (.Ball.Y >= ISMBallVertical.OppThird And .Posession.Offense.FieldManager.Field.IsOffensiveFrontPlayer)
			End With
		End Function

		Private Sub FallBack()
			With Me.GameEngine
				.Ball.PlaceAtMidField()
			End With
		End Sub

		Private Sub ShotSetupSequence()
			With Me.GameEngine
				Dim pseqPass As New Pass(Me.GameEngine)
				Dim pseqDribble As New Dribble(Me.GameEngine)
				Dim OptForPass As New DribbleVersusPassAction(Me.GameEngine)
				Dim PassAmt As New ShotSetupAction(Me.GameEngine)
				Dim pseqShot As New Shot(Me.GameEngine)

				Dim TotalPasses As Integer

				PassAmt.Execute()
				TotalPasses = PassAmt.Result

                Do Until .Posession.Changed = True Or TotalPasses <= 0 Or .Clock.IsClockEnd Or .PenaltyService.InterruptPlay
                    OptForPass.Execute()
                    If OptForPass.Result = ISMActionResult.OptForPass Then
                        pseqPass.Execute()
                    Else
                        pseqDribble.Execute()
                    End If
                    TotalPasses = TotalPasses - 1
                Loop

                If Not .PenaltyService.InterruptPlay Then
                    pseqShot.Execute()
                    If pseqShot.Result = ISMActionResult.GoalMade Then
                        Call Me.ScoreMade()
                    End If
                End If
            End With

        End Sub

        Public Sub SetUpPenaltyShotSequence()
            With Me.GameEngine
                Dim pseqShot As New Shot(Me.GameEngine)

                pseqShot.Execute()
                If pseqShot.Result = ISMActionResult.GoalMade Then
                    Call Me.ScoreMade()
                End If

            End With

        End Sub

        Public Sub SetUpShootoutSequence()
            Dim pyrOffense As Players.Player = Me.GameEngine.Posession.Offense.FieldManager.Field.ActivePlayer
            Dim pyrGoalie As Players.Player = Me.GameEngine.Posession.Defense.FieldManager.Field.GetPlayerByGamePosition(ISMGamePosition.GK)
            Dim pseqShot As New Shot(Me.GameEngine)

            With Me.GameEngine
                .PlayByPlay.SetPlayers(pyrOffense, pyrOffense, Nothing, pyrGoalie, Nothing)
                .GameLog.Create(.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.ShootoutSetup))
                .Ball.Y = ISMBallVertical.OppCrease
                .Ball.X = r.RandomNumber(.Ball.X.MidLeft, .Ball.X.MidRight)
                pseqShot.Execute()
                If pseqShot.Result = ISMActionResult.GoalMade Then
                    Call Me.ScoreMade()
                Else
                    Dim pyrGK As Player = .Posession.Defense.FieldManager.Field.GetPlayerByGamePosition(ISMGamePosition.GK)
                    .Posession.Offense.FieldManager.Field.ActivePlayer.Stats.Augment(Statistics.ISMStat.ShootoutAttempts, 1)
                    If Not pyrGK Is Nothing Then pyrGK.Stats.Augment(Statistics.ISMStat.ShootoutWins, 1)
                End If

            End With

        End Sub

        Sub ManagePlayerEnergy()
            With Me.GameEngine.Posession
                .Offense.FieldManager.Field.Fatigue()
                .Offense.FieldManager.Bench.Rejuvinate()
                .Offense.FieldManager.Box.Rejuvinate()

                .Defense.FieldManager.Field.Fatigue()
                .Defense.FieldManager.Bench.Rejuvinate()
                .Defense.FieldManager.Box.Rejuvinate()
            End With
        End Sub

        Sub ManageGPI()
            With Me.GameEngine.Posession
                .Offense.FieldManager.Field.ManageGPI()
                .Defense.FieldManager.Field.ManageGPI()
            End With
        End Sub

        Sub GameSummaryToLog()
            With Me.GameEngine.PlayByPlay
                Me.GameEngine.GameLog.Create(.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.GameSituation))
            End With
        End Sub

        Sub ManageSubstitutions()
            Me.GameEngine.Coaching.SetLines()
        End Sub

        Sub ManagePlayersComingOutOfBox()
            Me.GameEngine.PenaltyService.HandlePlayerReturns()
        End Sub

        Private Sub HandleGameWinningShot(ByVal Points As Integer)
            With Me.GameEngine.Posession
                Dim OffenseScore As Integer = .Offense.Scoreboard.Score
                Dim DefenseScore As Integer = .Defense.Scoreboard.Score

                If OffenseScore > DefenseScore Then
                    If vs.Between((OffenseScore - DefenseScore), 1, Points) Then
                        .Offense.FieldManager.GameWinningPlayer = .Offense.FieldManager.Field.ActivePlayer
                        .Defense.FieldManager.GameWinningPlayer = Nothing

                        .Offense.FieldManager.WinningGoalie = .Offense.FieldManager.Field.GetPlayerByGamePosition(ISMGamePosition.GK)
                        .Defense.FieldManager.LosingGoalie = .Defense.FieldManager.Field.GetPlayerByGamePosition(ISMGamePosition.GK)

                        .Offense.FieldManager.LosingGoalie = Nothing
                        .Defense.FieldManager.WinningGoalie = Nothing
                    End If

                    If .Offense.FieldManager.LosingGoalie Is Nothing Then
                        If .Defense.FieldManager.LosingGoalie Is Nothing Then
                            Debug.Assert(True, "Should not happen.")
                        End If
                    End If
                End If
            End With
        End Sub

    End Class
End Namespace
