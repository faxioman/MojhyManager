'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Leagues
Imports ISoccerSim.Teams
Imports System.Xml


Namespace Multiplayer
    Public Class ExportManager

        Public ProcessDir As String
        Dim x As New XmlDocument
        Dim mLeague As League
        Dim mTeamID As Integer
        Dim mTeam As Team

        Public Sub New(ByVal TeamID As Integer)
            Dim Sim As Simulation = Simulation.GetInstance

            mLeague = Sim.GetInstance.League
            mTeamID = TeamID
            mTeam = mLeague.GetTeamByID(mTeamID)

        End Sub


        Public Sub Export()

            Dim ExportFile = mLeague.Dir.Remote & "\" & mTeam.TeamID & ".txt"
            Dim n As XmlElement = x.CreateNode(XmlNodeType.Element, "export", "")
            SetRootNode(n)
            SetPlayerNode(n)
            SetSubstitutionNode(n)
            x.AppendChild(n)
            x.Save(ExportFile)
            MsgBox("Done")

            'mTeam.SubstitutionSets.Load(TeamID)
            'If mTeam.SubstitutionSets.IsLegal(TeamID) Then

            'End If
        End Sub


        Private Sub SetRootNode(ByVal e As XmlElement)
            e.SetAttribute("league", mLeague.Name)
            e.SetAttribute("exportdate", System.DateTime.Now)
            e.SetAttribute("phase", mLeague.Phase)
            e.SetAttribute("leaguedate", mLeague.Schedule.GetCurrentDate)
            e.SetAttribute("teamid", mTeamID)
        End Sub

        Private Sub SetPlayerNode(ByVal e As XmlElement)
            Dim n As XmlElement = CreateElement("roster", "")
            Dim p As XmlElement
            Dim i As Integer

            mTeam.Roster.Load(mTeam.TeamID)
            For i = 0 To mTeam.Roster.Count - 1
                n = AddToElement(n, "player", "")
                CType(n.LastChild, XmlElement).SetAttribute("playerid", mTeam.Roster.Item(i).PlayerID)
            Next
            e.AppendChild(n)
        End Sub

        Private Sub SetSubstitutionNode(ByVal e As XmlElement)
            Dim n As XmlElement = CreateElement("subs", "")
            Dim i As Integer
            Dim x As Integer

            mTeam.SubstitutionSets.Load(mTeam.TeamID)
            If mTeam.SubstitutionSets.IsLegal(mTeam.TeamID) Then
                For i = 0 To mTeam.SubstitutionSets.Count - 1
                    Dim sl As XmlElement = CreateElement("line", "")
                    sl.SetAttribute("lineid", i)
                    For x = 0 To mTeam.SubstitutionSets(i).Count - 1
                        sl = AddToElement(sl, "player", "")
                        CType(sl.LastChild, XmlElement).SetAttribute("playerid", mTeam.SubstitutionSets.Item(i).Item(x).PlayerID)
                        CType(sl.LastChild, XmlElement).SetAttribute("positionid", x)
                    Next
                    n.AppendChild(sl)
                Next
            End If
            e.AppendChild(n)
        End Sub

        Private Function CreateElement(ByVal Name As String, ByVal Value As String) As XmlElement
            Dim n As XmlElement = x.CreateNode(XmlNodeType.Element, Name, "")
            n.InnerText = Value
            Return n
        End Function

        Private Function AddToElement(ByVal e As XmlElement, ByVal Name As String, ByVal Value As String) As XmlElement
            Dim n As XmlElement = CreateElement(Name, Value)
            e.AppendChild(n)
            Return e
        End Function

        Private Function SetAttribute(ByVal n As XmlNode, ByVal Name As String, ByVal Value As String)
            If n.NodeType = XmlNodeType.Element Then
                CType(n, XmlElement).SetAttribute(Name, Value)
            End If
        End Function
    End Class
End Namespace