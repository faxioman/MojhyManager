'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.Data.OleDb

Namespace DataServices

    Interface IStatReport
        Function GetBaseLeagueStat(ByVal SeasonID As Integer) As DataSet
        Function GetBaseLeagueStatForTeam(ByVal Stat As ISoccerSim.Statistics.ISMStat, ByVal TeamID As Integer, ByVal SeasonID As Integer) As DataSet
        Function GetBaseLeagueStatForConference(ByVal Stat As ISoccerSim.Statistics.ISMStat, ByVal ConferenceID As Integer, ByVal SeasonID As Integer) As DataSet
        Function GetBaseLeagueStatForDivision(ByVal Stat As ISoccerSim.Statistics.ISMStat, ByVal DivisionID As Integer, ByVal SeasonID As Integer) As DataSet
        Function GetBaseTeamStat(ByVal Stat As ISoccerSim.Statistics.ISMStat, ByVal SeasonID As Integer) As DataSet
        Function GetBaseTeamStatForConference(ByVal Stat As ISoccerSim.Statistics.ISMStat, ByVal ConferenceID As Integer, ByVal SeasonID As Integer) As DataSet
        Function GetBaseTeamStatForDivision(ByVal Stat As ISoccerSim.Statistics.ISMStat, ByVal DivisionID As Integer, ByVal SeasonID As Integer) As DataSet

    End Interface

    Public Class DataService

        Shared myDBService As DataService
        Dim DBConnect As DatabaseConnection = DatabaseConnection.GetInstance()

        Sub Reconnect()
            DBConnect.Reconnect()

        End Sub

        Public Shared Function GetInstance() As DataService
            If myDBService Is Nothing Then
                myDBService = New DataService
            End If

            Return myDBService
        End Function

        Private Sub Connect()
            DBConnect.Connect()
        End Sub

        Sub Close()
            'DBConnect.cn.Close()
        End Sub


        Public Function GetDataReader(ByVal strSQL As String) As OleDbDataReader
            Try
                'Console.WriteLine("OK:  " & DBConnect.TotalCalls & " - " & strSQL)
                If DBConnect.cn.State <> ConnectionState.Open Then
                    DBConnect.Connect()
                End If
                Dim cmd As New OleDbCommand(strSQL, DBConnect.cn)
                Dim dr As OleDbDataReader = cmd.ExecuteReader()
                Return dr
            Catch ex As Exception
                Throw ex

            End Try

        End Function

        Public Function GetDataSet(ByVal strSQL As String, ByVal strName As String) As DataSet
            Try
                Dim ds As New DataSet
                Dim da As New OleDbDataAdapter(strSQL, DBConnect.cn)
                da.Fill(ds, strName)
                Return ds
            Catch ex As Exception
                Throw ex
            End Try
        End Function


        Public Function RunCommand(ByVal strSQL As String, ByVal IgnoreError As Boolean)
            Dim Cmd As New OleDbCommand(strSQL, DBConnect.cn)

            Try
                Cmd.ExecuteNonQuery()
            Catch ex As Exception
                If Not IgnoreError Then
                    Throw ex
                End If
            End Try
        End Function

        Public Function RunCommand(ByVal strSQL As String)
            Return RunCommand(strSQL, True)
        End Function

        Public Function FormatField(ByVal varIn As Object, ByVal IsString As Boolean, ByVal UseComma As Boolean) As String
            Dim strOut As String

            strOut = CStr(varIn)

            If strOut.IndexOf("'") > -1 Then
                strOut = Replace(strOut, "'", "''")
            End If

            If IsString Then
                strOut = "'" & strOut & "'"
            End If

            If UseComma Then
                strOut = strOut & ", "
            End If
            Return strOut
        End Function

        Public Function GetID(ByVal Table As String, ByVal IDField As String) As Integer
            Dim Out As Integer
            Dim SQL As String = _
             "SELECT TOP 1 " & IDField & " FROM " & Table & _
              " ORDER BY " & IDField & " DESC "

            Dim DR As OleDbDataReader = GetDataReader(SQL)
            Do While DR.Read
                Out = DR.Item(IDField)
            Loop
            DR.Close()
            Return Out


        End Function


    End Class
End Namespace

