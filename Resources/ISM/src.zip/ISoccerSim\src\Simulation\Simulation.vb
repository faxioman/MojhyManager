Imports System.IO
Imports System.Random
Imports ISoccerSim.SimEngine
Imports ISoccerSim.Ratings
Imports ISoccerSim.Positions
Imports ISoccerSim.Tactical
Imports ISoccerSim.Players
Imports ISoccerSim.Cities
Imports ISoccerSim.Leagues
Imports ISoccerSim.SimEngine.Results
Imports ISoccerSim.Utility.GUI
Imports ISoccerSim.Finances.Team

Public Class Simulation

    Public Enum ISM_SIM_State
        Empty = 1
        LeagueLoaded = 2
    End Enum

    Public FirstNames As BaseSettingSet
    Public LastNames As BaseSettingSet
    Public Colleges As BaseSettingSet
    Public Mascots As BaseSettingSet
    Public Nicknames As BaseSettingSet
    Public Tweaks As BaseSettingSet
    Public RateDistSet As RatingDistributionSet
    Public PlayerSkillSet As PlayerSkillSet
    Public PlayerAgeSet As PlayerAging
    Public PositionSet As PositionSet
    Public Cities As CitySet
    Public WithEvents League As League
    Public Skin As Skin
    Public PositionValues As PositionValues
    Public GamePositionSet As GamePositionSet
    Public TacticSet As TacticSet
    Public SituationSet As SituationSet
    Public UserSettings As UserSettings.UserSettings
    Public Referees As RefereeSet
    Public MediaSet As MediaSet

    Private IsLoaded As Boolean
    Private TestDirectory As String

    Private Shared mySim As Simulation
    Private blnLegal As Boolean

    Public Shared Function GetInstance() As Simulation
        If mySim Is Nothing Then
            mySim = New Simulation
            mySim.SetNew()
        End If
        Return mySim
    End Function

    Private Sub SetNew()
        FirstNames = New BaseSettingSet
        LastNames = New BaseSettingSet
        Colleges = New BaseSettingSet
        Mascots = New BaseSettingSet
        Nicknames = New BaseSettingSet
        Tweaks = New BaseSettingSet
        RateDistSet = New RatingDistributionSet
        PlayerSkillSet = New PlayerSkillSet
        PlayerAgeSet = New PlayerAging
        PositionSet = New PositionSet
        Cities = New CitySet
        League = New League
        Skin = New Skin
        PositionValues = New PositionValues
        GamePositionSet = New GamePositionSet
        TacticSet = New TacticSet
        SituationSet = New SituationSet
        UserSettings = New UserSettings.UserSettings
        Referees = New RefereeSet
        MediaSet = New MediaSet

    End Sub

    Public Sub New()

    End Sub

    Sub LoadGlobalAppSettings(ByVal blnReloadSkin As Boolean)

        Try
            Dim mBaseTable As New DataServices.BaseTables

            FirstNames.Load(mBaseTable.GetFirstNames, "NameID", "FirstName")
            LastNames.Load(mBaseTable.GetLastNames, "NameID", "LastName")
            Colleges.Load(mBaseTable.GetColleges, "CollegeID", "College")
            Mascots.Load(mBaseTable.GetMascots, "MascotID", "Mascot")
            Nicknames.Load(mBaseTable.GetNicknames, "NicknameID", "Nickname")
            Tweaks.Load(mBaseTable.GetTweaks, "Key", "Value")
            RateDistSet.Load()
            PlayerSkillSet.Load()
            PlayerAgeSet.Load()
            Cities.Load()
            PositionSet.Load()
            If blnReloadSkin = True Then Skin.Load()
            PositionValues.Load()
            GamePositionSet.Load()
            TacticSet.Load()
            TacticSet.Sort()
            SituationSet.Load()
            UserSettings.Load()
            Referees.Load()
            MediaSet.Load()

            ' Options.Load()
        Catch ex As System.Exception
            '			gs.ShowMessageBox("League Incompatability", "The league you are loading is not compatable " & _
            '			 " with the version of ISM you are using.  Please make sure you are running the latest " & _
            '			 " beta with leagues created from it.", Nothing)
            Throw ex

        End Try
    End Sub

    Function LoadDefaultLeague() As Boolean
        Dim fs As FileService = FileService.GetInstance
        UserSettings.Load()
        Try
            If UserSettings.DefaultLeague.Trim.Length > 0 Then
                If Dir(fs.GetCurrentDirectory() & "\leagues\" & UserSettings.DefaultLeague & "\base.mdb") <> "" Then
                    Try
                        League.Load(UserSettings.DefaultLeague)
                        LoadGlobalAppSettings(True)
                    Catch ex As Exception
                        Throw ex
                    End Try
                    Return True
                Else
                    Return False
                End If
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Sub Load()
        If Not Me.LoadDefaultLeague() Then
            Call LoadBlankLeague()
        End If
    End Sub

    Public Sub LoadBlankLeague()
        Dim mBaseTable As New DataServices.BaseTables
        If IsLoaded = False Then
            LoadGlobalAppSettings(True)
            IsLoaded = True
        End If
    End Sub

    Public Function GetSimState() As ISM_SIM_State
        If Me.League Is Nothing Or Me.League.Name = "" Then
            Return ISM_SIM_State.Empty
        Else
            Return ISM_SIM_State.LeagueLoaded
        End If
    End Function


End Class
