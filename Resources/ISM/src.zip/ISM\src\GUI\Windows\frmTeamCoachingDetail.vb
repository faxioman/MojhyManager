'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.Tactical

Public Class frmTeamCoachingDetail
	Inherits System.Windows.Forms.Form

	Private mintTacticID As Integer = 0
	Private mintProbability As Integer = 100
	Private mintLoadMode As ISMLoadMode = ISMLoadMode.AddNew
	Private marrTacticsAlreadyUsed As New ArrayList()

	Public Event CoachingDetailClosed(ByVal sender As Object, ByVal e As CoachingDetailClosed)
    Dim Sim As Simulation = Simulation.GetInstance()
    Dim gs As GUIService = GUIService.GetInstance
#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		Call SetScreen()

	End Sub

	Public Sub New(ByVal objTeamTactic As TeamTactic, ByVal LoadMode As ISMLoadMode, ByVal TacticsAlreadyUsed As ArrayList)
		mintTacticID = objTeamTactic.TacticID
		mintProbability = objTeamTactic.Probability
		mintLoadMode = LoadMode
		marrTacticsAlreadyUsed = TacticsAlreadyUsed
		Call InitializeComponent()
		Call SetScreen()
	End Sub

	Sub New(ByVal TacticsAlreadyUsed As ArrayList)
		marrTacticsAlreadyUsed = TacticsAlreadyUsed
		Call InitializeComponent()
		Call SetScreen()
	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Public WithEvents grpContent As System.Windows.Forms.GroupBox
	Public WithEvents btnOK As System.Windows.Forms.Button
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents txtProbability As System.Windows.Forms.TextBox
	Public WithEvents cmbTactics As System.Windows.Forms.ComboBox
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.grpContent = New System.Windows.Forms.GroupBox()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.txtProbability = New System.Windows.Forms.TextBox()
		Me.cmbTactics = New System.Windows.Forms.ComboBox()
		Me.btnOK = New System.Windows.Forms.Button()
		Me.grpContent.SuspendLayout()
		Me.SuspendLayout()
		'
		'grpContent
		'
		Me.grpContent.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
					Or System.Windows.Forms.AnchorStyles.Left) _
					Or System.Windows.Forms.AnchorStyles.Right)
		Me.grpContent.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label2, Me.Label1, Me.txtProbability, Me.cmbTactics})
		Me.grpContent.Location = New System.Drawing.Point(8, 8)
		Me.grpContent.Name = "grpContent"
		Me.grpContent.Size = New System.Drawing.Size(312, 80)
		Me.grpContent.TabIndex = 0
		Me.grpContent.TabStop = False
		Me.grpContent.Text = "Select a tactic and a probability..."
		'
		'Label2
		'
		Me.Label2.Location = New System.Drawing.Point(16, 48)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(72, 16)
		Me.Label2.TabIndex = 3
		Me.Label2.Text = "Probability:"
		'
		'Label1
		'
		Me.Label1.Location = New System.Drawing.Point(16, 16)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(72, 16)
		Me.Label1.TabIndex = 2
		Me.Label1.Text = "Tactic:"
		'
		'txtProbability
		'
		Me.txtProbability.Location = New System.Drawing.Point(88, 48)
		Me.txtProbability.MaxLength = 3
		Me.txtProbability.Name = "txtProbability"
		Me.txtProbability.Size = New System.Drawing.Size(56, 20)
		Me.txtProbability.TabIndex = 1
		Me.txtProbability.Text = ""
		'
		'cmbTactics
		'
		Me.cmbTactics.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbTactics.Location = New System.Drawing.Point(88, 16)
		Me.cmbTactics.Name = "cmbTactics"
		Me.cmbTactics.Size = New System.Drawing.Size(216, 22)
		Me.cmbTactics.TabIndex = 0
		'
		'btnOK
		'
		Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnOK.Location = New System.Drawing.Point(208, 96)
		Me.btnOK.Name = "btnOK"
		Me.btnOK.Size = New System.Drawing.Size(112, 24)
		Me.btnOK.TabIndex = 2
		Me.btnOK.Text = "OK"
		'
		'frmTeamCoachingDetail
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.BackColor = System.Drawing.Color.FromArgb(CType(43, Byte), CType(72, Byte), CType(142, Byte))
		Me.ClientSize = New System.Drawing.Size(328, 133)
		Me.ControlBox = False
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnOK, Me.grpContent})
		Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.ForeColor = System.Drawing.Color.Gainsboro
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.Name = "frmTeamCoachingDetail"
		Me.ShowInTaskbar = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.Text = "Team Tactic Selection"
		Me.grpContent.ResumeLayout(False)
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub SetScreen()
        Call LoadTactics()
        gs.SkinForm(Me)
	End Sub

	Private Sub LoadTactics()
		Dim Item As New Tactic()
		Me.cmbTactics.Items.Clear()

		For Each Item In Sim.TacticSet
			If Not IsTacticUsed(Item.TacticID) Or Item.TacticID = mintTacticID Then
				Me.cmbTactics.Items.Add(Item)

				If Item.TacticID = mintTacticID Then
					Me.cmbTactics.SelectedItem = Item
				End If
			End If
		Next

		Me.txtProbability.Text = mintProbability
	End Sub

	Private Function IsTacticUsed(ByVal intTacticID As Integer)
		Dim Item As New TeamTactic()
		For Each Item In Me.marrTacticsAlreadyUsed
			If Item.TacticID = intTacticID Then
				Return True
			End If
		Next
		Return False

	End Function

	Private Sub frmDialogBase_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
		'Add standard error handler
		AddHandler Application.ThreadException, New ThreadExceptionEventHandler(AddressOf HandleException)
	End Sub

	Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		Me.Close()
	End Sub

	Sub SetMainFrameText(ByVal strText As String)
		Me.grpContent.Text = strText
	End Sub

	Private Sub frmTeamCoachingDetail_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
		mintProbability = Val(Me.txtProbability.Text)
		mintTacticID = CType(Me.cmbTactics.SelectedItem, Tactic).TacticID
		RaiseEvent CoachingDetailClosed(Me, New CoachingDetailClosed(mintTacticID, mintProbability, mintLoadMode))
	End Sub
End Class
