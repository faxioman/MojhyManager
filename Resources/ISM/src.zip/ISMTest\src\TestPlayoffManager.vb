'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports NUnit.Framework

Imports ISoccerSim.Schedules.Playoffs

Namespace NUnit.Tests

    <TestFixture()> Public Class TestPlayoffManager
        <Test()> _
        Public Sub TestDivisionTree()
            Dim t As PlayoffTree = Me.GetSimplePlayoffTree
            Dim pm As New PlayoffManager
            Dim Result As PlayoffTree

            Assert.AreEqual(8, t.Count)

            Result = pm.Calculate(t, 2, PlayoffManager.ISMPlayoffMethod.DivisionOnly)
            Assert.AreEqual(2, Result.Count)
            Assert.AreEqual("#5", Result.Item(0).Name)
            Assert.AreEqual("#2", Result.Item(1).Name)

        End Sub

        <Test()> _
        Public Sub TestDivisionTreeWithTieForLead()
            Dim t As PlayoffTree = Me.GetTieForLeadTree
            Dim pm As New PlayoffManager
            Dim Result As PlayoffTree

            Assert.AreEqual(8, t.Count)

            Result = pm.Calculate(t, 2, PlayoffManager.ISMPlayoffMethod.DivisionOnly)
            Assert.AreEqual(2, Result.Count)
            Assert.AreEqual("#5", Result.Item(0).Name)
            Assert.AreEqual("#2", Result.Item(1).Name)

        End Sub

        <Test()> _
        Public Sub TestDivisionTreeWithTieForLeadN()
            Dim t As PlayoffTree = Me.GetTieForLeadTree
            Dim pm As New PlayoffManager
            Dim Result As PlayoffTree

            Assert.AreEqual(8, t.Count)

            Result = pm.Calculate(t, 2, PlayoffManager.ISMPlayoffMethod.TopNTeams)
            Assert.AreEqual(2, Result.Count)
            Assert.AreEqual("#5", Result.Item(0).Name)
            Assert.AreEqual("#2", Result.Item(1).Name)

            t = New PlayoffTree
            t = Me.GetTieForLeadTree()
            pm = New PlayoffManager
            Result = New PlayoffTree

            Result = pm.Calculate(t, 4, PlayoffManager.ISMPlayoffMethod.TopNTeams)
            Assert.AreEqual(4, Result.Count)
            Assert.AreEqual("#5", Result.Item(0).Name)
            Assert.AreEqual("#1", Result.Item(1).Name)
            Assert.AreEqual("#2", Result.Item(2).Name)
            Assert.AreEqual("#6", Result.Item(3).Name)

        End Sub

        <Test()> _
            Public Sub TestConferenceTree()
            Dim t As PlayoffTree = Me.GetSimplePlayoffTree
            Dim pm As New PlayoffManager
            Dim Result As PlayoffTree

            Assert.AreEqual(8, t.Count)

            Result = pm.Calculate(t, 2, PlayoffManager.ISMPlayoffMethod.ConferenceOnly)
            Assert.AreEqual("#5", Result.Item(0).Name)


            Dim i As Integer
            For i = 0 To Result.Count - 1
                Console.WriteLine(Result.Item(i).Name & " " & Result.Item(i).Seed & " " & Result.Item(i).Wins)
            Next

            Assert.AreEqual(1, Result.Count)


        End Sub
        <Test()> _
            Public Sub TestConferenceTree2()
            Dim t As PlayoffTree = Me.GetTieForLeadTreeConf
            Dim pm As New PlayoffManager
            Dim Result As PlayoffTree

            Assert.AreEqual(8, t.Count)

            Result = pm.Calculate(t, 1, PlayoffManager.ISMPlayoffMethod.ConferenceOnly)
            Assert.AreEqual("#5", Result.Item(0).Name)


            Dim i As Integer
            For i = 0 To Result.Count - 1
                Console.WriteLine(Result.Item(i).Name & " " & Result.Item(i).Seed & " " & Result.Item(i).Wins)
            Next

            Assert.AreEqual(1, Result.Count)


        End Sub

        <Test()> _
            Public Sub TestSimpleDivisionTie()
            Dim t As PlayoffTree = Me.GetTieForLeadTree
            Dim pm As New PlayoffManager
            Dim Result As PlayoffTree

            Assert.AreEqual(8, t.Count)

            Result = pm.Calculate(t, 2, PlayoffManager.ISMPlayoffMethod.DivisionOnly)
            Assert.AreEqual("#5", Result.Item(0).Name)
            Assert.AreEqual("#2", Result.Item(1).Name)


            Dim i As Integer
            For i = 0 To Result.Count - 1
                Console.WriteLine("Tie #1: " & Result.Item(i).Name & " " & Result.Item(i).Seed & " " & Result.Item(i).Wins)
            Next

            Assert.AreEqual(2, Result.Count)


        End Sub

        <Test()> _
            Public Sub TestSimpleDivisionTie2()
            Dim t As PlayoffTree = Me.GetTieForLeadTree2
            Dim pm As New PlayoffManager
            Dim Result As PlayoffTree

            Assert.AreEqual(8, t.Count)

            Result = pm.Calculate(t, 2, PlayoffManager.ISMPlayoffMethod.DivisionOnly)
            Assert.AreEqual("#5", Result.Item(0).Name)
            Assert.AreEqual("#2", Result.Item(1).Name)


            Dim i As Integer
            For i = 0 To Result.Count - 1
                Console.WriteLine("Tie #1: " & Result.Item(i).Name & " " & Result.Item(i).Seed & " " & Result.Item(i).Wins)
            Next

            Assert.AreEqual(2, Result.Count)


        End Sub

        <Test()> _
            Public Sub TestSimpleDivisionTie3()
            Dim t As PlayoffTree = Me.GetTieForLeadTree2
            Dim pm As New PlayoffManager
            Dim Result As PlayoffTree

            Assert.AreEqual(8, t.Count)

            Result = pm.Calculate(t, 2, PlayoffManager.ISMPlayoffMethod.DivisionOnly)
            Assert.AreEqual("#5", Result.Item(0).Name)
            Assert.AreEqual("#2", Result.Item(1).Name)


            Dim i As Integer
            For i = 0 To Result.Count - 1
                Console.WriteLine("Tie #1: " & Result.Item(i).Name & " " & Result.Item(i).Seed & " " & Result.Item(i).Wins)
            Next

            Assert.AreEqual(2, Result.Count)


        End Sub



        Private Function GetSimplePlayoffTree() As PlayoffTree
            Dim t As New PlayoffTree

            t.Add(1, "#1", 4, 1, 1)
            t.Add(2, "#2", 8, 1, 1)
            t.Add(3, "#3", 7, 1, 1)
            t.Add(4, "#4", 5, 1, 1)

            t.Add(5, "#5", 15, 1, 2)
            t.Add(6, "#6", 8, 1, 2)
            t.Add(7, "#7", 7, 1, 2)
            t.Add(8, "#8", 5, 1, 2)

            Return t
        End Function

        Private Function GetTieForLeadTree2() As PlayoffTree
            Dim t As New PlayoffTree
            t.Add(1, "#1", 12, 1, 1)
            t.Add(2, "#2", 12, 1, 1)
            t.Add(3, "#3", 7, 1, 1)
            t.Add(4, "#4", 5, 1, 1)

            t(0).SetTestMargins(0.5, -5, 2)
            t(1).SetTestMargins(0.5, 5, 0)

            t.Add(5, "#5", 15, 1, 2)
            t.Add(6, "#6", 8, 1, 2)
            t.Add(7, "#7", 7, 1, 2)
            t.Add(8, "#8", 5, 1, 2)

            Return t
        End Function

        Private Function GetTieForLeadTree3() As PlayoffTree
            Dim t As New PlayoffTree
            t.Add(1, "#1", 12, 1, 1)
            t.Add(2, "#2", 12, 1, 1)
            t.Add(3, "#3", 7, 1, 1)
            t.Add(4, "#4", 5, 1, 1)

            t(0).SetTestMargins(0.5, 0, 3)
            t(1).SetTestMargins(0.5, 0, 4)

            t.Add(5, "#5", 15, 1, 2)
            t.Add(6, "#6", 8, 1, 2)
            t.Add(7, "#7", 7, 1, 2)
            t.Add(8, "#8", 5, 1, 2)

            Return t
        End Function

        Private Function GetTieForLeadTreeConf() As PlayoffTree
            Dim t As New PlayoffTree
            t.Add(1, "#1", 12, 1, 1)
            t.Add(2, "#2", 12, 1, 1)
            t.Add(3, "#3", 7, 1, 1)
            t.Add(4, "#4", 5, 1, 1)

            t(0).SetTestMargins(0.5, 0, 3)
            t(1).SetTestMargins(0.5, 0, 4)

            t.Add(5, "#5", 15, 1, 1)
            t.Add(6, "#6", 8, 1, 1)
            t.Add(7, "#7", 7, 1, 1)
            t.Add(8, "#8", 5, 1, 1)

            Return t
        End Function

        Private Function GetTieForLeadTree() As PlayoffTree
            Dim t As New PlayoffTree

            t.Add(1, "#1", 12, 1, 1)
            t.Add(2, "#2", 12, 1, 1)
            t.Add(3, "#3", 7, 1, 1)
            t.Add(4, "#4", 5, 1, 1)

            t(0).SetTestMargins(0.0, -5, 0)
            t(1).SetTestMargins(1.0, 5, 2)


            t.Add(5, "#5", 15, 1, 2)
            t.Add(6, "#6", 8, 1, 2)
            t.Add(7, "#7", 6, 1, 2)
            t.Add(8, "#8", 5, 1, 2)

            Return t
        End Function

    End Class

End Namespace

