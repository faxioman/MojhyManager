'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
'


Namespace Statistics

	Public Enum ISMStat
		GamesPlayed = 1
		Assists = 2
		PowerPlayGoal = 3
		ShortHandedGoal = 4
		SHootingPercentage = 5
		GoalsAgainst = 6
		PenaltyMinutes = 7
		GoalsAgainstAverage = 8
		ShootoutAttempts = 9
		ShootoutPercentage = 10
		ShootoutLosses = 11
		EmptyNetGoals = 12
		ShootoutGoals = 13
		Goals = 14
		Points = 15
		FirstGoal = 16
		Minutes = 17
		Shots = 18
		ShootoutWins = 19
		Shootouts = 20
		OverGlass = 21
		Saves = 22
		ShootoutPercent = 23
		ShorthandedGoalGivenUp = 24
		ShotMade3 = 25
		ShotAttempted3 = 26
		ShotMade2 = 27
		ShotAttempted2 = 28
		ShotMade1 = 29
		ShotAttempted1 = 30
		ShotStopped3 = 31
		ShotStopped2 = 32
		ShotStopped1 = 33
		ShotMade = 34
		ShotStopped = 35
		ShotAttempted = 36
		ShotAllowed = 37
		ShotAllowed1 = 38
		ShotAllowed2 = 39
		ShotAllowed3 = 40
		Block = 41
		GameWinningGoal = 42
		GoalieWin = 43
		GoalieLoss = 44
		ShotFaced = 45
		Fouls = 46
	End Enum


	Public Class StatSet
		Inherits CollectionBase
		'Inherits DictionaryBase

		Sub Add(ByVal objStat As Stat)
			Me.InnerList.Add(objStat)
		End Sub

		Default Public Property Item(ByVal Index As Integer) As Stat
			Get
				Return CType(Me.InnerList.Item(Index), Stat)
			End Get
			Set(ByVal Value As Stat)
				Me.InnerList.Item(Index) = Value
			End Set
		End Property

		Sub Create(ByVal StatID As Integer, ByVal Name As String, ByVal Abbreviation As String)
			Dim Item As New Stat()
			With Item
				.StatID = StatID
				.Name = Name
				.Abbreviation = Abbreviation
				.Value = 0
			End With
			Me.Add(Item)
		End Sub

		Sub Augment(ByVal Stat As ISMStat, ByVal Amount As Integer)
			Dim Item As Stat
			For Each Item In Me.InnerList
				If Item.StatID = Stat Then
					Item.Value = Item.Value + Amount
					Exit Sub
				End If
			Next
			Debug.Assert(False, "You did not reference a valid statistic.")
		End Sub

		Sub Augment(ByVal Stat As ISMStat)
			Call Augment(Stat, 1)
		End Sub

		Function GetValue(ByVal Stat As ISMStat) As Integer
			Dim Item As Stat
			For Each Item In Me.InnerList
				If Item.StatID = Stat Then
					Return Item.Value
				End If
			Next
		End Function

		Function GetOrdinal(ByVal Stat As ISMStat) As String
			Dim Out As String = CStr(GetValue(Stat) + 1)
			Select Case Out
				Case "11", "12", "13"
					Return Out & "th"
				Case Else

					Select Case Right(Out, 1)
						Case "1"
							Return Out & "st"
						Case "2"
							Return Out & "nd"
						Case "3"
							Return Out & "rd"
						Case Else
							Return Out & "th"
					End Select
			End Select

		End Function

		Sub Load()
			Dim Data As New DataServices.StatTables()
			Dim DR As OleDb.OleDbDataReader = Data.GetStatistics()
			Do While DR.Read()
				Me.Create(DR.Item("StatID"), DR.Item("Name"), DR.Item("Abbreviation"))
			Loop
			DR.Close()
		End Sub

	End Class
End Namespace