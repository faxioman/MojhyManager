Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Indoor Soccer Manager")> 
<Assembly: AssemblyDescription("Fantasy indoor soccer manager for the Windows platform.")> 
<Assembly: AssemblyCompany("To-Paw Software")> 
<Assembly: AssemblyProduct("Indoor Soccer Manager - Community Edition")> 
<Assembly: AssemblyCopyright("2003 Patent Pending - BSD")> 
<Assembly: AssemblyTrademark("2003 Patent Pending - BSD")> 
<Assembly: CLSCompliant(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("FC531434-25B7-40F6-AE64-472CAC5E9B89")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("2004.09.06.1")> 
