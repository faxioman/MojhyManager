'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.Collections

Namespace SimEngine.Penalty
	Public Class PenaltySet
        Inherits CollectionBase

        Dim r As MathService = MathService.GetInstance

		Sub Add(ByVal objItem As Penalty)
			Me.InnerList.Add(objItem)
		End Sub

		Default Public Property Item(ByVal Index As Integer) As Penalty
			Get
				Return CType(Me.InnerList.Item(Index), Penalty)
			End Get
			Set(ByVal Value As Penalty)
				Me.InnerList.Item(Index) = Value
			End Set
		End Property

		Sub Create(ByVal Name As String, ByVal IsAutomaticBlue As Boolean, ByVal IsAutomaticRed As Boolean, ByVal Type As ISM_PenaltyTYpe)
			Dim Item As New Penalty()
			With Item
				.IsAutomaticBlue = IsAutomaticBlue
				.IsAutomaticRed = IsAutomaticRed
				.Type = Type
				.Name = Name
			End With
			Me.Add(Item)
		End Sub

		Sub Create(ByVal Name As String)
			Call Create(Name, False, False, ISM_PenaltyType.Player)
		End Sub

		Sub Load()
			Me.InnerList.Clear()
			Me.Create("Kicking")
			Me.Create("Tripping")
			Me.Create("Charging")
			Me.Create("Elbowing", True, False, ISM_PenaltyType.Player)
			Me.Create("Spitting", False, True, ISM_PenaltyType.Player)
			Me.Create("Holding")
			Me.Create("Pushing")
			Me.Create("Illegal Contact")
			Me.Create("Roughing")
			Me.Create("Boarding", True, False, ISM_PenaltyType.Player)
			Me.Create("Obstruction")
			Me.Create("Interference")

			Me.Create("Striking", True, False, ISM_PenaltyType.Goalie)
			Me.Create("Illegal Handling", False, False, ISM_PenaltyType.Goalie)

			Me.Create("Misconduct", False, False, ISM_PenaltyType.Team)
			Me.Create("Illegal Substitution", False, False, ISM_PenaltyType.Team)

			Me.Create("Profanity", False, True, ISM_PenaltyType.Player)
			Me.Create("Fighting", False, True, ISM_PenaltyType.Player)

        End Sub

        Function GetPenalty(ByVal Type As ISM_PenaltyType) As Penalty
            Dim i As Integer
            Dim ConsiderRedCard As Boolean

            If Type <> ISM_PenaltyType.Team Then
                ConsiderRedCard = IIf(r.RandomNumber(1, 100) < 40, True, False)
            End If

            Do
                i = r.RandomNumber(0, Me.Count - 1)
                If Me.Item(i).Type = Type Then
                    If Not ConsiderRedCard And Not Me.Item(i).IsAutomaticRed Then
                        Return Me.Item(i)
                    ElseIf ConsiderRedCard Then
                        Return Me.Item(i)
                    End If
                End If
            Loop
        End Function



    End Class
End Namespace
