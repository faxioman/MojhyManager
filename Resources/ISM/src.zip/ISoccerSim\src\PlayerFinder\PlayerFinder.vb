'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace PlayerFinder
    Public Class PlayerFinderService
        Inherits DataServices.DataService

        Public Enum ISM_Pool
            Teams = 0
            FreeAgents = 1
            Rookies = 2
        End Enum

        Public LastName As String
        Public FirstName As String
        Public Pool As ISM_Pool
        Public Age As Range
        Public Position As Positions.ISMPlayerPosition
        Public TeamID As Integer

        Public Rating1 As RatingRange
        Public Players As New ArrayList()


        Public Sub Compute()
            'Me.PlayerSet.AddByID()
        End Sub

        Private Function GetRosterPoolTable()
            Select Case Me.Pool
                Case ISM_Pool.FreeAgents
                    Return "(FreeAgentPool r INNER JOIN Players pl ON r.PlayerID = pl.PlayerID) "

                Case ISM_Pool.Rookies
                    Return "(RookiePool r INNER JOIN Players pl ON r.PlayerID = pl.PlayerID) "

                Case ISM_Pool.Teams
                    Return "(Rosters r INNER JOIN Players pl ON r.PlayerID = pl.PlayerID) "

            End Select
        End Function

        Private Function GetRatingPoolTable()
            Select Case Me.Pool
                Case ISM_Pool.FreeAgents
                    Return " INNER JOIN FreeAgentPool AS r ON pl.PlayerID = r.PlayerID) "

                Case ISM_Pool.Rookies
                    Return " INNER JOIN RookiePool AS r ON pl.PlayerID = r.PlayerID) "

                Case ISM_Pool.Teams
                    Return " INNER JOIN Rosters AS r ON pl.PlayerID = r.PlayerID) "

            End Select
        End Function

        Function GetRosterGrid() As DataSet
            Dim Where As String
            Dim SQL As String
            SQL = _
             "SELECT r.RosterID, r.TeamID, r.PlayerID, pl.LastName + ', ' + pl.FirstName AS PlayerName, " & _
             "		pl.Jersey, pl.College, pl.HighSchool, pl.Age, p.Abbr " & _
             "FROM	" & Me.GetRosterPoolTable & _
             "		INNER JOIN Positions p ON pl.PositionID = p.PositionID "
            SQL = SQL & Where & _
             " ORDER BY p.PositionID, pl.LastName, pl.FirstName"

            Return Me.GetDataSet(SQL, "Roster")
        End Function

        Function GetRosterGridRatings() As DataSet
            Dim SQL As String
            Dim Where As String

            Where = Where & " AND RatingTypeID = " & Me.Rating1.RatingType

            SQL = "TRANSFORM Sum(pr.Rating) AS SumOfRating " & _
             "SELECT pl.PlayerID, [LastName] & ', ' & [FirstName] AS Name, pos.Abbr AS POS, pl.PositionID " & _
             "FROM ((Players AS pl INNER JOIN (Ratings AS ra INNER JOIN PlayerRatings AS pr ON ra.RatingID = pr.RatingID) ON pl.PlayerID = pr.PlayerID) " & Me.GetRatingPoolTable & " INNER JOIN Positions AS pos ON pl.PositionID = pos.PositionID "

            SQL = SQL & Where & _
              " GROUP BY r.TeamID, pl.PlayerID, [LastName] & ', ' & [FirstName], pos.Abbr, pl.PositionID, pl.LastName, pl.FirstName " & _
              " ORDER BY pl.PositionID, pl.LastName, pl.FirstName " & _
              " PIVOT(ra.Abbr) "
            Return Me.GetDataSet(SQL, "Roster")

        End Function



    End Class
End Namespace
