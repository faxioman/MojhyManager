'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.IO
Imports ISoccerSim.Substitution
Imports ISoccerSim.Positions
Imports ISoccerSim.Players
Imports ISoccerSim.Rosters
Imports ISoccerSim.Schedules
Imports ISoccerSim.Teams
Imports ISoccerSim.Cities
Imports ISoccerSim.Tactical
Imports ISoccerSim.Finances.Team

Namespace Leagues
    Public Enum ISSLeaguePhase
        Preseason = 0
        RegularSeason = 1
        RegularSeasonNoTrade = 2
        Playoffs = 3
        EndOfSeason = 4
        FreeAgency = 5
        AmateurDraft = 6
        NewLeagueRegular = 7
        NewLeagueFreeAgency = 8
        Offseason = 9
    End Enum

    Public Class League
        Inherits System.Collections.CollectionBase
        Implements ICloneable

        Public Name As String
        Public Championship As String
        Public Abbreviation As String
        Public PlayoffSeries As Integer
        Public ChampionshipSeries As Integer
        Public TeamsInPlayoff As Integer
        Public InterdivisionMatchups As Integer
        Public InterconferenceMatchups As Integer
        Public IntraconferenceMatchups As Integer
        Private mintLeagueSize As Integer
        Public LeagueID As Integer
        Public Dir As New LeagueDir
        Private TeamNames As New ArrayList
        Public Phase As ISSLeaguePhase
        Public PlayoffRound As Integer

        Public Season As Integer

        Public MultiPoint As Boolean
        Public DumpToFAPool As Boolean
        Public Total As Integer
        Public Conferences As New Conferences
        Public Divisions As New Divisions
        Public Schedule As New Schedule
        Public Standings As New Standings
        Public DefaultTeamID As Integer

        Private mcolTeams As Collection
        Dim Sim As Simulation = Simulation.GetInstance()
        Dim fs As FileService = FileService.GetInstance
        Dim DBConnect As DatabaseConnection = DatabaseConnection.GetInstance()
        Dim ms As MathService = MathService.GetInstance

        Public Event Progress(ByVal sender As Object, ByVal e As ProgressEventEventArgs)
        Public Event Loaded(ByVal sender As Object, ByVal e As LeagueLoadedEventArgs)

        Public Property LeagueSize() As Integer
            Get
                Return mintLeagueSize
            End Get
            Set(ByVal Value As Integer)
                mintLeagueSize = Value
            End Set
        End Property

        Default Property Item(ByVal index As Integer) As Team
            Get
                Return CType(InnerList.Item(index), Team)
            End Get
            Set(ByVal Value As Team)
                InnerList.Item(index) = Value
            End Set
        End Property

        Function GetTeamByID(ByVal index As Integer) As Team
            Dim Team As Team
            For Each Team In Me.InnerList
                If Team.TeamID = index Then
                    Return Team
                End If
            Next
        End Function

        Function GetTeamByPlayoffSeed(ByVal Seed As Integer) As Team
            Dim Team As Team
            For Each Team In Me.InnerList
                If Team.PlayoffSeed = Seed Then
                    Return Team
                End If
            Next
        End Function

        Sub Add(ByVal value As Team)
            InnerList.Add(value)
        End Sub

        Sub Create(ByVal TeamID As Integer, ByVal ConferenceID As Integer, ByVal DivisionID As Integer, ByVal Name As String, ByVal Nickname As String, _
           ByVal Logo As String, ByVal Mascot As String, ByVal OwnerEmail As String, ByVal OwnerName As String, _
           ByVal Abbreviation As String, ByVal IsCPUOwned As Boolean, ByVal CityID As Integer, ByVal FacilityID As Integer, _
           ByVal ExpectedAttendance As Integer)

            Dim Item As New Team
            With Item
                .TeamID = TeamID
                .IsCPUOwned = IsCPUOwned
                .ConferenceID = ConferenceID
                .DivisionID = DivisionID
                .Logo = Logo
                .Mascot = Mascot
                .Name = Name
                .Nickname = Nickname
                .OwnerEmail = OwnerEmail
                .OwnerName = OwnerName
                .Abbreviation = Abbreviation
                .FacilityID = FacilityID
                .CityID = CityID
                .ExpectedAttendance = ExpectedAttendance
                Me.Total = Me.Total + 1
            End With

            InnerList.Add(Item)
        End Sub

        Sub AddTeamName(ByVal strTeam As String, ByVal intConferenceID As Integer, ByVal intDivisionID As Integer)
            Dim Shell As New TeamShell
            With Shell
                .ConferenceID = intConferenceID
                .DivisionID = intDivisionID
                .Name = strTeam
            End With
            Me.TeamNames.Add(Shell)
        End Sub


        Sub CreateNewLeague()

            Sim.League = Nothing
            GC.Collect()

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Cleaning database...", 5))
            Call Me.CleanDatabase()

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Setting up league file structure...", 10))
            Call Me.SetupLeagueFileStructure()

            Sim.League = Me

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Setting up teams...", 15))
            Call Me.CreateRandomTeams()

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Creating league schedule...", 20))
            Call Me.SetupSchedule()

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Creating league players...", 25))
            Call Me.CreatePlayers()

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Creating team substitution sets...", 75))
            Call Me.CreateSubstitutionSets()

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Creating default team coaching profiles...", 85))
            Call Me.CreateCoachingProfiles()

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Creating default financial settings...", 90))
            Call Me.CreateMediaSettings()
            Call Me.CreateFinancialSettings()

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Creating referees...", 95))
            Call Me.CreateReferees()

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Registering league settings...", 99))
            Call Me.InsertLeague()

            RaiseEvent Loaded(Me, New LeagueLoadedEventArgs(True))
            RaiseEvent Progress(Me, New ProgressEventEventArgs("Done.", 100))




        End Sub

        Private Sub CleanDatabase()
            Dim oDS As New DataServices.BaseTables
            oDS.ClearDB()
        End Sub

        Private Sub CreateMediaSettings()
            Dim oDS As New DataServices.TeamTables
            Dim TeamID As Integer
            Dim Item As MediaItem
            Dim i As Integer

            For i = 0 To Me.Count - 1
                TeamID = CType(Me.InnerList.Item(i), Team).TeamID

                For Each Item In Sim.MediaSet
                    oDS.InsertTeamMedia(TeamID, Item.MediaID, Item.Default)
                Next
            Next
        End Sub

        Private Sub CreateFinancialSettings()
            Dim oDS As New DataServices.TeamTables

            Dim i As Integer
            Dim tb As New TeamBudgets

            For i = 0 To Me.Count - 1
                oDS.InsertTeamFinancesDefault(Me.Item(i).TeamID)
                tb.CalculateDefault(Me.Item(i).TeamID, Me.Schedule.GetHomeGamesForTeam(Me.Item(i).TeamID), Me.Item(i).ExpectedAttendance)
                tb.Insert()
            Next
        End Sub

        Private Sub CreateCoachingProfiles()
            Dim i As Integer
            Dim TeamID As Integer
            Dim TeamSituationSet As TeamSituationSet
            Dim TeamSituationID As Integer

            For i = 0 To Me.Count - 1
                TeamID = CType(Me.InnerList.Item(i), Team).TeamID

                Dim Situation As Situation
                For Each Situation In Sim.SituationSet
                    TeamSituationSet = New TeamSituationSet(TeamID, Situation.SituationID)
                    With Situation
                        If .IsPenaltyKill Then
                            TeamSituationSet.Create(ISMSublineType.PenaltyKill, ISMSublineType.SecondLine, 0, 90, 80)
                        ElseIf .IsPowerPlay Then
                            TeamSituationSet.Create(ISMSublineType.PowerPlay, ISMSublineType.Starters, 0, 90, 80)
                        Else
                            TeamSituationSet.Create(ISMSublineType.Starters, ISMSublineType.SecondLine, 0, 90, 80)
                        End If
                        TeamSituationID = TeamSituationSet.Insert()
                    End With

                    Dim TeamTactic As New TeamTactic
                    With TeamTactic
                        .Probability = 100
                        .TacticID = 0
                        .TeamSituationID = TeamSituationID
                        .Insert()
                    End With
                Next

            Next

        End Sub

        Private Sub CreateSubstitutionSets()
            Dim Roster As New Roster
            Dim Factory As New SubstitutionLineFactory
            Dim SubSet As New SubstitutionLineSet
            Dim TeamID As Integer
            Dim i As Integer

            If Me.DumpToFAPool Then Exit Sub
            Try
                For i = 0 To Me.Count - 1
                    TeamID = CType(Me.InnerList.Item(i), Team).TeamID
                    Roster.Load(TeamID)

                    SubSet = Factory.GenerateLines(Roster)
                    SubSet.TeamID = TeamID
                    SubSet.Insert()
                Next

            Catch ex As System.Exception
                Throw ex
            End Try



        End Sub

        Private Sub CreateRandomTeams()
            Dim i As Integer
            Dim Team As Team
            Dim City As City
            Dim Facility As Facility
            Me.LeagueID = 1
            Me.Season = Date.Now.Year

            For i = 1 To Me.TeamNames.Count
                Team = New Team
                City = New City
                With Team
                    Dim Shell As TeamShell

                    'Set up faciliy/city stuff...
                    Shell = CType(Me.TeamNames(i - 1), TeamShell)
                    City = Sim.Cities.GetItemByKey(Shell.Name)
                    .CityID = City.CityID
                    Facility = New Facility
                    Facility.InsertRandom(City)
                    .FacilityID = Facility.FacilityID

                    'Set up base stuff...
                    .ConferenceID = Shell.ConferenceID
                    .DivisionID = Shell.DivisionID
                    .Abbreviation = City.GetAbbreviation
                    .IsCPUOwned = True
                    .Logo = ""
                    .Mascot = ""
                    .Name = City.City
                    .Nickname = GetRandomNickname()
                    .OwnerEmail = "cpu@ism.com"
                    .OwnerName = "CPU"
                    .ExpectedAttendance = Facility.GetExpectedAttendance

                    .TeamID = i
                    Me.Create(.TeamID, .ConferenceID, .DivisionID, .Name, .Nickname, .Logo, .Mascot, .OwnerEmail, .OwnerName, .Abbreviation, .IsCPUOwned, .CityID, .FacilityID, .ExpectedAttendance)
                    .Save()
                    .Add(Team)
                End With
            Next


        End Sub

        Private Function GetRandomNickname() As String
            Dim Setting As String
            Dim objTeam As Team
            Dim pblnUnique As Boolean

            Do
                pblnUnique = True
                Setting = Sim.Nicknames.GetRandomItem().Value
                For Each objTeam In Me.InnerList
                    If objTeam.Nickname = Setting Then pblnUnique = False
                Next
                If pblnUnique Then Exit Do
            Loop
            Return Setting

        End Function

        Private Sub SetupSchedule()

            With Me.Schedule
                .mobjLeague = Me
                .CreateSchedule()
                .Save()
            End With

        End Sub

        Private Sub CreatePlayers()

            Dim i As Integer
            Dim x As Integer
            Dim intRosterID As Integer
            Dim Player As New Player
            Dim Roster As New RosterSlot
            Dim FA As New FreeAgentSlot
            Dim Msg As String
            Dim Progress As Integer
            Dim Photo As PhotoService = PhotoService.GetInstance


            'Generate base teams...
            For i = 1 To Me.Count
                Msg = String.Format("Creating players for {0} ...", Me.TeamNames(i - 1))
                Progress = ((((i / Me.Count) * 100) / 2) + 30)
                RaiseEvent Progress(Me, New ProgressEventEventArgs(Msg, Progress))

                For x = 1 To Sim.Tweaks.GetIntegerValueByKey("RosterSize")
                    intRosterID = intRosterID + 1

                    'Distribute out somewhat evenly...
                    Select Case x
                        Case 1, 2
                            Player.CreateByPosition(ISMPlayerPosition.Goalie, x)
                        Case 3, 4, 5
                            Player.CreateByPosition(ISMPlayerPosition.Defenseman, x)
                        Case 6, 7
                            Player.CreateByPosition(ISMPlayerPosition.Midfielder, x)
                        Case 8, 9, 10
                            Player.CreateByPosition(ISMPlayerPosition.Forward, x)
                        Case Else
                            Player.Create(x)
                    End Select

                    If Me.DumpToFAPool Then
                        With FA
                            .Create(intRosterID, Player.ID)
                            .Insert()
                        End With
                    Else
                        With Roster
                            .Create(intRosterID, Player.ID, i)
                            .Insert()
                        End With
                    End If

                    Photo.GeneratePicture(Player.LastName, Player.FirstName)
                Next
            Next

            'Generate random free agents...
            Msg = "Generating lower tier free agents..."
            RaiseEvent Progress(Me, New ProgressEventEventArgs(Msg, 85))
            For x = 1 To Sim.Tweaks.GetIntegerValueByKey("RosterSize")
                intRosterID = intRosterID + 1

                'Distribute out somewhat evenly...
                Player.BuildWeak = True
                Player.Create(0)

                With FA
                    .Create(intRosterID, Player.ID)
                    .Insert()
                End With
            Next

        End Sub

        Private Sub CreateReferees()
            Dim R As Referee
            Dim i As Integer
            For i = 1 To (Me.Total * 3) + ms.RandomNumber(1, 5)
                R = New Referee
                R.Create()
                R.Insert()
            Next

        End Sub

        Private Function GetRandomCity() As City
            Dim I As Integer
            Dim pblnOut As Boolean
            Dim Key As String
            Dim City As New City


            pblnOut = False

            Do Until pblnOut = True
                City = Sim.Cities.GetRandomItemByProbability
                Key = City.City
                pblnOut = True

                For I = 0 To InnerList.Count - 1
                    If InnerList.Item(I).Name = Key Then
                        pblnOut = False
                    End If
                Next
            Loop
            Return City

        End Function

        Private Sub SetupLeagueFileStructure()


            Dim MainDir As String = fs.GetCurrentDirectory() & "\leagues\"
            Dim MainCSSFile As String = fs.GetCurrentDirectory() & "\data\ism.css"
            Dim Name As String = Me.Name
            Dim LeagueDir As String = fs.GetCurrentDirectory() & "\leagues\" & Me.Name & "\"

            If Directory.Exists(LeagueDir) Then
                DBConnect.Pause()
                Directory.Delete(LeagueDir, True)
            End If

            Directory.CreateDirectory(MainDir)
            Directory.CreateDirectory(LeagueDir)
            Directory.CreateDirectory(LeagueDir & "box")
            Directory.CreateDirectory(LeagueDir & "games")
            Directory.CreateDirectory(LeagueDir & "log")
            Directory.CreateDirectory(LeagueDir & "remote")
            Directory.CreateDirectory(LeagueDir & "temp")
            Directory.CreateDirectory(LeagueDir & "images")
            Directory.CreateDirectory(LeagueDir & "images\faces")
            Directory.CreateDirectory(LeagueDir & "images\logos")
            File.Copy(MainCSSFile, LeagueDir & "ism.css")

            DBConnect.Pause()
            File.Copy(fs.GetCurrentDirectory() & "\data\base.mdb", LeagueDir & "base.mdb")
            DBConnect.Connect(LeagueDir)
            Call SetupLeagueDirectoryLocations()

        End Sub

        Sub SetupLeagueDirectoryLocations()
            Dim LeagueDir As String = fs.GetCurrentDirectory() & "\leagues\" & Me.Name & "\"
            Me.Dir.BoxScores = LeagueDir & "box"
            Me.Dir.Games = LeagueDir & "games"
            Me.Dir.Log = LeagueDir & "log"
            Me.Dir.Remote = LeagueDir & "remote"
            Me.Dir.Temp = LeagueDir & "temp"
            Me.Dir.Images = LeagueDir & "images"
        End Sub

        Sub UpdateDefaultTeamID()
            Dim DS As New DataServices.LeagueTables
            Call DS.UpdateDefaultTeamID(Me.DefaultTeamID)
        End Sub

        Sub UpdatePlayoffRound()
            Dim DS As New DataServices.LeagueTables
            Call DS.UpdatePlayoffRound(Me.PlayoffRound)
        End Sub

        Sub Load(ByVal LeagueName As String)
            Me.Name = LeagueName
            Dim DS As New DataServices.LeagueTables
            Dim DSTeams As New DataServices.TeamTables
            DS.Reconnect()
            DSTeams.Reconnect()
            Dim DR As OleDb.OleDbDataReader = DS.GetLeague

            'Load base league information first...

            Do While DR.Read()
                With Me
                    .InnerList.Clear()
                    .Abbreviation = DR.Item("Abbreviation")
                    .Championship = DR.Item("Championship")
                    .ChampionshipSeries = DR.Item("ChampionshipSeries")
                    .DefaultTeamID = DR.Item("DefaultTeamID")
                    .InterconferenceMatchups = DR.Item("InterconferenceMatchups")
                    .InterdivisionMatchups = DR.Item("InterdivisionMatchups")
                    .IntraconferenceMatchups = DR.Item("IntraconferenceMatchups")
                    .LeagueID = 1
                    .MultiPoint = DR.Item("Multipoint")
                    .Name = DR.Item("Name")
                    .PlayoffSeries = DR.Item("PlayoffSeries")
                    .Season = DR.Item("Season")
                    .TeamsInPlayoff = DR.Item("TeamsInPlayoff")
                    .Phase = DR.Item("Phase")
                    .PlayoffRound = DR.Item("PlayoffRound")
                End With
            Loop
            DR.Close()

            'Load teams...
            Me.InnerList.Clear()

            DR = DSTeams.GetAllTeams

            Do While DR.Read()
                Me.Create(DR.Item("TeamID"), DR.Item("ConferenceID"), _
                   DR.Item("DivisionID"), DR.Item("Name"), _
                   DR.Item("Nickname"), DR.Item("Logo"), _
                   DR.Item("Mascot"), DR.Item("OwnerEmail"), _
                   DR.Item("OwnerName"), DR.Item("Abbreviation"), DR.Item("IsCPUOwned"), _
                DR.Item("CityID"), DR.Item("FacilityID"), DR.Item("ExpectedAttendance"))
                Me.Total = Me.Count
            Loop
            DR.Close()

            Me.Conferences.Load()
            Me.Divisions.Load()
            Me.Schedule.mobjLeague = Me
            Me.Schedule.Load()
            Me.Standings.mobjLeague = Me
            Me.Standings.Load()


            SetupLeagueDirectoryLocations()
            RaiseEvent Loaded(Me, New LeagueLoadedEventArgs(True))
        End Sub

        Sub InsertLeague()
            Dim Data As New DataServices.LeagueTables
            If Me.DumpToFAPool = True Then
                Me.Phase = ISSLeaguePhase.NewLeagueFreeAgency
            Else
                Me.Phase = ISSLeaguePhase.NewLeagueRegular
            End If
            Data.InsertLeague(Me)
            Data.Close()

            Dim Conference As Conference
            For Each Conference In Me.Conferences
                Conference.Save()
            Next

            Dim Division As Division
            For Each Division In Me.Divisions
                Division.Save()
            Next
        End Sub

        Function Clone() Implements ICloneable.Clone
            Dim League As New League
            League = Me
            League.InnerList.Sort()
            Return League
        End Function

        Function CanRunExhibition() As Boolean
            If Me.Phase = ISSLeaguePhase.NewLeagueRegular Or Me.Phase = ISSLeaguePhase.RegularSeason Or _
             Me.Phase = ISSLeaguePhase.RegularSeasonNoTrade Or Me.Phase = ISSLeaguePhase.Preseason Or _
             Me.Phase = ISSLeaguePhase.EndOfSeason Then
                Return True
            Else
                Return False
            End If
        End Function

        Function GetDivisionsForConference(ByVal intConferenceID As Integer) As ArrayList
            Dim Div As Division
            Dim parrOut As New ArrayList

            For Each Div In Me.Divisions
                If Div.ConferenceID = intConferenceID Then
                    parrOut.Add(Div)
                End If
            Next
            parrOut.Sort()
            Return parrOut
        End Function

        Function GetTeamsForDivision(ByVal intDivisionID As Integer) As ArrayList
            Dim Team As Team
            Dim parrOut As New ArrayList

            For Each Team In Me.InnerList
                If Team.DivisionID = intDivisionID Then
                    parrOut.Add(Team)
                End If
            Next
            parrOut.Sort()
            Return parrOut
        End Function


    End Class

    Public Class LeagueLoadedEventArgs
        Inherits System.EventArgs

        Public Success As Boolean
        Sub New(ByVal blnSuccess As Boolean)
            Me.Success = blnSuccess
        End Sub
    End Class

    
End Namespace