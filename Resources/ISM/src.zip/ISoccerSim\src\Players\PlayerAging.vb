'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Players
    Public Class PlayerAging
        Inherits System.Collections.CollectionBase

        Public Total As Double


        Sub Add(ByVal value As PlayerAge)
            InnerList.Add(value)
        End Sub

        Sub Create(ByVal Age As Byte, ByVal InitialCurve As Integer, ByVal PotentialMin As Integer, ByVal PotentialMax As Integer)
            Dim Item As New PlayerAge()
            With Item
                .Age = Age
                .InitialCurve = InitialCurve
                .PotentialMax = PotentialMax
                .PotentialMin = PotentialMin
                Me.Total = Me.Total + .InitialCurve
            End With

            InnerList.Add(Item)
        End Sub

        Sub Load()
            Dim mBaseTable As New DataServices.BaseTables()
            Dim DR As OleDb.OleDbDataReader = mBaseTable.GetPlayerAging

            Me.Total = 0

            Me.Clear()
            With DR
                Do While .Read()
                    Me.Create(.Item("Age"), .Item("InitialCurve"), .Item("PotentialMin"), .Item("PotentialMax"))
                Loop
            End With
            DR.Close()

        End Sub

        Function GetRandomItemByProbability() As PlayerAge
            Dim Item As New PlayerAge()
            Dim m As MathService = MathService.GetInstance()
            Dim i As Integer
            Dim pdblTotal As Double
            Dim pdblCheck As Double

            pdblCheck = m.NextDouble() * Me.Total
            For i = 0 To InnerList.Count - 1
                Item = InnerList.Item(i)
                pdblTotal = pdblTotal + Item.InitialCurve
                If pdblTotal >= pdblCheck Then
                    Return Item
                End If
            Next

            Debug.Assert(False)

        End Function
    End Class
End Namespace

