'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Teams

Namespace Schedules

	Public Enum ISMPhase
		RegSeason = 0
		Preseason = -1
		PostSeason = 1
	End Enum

	Public Enum ISMGameScheduleStatus
		Played = 1
		NotPlayed = 0
        IfNeeded = 2
	End Enum

	Public Class Game
		Implements IComparable

		Public GameID As Integer
		Public HomeTeamID As Integer
		Public AwayTeamID As Integer
		Public HomeScore As Integer
		Public AwayScore As Integer
		Public Overtime As Boolean
		Public Status As ISMGameScheduleStatus
		Public Phase As ISMPhase
		Public Attendance As Integer
		Public Used As Boolean
		Public Season As Integer
		Public GameDate As Date
		Public WinnerID As Integer
		Public LoserID As Integer
		Public WinnerScore As Integer
        Public LoserScore As Integer
        Public SeriesID As Integer

        Dim Sim As Simulation = Simulation.GetInstance()

        Sub Save()
            Dim Data As New DataServices.LeagueTables
            Data.InsertGame(Me)
            Data.Close()
        End Sub

        Sub UpdateResult()
            Dim Data As New DataServices.LeagueTables
            Data.UpdateGame(Me)
            Data.Close()
        End Sub

        Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
            If obj Is Nothing Then Return 1

            Dim other As Game = CType(obj, Game)
            If Me.GameDate > other.GameDate Then
                Return 1
            ElseIf Me.GameDate < other.GameDate Then
                Return -1
            Else
                If Me.GameID > other.GameID Then
                    Return 1
                Else
                    Return -1
                End If
            End If

        End Function

        Function GetScheduleText() As String
            Dim HomeTeam As Team = Sim.League.GetTeamByID(Me.HomeTeamID)
            Dim AwayTeam As Team = Sim.League.GetTeamByID(Me.AwayTeamID)
            Dim Result As String

            If Me.Status = ISMGameScheduleStatus.NotPlayed Then
                Result = AwayTeam.Name & " at " & HomeTeam.Name

            ElseIf Me.Status = ISMGameScheduleStatus.Played Then
                Result = AwayTeam.Name & " " & Me.AwayScore & ", " & _
                         HomeTeam.Name & " " & Me.HomeScore
            Else
                Result = AwayTeam.Name & " at " & HomeTeam.Name & " (if needed)"
            End If

            Return Result
        End Function

    End Class

	Public Class ReverseDateSort
		Implements IComparer

		Function Compare(ByVal obj1 As Object, ByVal obj As Object) As Integer Implements IComparer.Compare
			If obj Is Nothing Then Return 1

			Dim other As Game = CType(obj, Game)
			Dim first As Game = CType(obj1, Game)

			If first.GameDate = other.GameDate Then
				If first.GameID > other.GameID Then
					Return 1
				Else
					Return -1
				End If
			Else
				Return -(DateTime.Compare(first.GameDate, other.GameDate))
			End If
			Return 0

		End Function
	End Class

	Public Class RegularDateSort
		Implements IComparer

		Function Compare(ByVal obj1 As Object, ByVal obj As Object) As Integer Implements IComparer.Compare
			If obj Is Nothing Then Return 1

			Dim other As Game = CType(obj, Game)
			Dim first As Game = CType(obj, Game)

			If first.GameDate = other.GameDate Then
				If first.GameID > other.GameID Then
					Return -1
				Else
					Return 1
				End If
			Else
				Return (DateTime.Compare(first.GameDate, other.GameDate))
			End If
			Return 0

		End Function
	End Class


End Namespace