Imports System.Collections

Namespace Schedules.Playoffs
    Public Class SeriesTemplate
        Inherits CollectionBase

        Public TemplateID As Integer
        Public NumberOfTeams As Integer

        Public Sub New()
            Me.Load()
        End Sub

        Private Sub Load()
            Me.Clear()
            Dim Sim As Simulation = Simulation.GetInstance
            Dim TeamsInPlayoffs As Integer = Sim.League.TeamsInPlayoff

            Select Case TeamsInPlayoffs
                Case 2
                    Me.Add(New Series(1, 1, 2, 0, 1))

                Case 4
                    Me.Add(New Series(1, 1, 4, 3, 1))
                    Me.Add(New Series(2, 2, 3, 3, 1))
                    Me.Add(New Series(3, Series.HIGH_SEED, Series.LOW_SEED, 0, 2))

                Case 6
                    Me.Add(New Series(1, 3, 6, 3, 1))
                    Me.Add(New Series(2, 4, 5, 4, 1))
                    Me.Add(New Series(3, 1, Series.LOW_SEED, 5, 2))
                    Me.Add(New Series(4, 2, Series.LOW_SEED, 5, 2))
                    Me.Add(New Series(5, Series.HIGH_SEED, Series.LOW_SEED, 0, 3))

                Case 8
                    Me.Add(New Series(1, 1, 8, 5, 1))
                    Me.Add(New Series(2, 2, 7, 5, 1))
                    Me.Add(New Series(3, 3, 6, 6, 1))
                    Me.Add(New Series(4, 4, 5, 6, 1))
                    Me.Add(New Series(5, Series.HIGH_SEED, Series.LOW_SEED, 7, 2))
                    Me.Add(New Series(6, Series.HIGH_SEED, Series.LOW_SEED, 7, 2))
                    Me.Add(New Series(7, Series.HIGH_SEED, Series.LOW_SEED, 0, 3))

                Case Else
                    Dim ex As New Exception("Unknown playoff total.")
            End Select

        End Sub

        Public Sub Add(ByVal s As Series)
            Me.InnerList.Add(s)
        End Sub

        Public Sub ApplyToSchedule(ByVal Round As Integer)
            Dim s As Series
            Dim Sim As Simulation = Simulation.GetInstance()
            Dim sch As Schedule = Sim.League.Schedule

            'Get teams to fill in schedule...
            For Each s In Me.InnerList
                If s.Round = Round Then
                    If s.TopSeed > 0 Then
                        s.TopTeamID = Sim.League.GetTeamByPlayoffSeed(s.TopSeed).TeamID
                    Else
                        If s.TopSeed = Series.LOW_SEED Then
                            s.TopTeamID = Sim.League.GetTeamByID(Me.GetLowSeedFromSeries(s.Round)).TeamID
                            s.TopSeed = Sim.League.GetTeamByID(Me.GetLowSeedFromSeries(s.Round)).PlayoffSeed
                        Else
                            s.TopTeamID = Sim.League.GetTeamByID(Me.GetHighSeedFromSeries(s.Round)).TeamID
                            s.TopSeed = Sim.League.GetTeamByID(Me.GetHighSeedFromSeries(s.Round)).PlayoffSeed
                        End If
                    End If

                    If s.BottomSeed > 0 Then
                        s.BottomTeamID = Sim.League.GetTeamByPlayoffSeed(s.BottomSeed).TeamID
                    Else
                        If s.BottomSeed = Series.LOW_SEED Then
                            s.BottomTeamID = Sim.League.GetTeamByID(Me.GetLowSeedFromSeries(s.Round)).TeamID
                            s.BottomSeed = Sim.League.GetTeamByID(Me.GetLowSeedFromSeries(s.Round)).PlayoffSeed
                        Else
                            s.BottomTeamID = Sim.League.GetTeamByID(Me.GetHighSeedFromSeries(s.Round)).TeamID
                            s.BottomSeed = Sim.League.GetTeamByID(Me.GetHighSeedFromSeries(s.Round)).PlayoffSeed
                        End If
                    End If
                End If
            Next

            'Now, for each series, create games in league schedule...
            Dim PlayoffStartDate As Date = DateAdd(DateInterval.Day, 7, sch.GetLastGameOfSeason())
            Dim SeriesManager As New PlayoffSeriesManager
            Dim GamesInSeries As Integer = GetGamesInSeries(Round)
            Dim NeededGames As Integer = Int(GamesInSeries / 2) + 1
            Dim x As Integer
            Dim GameType As ISMGameScheduleStatus
            Dim g As Game

            sch.Load()

            For Each s In Me.InnerList
                If s.Round = Round Then
                    For x = 1 To GamesInSeries
                        If x <= NeededGames Then
                            GameType = ISMGameScheduleStatus.NotPlayed
                        Else
                            GameType = ISMGameScheduleStatus.IfNeeded
                        End If

                        g = New Game
                        g.HomeTeamID = IIf(IsBestTeamHome(GamesInSeries, x), s.TopTeamID, s.BottomTeamID)
                        g.AwayTeamID = IIf(IsBestTeamHome(GamesInSeries, x), s.BottomTeamID, s.TopTeamID)
                        g.Phase = ISMPhase.PostSeason
                        g.Status = GameType
                        g.GameDate = DateAdd(DateInterval.Day, x, PlayoffStartDate)
                        g.SeriesID = s.SeriesID
                        sch.AddPlayoffGame(g)
                    Next
                    SeriesManager.InsertSeries(s.SeriesID, s.TopTeamID, s.BottomTeamID, s.TopSeed, s.BottomSeed, s.Round)
                End If
            Next
            Sim.League.PlayoffRound = Round
            Sim.League.UpdatePlayoffRound()

        End Sub

        Public Function GetGamesInSeries(ByVal Round As Integer) As Integer

            Dim Sim As Simulation = Simulation.GetInstance
            Dim l As Leagues.League = Sim.League

            If Me.IsChampionshipRound(Round) Then
                Return l.ChampionshipSeries
            Else
                Return l.PlayoffSeries
            End If
        End Function

        Private Function GetLowSeedFromSeries(ByVal Round As Integer) As Integer
            Dim ds As New DataServices.LeagueTables
            Return ds.GetLowSeedFromSeries(GetLastRound(Round))
        End Function

        Private Function GetHighSeedFromSeries(ByVal Round As Integer) As Integer
            Dim ds As New DataServices.LeagueTables
            Return ds.GetHighSeedFromSeries(GetLastRound(Round))
        End Function

        Private Function GetLastRound(ByVal Round As Integer) As Integer
            Return Round - 1
        End Function

        Public Function GetRoundFromSeries(ByVal SeriesID As Integer) As Integer
            Dim s As Series
            For Each s In Me.InnerList
                If s.SeriesID = SeriesID Then
                    Return s.Round
                End If
            Next
        End Function

        Public Function GetSeriesFromRound(ByVal Round As Integer) As Integer
            Dim s As Series
            For Each s In Me.InnerList
                If s.Round = Round Then
                    Return s.SeriesID
                End If
            Next
        End Function

        Private Function IsChampionshipRound(ByVal Round As Integer) As Boolean
            Dim s As Series
            Dim max As Integer = 0
            For Each s In Me.InnerList
                If s.Round > max Then max = s.Round
            Next
            If Round = max Then Return True

        End Function
        Public Function IsBestTeamHome(ByVal LengthOfSeries As Integer, ByVal GameNumber As Integer) As Boolean
            Select Case LengthOfSeries
                Case 7
                    Select Case GameNumber
                        Case 1, 2, 5, 7
                            Return True
                        Case Else
                            Return False
                    End Select
                Case 5
                    Select Case GameNumber
                        Case 1, 2, 5
                            Return True
                        Case Else
                            Return False
                    End Select
                Case 3
                    Select Case GameNumber
                        Case 1, 3
                            Return True
                        Case Else
                            Return False
                    End Select
                Case 1
                    Return True

                Case Else
                    Return True
            End Select
        End Function

    End Class
End Namespace