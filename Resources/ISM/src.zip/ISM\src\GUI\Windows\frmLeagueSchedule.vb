'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.Schedules
Imports ISoccerSim.SimEngine
Imports ISoccerSim.Utility.DataGrid
Imports ISoccerSim.Reporting.Narrative



Public Class frmLeagueSchedule
	Inherits System.Windows.Forms.Form

	Private WithEvents InProgress As frmInProgress
    Private WithEvents x As SimEngine.GameEngine

    Dim Sim As Simulation = Simulation.GetInstance()
    Dim gs As GUIService = GuiService.GetInstance

    Dim mblnStopSimulating As Boolean = False
    Dim mdatSelectedDate As Date


#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		Call SetScreen()
	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Public WithEvents grpContent As System.Windows.Forms.GroupBox
	Public WithEvents btnOK As System.Windows.Forms.Button
	Public WithEvents lstMonth As System.Windows.Forms.ListBox
	Public WithEvents GroupBox1 As System.Windows.Forms.GroupBox
	Public WithEvents radCurrentDate As System.Windows.Forms.RadioButton
	Public WithEvents radRegularSeason As System.Windows.Forms.RadioButton
    Public WithEvents dgSchedule As System.Windows.Forms.DataGrid
	Public WithEvents btnSimulate As System.Windows.Forms.Button
	Public WithEvents radSelectedDate As System.Windows.Forms.RadioButton
    Public WithEvents radPlayoffs As System.Windows.Forms.RadioButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.grpContent = New System.Windows.Forms.GroupBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.radSelectedDate = New System.Windows.Forms.RadioButton
        Me.btnSimulate = New System.Windows.Forms.Button
        Me.radPlayoffs = New System.Windows.Forms.RadioButton
        Me.radRegularSeason = New System.Windows.Forms.RadioButton
        Me.radCurrentDate = New System.Windows.Forms.RadioButton
        Me.lstMonth = New System.Windows.Forms.ListBox
        Me.dgSchedule = New System.Windows.Forms.DataGrid
        Me.btnOK = New System.Windows.Forms.Button
        Me.grpContent.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grpContent
        '
        Me.grpContent.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpContent.Controls.Add(Me.GroupBox1)
        Me.grpContent.Controls.Add(Me.lstMonth)
        Me.grpContent.Controls.Add(Me.dgSchedule)
        Me.grpContent.Location = New System.Drawing.Point(8, 8)
        Me.grpContent.Name = "grpContent"
        Me.grpContent.Size = New System.Drawing.Size(600, 344)
        Me.grpContent.TabIndex = 0
        Me.grpContent.TabStop = False
        Me.grpContent.Text = "Schedule"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radSelectedDate)
        Me.GroupBox1.Controls.Add(Me.btnSimulate)
        Me.GroupBox1.Controls.Add(Me.radPlayoffs)
        Me.GroupBox1.Controls.Add(Me.radRegularSeason)
        Me.GroupBox1.Controls.Add(Me.radCurrentDate)
        Me.GroupBox1.Location = New System.Drawing.Point(16, 192)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(128, 144)
        Me.GroupBox1.TabIndex = 22
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Simulate..."
        '
        'radSelectedDate
        '
        Me.radSelectedDate.Location = New System.Drawing.Point(8, 40)
        Me.radSelectedDate.Name = "radSelectedDate"
        Me.radSelectedDate.Size = New System.Drawing.Size(104, 16)
        Me.radSelectedDate.TabIndex = 4
        Me.radSelectedDate.Text = "Selected Date"
        '
        'btnSimulate
        '
        Me.btnSimulate.Location = New System.Drawing.Point(8, 112)
        Me.btnSimulate.Name = "btnSimulate"
        Me.btnSimulate.Size = New System.Drawing.Size(112, 24)
        Me.btnSimulate.TabIndex = 3
        Me.btnSimulate.Text = "&Simulate"
        '
        'radPlayoffs
        '
        Me.radPlayoffs.Enabled = False
        Me.radPlayoffs.Location = New System.Drawing.Point(8, 88)
        Me.radPlayoffs.Name = "radPlayoffs"
        Me.radPlayoffs.Size = New System.Drawing.Size(104, 16)
        Me.radPlayoffs.TabIndex = 2
        Me.radPlayoffs.Text = "Playoffs"
        '
        'radRegularSeason
        '
        Me.radRegularSeason.Location = New System.Drawing.Point(8, 64)
        Me.radRegularSeason.Name = "radRegularSeason"
        Me.radRegularSeason.Size = New System.Drawing.Size(104, 16)
        Me.radRegularSeason.TabIndex = 1
        Me.radRegularSeason.Text = "Regular Season"
        '
        'radCurrentDate
        '
        Me.radCurrentDate.Checked = True
        Me.radCurrentDate.Location = New System.Drawing.Point(8, 16)
        Me.radCurrentDate.Name = "radCurrentDate"
        Me.radCurrentDate.Size = New System.Drawing.Size(104, 16)
        Me.radCurrentDate.TabIndex = 0
        Me.radCurrentDate.TabStop = True
        Me.radCurrentDate.Text = "Current Date"
        '
        'lstMonth
        '
        Me.lstMonth.ItemHeight = 14
        Me.lstMonth.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"})
        Me.lstMonth.Location = New System.Drawing.Point(16, 16)
        Me.lstMonth.Name = "lstMonth"
        Me.lstMonth.Size = New System.Drawing.Size(128, 172)
        Me.lstMonth.TabIndex = 1
        '
        'dgSchedule
        '
        Me.dgSchedule.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgSchedule.DataMember = ""
        Me.dgSchedule.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgSchedule.Location = New System.Drawing.Point(160, 16)
        Me.dgSchedule.Name = "dgSchedule"
        Me.dgSchedule.Size = New System.Drawing.Size(432, 320)
        Me.dgSchedule.TabIndex = 0
        '
        'btnOK
        '
        Me.btnOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnOK.Location = New System.Drawing.Point(496, 360)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(112, 24)
        Me.btnOK.TabIndex = 2
        Me.btnOK.Text = "&OK"
        '
        'frmLeagueSchedule
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.FromArgb(CType(43, Byte), CType(72, Byte), CType(142, Byte))
        Me.ClientSize = New System.Drawing.Size(616, 397)
        Me.ControlBox = False
        Me.Controls.Add(Me.grpContent)
        Me.Controls.Add(Me.btnOK)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Gainsboro
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmLeagueSchedule"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "League Schedule"
        Me.grpContent.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.dgSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

	Private Sub frmDialogBase_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
		'Add standard error handler
		AddHandler Application.ThreadException, New ThreadExceptionEventHandler(AddressOf HandleException)
	End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        If Not InProgress Is Nothing Then
            InProgress.Close()
        End If
        Me.Close()
    End Sub

    Private Sub CreatePlayoffSchedule()
        Dim psg As New Playoffs.PlayoffScheduleGenerator
        psg.CreateFirstRound()
    End Sub

    Private Sub SetScreen()

        gs.SetCursor(Me)
        gs.SkinForm(Me)
        InProgress = New frmInProgress
        Me.AddOwnedForm(InProgress)
        mdatSelectedDate = Sim.League.Schedule.GetCurrentDate

        Call LoadMonths()
        Call SetInitialDay()
        Call SetSimOptions()

    End Sub

    Private Sub ReloadSchedule()
        Call LoadMonths()
        Call SetSimOptions()
    End Sub

    Private Sub SetInitialDay()
        Sim.League.Schedule.Load()
        Dim MyDate As Date = mdatSelectedDate
        Dim Item As ScheduleMonthItem
        For Each Item In Me.lstMonth.Items
            If IsDate(Item.GetMonthText) Then
                If Item.GetMonthText = MyDate Then
                    Me.lstMonth.SelectedItem = Item
                    Exit Sub
                End If
            End If
        Next
        SetSimOptions()
    End Sub

    Private Sub SetSimOptions()
        If Sim.League.Schedule.IsRegularSeasonDone Then
            Me.radRegularSeason.Enabled = False
            Me.radPlayoffs.Enabled = False
            Me.radCurrentDate.Enabled = True
            Me.radSelectedDate.Enabled = False
        End If

        If Sim.League.Schedule.IsSeasonDone Then
            Me.radRegularSeason.Enabled = False
            Me.radSelectedDate.Enabled = False
            Me.radCurrentDate.Enabled = False
            Me.radPlayoffs.Enabled = False
        End If
    End Sub


    Private Sub LoadMonths()
        Sim.League.Schedule.Load()
        Dim parrMonth As ArrayList = Sim.League.Schedule.GetMonthArray()
        Dim i As Integer

        Me.lstMonth.Items.Clear()

        For i = 0 To parrMonth.Count - 1
            Me.lstMonth.Items.Add(parrMonth.Item(i))
        Next
    End Sub

    Private Sub lstMonth_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstMonth.SelectedIndexChanged
        Call LoadSchedule()
        SetSimOptions()
        If IsDate(CType(Me.lstMonth.SelectedItem, ScheduleMonthItem).GetMonthText) Then
            mdatSelectedDate = CType(Me.lstMonth.SelectedItem, ScheduleMonthItem).GetMonthText
            If DateDiff(DateInterval.Day, CType(Me.lstMonth.SelectedItem, ScheduleMonthItem).ItemData, Sim.League.Standings.GetCurrentDate) > 0 Then
                Me.radSelectedDate.Enabled = False
            Else
                Me.radSelectedDate.Enabled = True
            End If
        Else
            Me.radSelectedDate.Enabled = False
        End If
    End Sub

    Private Sub LoadSchedule()
        Call LoadSchedule(Me.dgSchedule)
    End Sub

    Private Sub ProcessPostSeasonIfNecessary()

    End Sub

    Private Sub LoadSchedule(ByRef dg As DataGrid)

        gs.SetCursor(True, Me)
        Dim View As New DataViewUtility
        Sim.League.Schedule.Load()

        Dim Item As ScheduleMonthItem = CType(Me.lstMonth.SelectedItem, ScheduleMonthItem)
        If Item Is Nothing Then
            'Changed selected date to most recent date...
            mdatSelectedDate = Sim.League.Schedule.GetCurrentDate()
            Call SetInitialDay()
        End If
        If Item.IsMonth Then
            View.Standardize(Sim.League.Schedule.GetGamesForMonth(Item.ItemData))
        Else
            View.Standardize(Sim.League.Schedule.GetGamesForDate(Item.ItemData))
        End If

        With dg
            .DataSource = View
            If CType(Me.lstMonth.SelectedItem, ScheduleMonthItem).IsPlayoffDate Then
                .CaptionText = "Postseason "
            Else
                .CaptionText = ""
            End If
            .CaptionText = .CaptionText & CType(Me.lstMonth.SelectedItem, ScheduleMonthItem).GetMonthText & " Games"
        End With

        Dim Helper As New DataGridUtility(dg, "Schedule")
        With Helper
            .SetLeagueScheduleGrid()
            .Commit()
        End With
        gs.SetCursor(False, Me)
    End Sub

    Private Sub dgRoster_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgSchedule.MouseDown
        Dim pt As New Point(e.X, e.Y)
        Dim hti As DataGrid.HitTestInfo = Me.dgSchedule.HitTest(pt)

        If hti.Type = DataGrid.HitTestType.Cell Or hti.Type = DataGrid.HitTestType.RowHeader Then
            Me.dgSchedule.CurrentCell = New DataGridCell(hti.Row, hti.Column)
            Me.dgSchedule.Select(hti.Row)

            Call GetGameDetail(Int(Me.dgSchedule(hti.Row, 0)))
        End If
    End Sub

    Private Sub GetGameDetail(ByVal GameID As Integer)
        Dim Game As Game = Sim.League.Schedule.GetGameByID(GameID)
        If Game.Status = ISMGameScheduleStatus.NotPlayed Or Game.Status = ISMGameScheduleStatus.IfNeeded Then
            If Game.GameDate = mdatSelectedDate Then
                RefreshInProgressForm()
                InProgress.Show()
                Call SimulateGame(Game)
                InProgress.Hide()
                Call LoadSchedule()
            Else
                Call PreviewGame(Game)
            End If
        Else
            Call ShowResults(Game)
        End If
    End Sub

    Private Function SimulateGame(ByVal objGame As Game) As Boolean
        Dim Sim As Simulation = Simulation.GetInstance
        Dim s As Schedule = Sim.League.Schedule
        Dim psg As New Schedules.Playoffs.PlayoffScheduleGenerator

        RefreshInProgressForm()
        gs.SetCursor(True, Me)
        Try

            x = New GameEngine
            x.Load(objGame)
            InProgress.Reset()
            InProgress.UpdateBoard(x)
            InProgress.Refresh()

            Do Until x.Status = ISMGameStatus.GameOver
                x.Step()
                Application.DoEvents()
            Loop
            InProgress.SetStatusText("Saving statistics...")
            x.StatSave.Commit()

            If s.IsDateCompletelySimulated(objGame.GameDate) Then
                If Sim.UserSettings.SavePreviews Then
                    InProgress.SetStatusText("Writing weekly reports...")
                    Call WriteScoutingReports(objGame.GameDate)
                End If
            End If

            If s.IsRegularSeasonDone Then
                If Not s.ArePlayoffsCreated Then
                    InProgress.SetStatusText("Determining playoff matchups...")
                    psg.CreateFirstRound()
                    Me.ReloadSchedule()
                Else
                    Dim psm As New Schedules.Playoffs.PlayoffSeriesManager
                    If Not s.IsSeriesStillOn(x.HomeTeam.TeamID, x.AwayTeam.TeamID, objGame.SeriesID, psm.GetNumberOfPlayoffGamesOnStage(objGame.SeriesID)) Then
                        If s.IsTeamWinnerOfSeries(x.HomeTeam.TeamID, objGame.SeriesID, Sim.League.PlayoffSeries) Then
                            psm.UpdateSeries(objGame.SeriesID, x.HomeTeam.TeamID, x.AwayTeam.TeamID)
                        Else
                            psm.UpdateSeries(objGame.SeriesID, x.AwayTeam.TeamID, x.HomeTeam.TeamID)
                        End If
                        Me.ReloadSchedule()
                    Else
                        psm.PutNextGameOnSchedule(objGame.SeriesID, x.HomeTeam.TeamID, x.AwayTeam.TeamID)
                        Me.ReloadSchedule()
                    End If

                    If psm.IsPlayoffRoundComplete(objGame.SeriesID) Then
                        If s.IsSeasonDone Then
                            MsgBox("Get ready for next year.")
                        Else
                            psg.Generate2ndRoundOn()
                            Me.ReloadSchedule()
                        End If

                    End If

                End If
            End If

        Catch ex As Exception
            Call HandleException(Me, ex)
            Return True
        Finally
            gs.SetCursor(False, Me)

        End Try

        Return InProgress.ReturnToMain
    End Function

    Private Sub PreviewGame(ByVal objGame As Game)

    End Sub

    Private Sub ShowResults(ByVal objGame As Game)
        Dim f As New frmGameResults
        f.LoadGame(objGame.GameID)
        f.ShowDialog(Me)
    End Sub

    Private Sub btnSimulate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimulate.Click
        If Me.radCurrentDate.Checked = True Then SimulateCurrentDate()
        If Me.radRegularSeason.Checked = True Then SimulateRegularSeason()
        If Me.radSelectedDate.Checked = True Then SimulateToSelectedDate()
        InProgress.Close()
        InProgress = Nothing
    End Sub

    Private Sub SimulateCurrentDate()
        Dim Game As Game
        Dim i As Integer
        Dim CurrentDate As Date = mdatSelectedDate
        RefreshInProgressForm()

        For i = 0 To Sim.League.Schedule.Count - 1
            If i > Sim.League.Schedule.Count - 1 Then
                Exit For
            Else
                Game = Sim.League.Schedule.Item(i)
                If Game.GameDate = CurrentDate Then
                    If Game.Status = ISMGameScheduleStatus.NotPlayed Then
                        InProgress.Show()
                        If SimulateGame(Game) = True Then
                            InProgress.Hide()
                            Exit For
                        End If
                    End If
                End If
            End If
        Next
        InProgress.Hide()
        Call ReloadSchedule()
        Call SetInitialDay()
    End Sub

    Private Sub WriteScoutingReports(ByVal CurrentDate As Date)
        Dim Game As Game
        Dim asr As ISoccerSim.Reporting.Narrative.AdvanceScoutingReport
        Dim OpponentID As Integer
        Dim NextGame As Date

        Dim i As Integer

        For i = 0 To Sim.League.Schedule.Count - 1
            Game = Sim.League.Schedule.Item(i)
            If Game.GameDate = CurrentDate Then
                If Game.Status = ISMGameScheduleStatus.Played Then
                    asr = New ISoccerSim.Reporting.Narrative.AdvanceScoutingReport

                    OpponentID = Sim.League.Schedule.GetNextOpponent(Game.HomeTeamID, CurrentDate)
                    NextGame = Sim.League.Schedule.GetNextGameDate(Game.HomeTeamID, CurrentDate)

                    If OpponentID > 0 Then
                        If Not Sim.League.GetTeamByID(Game.HomeTeamID).IsCPUOwned Then
                            asr.Generate(OpponentID)
                            asr.Save(Game.HomeTeamID, OpponentID, NextGame)
                        End If
                    End If

                    OpponentID = Sim.League.Schedule.GetNextOpponent(Game.AwayTeamID, CurrentDate)
                    NextGame = Sim.League.Schedule.GetNextGameDate(Game.AwayTeamID, CurrentDate)

                    If OpponentID > 0 Then
                        If Not Sim.League.GetTeamByID(Game.AwayTeamID).IsCPUOwned Then
                            asr.Generate(OpponentID)
                            asr.Save(Game.AwayTeamID, OpponentID, NextGame)
                        End If
                    End If

                End If
            End If
        Next
        InProgress.Hide()
    End Sub




    Private Sub SimulateToSelectedDate()
        Dim Game As Game
        Dim i As Integer
        Dim SelectedDate As Date

        RefreshInProgressForm()

        If IsDate(CType(Me.lstMonth.SelectedItem, ScheduleMonthItem).GetMonthText) Then
            SelectedDate = CType(Me.lstMonth.SelectedItem, ScheduleMonthItem).GetMonthText
        Else
            Exit Sub
        End If

        For i = 0 To Sim.League.Schedule.Count - 1
            If i >= Sim.League.Schedule.Count - 1 Then
                Exit For
            Else
                Game = Sim.League.Schedule.Item(i)
                If DateDiff(DateInterval.Day, Game.GameDate, SelectedDate) >= 0 Then
                    If Game.Status = ISMGameScheduleStatus.NotPlayed Then
                        If InProgress.Visible Then
                            InProgress.Refresh()
                        Else
                            InProgress.Show()
                        End If
                        If SimulateGame(Game) = True Then
                            Exit For
                        End If
                    End If
                End If
            End If
        Next
        InProgress.Hide()
        Call ReloadSchedule()
        Call SetInitialDay()
    End Sub

    Private Sub RefreshInProgressForm()
        If InProgress Is Nothing Then
            InProgress = New frmInProgress
        End If
    End Sub


    Private Sub SimulateRegularSeason()
        Dim Game As Game
        Dim i As Integer
        Dim CurrentDate As Date = mdatSelectedDate

        RefreshInProgressForm()

        For i = 0 To Sim.League.Schedule.Count - 1
            If i > Sim.League.Schedule.Count - 1 Then
                Exit For
            Else
                Game = Sim.League.Schedule.Item(i)
                If Game.Status = ISMGameScheduleStatus.NotPlayed Then
                    If Game.Phase = ISMPhase.RegSeason Then
                        InProgress.Show()
                        If SimulateGame(Game) Then
                            Exit For
                        End If
                    End If
                End If
            End If
        Next
        InProgress.Hide()
        Call ReloadSchedule()
        Call SetInitialDay()
    End Sub

    Private Sub UpdateBoard() Handles x.QuarterOver, x.ScoreMade, x.PosessionChanged, x.GameOver
        InProgress.UpdateBoard(x)
    End Sub


End Class
