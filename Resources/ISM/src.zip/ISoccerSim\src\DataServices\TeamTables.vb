'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.Data.OleDb
Imports ISoccerSim.Substitution
Imports ISoccerSim.Rosters
Imports ISoccerSim.Teams
Imports ISoccerSim.Tactical
Imports ISoccerSim.Cities

Namespace DataServices
	Public Class TeamTables
		Inherits DataServices.DataService

		Function InsertTeam(ByVal objTeam As Team) As Integer

            Dim SQL As String
            With objTeam
                SQL = "INSERT INTO Teams " & _
                 "(Abbreviation, ConferenceID, DivisionID, IsCPUOwned, Logo, Mascot, Name, " & _
                 "Nickname, OwnerEmail, OwnerName, FacilityID, CityID, ExpectedAttendance, TeamID)" & _
                 "VALUES (" & _
                FormatField(.Abbreviation, True, True) & _
                FormatField(.ConferenceID, False, True) & _
                FormatField(.DivisionID, False, True) & _
                FormatField(.IsCPUOwned, False, True) & _
                FormatField(.Logo, True, True) & _
                FormatField(.Mascot, True, True) & _
                FormatField(.Name, True, True) & _
                FormatField(.Nickname, True, True) & _
                FormatField(.OwnerEmail, True, True) & _
                FormatField(.OwnerName, True, True) & _
                FormatField(.FacilityID, False, True) & _
                FormatField(.CityID, True, True) & _
                FormatField(.ExpectedAttendance, False, True) & _
                FormatField(.TeamID, False, False) & ")"

            End With

            RunCommand(SQL)
            Return objTeam.TeamID

        End Function

        Function InsertRosterSlot(ByVal objRoster As RosterSlot)
            Dim SQL As String
            With objRoster
                SQL = "INSERT INTO Rosters " & _
                 "(RosterID, PlayerID, TeamID)" & _
                 "VALUES (" & _
                FormatField(.RosterSlotID, False, True) & _
                FormatField(.PlayerID, False, True) & _
                FormatField(.TeamID, False, False) & ")"

            End With

            RunCommand(SQL)
            Return objRoster.RosterSlotID

        End Function

        Function InsertSubstitutionSlot(ByVal objSubSlot As SubstitutionSlot)
            Dim SQL As String
            With objSubSlot
                SQL = "INSERT INTO SubstitutionSlots " & _
                 "(PlayerID, SublineID, GamePositionID)" & _
                 "VALUES (" & _
                 FormatField(.PlayerID, False, True) & _
                 FormatField(.SublineID, False, True) & _
                 FormatField(.GamePositionID, False, False) & ")"

            End With

            RunCommand(SQL)
            Return GetID("SubstitutionSlots", "SlotID")

        End Function

        Sub UpdateSubstitutionSlot(ByVal objSubSlot As SubstitutionSlot)
            Dim SQL As String
            With objSubSlot
                SQL = "Update SubstitutionSlots SET " & _
                 "PlayerID = " & _
                 FormatField(.PlayerID, False, False) & _
                 " WHERE SlotID=" & .SlotID
            End With

            RunCommand(SQL)
        End Sub

        Sub DeleteSubstitutionSet(ByVal intTeamID As Integer)
            Dim SQL As String
            SQL = "DELETE ss.* " & _
             "FROM SubstitutionLines AS sl INNER JOIN	SubstitutionSlots AS ss ON sl.SubstitutionLineID = ss.SublineID " & _
             "WHERE(((sl.TeamID) = " & intTeamID & "))"

            RunCommand(SQL)

            SQL = "DELETE * FROM SubstitutionLines WHERE TeamID = " & intTeamID
            RunCommand(SQL)

        End Sub

        Function InsertSubstitutionLine(ByVal objSubLine As SubstitutionLine)
            Dim SQL As String
            With objSubLine
                SQL = "INSERT INTO SubstitutionLines " & _
                 "(SubLineTypeID, TeamID)" & _
                 "VALUES (" & _
                 FormatField(.SubLineTypeID, False, True) & _
                 FormatField(.TeamID, False, False) & ")"

            End With

            RunCommand(SQL)
            Return GetID("SubstitutionLines", "SubstitutionLineID")

        End Function

        Function InsertFreeAgent(ByVal objRoster As FreeAgentSlot)
            Dim SQL As String
            With objRoster
                SQL = "INSERT INTO FreeAgentPool " & _
                 "(PlayerID)" & _
                 "VALUES (" & _
                FormatField(.PlayerID, False, False) & ")"

            End With

            RunCommand(SQL)
            Return objRoster.FreeAgentID

        End Function

        Function GetAllTeams() As OleDbDataReader
            Dim SQL As String = "SELECT * FROM Teams ORDER BY TeamID"
            Return GetDataReader(SQL)
        End Function

        Function GetRoster(ByVal intTeamID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT * FROM Rosters WHERE TeamID = " & intTeamID
            Return GetDataReader(SQL)
        End Function

        Function GetFreeAgentPool() As OleDbDataReader
            Dim SQL As String = "SELECT * FROM FreeAgentPool"
            Return GetDataReader(SQL)
        End Function

        Function GetFreeAgentGrid(ByVal intPositionID As Integer) As DataSet
            Dim Where As String
            If intPositionID = 0 Then
                Where = "WHERE 1 = 1 "
            Else
                Where = "WHERE pl.PositionID = " & intPositionID
            End If
            Dim SQL As String
            SQL = _
             "SELECT r.FreeAgentID as RosterID, -1 AS TeamID, r.PlayerID, pl.LastName + ', ' + pl.FirstName AS PlayerName, " & _
             "		pl.Jersey, pl.College, pl.HighSchool, pl.Age, p.Abbr " & _
             "FROM	(FreeAgentPool r INNER JOIN Players pl ON r.PlayerID = pl.PlayerID) " & _
             "		INNER JOIN Positions p ON pl.PositionID = p.PositionID "
            SQL = SQL & Where & _
             " ORDER BY p.PositionID, pl.LastName, pl.FirstName"

            Return Me.GetDataSet(SQL, "Roster")
        End Function

        Function GetRosterGrid(ByVal intTeamID As Integer, ByVal intPositionID As Integer) As DataSet
            Dim Where As String
            If intPositionID = 0 Then
                Where = "WHERE r.TeamID = " & intTeamID
            Else
                Where = "WHERE pl.PositionID = " & intPositionID & " AND r.TeamID = " & intTeamID
            End If
            Dim SQL As String
            SQL = _
             "SELECT r.RosterID, r.TeamID, r.PlayerID, pl.LastName + ', ' + pl.FirstName AS PlayerName, " & _
             "		pl.Jersey, pl.College, pl.HighSchool, pl.Age, p.Abbr " & _
             "FROM	(Rosters r INNER JOIN Players pl ON r.PlayerID = pl.PlayerID) " & _
             "		INNER JOIN Positions p ON pl.PositionID = p.PositionID "
            SQL = SQL & Where & _
             " ORDER BY p.PositionID, pl.LastName, pl.FirstName"

            Return Me.GetDataSet(SQL, "Roster")
        End Function

        Function GetRosterGridActuals(ByVal intTeamID As Integer, ByVal intPositionID As Integer) As DataSet
            Dim SQL As String
            Dim Where As String
            If intPositionID = 0 Then
                Where = "WHERE r.TeamID = " & intTeamID
            Else
                Where = "WHERE pl.PositionID = " & intPositionID & " AND r.TeamID = " & intTeamID
            End If

            SQL = "SELECT pl.PlayerID, [LastName]+', '+[FirstName] AS Name, pos.Abbr AS POS, pl.PositionID, pa.ACT_DUR AS DUR, pa.ACT_DEF AS DEF, pa.ACT_END AS [END], pa.ACT_GK AS GK, pa.ACT_MOB AS MOB, pa.ACT_PAS AS PAS, pa.ACT_AGR AS AGR, pa.ACT_SHO AS SHO, pa.ACT_DRI AS DRI, pa.ACT_TAC AS TAC, pa.ACT_FK AS FK, pa.ACT_DET AS DET, pa.ACT_INF AS INF, pa.ACT_PSN AS PSN, r.TeamID " & _
                  "FROM (Positions AS pos INNER JOIN (PlayerAttributes AS pa INNER JOIN Players AS pl ON pa.PlayerID = pl.PlayerID) ON pos.PositionID = pl.PositionID) INNER JOIN Rosters AS r ON pl.PlayerID = r.PlayerID "
            SQL = SQL & Where
            SQL = SQL & " ORDER BY pl.PositionID, pl.LastName, pl.FirstName "
            Return Me.GetDataSet(SQL, "Roster")

        End Function

        Function GetFreeAgentGridActuals(ByVal intPositionID As Integer) As DataSet
            Dim SQL As String
            Dim Where As String
            Where = "WHERE RatingTypeID = 0 "
            If intPositionID <> 0 Then
                Where = Where & " AND  pl.PositionID = " & intPositionID
            End If

            SQL = "TRANSFORM Sum(pr.Rating) AS SumOfRating " & _
             "SELECT pl.PlayerID, [LastName] & ', ' & [FirstName] AS Name, pos.Abbr AS POS, pl.PositionID " & _
             "FROM ((Players AS pl INNER JOIN (Ratings AS ra INNER JOIN PlayerRatings AS pr ON ra.RatingID = pr.RatingID) ON pl.PlayerID = pr.PlayerID) INNER JOIN FreeAgentPool AS r ON pl.PlayerID = r.PlayerID) INNER JOIN Positions AS pos ON pl.PositionID = pos.PositionID "

            SQL = SQL & Where & _
              " GROUP BY pl.PlayerID, [LastName] & ', ' & [FirstName], pos.Abbr, pl.PositionID, pl.LastName, pl.FirstName " & _
              " ORDER BY pl.PositionID, pl.LastName, pl.FirstName " & _
              " PIVOT(ra.Abbr) "
            Return Me.GetDataSet(SQL, "Roster")

        End Function

        Function GetRosterGridPotentials(ByVal intTeamID As Integer, ByVal intPositionID As Integer) As DataSet
            Dim SQL As String
            Dim Where As String
            If intPositionID = 0 Then
                Where = "WHERE r.TeamID = " & intTeamID
            Else
                Where = "WHERE pl.PositionID = " & intPositionID & " AND r.TeamID = " & intTeamID
            End If

            SQL = "SELECT pl.PlayerID, [LastName]+', '+[FirstName] AS Name, pos.Abbr AS POS, pl.PositionID, pa.POT_DUR AS DUR, pa.POT_DEF AS DEF, pa.POT_END AS [END], pa.POT_GK AS GK, pa.POT_MOB AS MOB, pa.POT_PAS AS PAS, pa.POT_AGR AS AGR, pa.POT_SHO AS SHO, pa.POT_DRI AS DRI, pa.POT_TAC AS TAC, pa.POT_FK AS FK, pa.POT_DET AS DET, pa.POT_INF AS INF, pa.POT_PSN AS PSN, r.TeamID " & _
                  "FROM (Positions AS pos INNER JOIN (PlayerAttributes AS pa INNER JOIN Players AS pl ON pa.PlayerID = pl.PlayerID) ON pos.PositionID = pl.PositionID) INNER JOIN Rosters AS r ON pl.PlayerID = r.PlayerID "
            SQL = SQL & Where
            SQL = SQL & " ORDER BY pl.PositionID, pl.LastName, pl.FirstName "
            Return Me.GetDataSet(SQL, "Roster")
        End Function

        Function GetFreeAgentGridPotentials(ByVal intPositionID As Integer) As DataSet
            Dim SQL As String
            Dim Where As String

            Where = "WHERE RatingTypeID = 128 "
            If intPositionID <> 0 Then
                Where = Where & " AND  pl.PositionID = " & intPositionID
            End If

            SQL = "TRANSFORM Sum(pr.Rating) AS SumOfRating " & _
             "SELECT pl.PlayerID, [LastName] & ', ' & [FirstName] AS Name, pos.Abbr AS POS, pl.PositionID " & _
             "FROM ((Players AS pl INNER JOIN (Ratings AS ra INNER JOIN PlayerRatings AS pr ON ra.RatingID = pr.RatingID) ON pl.PlayerID = pr.PlayerID) INNER JOIN FreeAgentPool AS r ON pl.PlayerID = r.PlayerID) INNER JOIN Positions AS pos ON pl.PositionID = pos.PositionID "

            SQL = SQL & Where & _
              " GROUP BY pl.PlayerID, [LastName] & ', ' & [FirstName], pos.Abbr, pl.PositionID, pl.LastName, pl.FirstName " & _
              " ORDER BY pl.PositionID, pl.LastName, pl.FirstName " & _
              " PIVOT(ra.Abbr) "
            Return Me.GetDataSet(SQL, "Roster")

        End Function


        Function GetSubstitutionSet(ByVal intTeamID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT * FROM SubstitutionLines Where TeamID=" & intTeamID & _
              " ORDER BY SubLineTypeID ASC"
            Return GetDataReader(SQL)
        End Function

        Function GetSubstitutionSlot(ByVal intSublineID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT * FROM SubstitutionSlots Where SubLineID=" & intSublineID & _
              " ORDER BY GamePositionID ASC"
            Return GetDataReader(SQL)
        End Function

        Function GetPlayersOnTeamByPosition(ByVal intTeamID As Integer, ByVal intPositionID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT r.TeamID, p.PositionID, p.PlayerID" & _
            " FROM Rosters AS r INNER JOIN Players AS p ON r.PlayerID = p.PlayerID " & _
            " WHERE(((r.TeamID) = " & intTeamID & ") And ((p.PositionID) = " & intPositionID & "))"
            Return GetDataReader(SQL)
        End Function



        Function GetTeamSituations(ByVal intTeamID As Integer, ByVal intSituationID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT * FROM TeamSituations " & _
            " WHERE TeamID = " & intTeamID & " AND SituationID = " & intSituationID & _
            " ORDER BY TeamSituationID"
            Return GetDataReader(SQL)
        End Function

        Function GetTeamTactics(ByVal intID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT * FROM TeamTactics " & _
               " WHERE TeamSituationID = " & intID & _
               " ORDER BY TeamTacticID"
            Return GetDataReader(SQL)
        End Function

        Sub UpdateTeamTactic(ByVal objTeamTactic As TeamTactic)
            Dim SQL As String
            With objTeamTactic
                SQL = "Update TeamTactics SET " & _
                 "Probability = " & FormatField(.Probability, False, True) & _
                 "TacticID = " & FormatField(.TacticID, False, True) & _
                 "TeamSituationID = " & FormatField(.TeamSituationID, False, False) & _
                 " WHERE TeamTacticID=" & .TeamTacticID
            End With

            RunCommand(SQL)
        End Sub

        Sub UpdateTeamSituation(ByVal objTeamSituation As TeamSituation)
            Dim SQL As String
            With objTeamSituation
                SQL = "Update TeamSituations SET " & _
                 " PrimaryLineID = " & FormatField(.PrimaryLineID, False, True) & _
                 " SecondaryLineID = " & FormatField(.SecondaryLineID, False, True) & _
                 " SituationID = " & FormatField(.SituationID, False, True) & _
                 " TeamID = " & FormatField(.TeamID, False, True) & _
                 " SubInPercentage = " & FormatField(.SubInPercentage, False, True) & _
                 " SubOutPercentage = " & FormatField(.SubOutPercentage, False, False) & _
                 " WHERE TeamSituationID=" & .TeamSituationID
            End With

            RunCommand(SQL)
        End Sub

        Sub UpdateTeamPlayoffSeed(ByVal objTeam As Team)
            Dim SQL As String
            SQL = "Update Teams SET PlayoffSeed = " & objTeam.PlayoffSeed & " WHERE TeamID = " & objTeam.TeamID
            RunCommand(SQL)
        End Sub

        Sub UpdateTeamSettings(ByVal objTeam As Team)
            Dim SQL As String
            With objTeam
                SQL = "Update Teams SET " & _
                " Abbreviation = " & FormatField(.Abbreviation, True, True) & _
                " Name = " & FormatField(.Name, True, True) & _
                " CityID = " & FormatField(.CityID, False, True) & _
                " Nickname = " & FormatField(.Nickname, True, True) & _
                " Mascot = " & FormatField(.Mascot, True, True) & _
                " OwnerEmail = " & FormatField(.OwnerEmail, True, True) & _
                " OwnerName = " & FormatField(.OwnerName, True, True) & _
                " IsCPUOwned = " & FormatField(.IsCPUOwned, False, True) & _
                " Logo = " & FormatField(.Logo, True, False) & _
                " WHERE TeamID = " & .TeamID

            End With

            RunCommand(SQL)
        End Sub

        Function InsertTeamSituation(ByVal objTeamSituation As TeamSituation) As Integer
            Dim SQL As String
            With objTeamSituation
                SQL = "INSERT INTO TeamSituations (PrimaryLineID, SecondaryLineID, " & _
                 " SituationID, SubInPercentage, SuboutPercentage, TeamID) " & _
                 " VALUES (" & _
                 FormatField(.PrimaryLineID, False, True) & _
                 FormatField(.SecondaryLineID, False, True) & _
                 FormatField(.SituationID, False, True) & _
                 FormatField(.SubInPercentage, False, True) & _
                 FormatField(.SubOutPercentage, False, True) & _
                 FormatField(.TeamID, False, False) & _
                 ")"
            End With

            RunCommand(SQL)
            Return Me.GetID("TeamSituations", "TeamSituationID")
        End Function

        Function InsertTeamTactic(ByVal objTeamTactic As TeamTactic)
            Dim SQL As String
            With objTeamTactic
                SQL = "INSERT INTO TeamTactics (Probability, TacticID, TeamSituationID) VALUES (" & _
                FormatField(.Probability, False, True) & _
                FormatField(.TacticID, False, True) & _
                FormatField(.TeamSituationID, False, False) & ")"
            End With

            RunCommand(SQL)
            Return Me.GetID("TeamTactics", "TeamTacticID")

        End Function

        Function InsertTeamMedia(ByVal TeamID As Integer, ByVal MediaID As Integer, ByVal Amount As Integer)
            Dim SQL As String
            SQL = "INSERT INTO TeamMedia (TeamID, MediaID, Amount) VALUES (" & _
                     FormatField(TeamID, False, True) & _
                     FormatField(MediaID, False, True) & _
                     FormatField(Amount, False, False) & ")"
            RunCommand(SQL)
            Return Me.GetID("TeamMedia", "TeamMediaID")

        End Function

        Function InsertTeamFinancesDefault(ByVal TeamID As Integer) As Integer
            Dim SQL As String
            SQL = "INSERT INTO TeamFinances (TeamID) VALUES (" & TeamID & ")"
            RunCommand(SQL)
            Return Me.GetID("TeamFinances", "TeamFinanceID")
        End Function

        Sub DeleteTeamTactic(ByVal objTeamTactic As TeamTactic)
            Dim SQL As String
            With objTeamTactic
                SQL = "DELETE FROM TeamTactics WHERE TeamTacticID = " & .TeamTacticID
                RunCommand(SQL)
            End With
        End Sub

        Function InsertFacility(ByVal objFacility As Facility) As Integer
            Dim SQL As String
            With objFacility

                SQL = "INSERT INTO Facilities (Name, Capacity, CityID) VALUES ( " & _
                   FormatField(.Name, True, True) & _
                   FormatField(.Capacity, False, True) & _
                   FormatField(.CityID, False, False) & ")"
            End With

            RunCommand(SQL)
            Return Me.GetID("Facilities", "FacilityID")
        End Function

        Function GetFacility(ByVal intFacilityID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT * FROM Facilities Where FacilityID=" & intFacilityID

            Return GetDataReader(SQL)
        End Function

        Function GetMediaForTeam(ByVal TeamID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT tm.TeamID, tm.Amount, m.* " & _
                            " FROM Media m INNER JOIN TeamMedia tm ON m.MediaID = tm.MediaID " & _
                            " WHERE tm.TeamID =  " & TeamID & _
                            " ORDER BY m.MediaID "
            Return GetDataReader(SQL)
        End Function

        Function GetTeamBudget(ByVal TeamID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT * FROM TeamBudgets WHERE TeamID = " & TeamID
            Return GetDataReader(SQL)
        End Function

        Function InsertTeamBudget(ByVal TeamID As Integer, ByVal tf As Finances.team.TeamBudgets) As Integer
            Dim SQL As String = "INSERT INTO TeamBudgets " & _
                "(TeamID, Tickets, Sponsorship, Merchendise, SoccerCamps, Concessions, " & _
                "Marketing, FrontOffice, Salaries, Insurance, ArenaRental, Events, " & _
                "Promotions, Overhead, LeagueDues, Travel) VALUES (" & _
                FormatField(TeamID, False, True) & _
                FormatField(tf.Tickets, False, True) & _
                FormatField(tf.Sponsorship, False, True) & _
                FormatField(tf.Merchendise, False, True) & _
                FormatField(tf.SoccerCamps, False, True) & _
                FormatField(tf.Concessions, False, True) & _
                FormatField(tf.Marketing, False, True) & _
                FormatField(tf.FrontOffice, False, True) & _
                FormatField(tf.Salaries, False, True) & _
                FormatField(tf.Insurance, False, True) & _
                FormatField(tf.ArenaRental, False, True) & _
                FormatField(tf.Events, False, True) & _
                FormatField(tf.Promotions, False, True) & _
                FormatField(tf.Overhead, False, True) & _
                FormatField(tf.LeagueDues, False, True) & _
                FormatField(tf.Travel, False, False) & ")"

            RunCommand(SQL)
            Return Me.GetID("TeamBudgets", "BudgetID")

        End Function

        Function GetTeamFinances(ByVal TeamID As Integer)
            Dim SQL As String = "SELECT * FROM TeamFinances WHERE TeamID = " & TeamID
            Return GetDataReader(SQL)
        End Function

        Public Sub DeletePlayerFromRoster(ByVal RosterSlotID As Integer)
            Dim SQL As String = "DELETE FROM Rosters WHERE RosterID = " & RosterSlotID
            RunCommand(SQL)
        End Sub

        Public Sub DeletePlayerFromFreeAgentPool(ByVal FreeAgentID As Integer)
            Dim SQL As String = "DELETE FROM FreeAgentPool WHERE FreeAgentID = " & FreeAgentID
            RunCommand(SQL)
        End Sub

        Public Function InsertPlayerToRoster(ByVal PlayerID As Integer, ByVal TeamID As Integer) As Integer
            Dim SQL As String = "INSERT INTO Rosters (TeamID, PlayerID) VALUES (" & TeamID & ", " & PlayerID & ")"
            RunCommand(SQL)
            Return Me.GetID("Rosters", "RosterID")
        End Function

        Public Function InsertPlayerTOFreeAgentPool(ByVal PlayerID As Integer)
            Dim SQL As String = "INSERT INTO FreeAgentPool (PlayerID) VALUES (" & PlayerID & ")"
            RunCommand(SQL)
            Return Me.GetID("FreeAgentPool", "FreeAgentID")
        End Function

    End Class
End Namespace