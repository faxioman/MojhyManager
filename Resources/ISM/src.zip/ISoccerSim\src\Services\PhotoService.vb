Imports System.IO

Public Class PhotoService
    Private Shared myPhoto As PhotoService

    Dim TestDirectory As String

    Public Shared Function GetInstance() As PhotoService
        If myPhoto Is Nothing Then
            myPhoto = New PhotoService
        End If
        Return myPhoto
    End Function

    Public Sub GeneratePicture(ByVal LastName As String, ByVal FirstName As String)
        Dim fs As FileService = FileService.GetInstance()
        Dim sim As Simulation = Simulation.GetInstance
        Dim FaceDir As String = fs.GetBaseFacePath
        Dim DestDir As String = fs.GetLeagueFacePath(sim.League.Name)
        Dim Picture As String
        Dim ms As MathService = MathService.GetInstance
        Dim d As Directory
        Dim f As File
        Dim Extension As String


        If d.Exists(FaceDir) And d.Exists(DestDir) Then
            Dim faces As String() = d.GetFiles(FaceDir)
            If UBound(faces) > 0 Then
                Dim x As Integer = ms.Next(LBound(faces), UBound(faces))
                Picture = faces(x)
                Extension = Right(Picture, 4)
                If fs.IsValidGraphicFile(Picture) Then
                    f.Copy(Picture, DestDir & LastName & FirstName & Extension)
                    Exit Sub
                Else
                    Me.GeneratePicture(LastName, FirstName)
                    Exit Sub
                End If
            End If
        End If
    End Sub

    Public Function GetPicture(ByVal PhotoName As String) As String
        Dim fs As FileService = FileService.GetInstance()
        Dim sim As Simulation = Simulation.GetInstance

        Dim DestDir As String = fs.GetLeagueFacePath(sim.League.Name)
        Dim NoPicture As String = fs.GetBaseFacePath() & "none.bmp"

        Dim d As Directory
        Dim f As File

        If d.Exists(DestDir) Then
            Dim faces As String() = d.GetFiles(DestDir, PhotoName & "*")
            If faces.Length = 1 Then
                Return (faces(0))
            End If
        End If

        Return NoPicture
    End Function

    Public Function GetTeamPicture(ByVal TeamName As String) As String
        Dim fs As FileService = FileService.GetInstance()
        Dim sim As Simulation = Simulation.GetInstance

        Dim DestDir As String = fs.GetLeagueLogoPath(sim.League.Name)
        Dim NoPicture As String = ""

        Dim d As Directory
        Dim f As File

        TeamName = Replace(TeamName, " ", "")

        If d.Exists(DestDir) Then
            Dim logos As String() = d.GetFiles(DestDir, TeamName & "*")
            If UBound(logos) = 0 Then
                Return (logos(0))
            End If
        End If

        Return NoPicture
    End Function
End Class

