'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.SimEngine
Imports ISoccerSim.Substitution
Imports ISoccerSim.Rosters
Imports ISoccerSim.Statistics
Imports ISoccerSim.Cities
Imports ISoccerSim.Tactical
Imports ISoccerSim.Finances.Team

Namespace Teams
	Public Class Team
		Inherits System.Collections.CollectionBase
		Implements ICloneable
		Implements IComparable

		Public TeamID As Integer
		Public ConferenceID As Integer
		Public DivisionID As Integer
		Public CityID As Integer
		Public Name As String
		Public Nickname As String
		Public Logo As String
		Public Mascot As String
		Public OwnerEmail As String
		Public OwnerName As String
		Public Abbreviation As String
		Public IsCPUOwned As Boolean
		Public Roster As New Roster()
        Public FacilityID As Integer
        Public PlayoffSeed As Integer

		'Game engine specific stuff...
		Public Scoreboard As New Scoreboard()
        Public FieldManager As New FieldManager()

        Public SubstitutionSets As New SubstitutionLineSet()
		Public TeamTacticSet As New Tactical.TacticSet()
		Public TeamSituationSet As New Tactical.TeamSituationSet()

		Public CurrentLine As ISMSublineType
        Public CurrentGameSituation As ISMGameSituation
        Public MediaSet As MediaSet

        Private m_FacilityName As String
        Public ExpectedAttendance As Integer

        Sub Save()
            Dim Data As New DataServices.TeamTables()
            Data.InsertTeam(Me)
            Data.Close()
        End Sub

        Sub UpdateSettingsOnly()
            Dim Data As New DataServices.TeamTables()
            Data.UpdateTeamSettings(Me)
            Data.Close()
        End Sub
        Sub UpdatePlayoffSeed()
            Dim Data As New DataServices.TeamTables
            Data.UpdateTeamPlayoffSeed(Me)
            Data.Close()
        End Sub

        Public Overrides Function ToString() As String
            Return Me.Name & " " & Me.Nickname
        End Function

        Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
            If obj Is Nothing Then Return 1

            Dim other As Team = CType(obj, Team)
            Return StrComp(Me.Name & " " & Me.Nickname, other.Name & " " & other.Nickname, CompareMethod.Text)
        End Function

        Default Property Item(ByVal index As Integer) As Team
            Get
                Return CType(InnerList.Item(index), Team)
            End Get
            Set(ByVal Value As Team)
                InnerList.Item(index) = Value
            End Set
        End Property

        Sub Add(ByVal value As Team)
            InnerList.Add(value)
        End Sub

        Function Clone() As Object Implements ICloneable.Clone
            Dim Team As New Team
            Team = Me.MemberwiseClone
            Return Team
        End Function

        Public ReadOnly Property FacilityName() As String
            Get
                If FacilityName = "" Then
                    Dim Facility As New Facility
                    Facility.Load(Me.FacilityID)
                    m_FacilityName = Facility.Name
                End If
                Return m_FacilityName
            End Get

        End Property

        Public Property DisplayMember() As String
            Get
                Return "  " & Me.Name
            End Get
            Set(ByVal Value As String)
                'Pass
            End Set
        End Property

        Public Property ValueMember() As Integer
            Get
                Return Me.TeamID
            End Get
            Set(ByVal Value As Integer)
                'Pass
            End Set
        End Property

        Public Function GetExpectedAttendancePct() As Double
            Dim f As New Facility
            f.Load(Me.FacilityID)

            If Me.ExpectedAttendance > 0 Then
                Return Me.ExpectedAttendance / f.Capacity
            Else
                Return 0
            End If
        End Function

    End Class

    Public Class TeamShell
        Public TeamID As Integer
        Public Name As String
        Public DivisionID As Integer
        Public ConferenceID As Integer
        Public GamesScheduled As Integer

        Public Overrides Function ToString() As String
            Return Me.Name
        End Function
    End Class
End Namespace