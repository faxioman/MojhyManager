Imports ISoccerSim.Leagues

Namespace Schedules.Playoffs
    Public Class PlayoffScheduleGenerator

        Public Sub CreateFirstRound()
            Dim pm As New PlayoffManager
            Dim pt As New PlayoffTree
            Dim TeamsInPlayoffs As New PlayoffTree
            Dim l As League = Simulation.GetInstance.League
            Dim GamesInSeries As Integer = Me.GetNumberOfPlayoffGamesOnStage(1)

            TeamsInPlayoffs = pm.Calculate(pt.LoadTreeFromLeague, l.TeamsInPlayoff, PlayoffManager.ISMPlayoffMethod.TopNTeams)
            TeamsInPlayoffs.SaveSeeds()

            'Add games to schedule using series template...
            Dim st As New SeriesTemplate
            st.ApplyToSchedule(1)

        End Sub

        Public Function GetNumberOfPlayoffGamesOnStage(ByVal Round As Integer)
            Dim l As League = Simulation.GetInstance.League
            Dim st As New SeriesTemplate
            Dim s As Series

            For Each s In st
                If s.Round = Round Then
                    If s.AdvanceToSeriesID = 0 Then
                        Return l.ChampionshipSeries
                    Else
                        Return l.PlayoffSeries
                    End If
                End If
            Next
        End Function

        Public Function GetNumberOfGamesToWinStage(ByVal Round As Integer)
            Return Int(Me.GetNumberOfPlayoffGamesOnStage(Round) / 2) + 1
        End Function

        Public Function IsBestTeamHome(ByVal LengthOfSeries As Integer, ByVal GameNumber As Integer) As Boolean
            Select Case LengthOfSeries
                Case 7
                    Select Case GameNumber
                        Case 1, 2, 5, 7
                            Return True
                        Case Else
                            Return False
                    End Select
                Case 5
                    Select Case GameNumber
                        Case 1, 2, 5
                            Return True
                        Case Else
                            Return False
                    End Select
                Case 3
                    Select Case GameNumber
                        Case 1, 3
                            Return True
                        Case Else
                            Return False
                    End Select
                Case 1
                    Return True

                Case Else
                    Return True
            End Select
        End Function

        Public Sub Generate2ndRoundOn()
            'Add games to schedule using series template...
            Dim st As New SeriesTemplate
            Dim Sim As Simulation = Simulation.GetInstance
            Dim l As League = Sim.League

            st.ApplyToSchedule(l.Schedule.GetLastPlayoffRound() + 1)
        End Sub
    End Class
End Namespace