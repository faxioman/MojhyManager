'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Utility.DataGrid

    Public Class DataGridUtility
        Dim mDataGrid As System.Windows.Forms.DataGrid
        Dim mTableStyle As New DataGridTableStyle

        Sub New(ByRef dg As System.Windows.Forms.DataGrid, ByVal colData As ArrayList)
            mDataGrid = dg
            mDataGrid.DataSource = colData
            mTableStyle.MappingName = "ArrayList"
            mTableStyle.AlternatingBackColor = System.Drawing.Color.Beige
            mTableStyle.ResetAlternatingBackColor()
        End Sub

        Sub New(ByRef dg As System.Windows.Forms.DataGrid, ByVal colData As CollectionBase)
            mDataGrid = dg
            mDataGrid.DataSource = colData
            mTableStyle.MappingName = "CollectionBase"
            mTableStyle.AlternatingBackColor = System.Drawing.Color.Beige
            mTableStyle.ResetAlternatingBackColor()
        End Sub

        Sub New(ByRef dg As System.Windows.Forms.DataGrid, ByVal TableName As String)
            mDataGrid = dg
            mTableStyle.MappingName = TableName
            mTableStyle.GridColumnStyles.Clear()
            mTableStyle.AlternatingBackColor = System.Drawing.Color.Beige
            mTableStyle.ResetAlternatingBackColor()
        End Sub

        Sub New()

        End Sub

        Sub AddColumn(ByVal PropertyName As String, ByVal ColumnText As String, ByVal Width As Integer)
            Call AddColumn(PropertyName, ColumnText, Width, "")
        End Sub

        Sub AddCheckboxColumn(ByVal PropertyName As String, ByVal ColumnText As String, ByVal Width As Integer)
            Dim Column As New DataGridBoolColumn
            With Column
                .MappingName = PropertyName
                .HeaderText = ColumnText
                .AllowNull = False
                If Width = 0 Then
                    .Width = 0
                Else
                    Width = Width * 0.85
                    .Width = (mDataGrid.Width / 100) * Width
                End If
            End With
            mTableStyle.GridColumnStyles.Add(Column)
        End Sub

        Sub AddColumn(ByVal PropertyName As String, ByVal ColumnText As String, ByVal Width As Integer, ByVal Format As String)
            Dim Column As New DataGridTextBoxColumn
            With Column
                .MappingName = PropertyName
                .HeaderText = ColumnText
                If Width = 0 Then
                    .Width = 0
                Else
                    Width = Width * 0.85
                    .Width = (mDataGrid.Width / 100) * Width
                End If
                .Format = Format
            End With
            mTableStyle.GridColumnStyles.Add(Column)
        End Sub

        Sub AddColumn(ByVal PropertyName As String, ByVal ColumnText As String, ByVal Width As Integer, ByRef objGraphCol As DataGridGraphColumn)
            Dim Column As DataGridGraphColumn = objGraphCol
            With Column
                .MappingName = PropertyName
                .HeaderText = ColumnText
                If Width = 0 Then
                    .Width = 0
                Else
                    Width = Width * 0.85
                    .Width = (mDataGrid.Width / 100) * Width
                End If
                '.Format = Format()
            End With
            mTableStyle.GridColumnStyles.Add(Column)
            mTableStyle.RowHeaderWidth = 0
        End Sub

        Sub Commit()
            With mDataGrid
                .TableStyles.Clear()
                .TableStyles.Add(mTableStyle)
                .AllowSorting = True
                .AllowDrop = False
                .AlternatingBackColor = System.Drawing.Color.Beige
            End With
        End Sub

        Sub SetBasePlayerStatGrid(ByVal Heading As String)
            AddColumn("PlayerID", "ID", 0)
            AddColumn("Team", "Team", 10)
            AddColumn("PlayerName", "Player", 50)
            AddColumn("Value", Heading, 40)
        End Sub

        Sub SetBaseTeamStatGrid(ByVal Heading As String)
            AddColumn("PlayerID", "ID", 0)
            AddColumn("Team", "Team", 50)
            AddColumn("Value", Heading, 40)
        End Sub

        Sub SetLeagueLeaderGridIndividual()
            AddColumn("PlayerID", "ID", 0)
            AddColumn("PlayerName", "Player", 50)
            AddColumn("Team", "Team", 10)
            AddColumn("G", "G", 15)
            AddColumn("A", "A", 15)
            AddColumn("Total", "Total", 10)
        End Sub

        Sub SetLeagueLeaderGridTeam()
            AddColumn("TeamID", "ID", 0)
            AddColumn("Team", "Team", 50)
            AddColumn("G", "G", 15)
            AddColumn("A", "A", 15)
            AddColumn("Total", "Total", 10)
        End Sub

        Sub SetLeagueLeaderGridIndividualMPS()
            AddColumn("PlayerID", "ID", 0)
            AddColumn("PlayerName", "Player", 25)
            AddColumn("Team", "Team", 10)
            AddColumn("GP", "GP", 10)
            AddColumn("3PT", "3PT", 10)
            AddColumn("2PT", "2PT", 10)
            AddColumn("1PT", "1PT", 10)
            AddColumn("A", "A", 10)
            AddColumn("Total", "Total", 10)
            AddColumn("Avg", "Avg", 10, "0.00")
        End Sub

        Sub SetLeagueLeaderGoaliesIndividualMPS()
            AddColumn("PlayerID", "ID", 0)
            AddColumn("PlayerName", "Player", 25)
            AddColumn("Team", "Team", 10)
            AddColumn("GP", "GP", 10)
            AddColumn("MIN", "MIN", 10, "0")
            AddColumn("SF", "SF", 10)
            AddColumn("SV", "SV", 10)

            AddColumn("3PG", "3PG", 10)
            AddColumn("2PG", "2PG", 10)
            AddColumn("1PG", "1PG", 10)

            AddColumn("PTS", "PTS", 10)

            AddColumn("W", "W", 10)
            AddColumn("L", "L", 10)

            AddColumn("Avg", "Avg", 10, "0.00")
        End Sub

        Sub SetLeagueLeaderGoaliesTeamMPS()
            AddColumn("PlayerID", "ID", 0)

            AddColumn("Team", "Team", 25)
            AddColumn("GP", "GP", 10)
            AddColumn("MIN", "MIN", 10, "0")
            AddColumn("SF", "SF", 10)
            AddColumn("SV", "SV", 10)

            AddColumn("3PG", "3PG", 10)
            AddColumn("2PG", "2PG", 10)
            AddColumn("1PG", "1PG", 10)

            AddColumn("PTS", "PTS", 10)

            AddColumn("W", "W", 10)
            AddColumn("L", "L", 10)

            AddColumn("Avg", "Avg", 10, "0.00")
        End Sub

        Sub SetLeagueLeaderGoaliesIndividual()
            AddColumn("PlayerID", "ID", 0)
            AddColumn("PlayerName", "Player", 25)
            AddColumn("Team", "Team", 10)
            AddColumn("GP", "GP", 10)
            AddColumn("MIN", "MIN", 10, "0")
            AddColumn("SF", "SF", 10)
            AddColumn("SV", "SV", 10)

            AddColumn("G", "G", 10)
            AddColumn("PTS", "PTS", 10)

            AddColumn("W", "W", 10)
            AddColumn("L", "L", 10)

            AddColumn("Avg", "Avg", 10, "0.00")
        End Sub

        Sub SetLeagueLeaderGoaliesTeam()
            AddColumn("Team", "Team", 10)
            AddColumn("GP", "GP", 10)
            AddColumn("MIN", "MIN", 10, "0")
            AddColumn("SF", "SF", 10)
            AddColumn("SV", "SV", 10)

            AddColumn("G", "G", 10)
            AddColumn("PTS", "PTS", 10)

            AddColumn("W", "W", 10)
            AddColumn("L", "L", 10)

            AddColumn("Avg", "Avg", 10, "0.00")
        End Sub

        Sub SetLeagueLeaderGridTeamMPS()
            AddColumn("TeamID", "ID", 0)
            AddColumn("Team", "Team", 30)
            AddColumn("GP", "GP", 10)
            AddColumn("3PT", "3PT", 10)
            AddColumn("2PT", "2PT", 10)
            AddColumn("1PT", "1PT", 10)
            AddColumn("A", "A", 10)
            AddColumn("Total", "Total", 10)
            AddColumn("Avg", "Avg", 10, "0.00")
        End Sub

        Sub SetStandingGrid()
            AddColumn("ID", "ID", 0)
            AddColumn("Team", "Team", 20)
            AddColumn("W", "W", 5)
            AddColumn("L", "L", 5)
            AddColumn("PCT", "PCT", 8, "0.000")
            AddColumn("GB", "GB", 7)
            AddColumn("PF", "PF", 7)
            AddColumn("PA", "PA", 7)
            AddColumn("Home", "Home", 7)
            AddColumn("Away", "Away", 7)
            AddColumn("Streak", "Streak", 7)
            AddColumn("Last10", "10", 7)
            AddColumn("DIV", "DIV", 7)
            AddColumn("CONF", "CONF", 7)
        End Sub

        Sub SetLeagueScheduleGrid()
            AddColumn("ID", "ID", 0)
            AddColumn("GameDate", "Date", 25)
            AddColumn("Game", "Matchup", 75)
        End Sub

        Sub SetRosterGrid()
            AddColumn("PlayerID", "ID", 0)
            AddColumn("PlayerName", "Name", 50)
            AddColumn("Jersey", "Jersey", 10)
            AddColumn("Abbr", "POS", 10)
            AddColumn("Age", "Age", 10)
        End Sub

        Sub SetRosterGridActuals()
            AddColumn("PlayerID", "ID", 0)
            AddColumn("Name", "Name", 18)
            AddColumn("POS", "POS", 7)

            AddColumn("DEF", "DEF", 7)
            AddColumn("DET", "DET", 7)
            AddColumn("DRI", "DRI", 7)
            AddColumn("END", "END", 7)
            AddColumn("FRE", "FRE", 7)
            AddColumn("GK", "GK", 7)
            AddColumn("INF", "INF", 7)
            AddColumn("INJ", "INJ", 7)
            AddColumn("MOB", "MOB", 7)
            AddColumn("PAS", "PAS", 7)
            AddColumn("PEN", "PEN", 7)
            AddColumn("PSN", "PSN", 7)
            AddColumn("SHO", "SHO", 7)
            AddColumn("TAC", "TAC", 7)
        End Sub

        Sub SetPBPGrid()
            AddColumn("ItemID", "ID", 0)
            AddColumn("Probability", "Probability", 20, "#0")
            AddColumn("Description", "Narrative", 80)
        End Sub

        Sub SetFinanceGrid()
            AddColumn("ItemID", "ID", 0)
            AddColumn("Category", "Category", 40)
            AddColumn("Unit", "Unit", 20)
            AddColumn("Modifier", "Modifier", 20)
            AddColumn("Total", "Total", 20)
        End Sub

        Sub SetPlayerCardRatingGrid()
            Dim GridCol As New DataGridGraphColumn(5)
            With GridCol
                .ParentDataGrid = mDataGrid
                .ActualRatingColumn = 3
                .PotentialRatingColumn = 4
                .IsGraphColumn = True
            End With

            AddColumn("PlayerID", "ID", 0)
            AddColumn("RatingID", "RatingID", 0)
            AddColumn("Name", "Rating", 35)
            AddColumn("0", "ACT", 10)
            AddColumn("128", "POT", 10)
            AddColumn("Grade", "Grade", 10)
            AddColumn("Graph", "---", 30, GridCol)

        End Sub

        Sub SetEmailGrid()
            AddColumn("EmailID", "EmailID", 0)
            AddColumn("MessageDate", "Date", 20)
            AddColumn("Subject", "Subject", 70)
            AddColumn("Viewed", "Viewed", 10)
        End Sub

        Sub SetPlayerCardScoringGrid()
            AddColumn("Season", "Season", 15)
            AddColumn("Team", "Team", 25)
            AddColumn("GP", "GP", 8)
            AddColumn("G", "G", 8)
            AddColumn("A", "A", 8)
            AddColumn("PT", "PT", 8)
            AddColumn("BLK", "BLK", 8)
            AddColumn("F", "F", 8)
            AddColumn("PIM", "PIM", 8)
        End Sub

        Sub SetPlayerCardGoalkeepingGrid()
            AddColumn("Season", "Season", 15)
            AddColumn("Team", "Team", 25)
            AddColumn("GP", "GP", 8)
            AddColumn("M", "M", 8)
            AddColumn("SF", "SF", 8)
            AddColumn("SV", "SV", 8)
            AddColumn("W", "W", 8)
            AddColumn("L", "L", 8)
            AddColumn("PAA", "PAA", 8)
        End Sub

    End Class
End Namespace