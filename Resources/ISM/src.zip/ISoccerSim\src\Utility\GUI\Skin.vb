'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.Xml
Imports System.IO

Namespace Utility.GUI
    Public Class Skin
        Public SkinDir As String = "Default"
        Public FormBackgroundColor As System.Drawing.Color
        Public FormFrameColor As System.Drawing.Color
        Public FormFontColor As System.Drawing.Color

        Public GridHeadingColor As System.Drawing.Color
        Public GridBackgroundColor As System.Drawing.Color
        Public GridCaptionColor As System.Drawing.Color
        Public GridCaptionFontColor As System.Drawing.Color
        Public GridFontColor As System.Drawing.Color

        Public InputBackColor As System.Drawing.Color
        Public InputFontColor As System.Drawing.Color

        Public ActualRatingColor As System.Drawing.Color
        Public PotentialRatingColor As System.Drawing.Color
        Public RatingGridBackColor As System.Drawing.Color
        Public RatingGraphColor As System.Drawing.Color

        Public Pictures As New Hashtable

        Dim fs As New FileService


        Sub Load()
            Call Load("Default")
        End Sub

        Sub Load(ByVal strSkinName As String)
            Me.SkinDir = strSkinName
            Dim MyFile As String = fs.GetSkinDirectory() & "skin.xml"
            Dim c As System.Drawing.Color

            If File.Exists(MyFile) Then
                Dim xtr As New XmlTextReader(MyFile)
                Do While xtr.Read
                    If xtr.NodeType = XmlNodeType.Element Then
                        Select Case xtr.Name
                            Case "FormBackgroundColor"
                                xtr.Read()
                                Me.FormBackgroundColor = GetColor(xtr.Value)
                            Case "FormFrameColor"
                                xtr.Read()
                                Me.FormFrameColor = GetColor(xtr.Value)
                            Case "FormFontColor"
                                xtr.Read()
                                Me.FormFontColor = GetColor(xtr.Value)
                            Case "GridHeadingColor"
                                xtr.Read()
                                Me.GridHeadingColor = GetColor(xtr.Value)
                            Case "GridBackgroundColor"
                                xtr.Read()
                                Me.GridBackgroundColor = GetColor(xtr.Value)
                            Case "GridCaptionColor"
                                xtr.Read()
                                Me.GridCaptionColor = GetColor(xtr.Value)
                            Case "GridCaptionFontColor"
                                xtr.Read()
                                Me.GridCaptionFontColor = GetColor(xtr.Value)
                            Case "GridFontColor"
                                xtr.Read()
                                Me.GridFontColor = GetColor(xtr.Value)
                            Case "InputBackColor"
                                xtr.Read()
                                Me.InputBackColor = GetColor(xtr.Value)
                            Case "InputFontColor"
                                xtr.Read()
                                Me.InputFontColor = GetColor(xtr.Value)
                            Case "ActualRatingColor"
                                xtr.Read()
                                Me.ActualRatingColor = GetColor(xtr.Value)
                            Case "PotentialRatingColor"
                                xtr.Read()
                                Me.PotentialRatingColor = GetColor(xtr.Value)
                            Case "RatingGridBackColor"
                                xtr.Read()
                                Me.RatingGridBackColor = GetColor(xtr.Value)
                            Case "RatingGraphColor"
                                xtr.Read()
                                Me.RatingGraphColor = GetColor(xtr.Value)
                            Case Else
                                If xtr.Name.Trim.Length > 0 Then
                                    Dim Key As String = xtr.Name.Trim
                                    If Not Me.Pictures.ContainsKey(Key) Then
                                        xtr.Read()
                                        Me.Pictures.Add(Key, Trim(xtr.Value))
                                    End If
                                End If
                        End Select
                    End If
                Loop
                xtr.Close()
            End If
        End Sub

        Private Function GetColor(ByVal Text As String) As System.Drawing.Color
            Dim c As New System.Drawing.Color
            If Text.IndexOf(",", 1) = -1 Then
                c = c.FromName(Text)
            Else
                Dim s As Array
                Dim R As Integer
                Dim G As Integer
                Dim B As Integer

                s = Text.Split(",")

                If s.GetLength(0) = 3 Then
                    R = s(0)
                    G = s(1)
                    B = s(2)
                    c = c.FromArgb(R, G, B)
                End If
            End If
            Return c
        End Function

    End Class
End Namespace