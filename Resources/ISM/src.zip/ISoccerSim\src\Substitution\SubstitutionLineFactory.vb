'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.SimEngine
Imports ISoccerSim.Ratings
Imports ISoccerSim.Positions
Imports ISoccerSim.Rosters


Namespace Substitution
	Public Class SubstitutionLineFactory


		Sub ClearSetForTeam(ByVal intTeamID As Integer)
			Dim DS As New DataServices.TeamTables()
			DS.DeleteSubstitutionSet(intTeamID)


		End Sub

		Function GenerateLines(ByVal objRoster As Roster) As SubstitutionLineSet

			Dim i As Integer
			Dim RankSet As New SubstitutionLineRankSet()
			Dim Rank As New SubstitutionLineRank()
            Dim RankArray(4) As Integer


			'Load players in...
			For i = 0 To objRoster.Count - 1
				Rank = New SubstitutionLineRank()
				With Rank
					.Player = objRoster.Item(i).Player
					.Position = .Player.Position
                    .Rank = Rank.Player.Ratings.GetRatingSetValue(.Position)
				End With
				RankSet.Add(Rank)
			Next

			'Assign rank per position...
			For Each Rank In RankSet
                RankArray(Rank.Position) += 1
                Rank.PositionRank = RankArray(Rank.Position)
			Next

			'Now, get players for starting line...
			Dim SubLine As New SubstitutionLine()
            Dim Result As New SubstitutionLineSet

            SubLine = Me.MakeLine(RankSet, ISMSublineType.Starters)
            Result.Add(SubLine)

            SubLine = Me.MakeLine(RankSet, ISMSublineType.SecondLine)
            Result.Add(SubLine)

            SubLine = Me.MakeLine(RankSet, ISMSublineType.ThirdLine)
            Result.Add(SubLine)

            SubLine = Me.MakeLine(RankSet, ISMSublineType.PowerPlay)
            Result.Add(SubLine)

            SubLine = Me.MakeLine(RankSet, ISMSublineType.PenaltyKill)
            Result.Add(SubLine)

            Return Result

		End Function

		Private Function MakeLine(ByRef RankSet As SubstitutionLineRankSet, ByVal intType As ISMSublineType) As SubstitutionLine

			Dim TempSet As New SubstitutionLineRankSet()
			Dim Rank As SubstitutionLineRank
			Dim SubLine As New SubstitutionLine()

			Dim OneSlot As Integer
			Dim TwoSlotLow As Integer
			Dim TwoSlotHigh As Integer

			Select Case intType
				Case ISMSublineType.Starters
					OneSlot = 1
					TwoSlotHigh = 1
					TwoSlotLow = 2

				Case ISMSublineType.SecondLine
					OneSlot = 2
					TwoSlotHigh = 3
					TwoSlotLow = 4

				Case ISMSublineType.ThirdLine
					OneSlot = 3
					TwoSlotHigh = 5
					TwoSlotLow = 6

				Case ISMSublineType.PowerPlay
					OneSlot = 1
					TwoSlotHigh = 1
					TwoSlotLow = 2

				Case ISMSublineType.PenaltyKill
					OneSlot = 1
					TwoSlotHigh = 2
					TwoSlotLow = 3

			End Select

			'Grab sets...
			TempSet = RankSet.GetPlayersForLine(ISMPlayerPosition.Goalie, 1)
			With TempSet
				SubLine.Create(.Item(0).Player.ID, ISMGamePosition.GK)
			End With

			TempSet = RankSet.GetPlayersForLine(ISMPlayerPosition.Midfielder, OneSlot)
			With TempSet
				SubLine.Create(.Item(0).Player.ID, ISMGamePosition.MF)
			End With


			TempSet = RankSet.GetPlayersForLine(ISMPlayerPosition.Defenseman, TwoSlotLow, TwoSlotHigh)
			With TempSet
				SubLine.Create(.Item(0).Player.ID, ISMGamePosition.LD)
				SubLine.Create(.Item(1).Player.ID, ISMGamePosition.RD)
			End With

			TempSet = RankSet.GetPlayersForLine(ISMPlayerPosition.Forward, TwoSlotLow, TwoSlotHigh)
			With TempSet
				SubLine.Create(.Item(0).Player.ID, ISMGamePosition.RF)
				SubLine.Create(.Item(1).Player.ID, ISMGamePosition.LF)
			End With
			SubLine.SubLineTypeID = intType
			Return SubLine
		End Function
	End Class
End Namespace