'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Namespace Tactical
	Public Class Situation
		Implements IComparable, ICloneable, IDefault

		Public SituationID As Integer
		Public Name As String
		Public BuiltIn As Boolean
		Public Abbreviation As String
		Public NetLow As Integer
		Public NetHigh As Integer
		Public MultiNetLow As Integer
		Public MultiNetHigh As Integer
		Public MinuteFrom As Integer
		Public MinuteTo As Integer
		Public IsPowerPlay As Boolean
		Public IsPenaltyKill As Boolean
		Public Half As Integer

		Function TranslateToLanguage() As String
			Dim Out As String
			Dim PtRange As String

			Out = Out.Format("[{0}]: My team is {1} and {2} in the {3} half with {4} left on the clock.", _
			 Me.SituationID, Me.GetPointString(Me.NetLow, Me.MultiNetLow), Me.GetPointString(Me.NetHigh, Me.MultiNetHigh), _
			 Me.GetHalfString(), Me.GetTimeString(Me.MinuteFrom, Me.MinuteTo))

			If Me.IsPowerPlay Then
				Out = Out & " (PP)"
			End If

			If Me.IsPenaltyKill Then
				Out = Out & " (PK)"
			End If

			Return Out
		End Function

		Private Function GetPointString(ByVal intValue As Integer, ByVal intMultiValue As Integer) As String
			If intValue < 0 Then
				Return "losing by " & Math.Abs(intValue)
				'& " (" & intMultiValue & ")"
			ElseIf intValue > 0 Then
				Return "winning by " & Math.Abs(intValue)				'& " (" & intMultiValue & ")"
			Else
				Return "tied"
			End If
		End Function

		Private Function GetTimeString(ByVal intTimeFrom As Integer, ByVal intTimeTo As Integer) As String
			Dim Out As String
			If intTimeFrom <> intTimeTo Then
				Return String.Format("between {0} and {1} minute(s)", intTimeFrom, intTimeTo)
			Else
				Return String.Format("{0} minute(s)", intTimeFrom)
			End If
		End Function

		Private Function GetHalfString() As String
			If Me.Half = 1 Then
				Return "1st"
			Else
				Return "2nd"
			End If
		End Function


		Public Overrides Function ToString() As String
			Return Me.Name
		End Function

		Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
			If obj Is Nothing Then Return 1

			Dim other As Situation = CType(obj, Situation)
			If Me.NetLow < other.NetLow Then
				Return -1
			ElseIf Me.NetLow > other.NetLow Then
				Return 1
			Else
				Return 0
			End If

		End Function

		Function Clone() As Object Implements ICloneable.Clone
			Dim Item As New Situation()
			Item = Me
			Return Item
		End Function

		Sub Update()
			Dim DS As New DataServices.BaseTables()
			DS.UpdateSituation(Me)
		End Sub


		Sub SetDefault(ByVal ID As Integer) Implements IDefault.SetDefault
			With Me
				.Abbreviation = "NEW"
				.BuiltIn = False
				.Half = 2
				.IsPenaltyKill = False
				.IsPowerPlay = False
				.MinuteFrom = 0
				.MinuteTo = 30
				.Name = "New Situation"
				.NetHigh = 99
				.NetLow = -99
				.MultiNetHigh = 99
				.MultiNetLow = -99
				.SituationID = ID
			End With
		End Sub
	End Class
End Namespace