'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.SimEngine.Actions
Imports ISoccerSim.SimEngine.Actions.Plays
Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports Microsoft.VisualBasic
Imports ISoccerSim.Players
Imports ISoccerSim.SimEngine

Namespace SimEngine.Actions.Sequence
	Public Class Shot
        Inherits Sequence

        Dim r As MathService = MathService.GetInstance

		Public Event Penalty(ByVal sender As Object, ByVal e As PenaltyRaisedEventArgs)

		Sub New(ByVal GameEngine As GameEngine)
			Me.GameEngine = GameEngine
			Me.Name = "Shot"
		End Sub

		Overrides Sub Execute()
			With Me.GameEngine

StartAnotherShot:

				If .Clock.IsEndOfGame Or .Posession.Changed Then Exit Sub


				Dim pyrOffense As Player = .Posession.Offense.FieldManager.Field.ActivePlayer
				Dim pyrGoalie As Player = .Posession.Defense.FieldManager.Field.GetPlayerByGamePosition(ISMGamePosition.GK)
				Dim pyrDefense As Player
				Dim Result As ISMActionResult

				Dim UnopposedShot As Integer = Me.GameEngine.Settings.Settings.GetValue(Settings.ISM_GameSettingType.ShotSequence, Settings.ISM_GameSetting.GenericAdj)
				Dim ShotAttempt As New ShotAttemptAction(Me.GameEngine)
				Dim ScrambleAttempt As New ScrambleForBallAction(Me.GameEngine)
				Dim ShotOnTarget As New ShotOnTargetAction(Me.GameEngine)
				Dim ShotInGoal As New ShotInGoalAction(Me.GameEngine)

				Me.Result = ISMActionResult.Failure
				.PlayByPlay.SetPlayers(pyrOffense, pyrOffense, pyrDefense, pyrGoalie, Nothing)
				.GameLog.Create(.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.ShotOnGoal))

				'Check to see if shot if unopposed or blocked...
                If r.GetRoll(MathService.ISMRollType.Percentage) < UnopposedShot Then
                    pyrDefense = GetDefensivePlayer()
                    ShotAttempt.Execute(pyrOffense, pyrDefense)
                    Select Case ShotAttempt.Result
                        Case ISMActionResult.Failure, ISMActionResult.Bizarre
                            'Shot is blocked by defender, see who gets it...
                            .Clock.Tick(2, 5)
                            .PlayByPlay.Defender = pyrDefense
                            .GameLog.Create(.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.BlockedShotOnGoal))
                            pyrDefense.Stats.Augment(Statistics.ISMStat.Block, 1)
                            pyrOffense.Stats.Augment(Statistics.ISMStat.ShotAttempted, 1)
                            If Not pyrGoalie Is Nothing Then pyrGoalie.Stats.Augment(Statistics.ISMStat.ShotFaced, 1)
                            Call Me.SetBallMovement()
                            If ReboundStaysWithOffense(pyrOffense) Then
                                GoTo Startanothershot
                            Else
                                Exit Sub
                            End If
                    End Select
                Else
                    pyrDefense = Nothing
                End If

                'Check to see if shot is on mark...

                ShotOnTarget.Execute(pyrOffense, pyrDefense)
                Select Case ShotOnTarget.Result
                    Case ISMActionResult.Bizarre, ISMActionResult.Failure
                        'Shot misses mark...
                        .GameLog.Create(.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.MissedShotOnGoal))
                        pyrOffense.Stats.Augment(Statistics.ISMStat.ShotAttempted, 1)
                        If Not pyrGoalie Is Nothing Then pyrGoalie.Stats.Augment(Statistics.ISMStat.ShotFaced, 1)
                        Me.GameEngine.Posession.Offense.FieldManager.Field.AssistPlayer = Nothing
                        .Clock.Tick(2, 5)
                        Call Me.SetBallMovement()
                        If ReboundStaysWithOffense(pyrOffense) Then
                            GoTo Startanothershot
                        Else
                            Exit Sub
                        End If
                End Select

                'Shot is on mark, now see if we get past the keeper...
                ShotInGoal.Execute(pyrOffense, pyrGoalie)
                Select Case ShotInGoal.Result
                    Case ISMActionResult.Bizarre
                        .GameLog.Create(.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.CoolGoalieStop))
                        pyrOffense.Stats.Augment(Statistics.ISMStat.ShotAttempted, 1)
                        If Not pyrGoalie Is Nothing Then pyrGoalie.Stats.Augment(Statistics.ISMStat.ShotStopped, 1)
                        If Not pyrGoalie Is Nothing Then pyrGoalie.Stats.Augment(Statistics.ISMStat.ShotFaced, 1)

                        .Clock.Tick(2, 5)
                        Call Me.SetBallToGoalie()
                        .Posession.Switch()
                        .Posession.Offense.FieldManager.Field.ActivePlayer = pyrGoalie

                        Exit Sub
                    Case ISMActionResult.Failure
                        .GameLog.Create(.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.GoalieStopOnGoal))
                        pyrOffense.Stats.Augment(Statistics.ISMStat.ShotAttempted, 1)
                        If Not pyrGoalie Is Nothing Then pyrGoalie.Stats.Augment(Statistics.ISMStat.ShotStopped, 1)
                        If Not pyrGoalie Is Nothing Then pyrGoalie.Stats.Augment(Statistics.ISMStat.ShotFaced, 1)

                        .Clock.Tick(2, 5)
                        Call Me.SetBallToGoalie()
                        .Posession.Switch()
                        If Not pyrGoalie Is Nothing Then
                            .Posession.Offense.FieldManager.Field.ActivePlayer = pyrGoalie
                        Else
                            .Posession.Offense.FieldManager.Field.ActivePlayer = .Posession.Offense.FieldManager.Field.GetRandomPlayerOnField(0, 40, 40, 3, 4, 3)
                        End If

                        Exit Sub
                    Case ISMActionResult.Success
                        'YOU MADE IT IN THE GOAL!  GRAB YOURSELF A BEER!
                        Me.GameEngine.Ball.Check3PtProbability()         'Somewhat dirty hack for MPS

                        .GameLog.Create(.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.RegularGoal))
                        If Not pyrGoalie Is Nothing Then pyrGoalie.Stats.Augment(Statistics.ISMStat.ShotFaced, 1)

                        Me.Result = ISMActionResult.GoalMade
                        Exit Sub
                End Select
            End With
		End Sub

		Private Function ReboundStaysWithOffense(ByVal pyrOffense As Player) As Boolean
			With Me.GameEngine
				Dim ScrambleAttempt As New ScrambleForBallAction(Me.GameEngine)

				ScrambleAttempt.Execute()
				If ScrambleAttempt.Result = ISMActionResult.Success Then
					'Shot rebound picked up by offense..
					pyrOffense = .Posession.Offense.FieldManager.Field.GetRandomPlayerOnField(0, 20, 20, 20, 20, 20)
					.GameLog.Create(.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.ReboundOff))
					Return True
				Else
					'Shot rebound picked up by defense...
					.PlayByPlay.Defender = GetDefensivePlayer()
					.GameLog.Create(.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.ReboundDef))
					.Posession.Defense.FieldManager.Field.ActivePlayer = .PlayByPlay.Defender
					.Posession.Switch()
					Return False
				End If
			End With
		End Function

		Private Function GetUnopposedPercentage() As Byte
			Return Me.GameEngine.Settings.Settings.GetFieldPenalty(Settings.ISM_GameSettingType.PassSequence, Me.GameEngine.Ball.Y)
		End Function

		Private Function GetDefensivePlayer() As Player
			With Me.GameEngine.Posession.Defense.FieldManager.Field
				Select Case Me.GameEngine.Ball.Y
					Case ISMBallVertical.OppCrease
						Return .GetRandomPlayerOnField(0, 15, 15, 10, 10, 10)						 '40
					Case ISMBallVertical.OppShortRange
						Return .GetRandomPlayerOnField(0, 20, 20, 10, 10, 20)						' 20
					Case ISMBallVertical.OppThird
						Return .GetRandomPlayerOnField(0, 24, 24, 20, 20, 10)
					Case ISMBallVertical.MidField
						Return .GetRandomPlayerOnField(0, 20, 20, 20, 20, 20)
					Case Else
						Return .GetRandomPlayerOnField(0, 10, 10, 25, 25, 30)
				End Select
			End With
		End Function



		Private Sub SetBallMovement()
			With Me.GameEngine.Ball
				.PlaceRandomly()
			End With
		End Sub

		Private Sub SetBallToGoalie()
			With Me.GameEngine.Ball
				.Y = ISMBallVertical.OppCrease
				.X = ISMBallLateral.Middle
			End With
		End Sub

	End Class
End Namespace


