'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.DataServices
Imports System.Data


Namespace Statistics

	Public Enum ISMStatScope
		League = 0
		Conference = 1
		Division = 2
		Team = 3
	End Enum

	Public Enum ISMStatType
		Individual = 0
		League = 1
	End Enum



	Public Class StatisticManager

        Private DataTable As New StatTables
        Public Season As Integer
		Public StatReports As New StatReportItemSet()


		Public Scope As ISMStatScope
		Public StatType As ISMStatType
		Public ConferenceID As Integer
		Public DivisionID As Integer
		Public TeamID As Integer
		Public Report As StatReportItem

		Public Sub New()

            Dim Sim As Simulation = Simulation.GetInstance
            Me.StatReports.Load()
            Season = Sim.League.Season
		End Sub

		Public Function GetData(ByVal Report As StatReportItem) As DataSet
			Me.Report = Report

			If Report.IsBase Then
				Return RunBaseReport()
			Else
				'Do something more complicated....
				Return RunAdvancedReport(Report)
			End If
		End Function


		Private Function RunBaseReport() As DataSet

			If Me.StatType = ISMStatType.Individual Then
				Select Case Me.Scope
					Case ISMStatScope.Conference
                        Return Me.DataTable.GetBaseLeagueStatForConference(Report.ISMStat, Me.ConferenceID, Me.Season)
					Case ISMStatScope.Division
                        Return Me.DataTable.GetBaseLeagueStatForDivision(Report.ISMStat, Me.DivisionID, Me.Season)
					Case ISMStatScope.League
                        Return Me.DataTable.GetBaseLeagueStat(Report.ISMStat, Me.Season)
					Case ISMStatScope.Team
                        Return Me.DataTable.GetBaseLeagueStatForTeam(Report.ISMStat, Me.TeamID, Me.Season)
				End Select
			Else
				Select Case Me.Scope
					Case ISMStatScope.Conference
                        Return Me.DataTable.GetBaseTeamStatForConference(Report.ISMStat, Me.ConferenceID, Me.Season)
					Case ISMStatScope.Division
                        Return Me.DataTable.GetBaseTeamStatForDivision(Report.ISMStat, Me.DivisionID, Me.Season)
					Case Else
						Return Me.DataTable.GetBaseTeamStat(Report.ISMStat)
				End Select
			End If

		End Function

		Private Function RunAdvancedReport(ByVal Report As StatReportItem) As DataSet

			If Report.ID = ISMStatReport.ScoringLeaders Then
				Return GetAdvancedTable(New AdvancedStats.Leaderboard())
			ElseIf Report.ID = ISMStatReport.MPS_ScoringLeaders Then
				Return GetAdvancedTable(New AdvancedStats.LeaderboardMPS())
			ElseIf Report.ID = ISMStatReport.GoalieLeaders Then
				Return GetAdvancedTable(New AdvancedStats.LeadingGoalkeepers())
			ElseIf Report.ID = ISMStatReport.MPS_GoalieLeaders Then
				Return GetAdvancedTable(New AdvancedStats.LeadingGoalkeepersMPS())
			End If

		End Function


		Private Function GetAdvancedTable(ByVal Table As AdvancedStats.AdvancedStatService) As DataSet

			If Me.StatType = ISMStatType.Individual Then
				Select Case Me.Scope
					Case ISMStatScope.Conference
                        Return Table.GetBaseLeagueStatForConference(Report.ISMStat, Me.ConferenceID, Me.Season)
					Case ISMStatScope.Division
                        Return Table.GetBaseLeagueStatForDivision(Report.ISMStat, Me.DivisionID, Me.Season)
					Case ISMStatScope.League
                        Return Table.GetBaseLeagueStat(Me.Season)
					Case ISMStatScope.Team
                        Return Table.GetBaseLeagueStatForTeam(Report.ISMStat, Me.TeamID, Me.Season)
				End Select
			Else
				Select Case Me.Scope
					Case ISMStatScope.Conference
                        Return Table.GetBaseTeamStatForConference(Report.ISMStat, Me.ConferenceID, Me.Season)
					Case ISMStatScope.Division
                        Return Table.GetBaseTeamStatForDivision(Report.ISMStat, Me.DivisionID, Me.Season)
					Case Else
                        Return Table.GetBaseTeamStat(Report.ISMStat, Me.Season)
				End Select
			End If
		End Function

        Public Function GetCareerScoringHistory(ByVal PlayerID As Integer, ByVal Season As Integer, ByVal TeamName As String) As DataSet
            Dim st As New StatTables
            Dim dr As OleDb.OleDbDataReader = st.GetCareerOffenseForPlayer(PlayerID)
            Dim dt As DataTable = GetCareerScoringTable()

            Dim holder As New OffenseCareerStatHolder
            Dim Result As New DataSet

            Dim Break As Integer
            Dim BreakTeam As String

            Do While dr.Read
                If Break = 0 Then
                    Break = dr.Item("SeasonID")
                    BreakTeam = dr.Item("Team")

                    holder.Season = Break
                    holder.Team = dr.Item("Team")
                End If

                If dr.Item("SeasonID") <> Break Or dr.Item("Team") <> BreakTeam Then
                    dt.Rows.Add(holder.GetArray())
                    Break = dr.Item("SeasonID")
                    BreakTeam = dr.Item("Team")
                    holder = New OffenseCareerStatHolder
                    holder.Season = Break
                    holder.Team = dr.Item("Team")
                End If

                If dr.Item("StatID") = ISMStat.Assists Then holder.A = dr.Item("Total")
                If dr.Item("StatID") = ISMStat.Points Then holder.G = dr.Item("Total")
                If dr.Item("StatID") = ISMStat.GamesPlayed Then holder.GP = dr.Item("Total")
                If dr.Item("StatID") = ISMStat.Points Then holder.PT = dr.Item("Total")
                If dr.Item("StatID") = ISMStat.Block Then holder.BLK = dr.Item("Total")
                If dr.Item("StatID") = ISMStat.Fouls Then holder.F = dr.Item("Total")
                If dr.Item("StatID") = ISMStat.PenaltyMinutes Then holder.PIM = dr.Item("Total")

            Loop
            dr.Close()
            If holder.Season > 0 Then
                dt.Rows.Add(holder.GetArray())
            Else
                dt.Rows.Add(holder.GetArray(Season, TeamName))
            End If

            dt.TableName = "Career Scoring"
            Result.Tables.Add(dt)
            Return Result

        End Function

        Private Function GetCareerScoringTable()
            Dim Result As New DataTable
            'DEF/OFF - PT, BLK, F, PIM

            Result.Columns.Add("Season")
            Result.Columns.Add("Team")
            Result.Columns.Add("GP")
            Result.Columns.Add("G") ', System.Type.GetType("System.Integer"))
            Result.Columns.Add("A")
            Result.Columns.Add("PT")
            Result.Columns.Add("BLK")
            Result.Columns.Add("F")
            Result.Columns.Add("PIM")
            Return Result
        End Function

        Private Function GetCareerDefenseTableStructure()
            Dim Result As New DataTable
            Result.Columns.Add("Season")
            Result.Columns.Add("Team")
            Result.Columns.Add("GP")
            Result.Columns.Add("SF")
            Result.Columns.Add("SV")
            Result.Columns.Add("W")
            Result.Columns.Add("L")
            Result.Columns.Add("PAA")
            Return Result
        End Function

        Public Function GetCareerGoalkeepingHistory(ByVal PlayerID As Integer, ByVal Season As Integer, ByVal TeamName As String) As DataSet
            Dim st As New StatTables
            Dim dr As OleDb.OleDbDataReader = st.GetCareerDefenseForPlayer(PlayerID)
            Dim dt As DataTable = GetCareerDefenseTableStructure()

            Dim holder As New DefenseCareerStatHolder
            Dim Result As New DataSet

            Dim Break As Integer
            Dim BreakTeam As String

            Do While dr.Read
                If Break = 0 Then
                    Break = dr.Item("SeasonID")
                    BreakTeam = dr.Item("Team")

                    holder.Season = Break
                    holder.Team = dr.Item("Team")
                End If

                If dr.Item("SeasonID") <> Break Or dr.Item("Team") <> BreakTeam Then
                    dt.Rows.Add(holder.GetArray())
                    Break = dr.Item("SeasonID")
                    BreakTeam = dr.Item("Team")
                    holder = New DefenseCareerStatHolder
                    holder.Season = Break
                    holder.Team = dr.Item("Team")
                End If


                If dr.Item("StatID") = ISMStat.GamesPlayed Then holder.GP = dr.Item("Total")
                If dr.Item("StatID") = ISMStat.ShotFaced Then holder.SF = dr.Item("Total")
                If dr.Item("StatID") = ISMStat.ShotStopped Then holder.S = dr.Item("Total")
                If dr.Item("StatID") = ISMStat.GoalieWin Then holder.W = dr.Item("Total")
                If dr.Item("StatID") = ISMStat.GoalieLoss Then holder.L = dr.Item("Total")
                If dr.Item("StatID") = ISMStat.Minutes Then holder.M = dr.Item("Total")
                If dr.Item("StatID") = ISMStat.ShotAllowed Then holder.SA = dr.Item("Total")

                '

            Loop
            dr.Close()
            If holder.Season > 0 Then
                dt.Rows.Add(holder.GetArray())
            Else
                dt.Rows.Add(holder.GetArray(Season, TeamName))
            End If

            dt.TableName = "Career Goalkeeping"
            Result.Tables.Add(dt)
            Return Result
        End Function
    End Class

    


End Namespace