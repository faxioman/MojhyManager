Imports System.Threading
Imports ISoccerSim.Simulation
Imports ISoccerSim
Imports System.IO

Module modMain
    <STAThread()> _
Sub Main()
        'Add standard error handler
        AddHandler Application.ThreadException, New ThreadExceptionEventHandler(AddressOf HandleException)

        Try
            Dim f As New frmAbout
            Dim Sim As Simulation = Simulation.GetInstance()

            f.Show()
            f.Refresh()
            Sim.Load()
            f.Close()
            Application.Run(New frmMain)
        Catch ex As Exception
            Call HandleException(Nothing, ex)
        End Try

    End Sub

    Sub ShowMessageBox(ByVal Title As String, ByVal Message As String, ByVal ParentForm As Form)
        Dim f As New frmDialog(Title, Message)
        Dim s As String
        f.ShowDialog(ParentForm)
    End Sub


    Sub HandleException(ByVal Sender As Object, ByVal e As Exception)
        Dim fs As FileService = FileService.GetInstance
        Dim tw As StreamWriter = File.AppendText(fs.GetErrorFileName)

        With e
            tw.WriteLine("-----------")
            tw.WriteLine("Error:")
            tw.WriteLine("Date : " & Now & vbCrLf)
            tw.WriteLine("Path : " & fs.GetCurrentDirectory() & vbCrLf)
            tw.WriteLine("Source : " & .Source & vbCrLf)
            tw.WriteLine("Error: " & .Message & vbCrLf)
            tw.WriteLine("Stack Trace:" & .StackTrace & vbCrLf)
            tw.WriteLine("-----------")
            tw.Close()
        End With
        MsgBox("An error has occured.  An error.txt file has been created in the ISS directory.  Please email to the team!" & vbCrLf & vbCrLf & e.ToString)
    End Sub

    Sub HandleException(ByVal Sender As Object, ByVal t As ThreadExceptionEventArgs)
        Call HandleException(t, t.Exception)
    End Sub

End Module
