
'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.SimEngine
Imports ISoccerSim.Substitution
Imports ISoccerSim.Positions
Imports ISoccerSim.Players
Imports ISoccerSim.Rosters
Imports ISoccerSim.Teams

Public Class frmTeamSublines
	Inherits System.Windows.Forms.Form

	Private mblnLoading As Boolean
	Private mblnDirty As Boolean
	Private mintPlayerID As Integer
	Private mintLastSetIndex As Integer
    Private mintLastTeamIndex As Integer

    Dim gs As GUIService = GuiService.GetInstance


#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.

		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		Call SetScreen()
	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Public WithEvents tipLeague As System.Windows.Forms.ToolTip
	Public WithEvents btnOK As System.Windows.Forms.Button
	Public WithEvents Label3 As System.Windows.Forms.Label
    Public WithEvents grpSubline As System.Windows.Forms.GroupBox
    Public WithEvents lstSublines As System.Windows.Forms.ListBox
	Public WithEvents grpLineUp As System.Windows.Forms.GroupBox
	Public WithEvents cmbLF As System.Windows.Forms.ComboBox
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents btnAutoCreateAll As System.Windows.Forms.Button
	Public WithEvents cmbLD As System.Windows.Forms.ComboBox
	Public WithEvents cmbRD As System.Windows.Forms.ComboBox
	Public WithEvents cmbRF As System.Windows.Forms.ComboBox
	Public WithEvents cmbMF As System.Windows.Forms.ComboBox
	Public WithEvents btnLD As System.Windows.Forms.Button
	Public WithEvents btnLF As System.Windows.Forms.Button
	Public WithEvents btnMF As System.Windows.Forms.Button
	Public WithEvents btnRF As System.Windows.Forms.Button
	Public WithEvents btnRD As System.Windows.Forms.Button
	Public WithEvents btnSave As System.Windows.Forms.Button
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents btnGK As System.Windows.Forms.Button
	Public WithEvents cmbGK As System.Windows.Forms.ComboBox
    Public WithEvents cmbTeam As TeamCombo
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.btnOK = New System.Windows.Forms.Button
        Me.grpSubline = New System.Windows.Forms.GroupBox
        Me.grpLineUp = New System.Windows.Forms.GroupBox
        Me.btnGK = New System.Windows.Forms.Button
        Me.Label7 = New System.Windows.Forms.Label
        Me.cmbGK = New System.Windows.Forms.ComboBox
        Me.btnRF = New System.Windows.Forms.Button
        Me.btnMF = New System.Windows.Forms.Button
        Me.btnLF = New System.Windows.Forms.Button
        Me.btnRD = New System.Windows.Forms.Button
        Me.btnLD = New System.Windows.Forms.Button
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.cmbLD = New System.Windows.Forms.ComboBox
        Me.cmbRD = New System.Windows.Forms.ComboBox
        Me.cmbRF = New System.Windows.Forms.ComboBox
        Me.cmbMF = New System.Windows.Forms.ComboBox
        Me.cmbLF = New System.Windows.Forms.ComboBox
        Me.lstSublines = New System.Windows.Forms.ListBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.tipLeague = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnAutoCreateAll = New System.Windows.Forms.Button
        Me.btnSave = New System.Windows.Forms.Button
        Me.cmbTeam = New TeamCombo
        Me.grpSubline.SuspendLayout()
        Me.grpLineUp.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnOK
        '
        Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnOK.Location = New System.Drawing.Point(568, 320)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(112, 24)
        Me.btnOK.TabIndex = 4
        Me.btnOK.Text = "&OK"
        '
        'grpSubline
        '
        Me.grpSubline.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.grpSubline.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmbTeam, Me.grpLineUp, Me.lstSublines, Me.Label3})
        Me.grpSubline.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpSubline.Location = New System.Drawing.Point(16, 32)
        Me.grpSubline.Name = "grpSubline"
        Me.grpSubline.Size = New System.Drawing.Size(664, 280)
        Me.grpSubline.TabIndex = 11
        Me.grpSubline.TabStop = False
        Me.grpSubline.Text = "Substitution Lines"
        '
        'grpLineUp
        '
        Me.grpLineUp.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnGK, Me.Label7, Me.cmbGK, Me.btnRF, Me.btnMF, Me.btnLF, Me.btnRD, Me.btnLD, Me.Label6, Me.Label5, Me.Label4, Me.Label2, Me.Label1, Me.cmbLD, Me.cmbRD, Me.cmbRF, Me.cmbMF, Me.cmbLF})
        Me.grpLineUp.Location = New System.Drawing.Point(104, 48)
        Me.grpLineUp.Name = "grpLineUp"
        Me.grpLineUp.Size = New System.Drawing.Size(552, 216)
        Me.grpLineUp.TabIndex = 20
        Me.grpLineUp.TabStop = False
        Me.grpLineUp.Text = "Line Up"
        '
        'btnGK
        '
        Me.btnGK.Location = New System.Drawing.Point(176, 96)
        Me.btnGK.Name = "btnGK"
        Me.btnGK.Size = New System.Drawing.Size(28, 22)
        Me.btnGK.TabIndex = 31
        Me.btnGK.Text = "+"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(8, 80)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(24, 16)
        Me.Label7.TabIndex = 32
        Me.Label7.Text = "GK"
        '
        'cmbGK
        '
        Me.cmbGK.Location = New System.Drawing.Point(8, 96)
        Me.cmbGK.Name = "cmbGK"
        Me.cmbGK.Size = New System.Drawing.Size(168, 22)
        Me.cmbGK.TabIndex = 30
        '
        'btnRF
        '
        Me.btnRF.Location = New System.Drawing.Point(512, 176)
        Me.btnRF.Name = "btnRF"
        Me.btnRF.Size = New System.Drawing.Size(28, 22)
        Me.btnRF.TabIndex = 9
        Me.btnRF.Text = "+"
        '
        'btnMF
        '
        Me.btnMF.Location = New System.Drawing.Point(512, 104)
        Me.btnMF.Name = "btnMF"
        Me.btnMF.Size = New System.Drawing.Size(28, 22)
        Me.btnMF.TabIndex = 7
        Me.btnMF.Text = "+"
        '
        'btnLF
        '
        Me.btnLF.Location = New System.Drawing.Point(512, 32)
        Me.btnLF.Name = "btnLF"
        Me.btnLF.Size = New System.Drawing.Size(28, 22)
        Me.btnLF.TabIndex = 5
        Me.btnLF.Text = "+"
        '
        'btnRD
        '
        Me.btnRD.Location = New System.Drawing.Point(344, 136)
        Me.btnRD.Name = "btnRD"
        Me.btnRD.Size = New System.Drawing.Size(28, 22)
        Me.btnRD.TabIndex = 3
        Me.btnRD.Text = "+"
        '
        'btnLD
        '
        Me.btnLD.Location = New System.Drawing.Point(344, 64)
        Me.btnLD.Name = "btnLD"
        Me.btnLD.Size = New System.Drawing.Size(28, 22)
        Me.btnLD.TabIndex = 1
        Me.btnLD.Text = "+"
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(344, 160)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(24, 16)
        Me.Label6.TabIndex = 29
        Me.Label6.Text = "RF"
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(344, 88)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(24, 16)
        Me.Label5.TabIndex = 28
        Me.Label5.Text = "MF"
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(344, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(24, 16)
        Me.Label4.TabIndex = 27
        Me.Label4.Text = "LF"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(176, 120)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(24, 16)
        Me.Label2.TabIndex = 26
        Me.Label2.Text = "RD"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(176, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(24, 16)
        Me.Label1.TabIndex = 25
        Me.Label1.Text = "LD"
        '
        'cmbLD
        '
        Me.cmbLD.Location = New System.Drawing.Point(176, 64)
        Me.cmbLD.Name = "cmbLD"
        Me.cmbLD.Size = New System.Drawing.Size(168, 22)
        Me.cmbLD.TabIndex = 0
        '
        'cmbRD
        '
        Me.cmbRD.Location = New System.Drawing.Point(176, 136)
        Me.cmbRD.Name = "cmbRD"
        Me.cmbRD.Size = New System.Drawing.Size(168, 22)
        Me.cmbRD.TabIndex = 2
        '
        'cmbRF
        '
        Me.cmbRF.Location = New System.Drawing.Point(344, 176)
        Me.cmbRF.Name = "cmbRF"
        Me.cmbRF.Size = New System.Drawing.Size(168, 22)
        Me.cmbRF.TabIndex = 8
        '
        'cmbMF
        '
        Me.cmbMF.Location = New System.Drawing.Point(344, 104)
        Me.cmbMF.Name = "cmbMF"
        Me.cmbMF.Size = New System.Drawing.Size(168, 22)
        Me.cmbMF.TabIndex = 6
        '
        'cmbLF
        '
        Me.cmbLF.Location = New System.Drawing.Point(344, 32)
        Me.cmbLF.Name = "cmbLF"
        Me.cmbLF.Size = New System.Drawing.Size(168, 22)
        Me.cmbLF.TabIndex = 4
        '
        'lstSublines
        '
        Me.lstSublines.ItemHeight = 14
        Me.lstSublines.Items.AddRange(New Object() {"Starters", "2nd Line", "3rd Line", "Power Play", "Penalty Kill"})
        Me.lstSublines.Location = New System.Drawing.Point(16, 48)
        Me.lstSublines.Name = "lstSublines"
        Me.lstSublines.Size = New System.Drawing.Size(72, 214)
        Me.lstSublines.TabIndex = 14
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 24)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Team:"
        '
        'btnAutoCreateAll
        '
        Me.btnAutoCreateAll.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnAutoCreateAll.Location = New System.Drawing.Point(16, 320)
        Me.btnAutoCreateAll.Name = "btnAutoCreateAll"
        Me.btnAutoCreateAll.Size = New System.Drawing.Size(112, 24)
        Me.btnAutoCreateAll.TabIndex = 13
        Me.btnAutoCreateAll.Text = "&Computer Set All"
        '
        'btnSave
        '
        Me.btnSave.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnSave.Location = New System.Drawing.Point(448, 320)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(112, 24)
        Me.btnSave.TabIndex = 14
        Me.btnSave.Text = "&Save"
        '
        'cmbTeam
        '
        Me.cmbTeam.Location = New System.Drawing.Point(104, 16)
        Me.cmbTeam.Name = "cmbTeam"
        Me.cmbTeam.Size = New System.Drawing.Size(256, 24)
        Me.cmbTeam.TabIndex = 21
        '
        'frmTeamSublines
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(694, 355)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnSave, Me.btnAutoCreateAll, Me.btnOK, Me.grpSubline})
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "frmTeamSublines"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Team Substitution Lines"
        Me.grpSubline.ResumeLayout(False)
        Me.grpLineUp.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		CheckForSave()
		Me.Close()
	End Sub


	Private Sub SetScreen()
		mblnLoading = True
        Call gs.SetCursor(Me)
        gs.SkinForm(Me)
        Me.lstSublines.SelectedIndex = 0
        mintLastTeamIndex = 0
        mintLastSetIndex = 0
        Me.cmbTeam.LoadTeams()
        Call LoadSubline()
		mblnLoading = False
	End Sub


    Private Sub LoadSubline()
        Dim objSubset As New SubstitutionLineSet()
        Dim Team As Integer = Me.cmbTeam.TeamID
        Dim Line As Integer = Me.lstSublines.SelectedIndex
        gs.SetCursor(True, Me)
        objSubset.Load(Team)
        Dim sLine As SubstitutionLine = objSubset.Item(Line)
        Call LoadPlayersIntoCombos(sLine)
        Me.btnSave.Enabled = False
        gs.SetCursor(False, Me)
    End Sub


    Private Sub LoadPlayersIntoCombos(ByVal objLine As SubstitutionLine)
        LoadPlayerList(ISMGamePosition.LD, objLine)
        LoadPlayerList(ISMGamePosition.LF, objLine)
        LoadPlayerList(ISMGamePosition.MF, objLine)
        LoadPlayerList(ISMGamePosition.RD, objLine)
        LoadPlayerList(ISMGamePosition.RF, objLine)
        LoadPlayerList(ISMGamePosition.GK, objLine)
    End Sub

    Private Sub LoadPlayerList(ByVal intGamePositionID As ISMGamePosition, ByVal objLine As SubstitutionLine)
        Dim ps As New PlayerSet
        mblnLoading = True

        Select Case intGamePositionID
            Case ISMGamePosition.LD, ISMGamePosition.RD
                ps.LoadByTeamForPosition(Me.cmbTeam.TeamID, ISMPlayerPosition.Defenseman)
            Case ISMGamePosition.MF
                ps.LoadByTeamForPosition(Me.cmbTeam.TeamID, ISMPlayerPosition.Midfielder)
            Case ISMGamePosition.LF, ISMGamePosition.RF
                ps.LoadByTeamForPosition(Me.cmbTeam.TeamID, ISMPlayerPosition.Forward)
            Case Else
                ps.LoadByTeamForPosition(Me.cmbTeam.TeamID, ISMPlayerPosition.Goalie)
        End Select

        Dim Combo As ComboBox = GetComboBox(intGamePositionID)
        Combo.DisplayMember = "DisplayMember"
        Combo.ValueMember = "ValueMember"
        Combo.DropDownStyle = ComboBoxStyle.DropDownList

        Dim Player As Player

        Combo.Items.Clear()
        For Each Player In ps
            Combo.Items.Add(Player)
            If Player.ID = objLine.GetPlayerIDForPosition(intGamePositionID) Then
                Combo.SelectedItem = Player
            End If
        Next
        mblnLoading = False
    End Sub


    Private Function GetComboBox(ByVal intGamePositionID As ISMGamePosition) As ComboBox
        Select Case intGamePositionID
            Case ISMGamePosition.LD
                Return Me.cmbLD
            Case ISMGamePosition.LF
                Return Me.cmbLF
            Case ISMGamePosition.MF
                Return Me.cmbMF
            Case ISMGamePosition.RD
                Return Me.cmbRD
            Case ISMGamePosition.RF
                Return Me.cmbRF
            Case ISMGamePosition.GK
                Return Me.cmbGK
        End Select
    End Function

    Private Sub btnTeamRoster_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim f As New frmTeamRoster()
        f.SetScreen(Me.cmbTeam.TeamID)
        f.ShowDialog()

    End Sub

    Private Sub cmbTeams_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As TeamSelectedEventArgs) Handles cmbTeam.SelectionChanged
        If Not mblnLoading Then
            CheckForSave()
            Call LoadSubline()
            mintLastTeamIndex = Me.cmbTeam.LastTeamID
        End If
    End Sub

    Private Sub lstSublines_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstSublines.SelectedIndexChanged
        If Not mblnLoading Then
            CheckForSave()
            Call LoadSubline()
            mintLastSetIndex = Me.lstSublines.SelectedIndex
        End If
    End Sub

    Private Sub Save()
        Dim objSubset As New SubstitutionLineSet()
        Dim Team As Integer = IIf(Me.cmbTeam.LastTeamID = 0, Me.cmbTeam.TeamID, Me.cmbTeam.LastTeamID)
        Dim Line As Integer = mintLastSetIndex
        gs.SetCursor(True, Me)
        'Save stuff...
        objSubset.Load(Team)
        Dim subLine As SubstitutionLine = objSubset.Item(Line)
        subLine.Item(ISMGamePosition.LD).PlayerID = CType(Me.cmbLD.SelectedItem, Player).ID
        subLine.Item(ISMGamePosition.RD).PlayerID = CType(Me.cmbRD.SelectedItem, Player).ID
        subLine.Item(ISMGamePosition.LF).PlayerID = CType(Me.cmbLF.SelectedItem, Player).ID
        subLine.Item(ISMGamePosition.RF).PlayerID = CType(Me.cmbRF.SelectedItem, Player).ID
        subLine.Item(ISMGamePosition.MF).PlayerID = CType(Me.cmbMF.SelectedItem, Player).ID
        subLine.Item(ISMGamePosition.GK).PlayerID = CType(Me.cmbGK.SelectedItem, Player).ID
        subLine.Update()
        gs.SetCursor(False, Me)
    End Sub

    Private Sub ZoomPlayer(ByVal Combo As ComboBox)

        Dim i As Integer
        Dim arrPlayerList As New ArrayList(10)

        For i = 0 To Combo.Items.Count - 1
            arrPlayerList.Add(CType(Combo.Items(i), Player).ID)
        Next

        Dim f As New frmPlayerCard(CType(Combo.SelectedItem, Player).ID, arrPlayerList)
        f.ShowDialog()

    End Sub

    Private Sub ZoomPlayer(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLD.Click, btnLF.Click, btnMF.Click, btnRF.Click, btnRD.Click
        Dim Name As String = CType(sender, Button).Name
        Name = Name.Replace("btn", "")
        Select Case Name
            Case "LD"
                Call ZoomPlayer(Me.cmbLD)
            Case "RD"
                Call ZoomPlayer(Me.cmbRD)
            Case "LF"
                Call ZoomPlayer(Me.cmbLF)
            Case "RF"
                Call ZoomPlayer(Me.cmbRF)
            Case "MF"
                Call ZoomPlayer(Me.cmbMF)
            Case "GK"
                Call ZoomPlayer(Me.cmbGK)
        End Select
    End Sub

    Private Sub ScootOtherDefense(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbLD.SelectedIndexChanged, cmbRD.SelectedIndexChanged
        If Not mblnLoading Then
            If Me.cmbLD.SelectedIndex = Me.cmbRD.SelectedIndex Then
                mblnLoading = True
                If CType(sender, ComboBox).Name = "cmbLD" Then
                    SetSafeIndex(Me.cmbLD, Me.cmbRD)
                Else
                    SetSafeIndex(Me.cmbRD, Me.cmbLD)
                End If
                mblnLoading = False
            End If
            mblnDirty = True
            Me.btnSave.Enabled = True
        End If
    End Sub

    Private Sub SetSafeIndex(ByVal objComboFrom As ComboBox, ByVal objComboTo As ComboBox)
        Dim i As Integer
        For i = 0 To objComboTo.Items.Count - 1
            If CType(objComboTo.Items(i), Player).ID <> CType(objComboFrom.SelectedItem, Player).ID Then
                objComboTo.SelectedItem = objComboTo.Items(i)
                Exit Sub
            End If
        Next
    End Sub

    Private Sub ScootOtherForwards(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbLF.SelectedIndexChanged, cmbRF.SelectedIndexChanged
        If Not mblnLoading Then
            If Me.cmbLF.SelectedIndex = Me.cmbRF.SelectedIndex Then
                mblnLoading = True
                If CType(sender, ComboBox).Name = "cmbLF" Then
                    SetSafeIndex(Me.cmbLF, Me.cmbRF)
                Else
                    SetSafeIndex(Me.cmbRF, Me.cmbLF)
                End If
                mblnLoading = False
            End If
            mblnDirty = True
            Me.btnSave.Enabled = True
        End If
    End Sub

    Private Sub CheckForSave()
        If mblnDirty Then
            If MsgBox("Do you wish to save your changes?", MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton1, "ISM") = MsgBoxResult.Yes Then
                Call Save()
                mblnDirty = False
            End If
        End If
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If mblnDirty Then
            Call Save()
            mblnDirty = False
        End If
    End Sub

    Private Sub cmbMF_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbMF.SelectedIndexChanged
        If Not mblnLoading Then
            mblnDirty = True
            Me.btnSave.Enabled = True
        End If
    End Sub

    Private Sub cmbGK_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbGK.SelectedIndexChanged
        If Not mblnLoading Then
            mblnDirty = True
            Me.btnSave.Enabled = True
        End If
    End Sub

    Private Sub btnAutoCreateAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAutoCreateAll.Click
        Call CreateSubstitutionSets()
    End Sub

    Private Sub CreateSubstitutionSets()
        Dim Roster As New Roster()
        Dim Factory As New SubstitutionLineFactory()
        Dim SubSet As New SubstitutionLineSet()
        Dim TeamID As Integer
        Dim i As Integer

        If MsgBox("Are you sure you wish to recreate the lines for this team?", MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton1, "ISM") = MsgBoxResult.Yes Then
            gs.SetCursor(True, Me)
            TeamID = Me.cmbTeam.TeamID
            Roster.Load(TeamID)

            Factory.ClearSetForTeam(TeamID)
            SubSet = Factory.GenerateLines(Roster)
            SubSet.TeamID = TeamID
            SubSet.Insert()
            gs.SetCursor(False, Me)
            LoadSubline()
        End If
    End Sub
End Class
