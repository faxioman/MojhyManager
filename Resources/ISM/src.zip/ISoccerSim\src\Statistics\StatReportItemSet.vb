'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
'

Imports System.Collections

Namespace Statistics

	Public Enum ISMStatReport
		Goals = 0
		Blocks = 1
		Saves = 2
		ShotsMade = 3
		ShotsAttempted = 4
		Assists = 5
		ShotsAllowed = 6
		GamesPlayedIn = 7
		GameWinningGoal = 8
		ScoringLeaders = 9
		GoalieLeaders = 10

		MPS_3PtShotMade = 100
		MPS_2PtShotMade = 101
		MPS_1PtShotMade = 102
		MPS_3PtShotAllowed = 103
		MPS_2PtShotAllowed = 104
		MPS_1PtShotAllowed = 105
		MPS_ScoringLeaders = 106
		MPS_GoalieLeaders = 107
	End Enum

	Public Class StatReportItemSet
		Inherits CollectionBase

        Dim Sim As Simulation = Simulation.GetInstance()
		Public Sub Add(ByVal objStat As StatReportItem)
			Me.InnerList.Add(objStat)
		End Sub

		Default Public Property Item(ByVal Index As Integer) As StatReportItem
			Get
				Return CType(Me.InnerList.Item(Index), StatReportItem)
			End Get
			Set(ByVal Value As StatReportItem)
				Me.InnerList.Item(Index) = Value
			End Set
		End Property

		Public Sub Create(ByVal ISMStat As ISMStat, ByVal Description As String, ByVal ID As ISMStatReport, ByVal IsBase As Boolean)
			Dim Item As New StatReportItem()
			With Item
				.ISMStat = ISMStat
				.Description = Description
				.ID = ID
				.IsBase = IsBase
			End With
			Me.Add(Item)
		End Sub

		Public Sub Create(ByVal Description As String, ByVal ID As ISMStatReport)
			Dim Item As New StatReportItem()
			With Item
				.ISMStat = 0
				.Description = Description
				.ID = ID
				.IsBase = False
			End With
			Me.Add(Item)
		End Sub

		Public Sub Load()
			Me.Create(ISMStat.Assists, "Assists", ISMStatReport.Assists, True)
			Me.Create(ISMStat.Block, "Blocks", ISMStatReport.Blocks, True)
			Me.Create(ISMStat.GameWinningGoal, "Game Winning Goals", ISMStatReport.GameWinningGoal, True)
			Me.Create(ISMStat.GamesPlayed, "Games Played In", ISMStatReport.GamesPlayedIn, True)
			Me.Create(ISMStat.ShotMade, "Goals", ISMStatReport.Goals, True)
			Me.Create(ISMStat.ShotAllowed, "Goals Allowed", ISMStatReport.ShotsAllowed, True)
			Me.Create(ISMStat.ShotStopped, "Saves", ISMStatReport.Saves, True)
			Me.Create(ISMStat.ShotAttempted, "Shots Attempted", ISMStatReport.ShotsAttempted, True)

			If Sim.League.MultiPoint = True Then
				Me.Create(ISMStat.ShotAllowed1, "1 Pt Shot Allowed", ISMStatReport.MPS_1PtShotAllowed, True)
				Me.Create(ISMStat.ShotAllowed2, "2 Pt Shot Allowed", ISMStatReport.MPS_2PtShotAllowed, True)
				Me.Create(ISMStat.ShotAllowed3, "3 Pt Shot Allowed", ISMStatReport.MPS_3PtShotAllowed, True)
				Me.Create(ISMStat.ShotMade1, "1 Pt Shot Made", ISMStatReport.MPS_1PtShotMade, True)
				Me.Create(ISMStat.ShotMade2, "2 Pt Shot Made", ISMStatReport.MPS_2PtShotMade, True)
				Me.Create(ISMStat.ShotMade3, "3 Pt Shot Made", ISMStatReport.MPS_3PtShotMade, True)
				Me.Create("Leading Scorers", ISMStatReport.MPS_ScoringLeaders)
				Me.Create("Leading Goalkeepers", ISMStatReport.MPS_GoalieLeaders)
			Else
				Me.Create("Leading Scorers", ISMStatReport.ScoringLeaders)
				Me.Create("Leading Goalkeepers", ISMStatReport.GoalieLeaders)
			End If

			Me.InnerList.Sort()

		End Sub

		Public Function GetReportByID(ByVal ReportID As Integer) As StatReportItem
			Dim Item As New StatReportItem()
			For Each Item In Me.InnerList
				If Item.ID = ReportID Then
					Return Item
				End If
			Next
		End Function



	End Class
End Namespace
