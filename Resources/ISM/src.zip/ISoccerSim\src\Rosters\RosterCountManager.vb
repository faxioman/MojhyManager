'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Rosters
    Public Class RosterCountManager
        Public GK As Integer
        Public FW As Integer
        Public MF As Integer
        Public DF As Integer
        Public Roster As New Roster()

        Public Sub Create(ByVal Roster As Roster, ByVal PlayersToAdd As ArrayList, ByVal PlayersToDrop As ArrayList)

            Me.DF = 0
            Me.FW = 0
            Me.GK = 0
            Me.MF = 0
            Me.Roster = Roster

            Me.DF = Roster.GetNumberOfPlayersAtPosition(Positions.ISMPlayerPosition.Defenseman)
            Me.FW = Roster.GetNumberOfPlayersAtPosition(Positions.ISMPlayerPosition.Forward)
            Me.GK = Roster.GetNumberOfPlayersAtPosition(Positions.ISMPlayerPosition.Goalie)
            Me.MF = Roster.GetNumberOfPlayersAtPosition(Positions.ISMPlayerPosition.Midfielder)

            Me.DF = Me.DF + GetPositionCountFromArrayList(Positions.ISMPlayerPosition.Defenseman, PlayersToAdd)
            Me.FW = Me.FW + GetPositionCountFromArrayList(Positions.ISMPlayerPosition.Forward, PlayersToAdd)
            Me.GK = Me.GK + GetPositionCountFromArrayList(Positions.ISMPlayerPosition.Goalie, PlayersToAdd)
            Me.MF = Me.MF + GetPositionCountFromArrayList(Positions.ISMPlayerPosition.Midfielder, PlayersToAdd)

            Me.DF = Me.DF - GetPositionCountFromArrayList(Positions.ISMPlayerPosition.Defenseman, PlayersToDrop)
            Me.FW = Me.FW - GetPositionCountFromArrayList(Positions.ISMPlayerPosition.Forward, PlayersToDrop)
            Me.GK = Me.GK - GetPositionCountFromArrayList(Positions.ISMPlayerPosition.Goalie, PlayersToDrop)
            Me.MF = Me.MF - GetPositionCountFromArrayList(Positions.ISMPlayerPosition.Midfielder, PlayersToDrop)

        End Sub

        Public Function IsRosterMinimumMet() As Boolean
            Console.WriteLine("COUNT " & Me.Roster.Count)
            Return IIf(Me.Roster.Count >= 15, True, False)

        End Function

        Public Function IsPositionMinimumMet()
            If Me.GK >= 1 Then
                If Me.MF >= 1 Then
                    If Me.DF >= 2 Then
                        If Me.FW >= 2 Then
                            Return True
                        End If
                    End If
                End If
            End If
        End Function

        Public Function IsMoveLegal() As Boolean
            Return Me.IsPositionMinimumMet And Me.IsRosterMinimumMet
        End Function

        Private Function GetPositionCountFromArrayList(ByVal Position As Positions.ISMPlayerPosition, ByVal Players As ArrayList) As Integer
            Dim i As Integer
            Dim p As New Players.Player()
            Dim Result As Integer

            For i = 0 To Players.Count - 1
                p.Load(Players(i))

                If p.Position = Position Then
                    Result += 1
                End If
            Next

            Return Result
        End Function
    End Class
End Namespace
