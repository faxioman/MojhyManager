
Public Class ValidationService

    Private Shared myFS As ValidationService

    Public Shared Function GetInstance() As ValidationService
        If myFS Is Nothing Then
            myFS = New ValidationService
        End If
        Return myFS
    End Function

    Function IsStringValid(ByVal strIn As String) As Boolean
        strIn = Trim(strIn)
        If strIn.Length > 0 Then
            Return True
        End If
        Return False
    End Function

    Function IsStringValid(ByVal strIn As String, ByVal lenMin As Integer, ByVal lenMax As Integer) As Boolean
        strIn = Trim(strIn)

        If strIn.Length >= lenMin And strIn.Length < lenMax Then
            Return True
        End If
        Return False
    End Function

    Function IsValidNumericRange(ByVal intLow As Integer, ByVal intHigh As Integer) As Boolean
        If intLow <= intHigh Then
            Return True
        Else
            Return False
        End If
    End Function

    Function IsValidNumericRange(ByVal intLow As Integer, ByVal intHigh As Integer, ByVal intLowRange As Integer, ByVal intHighRange As Integer) As Boolean
        If IsValidNumericRange(intLow, intHigh) Then
            If intLow < intLowRange Or intHigh < intLowRange Then
                Return False
            ElseIf intLow > intHighRange Or intHigh > intHighRange Then
                Return False
            Else
                Return True
            End If
        End If
        Return False
    End Function

    Function Between(ByVal intValue As Integer, ByVal intLow As Integer, ByVal intHigh As Integer)
        If intValue >= intLow And intValue <= intHigh Then
            Return True
        Else
            Return False
        End If

    End Function
End Class
