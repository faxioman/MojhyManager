Namespace Schedules
    Public Class ScheduleMonthItem

        Public ItemData As Date
        Public IsMonth As Boolean
        Public IsPlayoffDate As Boolean

        Function GetMonthText() As String
            If Me.IsMonth Then
                Return Format(Me.ItemData, "MMMM")
            Else
                Return "  " & Format(Me.ItemData, "M/d/yy")
            End If
        End Function

        Public Overrides Function ToString() As String
            If Me.IsMonth Then
                Return Format(Me.ItemData, "MMMM")
            Else
                Return "  " & Format(Me.ItemData, "M/d/yy") & IIf(Me.IsPlayoffDate, "*", "")
            End If
        End Function



    End Class
End Namespace