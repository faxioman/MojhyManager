'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.IO
Imports ISoccerSim.Teams
Imports ISoccerSim.Reporting

Namespace SimEngine.Results
	Public Class GameResultStructure

		Function GetBoxScoreStructure() As ReportTable
			Dim BoxScore As New ReportTable()
			With BoxScore
				.Create("TEAMS", 20, "", False)
				.Create("1", 5, "", False)
				.Create("2", 5, "", False)
				.Create("3", 5, "", False)
				.Create("4", 5, "", False)
				.Create("OT", 5, "", False)
				.Create("FINAL", 6, "", False)
				.Header = ""
			End With
			Return BoxScore
		End Function

		Function GetPlayersInGame(ByVal objTeam As Team) As ReportTable
			Dim PlayersInGame As New ReportTable()
			With PlayersInGame
				.Create("Players In Game", 80, "", False)
				.Header = "<b>" & objTeam.Name & " " & objTeam.Nickname & "</b>"
			End With
			Return PlayersInGame
		End Function

		Function GetUnusedPlayers() As ReportTable
			Return GetGenericWideTable("Substitutions Not Used")
		End Function

		Function GetTeamDataBlock(ByVal objTeam As Team) As ReportTable
			Return GetGenericWideTable(objTeam.Name.ToUpper & " STATS")
		End Function

		Function GetGameDataBlock() As ReportTable
			Return GetGenericWideTable("OTHER GAME DETAILS")
		End Function

		Function GetAssists() As ReportTable
			Return GetGenericWideTable("Assists")
		End Function

		Function GetPlayByPlay() As ReportTable
			Return GetGenericWideTable("Play By Play")
		End Function

		Function GetEventLog() As ReportTable
			Dim objTable As New ReportTable()
			With objTable
				.Create("Time", 10, "", False)
				.Create("Summary", 70, "", False)
			End With
			Return objTable
		End Function

		Private Function GetGenericWideTable(ByVal Title As String) As ReportTable
			Dim objTable As New ReportTable()
			With objTable
				.Create(Title, 80, "", False)
				.Header = ""
			End With
			Return objTable
		End Function

	End Class
End Namespace
