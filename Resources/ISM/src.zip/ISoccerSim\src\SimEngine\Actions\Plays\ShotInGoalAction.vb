'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports Microsoft.VisualBasic
Imports ISoccerSim.SimEngine.Actions
Imports ISoccerSim.Players
Imports ISoccerSim.SimEngine

Namespace SimEngine.Actions.Plays

	Public Class ShotInGoalAction
		Inherits Action

        Dim r As MathService = MathService.GetInstance
		Shadows Sub Execute(ByVal OffPlayer As Player, ByVal DefPlayer As Player)

			If DefPlayer Is Nothing Then
				Me.Result = ISMActionResult.Success
				Exit Sub
			End If

			Dim OffRoll As Integer = GetOffensiveRoll(OffPlayer)
			Dim DefRoll As Integer = GetDefensiveRoll(DefPlayer)
            Dim Adjustment As Integer = DefRoll - OffRoll + r.GetRoll(MathService.ISMRollType.Percentage)
			Dim BaseChanceOfSuccess As Integer = GetBaseChanceOfSuccess()

			If Adjustment < BaseChanceOfSuccess Then
				Me.Result = ISMActionResult.Success
			ElseIf Adjustment > BaseChanceOfSuccess + 5 Then
				Me.Result = ISMActionResult.Failure
			Else
				Me.Result = ISMActionResult.Bizarre
			End If

		End Sub

		'Support methods/functions...

		Private Function GetOffensiveRoll(ByVal pyr As Player) As Integer
			With Me.GameEngine.Settings.Settings
                Dim Rating As Integer = pyr.Ratings(Ratings.ISS_Rating.Shooting)
				Dim Multiplier As Double = .GetValue(Settings.ISM_GameSettingType.ShotInGoal, Settings.ISM_GameSetting.OffensiveRatingMult)
				Dim Adjustment As Double = .GetValue(Settings.ISM_GameSettingType.ShotInGoal, Settings.ISM_GameSetting.OffensiveAdj)

				Return Me.GetRatingRoll(Adjustment, Rating, Multiplier)
			End With
		End Function

		Private Function GetDefensiveRoll(ByVal pyr As Player) As Integer
			If pyr Is Nothing Then
				Return 0
			Else
				With Me.GameEngine.Settings.Settings
                    Dim Rating As Integer = pyr.Ratings(Ratings.ISS_Rating.Goalkeeper)
					Dim Multiplier As Double = .GetValue(Settings.ISM_GameSettingType.ShotInGoal, Settings.ISM_GameSetting.DefensiveRatingMult)
					Dim Adjustment As Double = .GetValue(Settings.ISM_GameSettingType.ShotInGoal, Settings.ISM_GameSetting.DefensiveAdj)

					Return Me.GetRatingRoll(Adjustment, Rating, Multiplier)
				End With
			End If

		End Function

		Private Function GetBaseChanceOfSuccess() As Byte
			With Me.GameEngine.Settings.Settings
				.GetFieldPenalty(Settings.ISM_GameSettingType.ShotInGoal, Me.GameEngine.Ball.Y)
			End With
		End Function

		Sub New(ByVal GameEngine As GameEngine)
			Me.Name = "Shot"
			Me.GameEngine = GameEngine
		End Sub



	End Class


End Namespace


