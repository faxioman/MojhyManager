'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.IO
Imports ISoccerSim.SimEngine
Imports ISoccerSim.Ratings
Imports ISoccerSim.Positions
Imports ISoccerSim.Tactical
Imports ISoccerSim.Players
Imports ISoccerSim.Cities
Imports ISoccerSim.Leagues
Imports ISoccerSim.SimEngine.Results


Public Module General

    Public Const WTD_SATURDAY = 2
    Public Const WTD_WEDNESDAY = 0
    Public Const WTD_FRIDAY = 1
    Public Const WTD_FORMAT = "m/d/yyyy (ddd.)"

    Public Const MONEY_FORMAT = "$#,###,###.00"

    Public Const SE_HOMETEAM = 0
    Public Const SE_AWAYTEAM = 1

    Public Const GAME_STATUS_NOTPLAYED = 0
    Public Const GAME_STATUS_PLAYED = 1
    Public Const GAME_STATUS_NOTNEEDED = -1

    Public Const GAME_PHASE_SEASON = 0
    Public Const GAME_PHASE_PRESEASON = -1
    Public Const GAME_PHASE_PLAYOFF = 1

    Public Class ProgressEventEventArgs
        Inherits System.EventArgs

        Public Message As String
        Public PercentDone As Integer

        Sub New(ByVal strMessage As String, ByVal intPercentDone As Integer)
            Me.Message = strMessage
            Me.PercentDone = intPercentDone
        End Sub
    End Class



    'Sub HandleException(ByVal Sender As Object, ByVal e As Exception)
    '    Try
    '        Throw e
    '    Finally
    '        'Pass
    '    End Try
    'End Sub

    'Sub HandleException(ByVal Sender As Object, ByVal t As ThreadExceptionEventArgs)
    '    Call HandleException(t, t.Exception)
    'End Sub

    ''<STAThread()> _
    ''Sub Main()
    ''    'Add standard error handler
    ''    AddHandler Application.ThreadException, New ThreadExceptionEventHandler(AddressOf HandleException)
    ''    Dim f As New frmAbout
    ''    Dim Sim As Simulation = Simulation.GetInstance()

    ''    f.Show()
    ''    f.Refresh()
    ''    Sim.Load()
    ''    f.Close()
    ''    Application.Run(New frmMain)

    ''End Sub








End Module

