'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.Collections
Imports ISoccerSim.Leagues

Namespace Schedules
	Public Class GamesOnDay
		Inherits CollectionBase

		Public MaxGamesForDate As Integer
		Public GameDate As Date
		Public Threshold As Integer = 10
		Public Fails As Integer

		Public League As League

		Default Property Item(ByVal index As Integer) As Game
			Get
				Return CType(InnerList.Item(index), Game)
			End Get
			Set(ByVal Value As Game)
				InnerList.Item(index) = Value
			End Set
		End Property

		Sub Add(ByVal value As Game)
			InnerList.Add(value)
		End Sub

		Function IsGameValid(ByVal objGame As Game) As Boolean
			If IsTeamIDUsed(objGame.AwayTeamID) Or IsTeamIDUsed(objGame.HomeTeamID) Then
				Me.Fails = Me.Fails + 1
				Return False
			End If
			Return True
		End Function

		Function IsThresholdReached() As Boolean
			If Me.Fails > Me.Threshold Then
				Return True
			End If
			Return False
		End Function

		Private Function IsTeamIDUsed(ByVal intTeamID As Integer) As Boolean
			Dim Game As Game
			For Each Game In Me.InnerList
				If Game.AwayTeamID = intTeamID Or Game.HomeTeamID = intTeamID Then
					Return True
				End If
			Next
			Return False
		End Function

	End Class
End Namespace