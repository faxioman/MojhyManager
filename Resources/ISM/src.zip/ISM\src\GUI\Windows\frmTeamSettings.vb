
'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Positions
Imports ISoccerSim.Teams
Imports ISoccerSim.Utility.GUI

Public Class frmTeamSettings
	Inherits System.Windows.Forms.Form

	Private mblnLoading As Boolean
	Private mblnDirty As Boolean
	Private mintPlayerID As Integer
    Dim Sim As Simulation = Simulation.GetInstance()
    Dim gs As GUIService = GuiService.GetInstance
#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
        Call SetScreen()


	End Sub

	Public Sub SetScreen(ByVal objTeam As Team)
        Me.cmbTeam.LoadTeams(objTeam.TeamID)
        ' Me.cmbTeam.Enabled = False


	End Sub

	Public Sub SetScreen(ByVal objTeam As Team, ByVal intSquad As ISMPlayerPosition)
		Call SetScreen(objTeam)
        Me.cmbTeam.Enabled = False
	End Sub

	
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Public WithEvents grpFinish As System.Windows.Forms.GroupBox
	Public WithEvents tipLeague As System.Windows.Forms.ToolTip
	Public WithEvents btnOK As System.Windows.Forms.Button
	Public WithEvents Label3 As System.Windows.Forms.Label
    Public WithEvents txtName As System.Windows.Forms.TextBox
    Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents Label9 As System.Windows.Forms.Label
	Public WithEvents btnSave As System.Windows.Forms.Button
	Public WithEvents cmbControl As System.Windows.Forms.ComboBox
	Public WithEvents txtOwnerEmail As System.Windows.Forms.TextBox
	Public WithEvents txtOwnerName As System.Windows.Forms.TextBox
	Public WithEvents txtMascot As System.Windows.Forms.TextBox
	Public WithEvents txtAbbr As System.Windows.Forms.TextBox
	Public WithEvents txtNickname As System.Windows.Forms.TextBox
	Public WithEvents cmbCity As System.Windows.Forms.ComboBox
    Public WithEvents cmbTeam As TeamCombo
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.btnOK = New System.Windows.Forms.Button
        Me.grpFinish = New System.Windows.Forms.GroupBox
        Me.cmbControl = New System.Windows.Forms.ComboBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtOwnerEmail = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtOwnerName = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtMascot = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtAbbr = New System.Windows.Forms.TextBox
        Me.cmbCity = New System.Windows.Forms.ComboBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtNickname = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtName = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.tipLeague = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnSave = New System.Windows.Forms.Button
        Me.cmbTeam = New TeamCombo
        Me.grpFinish.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnOK
        '
        Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnOK.Location = New System.Drawing.Point(264, 280)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(112, 24)
        Me.btnOK.TabIndex = 1
        Me.btnOK.Text = "&OK"
        '
        'grpFinish
        '
        Me.grpFinish.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.grpFinish.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmbTeam, Me.cmbControl, Me.Label9, Me.Label8, Me.txtOwnerEmail, Me.Label7, Me.txtOwnerName, Me.Label6, Me.txtMascot, Me.Label5, Me.txtAbbr, Me.cmbCity, Me.Label4, Me.Label2, Me.txtNickname, Me.Label1, Me.txtName, Me.Label3})
        Me.grpFinish.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpFinish.Location = New System.Drawing.Point(8, 8)
        Me.grpFinish.Name = "grpFinish"
        Me.grpFinish.Size = New System.Drawing.Size(368, 264)
        Me.grpFinish.TabIndex = 11
        Me.grpFinish.TabStop = False
        Me.grpFinish.Text = "Settings"
        '
        'cmbControl
        '
        Me.cmbControl.Items.AddRange(New Object() {"Human", "Computer"})
        Me.cmbControl.Location = New System.Drawing.Point(104, 232)
        Me.cmbControl.Name = "cmbControl"
        Me.cmbControl.Size = New System.Drawing.Size(80, 22)
        Me.cmbControl.TabIndex = 8
        Me.cmbControl.Text = "Computer"
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(16, 232)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(80, 16)
        Me.Label9.TabIndex = 28
        Me.Label9.Text = "Controlled By:"
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(16, 200)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(80, 16)
        Me.Label8.TabIndex = 27
        Me.Label8.Text = "Owner Email:"
        '
        'txtOwnerEmail
        '
        Me.txtOwnerEmail.Location = New System.Drawing.Point(104, 200)
        Me.txtOwnerEmail.Name = "txtOwnerEmail"
        Me.txtOwnerEmail.Size = New System.Drawing.Size(208, 20)
        Me.txtOwnerEmail.TabIndex = 7
        Me.txtOwnerEmail.Text = ""
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(16, 176)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(80, 16)
        Me.Label7.TabIndex = 25
        Me.Label7.Text = "Owner Name:"
        '
        'txtOwnerName
        '
        Me.txtOwnerName.Location = New System.Drawing.Point(104, 176)
        Me.txtOwnerName.Name = "txtOwnerName"
        Me.txtOwnerName.Size = New System.Drawing.Size(208, 20)
        Me.txtOwnerName.TabIndex = 6
        Me.txtOwnerName.Text = ""
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(16, 144)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(72, 16)
        Me.Label6.TabIndex = 23
        Me.Label6.Text = "Mascot:"
        '
        'txtMascot
        '
        Me.txtMascot.Location = New System.Drawing.Point(104, 144)
        Me.txtMascot.Name = "txtMascot"
        Me.txtMascot.Size = New System.Drawing.Size(208, 20)
        Me.txtMascot.TabIndex = 5
        Me.txtMascot.Text = ""
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(16, 120)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 16)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Abbr.:"
        '
        'txtAbbr
        '
        Me.txtAbbr.Location = New System.Drawing.Point(104, 120)
        Me.txtAbbr.Name = "txtAbbr"
        Me.txtAbbr.Size = New System.Drawing.Size(48, 20)
        Me.txtAbbr.TabIndex = 4
        Me.txtAbbr.Text = ""
        '
        'cmbCity
        '
        Me.cmbCity.Location = New System.Drawing.Point(104, 48)
        Me.cmbCity.Name = "cmbCity"
        Me.cmbCity.Size = New System.Drawing.Size(208, 22)
        Me.cmbCity.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(16, 48)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 24)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "City:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 96)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 16)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Nickname:"
        '
        'txtNickname
        '
        Me.txtNickname.Location = New System.Drawing.Point(104, 96)
        Me.txtNickname.Name = "txtNickname"
        Me.txtNickname.Size = New System.Drawing.Size(208, 20)
        Me.txtNickname.TabIndex = 3
        Me.txtNickname.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 16)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "Name:"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(104, 72)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(208, 20)
        Me.txtName.TabIndex = 2
        Me.txtName.Text = ""
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 24)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Team:"
        '
        'btnSave
        '
        Me.btnSave.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnSave.Location = New System.Drawing.Point(144, 280)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(112, 24)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "&Save"
        '
        'cmbTeam
        '
        Me.cmbTeam.Location = New System.Drawing.Point(104, 16)
        Me.cmbTeam.Name = "cmbTeam"
        Me.cmbTeam.Size = New System.Drawing.Size(256, 24)
        Me.cmbTeam.TabIndex = 29
        '
        'frmTeamSettings
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(382, 315)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnSave, Me.btnOK, Me.grpFinish})
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "frmTeamSettings"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Team Settings"
        Me.grpFinish.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		Me.Close()
	End Sub

#Region "CustomSetup"

	Private Sub SetScreen()
		Call InitializeDefaults()
        Call gs.SetCursor(Me)
        Call Me.cmbTeam.LoadTeams()
        gs.SkinForm(Me)

	End Sub

	Private Sub InitializeDefaults()
		mblnLoading = True

        Dim ComboHelperCity As New DropDownUtility()
        With ComboHelperCity
            .DisplayMember = "City"
            .ValueMember = "City"
            .DataSource = Sim.Cities
            .Style = ComboBoxStyle.DropDownList    'DropDown
            .Sorted = True
            .Fill(Me.cmbCity)
        End With

        Me.btnSave.Enabled = False
        Call SetModifications()
        mblnLoading = False
	End Sub

	Private Sub SetModifications()
		Dim pblnEnabled As Boolean
		Select Case Sim.League.Phase
			Case Leagues.ISSLeaguePhase.NewLeagueRegular, Leagues.ISSLeaguePhase.NewLeagueFreeAgency
				pblnEnabled = True
			Case Else
				pblnEnabled = False
		End Select
		pblnEnabled = True

		Me.cmbCity.Enabled = pblnEnabled
		Me.txtName.Enabled = pblnEnabled
		Me.txtNickname.Enabled = pblnEnabled
		Me.txtAbbr.Enabled = pblnEnabled
	End Sub

	Private Sub LoadTeam(ByVal objTeam As Team)
		With objTeam
			Me.txtAbbr.Text = .Abbreviation
			Me.txtMascot.Text = .Mascot
			Me.txtName.Text = .Name
			Me.txtNickname.Text = .Nickname
			Me.txtOwnerEmail.Text = .OwnerEmail
			Me.txtOwnerName.Text = .OwnerName
            Me.cmbCity.Text = Sim.Cities.GetCityByID(.CityID).City
			If .IsCPUOwned Then
				Me.cmbControl.Text = "Computer"
			Else
				Me.cmbControl.Text = "Human"
			End If
			mblnDirty = False
			Me.btnSave.Enabled = False
		End With
	End Sub
#End Region

    Private Sub cmbTeams_SelectedIndexChanged(ByVal sender As Object, ByVal e As TeamSelectedEventArgs) Handles cmbTeam.SelectionChanged
        If Not mblnLoading Then
            Call LoadTeam(Sim.League.GetTeamByID(e.TeamID))
        End If
    End Sub


    Private Sub DirtyText(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtAbbr.TextChanged, txtMascot.TextChanged, txtName.TextChanged, txtNickname.TextChanged, txtOwnerEmail.TextChanged, txtOwnerName.TextChanged
        If Not mblnLoading Then
            mblnDirty = True
            Me.btnSave.Enabled = True
        End If
    End Sub

    Private Sub DirtyCombo(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbCity.SelectedIndexChanged, cmbControl.SelectedIndexChanged
        If Not mblnLoading Then
            mblnDirty = True
            Me.btnSave.Enabled = True
        End If
    End Sub

    Private Sub Save()

        Dim Team As Team = Me.cmbTeam.SelectedTeam
        With Team
            .Abbreviation = Me.txtAbbr.Text
            .CityID = CType(Me.cmbCity.SelectedItem, Cities.City).CityID
            .Nickname = Me.txtNickname.Text
            .Name = Me.txtName.Text
            .Logo = ""    'Change later
            .Mascot = Me.txtMascot.Text
            .OwnerEmail = Me.txtOwnerEmail.Text
            .OwnerName = Me.txtOwnerName.Text
            .IsCPUOwned = IIf(Me.cmbControl.Text = "Computer", True, False)
            .UpdateSettingsOnly()
            InitializeDefaults()
        End With
        Me.cmbTeam.Text = Team.ToString
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Call Save()
    End Sub
End Class
