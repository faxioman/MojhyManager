'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Ratings
    Public Class RatingDistributionSet
        Inherits System.Collections.CollectionBase

        Public Total As Double

        Default Property Item(ByVal index As Integer) As RatingDistribution
            Get
                Return CType(InnerList.Item(index), RatingDistribution)
            End Get
            Set(ByVal Value As RatingDistribution)
                InnerList.Item(index) = Value
            End Set
        End Property

        Sub Add(ByVal value As RatingDistribution)
            InnerList.Add(value)
        End Sub

        Sub Create(ByVal RatingDistributionID As Integer, ByVal Maximum As Integer, ByVal Minimum As Integer, ByVal Mean As Double, _
          ByVal PositionID As Integer, ByVal RatingID As Integer, ByVal StandardDeviation As Double)
            Dim Item As New RatingDistribution()
            With Item
                .RatingDistributionID = RatingDistributionID
                .Maximum = Maximum
                .Mean = Mean
                .Minimum = Minimum
                .PositionID = PositionID
                .RatingID = RatingID
                .StandardDeviation = StandardDeviation
                Me.Total = Me.Total + 1
            End With

            InnerList.Add(Item)
        End Sub

        Sub Load()
            Dim mBaseTable As New DataServices.BaseTables()
            Dim DR As OleDb.OleDbDataReader = mBaseTable.GetRatingDistribution

            Me.Clear()
            Me.Total = 0

            With DR
                Do While .Read()
                    Me.Create(.Item("RatingDistID"), .Item("Max"), .Item("Min"), _
                     .Item("Mean"), .Item("PositionID"), .Item("RatingID"), .Item("StdDev"))
                Loop
            End With
            DR.Close()

        End Sub

        Function GetRatingDistribution(ByVal PositionID As Integer, ByVal RatingID As Integer) As RatingDistribution
            Dim RateDist As New RatingDistribution()
            Dim RateDistOut As New RatingDistribution()

            For Each RateDist In InnerList
                With RateDist
                    If .PositionID = 0 And .RatingID = RatingID Then
                        RateDistOut = RateDist
                    ElseIf .PositionID = PositionID And .RatingID = RatingID Then
                        Return RateDist
                        Exit Function
                    End If
                End With
            Next

            Return RateDistOut

        End Function
    End Class
End Namespace