Imports System.IO

Public Class GUIService
    Private Shared myGUI As GUIService

    Public Shared Function GetInstance() As GUIService
        If myGUI Is Nothing Then
            myGUI = New GUIService()
        End If
        Return myGUI
    End Function

    Sub SetCursor(ByVal ShowBusy As Boolean, ByVal ParentForm As Form)
        If ShowBusy Then
            ParentForm.Cursor = Windows.Forms.Cursors.WaitCursor
        Else
            ParentForm.Cursor = Windows.Forms.Cursors.Default
        End If
    End Sub

    Sub SetCursor(ByVal ParentForm As Form)
        ParentForm.Cursor = Windows.Forms.Cursors.Default
    End Sub

    Private Sub SetImage(ByVal f As Form)
        Dim Name As String = Mid(f.Name.Trim, 4)
        Dim Sim As Simulation = Simulation.GetInstance
        Dim fs As FileService = FileService.GetInstance

        Dim FileImage As String
        If Sim.Skin.Pictures.ContainsKey(Name) Then
            FileImage = Sim.Skin.Pictures.Item(Name)
        Else
            FileImage = "default.png"
        End If

        FileImage = fs.GetSkinDirectory() & FileImage

        If File.Exists(FileImage) Then
            f.SuspendLayout()
            f.BackgroundImage = Image.FromFile(FileImage)
            f.ResumeLayout()
        End If

    End Sub



    Sub SkinForm(ByVal f As Form)

        Call SetImage(f)
        Dim Sim As Simulation = Simulation.GetInstance
        With Sim.Skin
            f.BackColor = .FormBackgroundColor
            f.ForeColor = .FormFontColor

            Dim Control As Control
            For Each Control In f.Controls
                If TypeOf Control Is GroupBox Then
                    Control.ForeColor = .FormFrameColor
                    Control.BackColor = .FormBackgroundColor

                    Dim ChildControl As Control
                    For Each ChildControl In Control.Controls
                        If TypeOf ChildControl Is DataGrid Then
                            Dim Grid As DataGrid = CType(ChildControl, DataGrid)
                            Grid.BackColor = .GridBackgroundColor
                            Grid.HeaderForeColor = .GridHeadingColor
                            Grid.CaptionBackColor = .GridCaptionColor
                            Grid.CaptionForeColor = .GridCaptionFontColor
                            Grid.ForeColor = .GridFontColor
                        End If

                        If (TypeOf ChildControl Is ComboBox) Or _
                         (TypeOf ChildControl Is ListBox) Or _
                         (TypeOf ChildControl Is TextBox) Or _
                         (TypeOf ChildControl Is TreeView) Then
                            ChildControl.BackColor = .InputBackColor
                            ChildControl.ForeColor = .InputFontColor
                        End If

                    Next
                End If

                If TypeOf Control Is DataGrid Then
                    Dim Grid As DataGrid = CType(Control, DataGrid)
                    Grid.BackColor = .GridBackgroundColor
                    Grid.HeaderForeColor = .GridHeadingColor
                    Grid.CaptionBackColor = .GridCaptionColor
                    Grid.CaptionForeColor = .GridCaptionFontColor
                    Grid.ForeColor = .GridFontColor
                End If


            Next
        End With
    End Sub
End Class
