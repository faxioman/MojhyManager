'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.IO
Imports ISoccerSim.Teams
Imports ISoccerSim.Reporting
Imports ISoccerSim.SimEngine.PlayByPlay

Namespace SimEngine.Results
	Public Class GameResultService
		Public GameEngine As GameEngine
		Dim [Structure] As New GameResultStructure()
		Dim Data As New GameResultDataService()
        Dim Sim As Simulation = Simulation.GetInstance()
        Dim fs As FileService = FileService.GetInstance()

		Private Sub CreateEventLog()
			Dim Report As New Report()
			Dim EventLog As ReportTable = Me.Structure.GetEventLog()

			Report.Subheader = "EVENT LOG"
			Report.Header = Me.GameEngine.AwayTeam.ToString & " at " & Me.GameEngine.HomeTeam.ToString

			Dim EventLogData As New ReportData()
			Dim Item As GameSummaryItem
			For Each Item In Me.GameEngine.GameSummary
                With EventLogData
                    .Fill(Item.ToArrayList)
                End With
            Next
			EventLog.Data = EventLogData

			Report.Add(EventLog)

			'Generate...
			Report.Generate()
			If Me.GameEngine.ScheduleID = 0 Then
                Me.Save(Report, fs.GetTempGameEventLogFilePath(Sim.League.Name))
			Else
                Me.Save(Report, fs.GetScheduledEventLogFileName(Sim.League.Name, (Me.GameEngine.ScheduleID)))
			End If


		End Sub

		Private Sub CreateBoxScore()
			Dim Report As New Report()
			Dim BoxScore As ReportTable = Me.Structure.GetBoxScoreStructure()
			Dim AwayTeamStats As ReportTable = Me.Structure.GetTeamDataBlock(Me.GameEngine.AwayTeam)
			Dim HomeTeamStats As ReportTable = Me.Structure.GetTeamDataBlock(Me.GameEngine.HomeTeam)
			Dim GameStats As ReportTable = Me.Structure.GetGameDataBlock()
			Dim Delimiter As New Reporting.ArrayListDelimiter()

			Report.Subheader = "BOX SCORE"
			Report.Header = Me.GameEngine.AwayTeam.ToString & " at " & Me.GameEngine.HomeTeam.ToString

			'Add box score....
			Dim BoxScoreData As New ReportData()
			With BoxScoreData
				.Fill(Me.Data.GetBoxScoreArray(Me.GameEngine.AwayTeam))
				.Fill(Me.Data.GetBoxScoreArray(Me.GameEngine.HomeTeam))
			End With
			BoxScore.Data = BoxScoreData

			'AWAY TEAM DATA

			'Add shots made for away team...
			Dim AwayTeamData As New ReportData()
			With AwayTeamData
				If Sim.League.MultiPoint Then
					.Fill(Delimiter.ArrayListToCommas("POINTS", Me.Data.GetPointsMade(Me.GameEngine.AwayTeam), True))
				End If
				.Fill(Delimiter.ArrayListToCommas("GOALS", Me.Data.GetShotsMade(Me.GameEngine.AwayTeam), True))
				.Fill(Delimiter.ArrayListToCommas("SHOTS ATTEMPTED", Me.Data.GetShotsAttempted(Me.GameEngine.AwayTeam), True))
				.Fill(Delimiter.ArrayListToCommas("ASSISTS", Me.Data.GetAssists(Me.GameEngine.AwayTeam), True))
				.Fill(Delimiter.ArrayListToCommas("SAVES", Me.Data.GetSaves(Me.GameEngine.AwayTeam), True))
				.Fill(Delimiter.ArrayListToCommas("BLOCKS", Me.Data.GetBlocks(Me.GameEngine.AwayTeam), True))
                .Fill(Delimiter.ArrayListToCommas("FOULS", Me.Data.GetFouls(Me.GameEngine.AwayTeam), True))
                .Fill(Delimiter.ArrayListToCommas("PENALTY MINUTES", Me.Data.GetPenaltyMinutes(Me.GameEngine.AwayTeam), True))
                .Fill(Delimiter.ArrayListToCommas("POWER PLAY GOALS", Me.Data.GetPowerPlayGoals(Me.GameEngine.AwayTeam), True))
                .Fill(Delimiter.ArrayListToCommas("SHORTHANDED GOALS", Me.Data.GetPenaltyKillGoals(Me.GameEngine.AwayTeam), True))
				.Fill(Delimiter.ArrayListToCommas("PLAYERS IN GAME", Me.Data.GetPlayerArray(Me.GameEngine.AwayTeam), False))
				.Fill(Delimiter.ArrayListToCommas("UNUSED PLAYERS", Me.Data.GetUnusedPlayers(Me.GameEngine.AwayTeam), False))

			End With
			AwayTeamStats.Data = AwayTeamData


			''''''''''''''''''''
			'Home TEAM DATA
			''''''''''''''''''''

			'Add stats...
			Dim HomeTeamData As New ReportData()
			With HomeTeamData
				If Sim.League.MultiPoint Then
					.Fill(Delimiter.ArrayListToCommas("POINTS", Me.Data.GetPointsMade(Me.GameEngine.HomeTeam), True))
				End If
				.Fill(Delimiter.ArrayListToCommas("GOALS", Me.Data.GetShotsMade(Me.GameEngine.HomeTeam), True))
				.Fill(Delimiter.ArrayListToCommas("SHOTS ATTEMPTED", Me.Data.GetShotsAttempted(Me.GameEngine.HomeTeam), True))
				.Fill(Delimiter.ArrayListToCommas("ASSISTS", Me.Data.GetAssists(Me.GameEngine.HomeTeam), True))
				.Fill(Delimiter.ArrayListToCommas("SAVES", Me.Data.GetSaves(Me.GameEngine.HomeTeam), True))
				.Fill(Delimiter.ArrayListToCommas("BLOCKS", Me.Data.GetBlocks(Me.GameEngine.HomeTeam), True))
                .Fill(Delimiter.ArrayListToCommas("FOULS", Me.Data.GetFouls(Me.GameEngine.HomeTeam), True))
                .Fill(Delimiter.ArrayListToCommas("PENALTY MINUTES", Me.Data.GetPenaltyMinutes(Me.GameEngine.HomeTeam), True))
                .Fill(Delimiter.ArrayListToCommas("POWER PLAY GOALS", Me.Data.GetPowerPlayGoals(Me.GameEngine.HomeTeam), True))
                .Fill(Delimiter.ArrayListToCommas("SHORTHANDED GOALS", Me.Data.GetPenaltyKillGoals(Me.GameEngine.HomeTeam), True))
				.Fill(Delimiter.ArrayListToCommas("PLAYERS IN GAME", Me.Data.GetPlayerArray(Me.GameEngine.HomeTeam), False))
				.Fill(Delimiter.ArrayListToCommas("UNUSED PLAYERS", Me.Data.GetUnusedPlayers(Me.GameEngine.HomeTeam), False))
			End With
			HomeTeamStats.Data = HomeTeamData

			'''''''''''''''''''''''
			' GENERIC DATA 
			'''''''''''''''''''''''

            Dim GameData As New ReportData()
            Dim f As New Cities.Facility()
            f.Load(Me.GameEngine.HomeTeam.FacilityID)

            With GameData
                Delimiter.Delimiter = ";"
                .Fill(Delimiter.ArrayListToCommas("OFFICIALS", Me.Data.GetReferees(Me.GameEngine.Referees), True))
                .Fill("<B>ATTENDANCE:</B>" & Format(Me.GameEngine.Attendance, "#,000") & " - (" & Format(Me.GameEngine.Attendance / f.Capacity, "###.00%") & ")")
            End With
            GameStats.Data = GameData


            ''''''''''''''''''
            'Build tables...
            ''''''''''''''''''

            Report.Add(BoxScore)
            Report.Add(AwayTeamStats)
            Report.Add(HomeTeamStats)
            Report.Add(GameStats)

            'Generate...
            Report.Generate()
            If Me.GameEngine.ScheduleID = 0 Then
                Me.Save(Report, fs.GetTempBoxScoreFilePath(Sim.League.Name))
            Else
                Me.Save(Report, fs.GetScheduledGameBoxFileName(Sim.League.Name, (Me.GameEngine.ScheduleID)))
            End If
		End Sub



		Private Sub CreatePlayByPlay()
			Dim Report As New Report()
			Dim GamePlay As ReportTable = Me.Structure.GetPlayByPlay

			Report.Subheader = "PLAY BY PLAY"
			Report.Header = Me.GameEngine.AwayTeam.ToString & " at " & Me.GameEngine.HomeTeam.ToString

			Dim GamePlayData As New ReportData()
			With GamePlayData
				.FillRange(Me.Data.GetPlayByPlay(Me.GameEngine.GameLog))
			End With
			GamePlay.Data = GamePlayData
			Report.Add(GamePlay)

			'Generate...
			Report.Generate()
            If Me.GameEngine.ScheduleID = 0 Then
                Report.Save(fs.GetTempGameLogFilePath(Sim.League.Name))
            Else
                Report.Save(fs.GetScheduledPBPFileName(Sim.League.Name, Me.GameEngine.ScheduleID))
            End If

		End Sub

        Sub Create()
            If Me.Sim.UserSettings.SaveBoxScore Then CreateBoxScore()
            If Me.Sim.UserSettings.SavePlayByPlay Then CreatePlayByPlay()
            If Me.Sim.UserSettings.SaveEventLog Then Call CreateEventLog()
        End Sub


        Sub Save(ByVal Report As Report, ByVal Path As String)
            Dim Writer As StreamWriter = File.CreateText(Path)
            Writer.Write(Report.Output)
            Writer.Close()
        End Sub

    End Class
End Namespace