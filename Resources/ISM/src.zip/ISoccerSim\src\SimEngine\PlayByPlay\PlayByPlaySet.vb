'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Players

Namespace SimEngine.PlayByPlay
	Public Class PlayByPlaySet
		Inherits CollectionBase

		Public GameEngine As GameEngine

		Public PlayerPassTo As Player
		Public BallHandler As Player
		Public Defender As Player
		Public Goalie As Player
        Public ActivePlayer As Player
        Public Penalty As Penalty.Penalty
        Public PenaltyPlayer As Player

        Dim r As MathService = MathService.GetInstance

        Sub Add(ByVal objItem As PlayByPlay)
            Me.InnerList.Add(objItem)
        End Sub

        Default Public Property Item(ByVal Index As ISM_PBPSituation) As PlayByPlay
            Get
                Return CType(Me.InnerList.Item(Index), PlayByPlay)
            End Get
            Set(ByVal Value As PlayByPlay)
                Me.InnerList.Item(Index) = Value
            End Set
        End Property

        Sub Create(ByVal Name As String, ByVal Abbreviation As String, ByVal PlayByPlayID As Integer)
            Dim Item As New PlayByPlay()
            With Item
                .Name = Name
                .Abbreviation = Abbreviation
                .PlayByPlayID = PlayByPlayID
            End With
            Me.Add(Item)
        End Sub

        Sub Sort()
            Me.InnerList.Sort()
        End Sub

        Sub Load()
            Dim Data As New DataServices.BaseTables()
            Dim DR As OleDb.OleDbDataReader = Data.GetPlayByPlay()

            'Create '0' entry first...
            Me.Create("None", "None", 0)

            Do While DR.Read()
                Me.Create(DR.Item("Situation"), DR.Item("Situation"), DR.Item("PlayByPLayID"))
            Loop
            DR.Close()

            Dim Item As PlayByPlay
            For Each Item In Me.InnerList
                Item.Load()
            Next
        End Sub

        Sub SetPlayers(ByVal ActivePlayer As Player, ByVal BallHandler As Player, ByVal Defender As Player, ByVal Goalie As Player, ByVal PlayerPassTo As Player)
            With Me
                .ActivePlayer = ActivePlayer
                .BallHandler = BallHandler
                .Defender = Defender
                .Goalie = Goalie
                .PlayerPassTo = PlayerPassTo
            End With
        End Sub

        Function Narrate(ByVal index As ISM_PBPSituation) As String
            Dim Item As PlayByPlay
            Item = Me.InnerList(index)
            Me.GameEngine.GameSummary.Narrate(index)

            Return Me.Process(Item.GetNarrative, index)
        End Function


        Private Function Process(ByVal strNarrative As String, ByVal Situation As ISM_PBPSituation) As String
            Dim Temp As String = strNarrative
            With Me.GameEngine

                If Situation = PlayByPlaySupport.ISM_PBPSituation.Penalty Then
                    Temp = GetStandardPenaltyText()
                ElseIf Temp.IndexOf("%") = -1 Then
                    Return Temp
                End If

                'Teams...
                Temp = Replace(Temp, PBP_HOMETEAMCITY, .HomeTeam.Name)
                Temp = Replace(Temp, PBP_HOMETEAMNICKNAME, .HomeTeam.Nickname)
                Temp = Replace(Temp, PBP_ARENA, .HomeTeam.FacilityName)
                Temp = Replace(Temp, PBP_HOMETEAMCOACH, .HomeTeam.OwnerName)

                Temp = Replace(Temp, PBP_AWAYTEAMCITY, .AwayTeam.Name)
                Temp = Replace(Temp, PBP_AWAYTEAMNICKNAME, .AwayTeam.Nickname)
                Temp = Replace(Temp, PBP_AWAYTEAMCOACH, .AwayTeam.OwnerName)

                Temp = Replace(Temp, PBP_OFFTEAM, .Posession.Offense.Name)
                Temp = Replace(Temp, PBP_DEFTEAM, .Posession.Defense.Name)

                'Players...
                If Not (Me.PlayerPassTo Is Nothing) Then
                    Temp = Replace(Temp, PBP_PASSTO, Me.PlayerPassTo.ShortName)
                    Temp = Replace(Temp, PBP_PASSTO_FULL, Me.PlayerPassTo.DisplayName)
                End If

                If Not (Me.BallHandler Is Nothing) Then
                    Temp = Replace(Temp, PBP_PASSTO, Me.BallHandler.ShortName)
                    Temp = Replace(Temp, PBP_PASSTO_FULL, Me.BallHandler.DisplayName)
                End If

                If Not (Me.Defender Is Nothing) Then
                    Temp = Replace(Temp, PBP_DEFENDER, Me.Defender.ShortName)
                    Temp = Replace(Temp, PBP_DEFENDER_FULL, Me.Defender.DisplayName)
                End If

                If Not (Me.Goalie Is Nothing) Then
                    Temp = Replace(Temp, PBP_GOALIE, Me.Goalie.ShortName)
                    Temp = Replace(Temp, PBP_GOALIE_FULL, Me.Goalie.DisplayName)
                End If

                If Not (Me.ActivePlayer Is Nothing) Then
                    Temp = Replace(Temp, PBP_BALLHANDLER, Me.ActivePlayer.ShortName)
                    Temp = Replace(Temp, PBP_BALLHANDLER_FULL, Me.ActivePlayer.DisplayName)
                End If

                'Score, clock, game position...
                Temp = Replace(Temp, PBP_HOMETEAMSCORE, .HomeTeam.Scoreboard.Score)
                Temp = Replace(Temp, PBP_AWAYTEAMSCORE, .AwayTeam.Scoreboard.Score)
                Temp = Replace(Temp, PBP_QUARTER, .Clock.Quarter)
                Temp = Replace(Temp, PBP_MINUTES, .Clock.Time.Minute)
                Temp = Replace(Temp, PBP_SECONDS, .Clock.Time.Second)
                Temp = Replace(Temp, PBP_TIME, Format(.Clock.Time.Minute, "00") & ":" & Format(.Clock.Time.Second, "00") & ", " & .Clock.GetOrdinal)
                Temp = Replace(Temp, PBP_POSITION, .Ball.GetPosition)

                'Shot position
                Select Case Situation
                    Case PlayByPlaySupport.ISM_PBPSituation.MissedShotOnGoal
                        Temp = Temp & "  Result: " & Me.GameEngine.Ball.GetOnTargetText & "."
                    Case PlayByPlaySupport.ISM_PBPSituation.CoolGoalieStop, PlayByPlaySupport.ISM_PBPSituation.GoalieStopOnGoal
                        Temp = Temp & "  Result: Goalie punch/catch."
                    Case PlayByPlaySupport.ISM_PBPSituation.RegularGoal
                        Temp = Temp & "  Result: Score."
                End Select


                Debug.Assert(Temp.IndexOf("%") = -1, "Missed something.")

            End With
            Return Temp
        End Function

        Private Function GetStandardPenaltyText() As String
            Dim Out As String = "Penalty: " & Me.Penalty.Name & " - " & Me.PenaltyPlayer.DisplayName
            Select Case Me.Penalty.Severity
                Case ISoccerSim.SimEngine.Penalty.ISM_CardThrown.Red
                    Out &= "  Red card issued."
                Case ISoccerSim.SimEngine.Penalty.ISM_CardThrown.Blue
                    Out &= "  Blue card issued."
                Case ISoccerSim.SimEngine.Penalty.ISM_CardThrown.Yellow
                    Out &= "  Yellow card issued."
                Case ISoccerSim.SimEngine.Penalty.ISM_CardThrown.Regular
                    'Pass...
            End Select

            Out &= "  " & r.GetOrdinal(Me.PenaltyPlayer.FoulsPerHalf) & " foul in half."
            Return Out

        End Function

    End Class
End Namespace