'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Ratings
    Public Class RatingDistribution
        Public RatingDistributionID As Integer
        Public RatingID As Integer
        Public PositionID As Integer
        Public Mean As Double
        Public StandardDeviation As Double
        Public Minimum As Integer
        Public Maximum As Integer

        Private mobjGauss As New GaussService

        Function GetRating() As Byte
            With mobjGauss
                .Max = Me.Maximum
                .Min = Me.Minimum
                .Mean = Me.Mean
                .StdDev = Me.StandardDeviation

                Return .GetNextInt
            End With
        End Function

        Function GetRatingGrade(ByVal Value As Integer) As String
            Dim Result As String
            If Value < Me.Mean Then
                If Value <= Me.Mean - Me.StandardDeviation Then
                    Result = "F"
                ElseIf Value <= Me.Mean - (Me.StandardDeviation * 0.8) Then
                    Result = "D-"
                ElseIf Value <= Me.Mean - (Me.StandardDeviation * 0.2) Then
                    Result = "D"
                Else
                    Result = "D+"
                End If
            Else
                If Value <= Me.Mean + (Me.StandardDeviation * 0.2) Then
                    Result = "C-"
                ElseIf Value <= Me.Mean + (Me.StandardDeviation * 0.8) Then
                    Result = "C"
                ElseIf Value <= Me.Mean + (Me.StandardDeviation * 1.0) Then
                    Result = "C+"
                ElseIf Value <= Me.Mean + (Me.StandardDeviation * 1.2) Then
                    Result = "B+"
                ElseIf Value <= Me.Mean + (Me.StandardDeviation * 1.8) Then
                    Result = "B"
                ElseIf Value <= Me.Mean + (Me.StandardDeviation * 2.0) Then
                    Result = "B+"
                ElseIf Value <= Me.Mean + (Me.StandardDeviation * 2.2) Then
                    Result = "A-"
                ElseIf Value <= Me.Mean + (Me.StandardDeviation * 2.8) Then
                    Result = "A"
                ElseIf Value <= Me.Mean + (Me.StandardDeviation * 3.0) Then
                    Result = "A"
                Else
                    Result = "A+"
                End If
            End If
            Return Result
        End Function
    End Class
End Namespace