'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Utility.DataGrid


Public Class PlayerPicker
    Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Public WithEvents dgRoster As System.Windows.Forms.DataGrid
    Public WithEvents popRoster As System.Windows.Forms.ContextMenu
    Public WithEvents mnuGridShowDetails As System.Windows.Forms.MenuItem
    Public WithEvents mnuGridDrop As System.Windows.Forms.MenuItem
    Public WithEvents popFA As System.Windows.Forms.ContextMenu
    Public WithEvents mnuFAShowPlayer As System.Windows.Forms.MenuItem
    Public WithEvents mnuFASign As System.Windows.Forms.MenuItem
    Public WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Public WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Public WithEvents popPickPlayer As System.Windows.Forms.ContextMenu
    Public WithEvents mnuPickShowDetails As System.Windows.Forms.MenuItem
    Public WithEvents mnuPickSelect As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.dgRoster = New System.Windows.Forms.DataGrid
        Me.popRoster = New System.Windows.Forms.ContextMenu
        Me.mnuGridShowDetails = New System.Windows.Forms.MenuItem
        Me.mnuGridDrop = New System.Windows.Forms.MenuItem
        Me.popFA = New System.Windows.Forms.ContextMenu
        Me.mnuFAShowPlayer = New System.Windows.Forms.MenuItem
        Me.mnuFASign = New System.Windows.Forms.MenuItem
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.popPickPlayer = New System.Windows.Forms.ContextMenu
        Me.mnuPickShowDetails = New System.Windows.Forms.MenuItem
        Me.mnuPickSelect = New System.Windows.Forms.MenuItem
        CType(Me.dgRoster, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgRoster
        '
        Me.dgRoster.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.dgRoster.DataMember = ""
        Me.dgRoster.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgRoster.Name = "dgRoster"
        Me.dgRoster.Size = New System.Drawing.Size(616, 344)
        Me.dgRoster.TabIndex = 16
        '
        'popRoster
        '
        Me.popRoster.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuGridShowDetails, Me.mnuGridDrop})
        '
        'mnuGridShowDetails
        '
        Me.mnuGridShowDetails.DefaultItem = True
        Me.mnuGridShowDetails.Index = 0
        Me.mnuGridShowDetails.Text = "Show Details"
        '
        'mnuGridDrop
        '
        Me.mnuGridDrop.Index = 1
        Me.mnuGridDrop.Text = "Drop"
        '
        'popFA
        '
        Me.popFA.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFAShowPlayer, Me.mnuFASign})
        '
        'mnuFAShowPlayer
        '
        Me.mnuFAShowPlayer.DefaultItem = True
        Me.mnuFAShowPlayer.Index = 0
        Me.mnuFAShowPlayer.Text = "Show Details"
        '
        'mnuFASign
        '
        Me.mnuFASign.Index = 1
        Me.mnuFASign.Text = "Sign"
        '
        'MenuItem1
        '
        Me.MenuItem1.DefaultItem = True
        Me.MenuItem1.Index = -1
        Me.MenuItem1.Text = "Show Details"
        '
        'MenuItem2
        '
        Me.MenuItem2.DefaultItem = True
        Me.MenuItem2.Index = -1
        Me.MenuItem2.Text = "Show Details"
        '
        'popPickPlayer
        '
        Me.popPickPlayer.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuPickShowDetails, Me.mnuPickSelect})
        '
        'mnuPickShowDetails
        '
        Me.mnuPickShowDetails.DefaultItem = True
        Me.mnuPickShowDetails.Index = 0
        Me.mnuPickShowDetails.Text = "Show Details"
        '
        'mnuPickSelect
        '
        Me.mnuPickSelect.Index = 1
        Me.mnuPickSelect.Text = "Select"
        '
        'PlayerPicker
        '
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.dgRoster})
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "PlayerPicker"
        Me.Size = New System.Drawing.Size(616, 344)
        CType(Me.dgRoster, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public TeamID As Integer
    Public Mode As ISM_GridMode
    Public PlayerID As Integer
    Public PositionID As Integer
    Public RosterView As Integer

    Private mblnLoading As Boolean
    Private mintPlayerID As Integer

    Public Event PlayerSigned(ByVal sender As Object, ByVal e As System.EventArgs)
    Public Event PlayerDropped(ByVal sender As Object, ByVal e As System.EventArgs)
    Public Event PlayerSelected(ByVal sender As Object, ByVal e As PlayerSelectedEventArgs)

    Dim gs As GUIService = GUIService.GetInstance()

    Public Enum ISM_GridMode
        Roster = 0
        FreeAgent = 1
        Rookie = 2
        SelectPlayer = 4
    End Enum

    Public Function GetPositionToShow(ByVal Text As String) As Integer
        Select Case Trim(Text)
            Case "All"
                Return 0
            Case "GK"
                Return 1
            Case "FW"
                Return 2
            Case "DEF"
                Return 3
            Case "MF"
                Return 4
        End Select

    End Function

    Private Function GetGridToShow() As DataSet
        Select Case Me.Mode
            Case ISM_GridMode.Roster
                Return GetRosterGridToShow()
            Case ISM_GridMode.Rookie
                Return GetRookieGridToShow()
            Case ISM_GridMode.FreeAgent
                Return GetFreeAgentGridToShow()
        End Select
    End Function

    Private Function GetRosterGridToShow() As DataSet
        Dim DS As New DataServices.TeamTables
        Dim Helper As New DataGridUtility(Me.dgRoster, "Roster")
        Dim DataSet As New DataSet

        Select Case Me.RosterView
            Case 0 '"General"
                DataSet = DS.GetRosterGrid(Me.TeamID, Me.PositionID)
                Helper.SetRosterGrid()
            Case 1 '"Actuals"
                DataSet = DS.GetRosterGridActuals(Me.TeamID, Me.PositionID)
                Helper.SetRosterGridActuals()
            Case 2 '"Potentials"
                DataSet = DS.GetRosterGridPotentials(Me.TeamID, Me.PositionID)
                Helper.SetRosterGridActuals()
            Case Else
                DataSet = DS.GetRosterGridActuals(Me.TeamID, Me.PositionID)
                Helper.SetRosterGridActuals()
        End Select
        Helper.Commit()
        Return DataSet
    End Function

    Private Function GetRookieGridToShow() As DataSet
        Dim DS As New DataServices.TeamTables
        Dim Helper As New DataGridUtility(Me.dgRoster, "Roster")
        Dim DataSet As New DataSet

        Select Case Me.RosterView
            Case 0 '"General"
                DataSet = DS.GetRosterGrid(Me.TeamID, Me.PositionID)
                Helper.SetRosterGrid()
            Case 1 '"Actuals"
                DataSet = DS.GetRosterGridActuals(Me.TeamID, Me.PositionID)
                Helper.SetRosterGridActuals()
            Case 2 '"Potentials"
                DataSet = DS.GetRosterGridPotentials(Me.TeamID, Me.PositionID)
                Helper.SetRosterGridActuals()
            Case Else
                DataSet = DS.GetRosterGridActuals(Me.TeamID, Me.PositionID)
                Helper.SetRosterGridActuals()
        End Select
        Helper.Commit()
        Return DataSet
    End Function

    Private Function GetFreeAgentGridToShow() As DataSet
        Dim DS As New DataServices.TeamTables
        Dim Helper As New DataGridUtility(Me.dgRoster, "Roster")
        Dim DataSet As New DataSet

        Select Case Me.RosterView
            Case 0 '"General"
                DataSet = DS.GetFreeAgentGrid(Me.PositionID)
                Helper.SetRosterGrid()
            Case 1 '"Actuals"
                DataSet = DS.GetFreeAgentGridActuals(Me.PositionID)
                Helper.SetRosterGridActuals()
            Case 2 '"Potentials"
                DataSet = DS.GetFreeAgentGridPotentials(Me.PositionID)
                Helper.SetRosterGridActuals()
            Case Else
                DataSet = DS.GetFreeAgentGridActuals(Me.PositionID)
                Helper.SetRosterGridActuals()
        End Select
        Helper.Commit()
        Return DataSet
    End Function

    Private Sub dgRoster_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgRoster.MouseUp
        Dim pt As New Point(e.X, e.Y)
        Dim hti As DataGrid.HitTestInfo = Me.dgRoster.HitTest(pt)

        If hti.Type = DataGrid.HitTestType.Cell Or hti.Type = DataGrid.HitTestType.RowHeader Then
            Me.dgRoster.CurrentCell = New DataGridCell(hti.Row, hti.Column)
            Me.dgRoster.Select(hti.Row)
            mintPlayerID = Int(Me.dgRoster(hti.Row, 0))

            If e.Button = MouseButtons.Left Then
                Call ShowPlayerDetail()
            ElseIf e.Button = MouseButtons.Right Then
                Call PopupCorrectMenu(pt)
            End If
        End If
    End Sub

    Private Sub PopupCorrectMenu(ByVal pt As Point)
        Select Case Me.Mode
            Case ISM_GridMode.Roster
                Me.popRoster.Show(Me.dgRoster, pt)
            Case ISM_GridMode.FreeAgent
                Me.popFA.Show(Me.dgRoster, pt)
        End Select
    End Sub


    Private Sub ShowPlayer(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuGridShowDetails.Click, mnuFAShowPlayer.Click, mnuPickShowDetails.Click
        Call ShowPlayerDetail()
    End Sub

    Private Sub ShowPlayerDetail()

        Dim f As New frmPlayerCard(mintPlayerID, GetPlayersInGrid())
        f.ShowDialog()
        Me.LoadRoster()
    End Sub

    Private Sub mnuGridDrop_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuGridDrop.Click
        Call DropPlayerToFA()
        RaiseEvent PlayerDropped(Me, New System.EventArgs)
    End Sub

    Private Sub DropPlayerToFA()
        Dim rm As New Rosters.RosterManager
        rm.DumpToFA(Me.TeamID, mintPlayerID)
        Call Me.LoadRoster()

    End Sub

    Private Sub SignPlayerFromFA()
        Dim rm As New Rosters.RosterManager
        rm.SignFA(mintPlayerID, Me.TeamID)
        RaiseEvent PlayerSigned(Me, New System.EventArgs)

    End Sub

    Public Sub SetScreen()
        Call InitializeDefaults()
        Call gs.SkinForm(Me.ParentForm)

    End Sub

    Private Sub InitializeDefaults()
        Call LoadRoster()
    End Sub

    Public Sub LoadRoster()
        If Not mblnLoading Then
            gs.SetCursor(True, Me.ParentForm)
            Dim dg As DataGrid = Me.dgRoster

            Dim DataSet As New DataSet
            DataSet = GetGridToShow()

            Dim View As New DataViewUtility
            View.Standardize(DataSet)
            With dg
                .DataSource = View
                .CaptionText = "Roster"
            End With


            gs.SetCursor(False, Me.ParentForm)
        End If
    End Sub


    Public Function GetPlayersInGrid() As ArrayList
        Dim parrOut As New ArrayList
        Dim cm As CurrencyManager = CType(Me.BindingContext(Me.dgRoster.DataSource), CurrencyManager)
        Dim rowCount As Integer = cm.Count

        Dim i As Integer
        For i = 0 To rowCount - 1
            parrOut.Add(Me.dgRoster(i, 0))
        Next
        Return parrOut
    End Function


    Private Sub mnuFASign_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuFASign.Click
        Call Me.SignPlayerFromFA()
    End Sub

    Private Sub mnuPickSelect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuPickSelect.Click
        RaiseEvent PlayerSelected(Me, New PlayerSelectedEventArgs(Me.PlayerID))
    End Sub
End Class

Public Class PlayerSelectedEventArgs
    Inherits System.EventArgs

    Public PlayerID As Integer
    Sub New(ByVal PlayerID As Integer)
        Me.PlayerID = PlayerID
    End Sub
End Class
