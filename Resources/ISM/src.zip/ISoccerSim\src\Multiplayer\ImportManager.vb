'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Leagues
Imports ISoccerSim.Teams
Imports System.Xml
Imports System.IO


Namespace Multiplayer
    Public Class ImportManager
        Public Sub Import(ByVal Dir As String)
            Dim oDir As New DirectoryInfo(Dir)
            Dim oFile As FileInfo
            If oDir.Exists Then
                For Each oFile In oDir.GetFiles("*.txt")
                    ImportFile(oFile.FullName)
                Next
            End If
        End Sub

        Public Sub ImportFile(ByVal Filename As String)
            Console.WriteLine(Filename)
            Dim x As New XmlDocument
            x.Load(Filename)
            Dim TeamID As Integer = CType(x.GetElementsByTagName("export").Item(0), XmlElement).GetAttribute("teamid")
            If TeamID > 0 Then
                Dim t As Team = Simulation.GetInstance().League.GetTeamByID(TeamID)
                Try
                    x.Load(Filename)
                    If IsRosterValid(t, x.GetElementsByTagName("roster")) Then
                        If Me.IsSubLineValid(t, x.GetElementsByTagName("subs")) Then
                            Me.LoadSubLine(t, x.GetElementsByTagName("subs"))
                        End If
                    End If
                Catch ex As Exception

                End Try
            End If

        End Sub

        Private Function IsRosterValid(ByVal t As Team, ByVal nl As XmlNodeList) As Boolean
            Dim n As XmlNode
            Dim PlayerID As Integer
            t.Roster.Load(t.TeamID)

            For Each n In nl.Item(0).ChildNodes
                If n.Name = "player" Then
                    PlayerID = n.Attributes("playerid").Value
                    If Not t.Roster.IsPlayerOnRoster(PlayerID) Then
                        Return False
                    End If
                End If
            Next

            If nl.Item(0).ChildNodes.Count = t.Roster.Count Then
                Return True
            End If
        End Function

        Private Function IsSubLineValid(ByVal t As Team, ByVal nl As XmlNodeList) As Boolean
            Dim n As XmlNode
            Dim cn As XmlNode
            Dim l As XmlNode
            Dim PlayerID As Integer
            t.Roster.Load(t.TeamID)

            'check # of nodes, parents, attributes...
            If nl.Item(0).ChildNodes.Count = 5 Then
                For Each n In nl.Item(0).ChildNodes
                    If n.Name <> "line" Then
                        Return False
                    Else
                        If n.Attributes(0).Name <> "lineid" Then
                            Return False
                        Else
                            If n.ChildNodes.Count <> 6 Then
                                Return False
                            Else
                                For Each cn In n.ChildNodes
                                    If cn.Attributes.Count <> 2 Then
                                        Return False
                                    Else
                                        If cn.Attributes(0).Name <> "playerid" Or cn.Attributes(1).Name <> "positionid" Then
                                            Return False
                                        Else
                                            If Not t.Roster.IsPlayerOnRoster(cn.Attributes(0).Value) Then
                                                Return False
                                            Else
                                                If Not t.Roster.GetPlayerByID(cn.Attributes(0).Value).CanPlayGamePosition(cn.Attributes(1).Value) Then
                                                    Return False
                                                End If
                                            End If
                                        End If
                                    End If
                                Next
                            End If
                        End If
                    End If
                Next
            End If
            Return True
        End Function

        Private Function LoadSubLine(ByVal t As Team, ByVal n As XmlNodeList)
            'Assuming we have a valid subline to load, we will wipe out the old line and
            'put in the new one by doing a string of updates.  I really hope this works...

            Dim sl As Substitution.SubstitutionLine
            Dim i As Integer
            Dim cn As XmlNode
            Dim pn As XmlNode

            t.SubstitutionSets.Load(t.TeamID)

            For Each sl In t.SubstitutionSets
                cn = GetSubLineFromNode(n, sl.SubLineTypeID)
                If Not cn Is Nothing Then
                    For Each pn In cn.ChildNodes
                        If pn.Name = "player" Then
                            sl.SetPlayerIDForPosition(pn.Attributes("playerid").Value, pn.Attributes("positionid").Value)
                        End If
                    Next
                End If
                sl.Update()
            Next
        End Function

        Private Function GetSubLineFromNode(ByVal n As XmlNodeList, ByVal LineID As Integer) As XmlNode
            Dim i As Integer
            Dim cn As XmlNode
            For Each cn In n.Item(0)
                If cn.Name = "line" Then
                    If cn.Attributes("lineid").Value = LineID Then
                        Return cn
                    End If
                End If
            Next
        End Function
    End Class
End Namespace