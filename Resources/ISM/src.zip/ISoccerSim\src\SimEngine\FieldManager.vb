'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports ISoccerSim.Rosters
Imports ISoccerSim.Players
Imports ISoccerSim.Substitution
Imports ISoccerSim.SimEngine
Imports Microsoft.VisualBasic

Namespace SimEngine

	Public Class FieldManager
		Public Field As New FieldSet()
		Public Bench As New GamePlayerSet()
		Public Box As New GamePlayerSet()
		Public LockerRoom As New GamePlayerSet()

		Public PlayerSet As New GamePlayerSet()

		Public GameWinningPlayer As Player
		Public WinningGoalie As Player
		Public LosingGoalie As Player

		Public Enum ISMFieldServiceZone
			Field = 0
			Bench = 1
			Box = 2
			LockerRoom = 4
		End Enum

		Sub Reset()
			Me.Field.Clear()
			Me.Bench.Clear()
			Me.Box.Clear()
			Me.LockerRoom.Clear()
			Me.PlayerSet.Clear()
		End Sub

		Sub Load(ByVal intPlayerID As Integer, ByVal intLocation As ISMFieldServiceZone)
			Dim Item As New Player()
			Item.ID = intPlayerID

			Select Case intLocation
				Case ISMFieldServiceZone.Field
					Me.Field.Add(Item)
				Case ISMFieldServiceZone.Bench
					Me.Bench.Add(Item)
				Case ISMFieldServiceZone.Box
					Me.Box.Add(Item)
				Case ISMFieldServiceZone.LockerRoom
					Me.LockerRoom.Add(Item)
			End Select
		End Sub

		Sub Load(ByVal objRoster As Roster, ByVal objStartingLine As SubstitutionLine)
			Dim Item As New RosterSlot()
			Dim Player As Player
			Dim pblnStarter As Boolean


			For Each Item In objRoster
				pblnStarter = False
				Player = New Player()
				Player = Item.Player
				Player.Stats.Load()

				Dim SubItem As SubstitutionSlot
				For Each SubItem In objStartingLine
					If SubItem.PlayerID = Player.ID Then
						Player.GamePosition = SubItem.GamePositionID
						Me.Field.Add(Player)
						pblnStarter = True
					End If
				Next

				If Not pblnStarter Then
					Me.Bench.Add(Player)
				End If

				'Add to global list...
				Me.PlayerSet.Add(Player)
			Next
		End Sub

		Function GetGamePlayerSetFromLine(ByVal objSubline As SubstitutionLine) As GamePlayerSet
			Dim Item As Player
			Dim Slot As SubstitutionSlot
			Dim psetOut As New GamePlayerSet()

			For Each Slot In objSubline
				For Each Item In Me.PlayerSet
					If Slot.PlayerID = Item.ID Then
						Item.GamePosition = Slot.GamePositionID
						psetOut.Add(Item)
					End If
				Next
			Next

			Return psetOut
		End Function

		Sub PutLineOnField(ByVal objGamePlayerSet As GamePlayerSet)
			Dim i As Integer
			Dim Item As Player
			Dim Slot As SubstitutionSlot
			Dim psetOut As New GamePlayerSet()

			Me.Field.Clear()
            For Each Item In objGamePlayerSet
                If Not Me.Box.IsPlayerHere(Item) Then
                    Me.Field.Add(Item)
                End If
            Next

        End Sub

        Function IsPlayerOnTeam(ByVal objPlayer As Player) As Boolean
            Dim Item As Player
            For Each Item In Me.PlayerSet
                If Item.ID = objPlayer.ID Then Return True
            Next
        End Function

        Sub MovePlayerFromFieldToBox(ByVal objPlayer As Player)
            If Me.Field.IsPlayerHere(objPlayer) Then
                Me.Box.Add(objPlayer)
                Me.Field.Remove(objPlayer)
            End If
        End Sub

        Sub MovePlayerFromBoxToBench(ByVal objPlayer As Player)
            If Me.Box.IsPlayerHere(objPlayer) Then
                Me.Bench.Add(objPlayer)
                Me.Box.Remove(objPlayer)
            End If
        End Sub

        Sub MovePlayerBackOnField(ByVal objPlayer As Player)
            If Me.Box.IsPlayerHere(objPlayer) Then
                Me.Field.Add(objPlayer)
                Me.Box.Remove(objPlayer)
            ElseIf Me.Bench.IsPlayerHere(objPlayer) Then
                Me.Field.Add(objPlayer)
                Me.Bench.Remove(objPlayer)
            End If
        End Sub

        Sub EjectPlayer(ByVal objPlayer As Player)
            If Me.Field.IsPlayerHere(objPlayer) Then
                Me.LockerRoom.Add(objPlayer)
                Me.Field.Remove(objPlayer)
            End If
        End Sub


        Function GetSubstitutionCandidates(ByVal objPlayer As Player) As GamePlayerSet
            Dim PositionID = objPlayer.Position
            Dim Item As Player
            Dim Result As New GamePlayerSet

            For Each Item In Me.PlayerSet
                If Not Me.LockerRoom.IsPlayerHere(Item) Then
                    If Item.Position = objPlayer.Position Then
                        If Item.ID <> objPlayer.ID Then
                            Result.Add(Item)
                        End If
                    End If
                End If
            Next

            'Set.Sort
            Debug.Assert(Result.Count > 0, "Blank set")
            Return Result
        End Function

        Sub MovePlayerFromFieldToBench(ByVal objPlayer As Player)
            If Me.Field.IsPlayerHere(objPlayer) Then
                Me.Box.Add(objPlayer)
                Me.Bench.Remove(objPlayer)
            End If
        End Sub


    End Class





End Namespace