'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.IO

Namespace Reporting
	Public Class HTMLReportFormatService
		Inherits ReportFormatService

        Dim Sim As Simulation = Simulation.GetInstance()
        Dim fs As FileService = FileService.GetInstance()

		Public Overrides Sub Generate()
			Call WriteHeader()
			Call WriteBody()
			Call WriteFooter()
		End Sub

		Private Sub WriteBody()
			
			Dim Table As ReportTable
			For Each Table In Me.Report
				Me.Build("<p style=tableheading>" & Table.Header & "</p>", 2)
				Me.Build("<table width=" & GetReportWidth() & " class=HxLinkTable>", 2)
				Call WriteTableColumns(Table)
				Call WriteTableData(Table)
				Me.Build("</table>", 2)
				'Me.Build(GetDivider(), 2)
			Next
			Me.Build("</div>", 1)
			Me.Build("</body>", 1)
		End Sub

		Private Function WriteTableColumns(ByVal objReportTable As ReportTable) As String
			Dim Out As String
			Dim Col As ReportColumn
			Dim Header As String
			Dim i As Integer = 1

			Out = "<thead><tr>"

			For Each Col In objReportTable
				If Col.Width > 0 Then
					Out = Out & "<th>" & Col.Column & "</th>"
				End If
			Next
			Out = Out & "</tr></thead>"
			Me.Build(Out)
		End Function

		Private Sub WriteTableData(ByVal objReportTable As ReportTable)
			Dim Item As ReportRow

			For Each Item In objReportTable.Data
				Me.Build(WriteTableRow(objReportTable, Item))
			Next
		End Sub

		Private Function WriteTableRow(ByVal objTable As ReportTable, ByVal objRow As ReportRow) As String
			Dim intCols As Integer = objTable.Count - 1
			Dim i As Integer
			Dim Col As ReportColumn
			'Dim Out As New String(" ", Me.ReportWidth)
			Dim Value As Object
			Dim x As Integer = 1
			Dim Align As String
			Dim Out As New System.Text.StringBuilder()

			For i = 1 To Me.ReportWidth
				Out.Append(" ")
			Next
			Out.Append("<tr>")

			For i = 0 To intCols
				Col = objTable.Item(i)
				If Col.Width > 0 Then
					Value = objRow.Data(i)

					If Col.RightAlign Then
						Align = "right"
					Else
						Align = "left"
					End If

					Value = CStr(Value)
					Out.Append("<td align=")
					Out.Append(Align)
					Out.Append(" width=")
					Out.Append(GetColumnWidth(Col.Width))
					Out.Append(">")
					Out.Append(Value)
					Out.Append("</td>")

					'Out = Out & "<td align=" & Align & " width=" & GetColumnWidth(Col.Width) & ">"
					'Out = Out & Value
					'Out = Out & "</td>"

				End If
			Next
			Out.Append("</tr>")
			Out.Append(vbCrLf)

			Return Out.ToString

		End Function

		Private Function GetColumnWidth(ByVal intValue As Integer) As Integer
			Dim dblOut As Double
			If intValue > 0 Then
				dblOut = intValue / Me.ReportWidth
				dblOut = Int(dblOut * 640)
			End If
			Return dblOut
		End Function

		Private Function GetReportWidth() As Integer
			Dim dblOut As Integer

			dblOut = Int((Me.ReportWidth / 80) * 640)

			Return dblOut
		End Function

		Private Sub WriteHeader()
			Me.Build("<html>")
			Me.Build("<head>", 1)
			Me.Build("<title>" & Report.Header & "</title>", 2)
			Me.Build(Me.GetStyleSheet())
			'Me.Build("<link rel='stylesheet' type='text/css' href='..\ism.css'>", 2)
			Me.Build("</head>", 1)

			Me.Build("<body>", 1)
			Me.Build("<div id='nstext'>", 1)
			Me.Build("<h1>" & Me.Report.Header & "</h1>")
			Me.Build("<h4>" & Me.Report.Subheader & "</h4><hr>")

		End Sub

        Private Sub WriteFooter()
            Me.Build("<h4>Indoor Soccer Manager - 2004 - To-Paw Software</h4>")
            Me.Build("</html>")
        End Sub

        Private Function GetDivider() As String
            Return "<hr>"
        End Function

        Private Function GetStyleSheet()
            Dim objReader As New StreamReader(fs.GetStyleSheetTemplateFilePath(Sim.League.Name))
            Dim Out As String
            Out = "<style>" & objReader.ReadToEnd & "</style>"
            objReader.Close()
            Return Out
        End Function


    End Class
End Namespace
