'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.SimEngine.Results


Namespace SimEngine.Reporting
	Public Class ArrayListDelimiter

		Public Delimiter As String = ","

		Function ArrayListToCommas(ByVal Title As String, ByVal objGameResultSet As GameResultSet, ByVal Sort As Boolean) As String

			Dim ArrayList As New ArrayList()
			Dim Item As GameResultItem
			Dim Total As Integer
			Dim pblnTotalInSet As Boolean

			If Sort Then
				objGameResultSet.Sort()
			End If

			For Each Item In objGameResultSet
				If Item.Value <> -1 Then
					If Item.Total Then
						Total = Item.Value
						pblnTotalInSet = True
					Else
						ArrayList.Add(Item.Value & " - " & Item.Name)
					End If
				Else
					ArrayList.Add(Item.Name)
				End If
			Next
			If pblnTotalInSet Then
				Return "<b>" & Title & " (" & Total & ")</b>: " & ArrayListToCommas(ArrayList)
			Else
				Return "<b>" & Title & "</b>: " & ArrayListToCommas(ArrayList)
			End If

		End Function

		Function ArrayListToCommas(ByVal objGameResultSet As GameResultSet) As String
			objGameResultSet.Sort()
			Dim ArrayList As New ArrayList()
			Dim Item As GameResultItem
			For Each Item In objGameResultSet
				ArrayList.Add(Item.Value & " - " & Item.Name)
			Next
			Return ArrayListToCommas(ArrayList)

		End Function

		Function ArrayListToCommas(ByVal objArrayList As ArrayList) As String
			Dim i As Integer
			Dim Out As String

			If objArrayList Is Nothing Then Return "None."

			With objArrayList
				If .Count = 0 Then Return "None."

				For i = 0 To .Count - 1
					Out = Out & .Item(i)
					If i < .Count - 1 Then
						Out = Out & Me.Delimiter & " "
					Else
						Out = Out & "."
					End If
				Next
				Return Out
			End With

		End Function
	End Class
End Namespace
