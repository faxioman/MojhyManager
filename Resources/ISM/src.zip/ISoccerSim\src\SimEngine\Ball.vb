'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports Microsoft.VisualBasic
Imports ISoccerSim.SimEngine
Imports ISoccerSim.SimEngine.Actions

Namespace SimEngine


	Public Class Ball
		Public X As ISMBallLateral
		Public Y As ISMBallVertical
		Public TargetLocation As ISMBallOffTarget
        Dim Sim As Simulation = Simulation.GetInstance()
        Dim r As MathService = MathService.GetInstance

		Sub Place(ByVal x1 As ISMBallLateral, ByVal y1 As ISMBallVertical)
			Me.X = x1
			Me.Y = y1
			Me.TargetLocation = ISMBallOffTarget.OnTarget
		End Sub

		Sub PlaceRandomly()
            Dim x As Integer = r.RandomNumber(ISMBallVertical.OppThird, ISMBallVertical.OppCrease)
            Dim y As Integer = r.RandomNumber(ISMBallLateral.WallLeft, ISMBallLateral.WallRight)
			Me.X = x
			Me.Y = y
			Me.TargetLocation = ISMBallOffTarget.OnTarget
		End Sub

		Sub Check3PtProbability()
			If Me.Y = ISMBallVertical.OppThird Then
                If r.GetRoll(MathService.ISMRollType.Percentage) > 10 Then
                    Me.Y = ISMBallVertical.OppShortRange
                End If
            End If
		End Sub

		Sub PlaceAtMidField()
			Me.X = ISMBallLateral.Middle
			Me.Y = ISMBallVertical.MidField
			Me.TargetLocation = ISMBallOffTarget.OnTarget
		End Sub

		Sub MoveUpfield(ByVal Amount As Integer, ByVal Limit As ISMBallVertical)
			Me.Y = Me.Y + Amount
			If Me.Y > Limit Then
				Me.Y = Limit
			End If
		End Sub

		Sub MoveUpfield(ByVal Amount As Integer, ByVal Limit As ISMBallVertical, ByVal Probability As Integer)
            If r.GetRoll(MathService.ISMRollType.Percentage) <= Probability Then
                If Amount > 1 Then
                    MoveUpfield(r.RandomNumber(1, Amount), Limit)
                Else
                    MoveUpfield(1, Limit)
                End If
            End If
		End Sub

		Sub MoveLateral(ByVal Amount As Integer, ByVal Limit As ISMBallMoveSideways, ByVal Probability As Integer)
            If r.GetRoll(MathService.ISMRollType.Percentage) <= Probability Then
                MoveLateral(Amount, Limit)
            End If
		End Sub

		Sub MoveLateral(ByVal Amount As Integer, ByVal Left As Integer, ByVal Right As Integer)
            Dim x As Integer = r.GetRoll(MathService.ISMRollType.Percentage)
			If x < Left Then
				MoveLateral(Amount, ISMBallMoveSideways.Left)
			ElseIf x < Left + Right Then
				MoveLateral(Amount, ISMBallMoveSideways.Right)
			End If
		End Sub

		Sub MoveLateral(ByVal Amount As Integer, ByVal Direction As ISMBallMoveSideways)
			Me.X = Me.X + (Amount * Direction)
			If Me.X < -3 Then
				Me.X = ISMBallLateral.WallLeft
			End If

			If Me.X > 3 Then
				Me.X = ISMBallLateral.WallRight
			End If
		End Sub

		Function GetPosition() As String

			Select Case Me.Y
				Case ISMBallVertical.MidField
					Return "Ball is at centerfield."
				Case ISMBallVertical.OppCrease
					Return "Ball is in the opponent's goalie box."
				Case ISMBallVertical.OppShortRange
					If Sim.League.MultiPoint Then
						Return "Ball is within the opponent's point line."
					Else
						Return "Ball is mid-range from opponent's goal."
					End If
				Case ISMBallVertical.OppThird
					Return "Ball is within their own red line."
				Case ISMBallVertical.OwnCrease
					Return "Ball is in their own goalie box."
				Case ISMBallVertical.OwnShortRange
					If Sim.League.MultiPoint Then
						Return "Ball is within their own point line."
					Else
						Return "Ball is mid-range from their own goal."
					End If
				Case ISMBallVertical.OwnThird
					Return "Ball is within their own red line."
			End Select
		End Function

		Function GetOnTargetText() As String
			Select Case Me.TargetLocation
				Case ISMBallOffTarget.Crossbar
					Return "Off Crossbar"
				Case ISMBallOffTarget.High
					Return "High"
				Case ISMBallOffTarget.Left
					Return "Wide Left"
				Case ISMBallOffTarget.LeftBar
					Return "Off Left Bar"
				Case ISMBallOffTarget.OnTarget
					Return "On Target"
				Case ISMBallOffTarget.Right
					Return "Wide Right"
				Case ISMBallOffTarget.RightBar
					Return "Off Right Bar"
			End Select
		End Function

		Sub Flip()
			Me.Y = 6 - Me.Y
			Me.X = -(Me.X)
        End Sub

        Public Function IsBallInPenaltyArea() As Boolean
            If Me.Y <= ISMBallVertical.OwnShortRange Then
                If Me.X >= ISMBallLateral.SlightLeft And Me.X <= ISMBallLateral.SlightRight Then
                    Return True
                End If
            End If
        End Function

        Public Function IsBallInFreeKickArea() As Boolean
            If Me.Y > ISMBallVertical.OwnShortRange Then
                Return True
            End If
        End Function

        Public Function IsBallInCornerKickArea() As Boolean
            If Me.Y >= ISMBallVertical.OverEndBoard Then
                Return True
            End If
        End Function

        Sub New()
            Me.X = ISMBallLateral.Middle
            Me.Y = ISMBallVertical.MidField
            Me.TargetLocation = ISMBallOffTarget.OnTarget
        End Sub
    End Class

End Namespace
