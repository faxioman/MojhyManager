'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.Collections


Namespace SimEngine.PlayByPlay
	Public Class PlayByPlayInsert
		Inherits CollectionBase

		Sub Add(ByVal objItem As PlayByPlayInsertItem)
			Me.InnerList.Add(objItem)
		End Sub

		Default Public Property Item(ByVal Index As Integer) As PlayByPlayInsertItem
			Get
				Return CType(Me.InnerList.Item(Index), PlayByPlayInsertItem)
			End Get
			Set(ByVal Value As PlayByPlayInsertItem)
				Me.InnerList.Item(Index) = Value
			End Set
		End Property

		Sub Create(ByVal Slug As String, ByVal Text As String)
			Dim Item As New PlayByPlayInsertItem()
			With Item
				.SLug = Slug
				.Text = Text
			End With
			Me.Add(Item)
		End Sub

		Public Sub New()
			Me.Create(PBP_PASSTO, "Pass to player")
			Me.Create(PBP_BALLHANDLER, "Ball handler")
			Me.Create(PBP_DEFENDER, "Defender")
			Me.Create(PBP_GOALIE, "Goalkeeper")
			Me.Create(PBP_ACTIVE, "Active player")

			Me.Create(PBP_PASSTO_FULL, "Pass to player (full name)")
			Me.Create(PBP_BALLHANDLER_FULL, "Ball handler (full name)")
			Me.Create(PBP_DEFENDER_FULL, "Defender (full name)")
			Me.Create(PBP_GOALIE_FULL, "Goalkeeper (full name)")
			Me.Create(PBP_ACTIVE_FULL, "Active player (full name)")
			'Me.Create(PBP_PENALTY_FULL, "Penalty text")

			Me.Create(PBP_RANDOMCROWDNAME, "Random fan in crowd.")
			Me.Create(PBP_RANDOMPLAYERNAME, "Random player in the name")
			Me.Create(PBP_HOMETEAMCITY, "Home team name")
			Me.Create(PBP_HOMETEAMNICKNAME, "Home team nickname")
			Me.Create(PBP_HOMETEAMSCORE, "Home team score")
			Me.Create(PBP_AWAYTEAMCITY, "Away team name")
			Me.Create(PBP_AWAYTEAMNICKNAME, "Away team nickname")
			Me.Create(PBP_AWAYTEAMSCORE, "Away team score")
			Me.Create(PBP_ARENA, "Arena")
			Me.Create(PBP_HOMETEAMCOACH, "Home team coach")
			Me.Create(PBP_AWAYTEAMCOACH, "Away team coach")
			Me.Create(PBP_OFFTEAM, "Offensive team")
			Me.Create(PBP_DEFTEAM, "Defensive team")

			Me.Create(PBP_QUARTER, "Time: Quarter")
			Me.Create(PBP_MINUTES, "Time: Minute")
			Me.Create(PBP_SECONDS, "Time: Second")
			Me.Create(PBP_TIME, "Time: Clock")
			Me.Create(PBP_POSITION, "Ball position")
			Me.InnerList.Sort()

		End Sub

	End Class

	Public Class PlayByPlayInsertItem
		Implements IComparable

        Dim m_Slug As String
        Dim m_Text As String

		Public Property Slug() As String
			Get
                Return m_Slug
			End Get
			Set(ByVal Value As String)
                m_Slug = Value
			End Set
		End Property

		Public Property Text() As String
			Get
                Return m_Text
			End Get
			Set(ByVal Value As String)
                m_Text = Value
			End Set
		End Property

		Private Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
			If obj Is Nothing Then Return 1
			Dim other As PlayByPlayInsertItem = CType(obj, PlayByPlayInsertItem)
			Return StrComp(Me.Text, other.Text, CompareMethod.Text)
		End Function
	End Class


End Namespace
