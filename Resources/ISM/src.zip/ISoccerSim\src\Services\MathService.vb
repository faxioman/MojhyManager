Imports System.Random

Public Class MathService

    Private Shared myMath As MathService
    Dim Random As Random

    Dim TestDirectory As String

    Public Enum ISMRollType
        Standard = 0
        Percentage = 1
        PenaltyRoll = 2
    End Enum

    Public Sub New()
        Random = New Random(CInt(Date.Now.Ticks And Integer.MaxValue))
    End Sub


    Public Shared Function GetInstance() As MathService
        If myMath Is Nothing Then
            myMath = New MathService
            myMath.Random = New Random(CInt(Date.Now.Ticks And Integer.MaxValue))
        End If
        Return myMath
    End Function

    Function RandomNumber(ByVal intLow As Integer, ByVal intHigh As Integer) As Integer
        If intLow > intHigh Then Return intHigh
        Return Random.Next(intLow, intHigh)
    End Function

    Function GetRoll(ByVal RollType As ISMRollType)
        Select Case RollType
            Case ISMRollType.Percentage
                Return Me.RandomNumber(1, 100)
            Case ISMRollType.Standard
                Return Me.RandomNumber(1, 50)
            Case ISMRollType.PenaltyRoll
                Return Me.RandomNumber(1, 500)
            Case Else
                Debug.Assert(True, "Should not get here.")
        End Select
    End Function

    Function GetRoll(ByVal RollType As ISMRollType, ByVal Add As Integer)
        Return GetRoll(RollType) + Add
    End Function

    Function NextDouble() As Double
        Return Random.NextDouble()
    End Function

    Function [Next](ByVal minValue As Integer, ByVal maxValue As Integer) As Integer
        Return Random.Next(minValue, maxValue)
    End Function

    Sub SetSeed(ByVal Seed As Integer)
        Random = New Random(Seed)
    End Sub

    Public Function GetOrdinal(ByVal Number As Integer) As String

        Dim Remainder As Integer
        Dim Result As String

        Result = "th"
        Remainder = Number Mod 100

        If Remainder < 11 Or Remainder > 13 Then
            Select Case Number Mod 10
                Case 1
                    Result = "st"

                Case 2
                    Result = "nd"

                Case 3
                    Result = "rd"
            End Select
        End If
        Result = Number & Result

        Return Result

    End Function

    Public Function GetPlural(ByVal Value As Integer, ByVal Word As String) As String
        Select Case Value
            Case 0
                Return "no " & Word & "s"

            Case 1
                Return "1 " & Word

            Case Is > 1
                Return Value & " " & Word & "s"

            Case Else
                Return Value & " " & Word & "s"
        End Select
    End Function



End Class
