'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports Microsoft.VisualBasic
Imports ISoccerSim.Players
Imports ISoccerSim.Teams

Namespace SimEngine.PlayByPlay
	Public Class GameSummary
		Inherits CollectionBase
        Public GameEngine As GameEngine

        Dim r As MathService = MathService.GetInstance

		Public Sub New(ByVal GameEngine As GameEngine)
			Me.GameEngine = GameEngine
		End Sub

		Sub Add(ByVal objItem As GameSummaryItem)
			Me.InnerList.Add(objItem)
		End Sub

		Default Public Property Item(ByVal Index As Integer) As GameSummaryItem
			Get
				Return CType(Me.InnerList.Item(Index), GameSummaryItem)
			End Get
			Set(ByVal Value As GameSummaryItem)
				Me.InnerList.Item(Index) = Value
			End Set
		End Property

		Public Sub Narrate(ByVal Situation As ISM_PBPSituation)
			If IsAppropriateForGameSummary(Situation) Then
				Call Process(Situation)
			End If
		End Sub

		Private Function IsAppropriateForGameSummary(ByVal Situation As ISM_PBPSituation) As Boolean
			Select Case Situation
                Case PlayByPlaySupport.ISM_PBPSituation.CoolGoalieStop, PlayByPlaySupport.ISM_PBPSituation.CriticalGoal, _
                  PlayByPlaySupport.ISM_PBPSituation.GoalieStopOnGoal, PlayByPlaySupport.ISM_PBPSituation.MissedShotOnGoal, _
                  PlayByPlaySupport.ISM_PBPSituation.Kickoff, PlayByPlaySupport.ISM_PBPSituation.PenaltyKillGoal, _
                  PlayByPlaySupport.ISM_PBPSituation.PowerPlayGoal, PlayByPlaySupport.ISM_PBPSituation.Penalty, PlayByPlaySupport.ISM_PBPSituation.RegularGoal, _
                  PlayByPlaySupport.ISM_PBPSituation.BlockedShotOnGoal, PlayByPlaySupport.ISM_PBPSituation.Penalty, _
                  PlayByPlaySupport.ISM_PBPSituation.PenaltyKickSetup, PlayByPlaySupport.ISM_PBPSituation.ShootoutSetup, _
                  PlayByPlaySupport.ISM_PBPSituation.FreeKickSetup

                    Return True
                Case Else
                    Return False

            End Select
		End Function

		Private Sub Process(ByVal Situation As ISM_PBPSituation)
			Dim Item As GameSummaryItem = Me.CreateNewItem()
			Dim PBP As PlayByPlaySet = Me.GameEngine.PlayByPlay
			With Item
				Select Case Situation
					Case PlayByPlaySupport.ISM_PBPSituation.Kickoff
						.Description &= "Kickoff by " & PBP.ActivePlayer.DisplayName & "."
					Case PlayByPlaySupport.ISM_PBPSituation.Penalty
                        Call BuildPenaltyDescription(Item)
					Case PlayByPlaySupport.ISM_PBPSituation.MissedShotOnGoal
						Call BuildShotDescription(Item)
						.Description &= Me.GameEngine.Ball.GetOnTargetText & "."
					Case PlayByPlaySupport.ISM_PBPSituation.CoolGoalieStop, PlayByPlaySupport.ISM_PBPSituation.GoalieStopOnGoal
						Call BuildShotDescription(Item)
						.Description &= "Save by " & PBP.Goalie.DisplayName & " " & Me.GameEngine.Posession.Defense.FieldManager.Field.GetPlayerByGamePosition(ISMGamePosition.GK).Stats.GetOrdinal(Statistics.ISMStat.ShotStopped) & " of game."
					Case PlayByPlaySupport.ISM_PBPSituation.BlockedShotOnGoal
						Call BuildShotDescription(Item)
                        .Description &= "Block by " & PBP.Defender.DisplayName() & "."
                    Case PlayByPlaySupport.ISM_PBPSituation.PenaltyKickSetup
                        .Description &= "Penalty Kick: " & PBP.ActivePlayer.DisplayName & " - " & PBP.Goalie.DisplayName & " in goal."
                    Case PlayByPlaySupport.ISM_PBPSituation.ShootoutSetup
                        .Description &= "Shootout: " & PBP.ActivePlayer.DisplayName & " - " & PBP.Goalie.DisplayName & " in goal."
                    Case PlayByPlaySupport.ISM_PBPSituation.FreeKickSetup
                        .Description &= "Free Kick: " & PBP.ActivePlayer.DisplayName
                    Case Else
                        Call BuildShotDescription(Item)
                        .Description &= "Goal by " & PBP.ActivePlayer.DisplayName & "."
                        Dim pyr As Player = Me.GameEngine.Posession.Offense.FieldManager.Field.AssistPlayer
                        If Not (pyr Is Nothing) Then
                            .Description &= "  Assist by " & pyr.DisplayName & " " & pyr.Stats.GetOrdinal(Statistics.ISMStat.Assists) & " of game."
                        End If
                End Select
			End With
			Me.Add(Item)
        End Sub

        Private Sub BuildPenaltyDescription(ByRef objItem As GameSummaryItem)
            Dim PBP As PlayByPlaySet = Me.GameEngine.PlayByPlay
            With objItem
                .Description &= "Foul by " & PBP.PenaltyPlayer.DisplayName & "."
                If PBP.Penalty.IsTimePenalty Then
                    Select Case PBP.Penalty.Severity
                        Case Penalty.ISM_CardThrown.Blue
                            .Description &= "  Blue card issued."
                        Case Penalty.ISM_CardThrown.Red
                            .Description &= "  Red card issued."
                        Case Penalty.ISM_CardThrown.Yellow
                            .Description &= "  Yellow card issued."
                    End Select
                End If

                .Description &= "  " & r.GetOrdinal(PBP.PenaltyPlayer.FoulsPerHalf) & " foul in half.  "
                .Description &= "  " & r.GetOrdinal(PBP.PenaltyPlayer.Stats.GetValue(Statistics.ISMStat.Fouls)) & " foul in game.  "
            End With
        End Sub

        Private Sub BuildShotDescription(ByRef objItem As GameSummaryItem)
            Dim pyr As Player = Me.GameEngine.PlayByPlay.ActivePlayer
            With objItem
                .Description &= "Shot on Goal by " & pyr.DisplayName & " " & _
              pyr.Stats.GetOrdinal(Statistics.ISMStat.ShotAttempted) & " of game.  Result: "
            End With
        End Sub

        Private Function CreateNewItem()
            Dim Item As New GameSummaryItem()
            With Item
                .Abbreviation = Me.GameEngine.Posession.Offense.Abbreviation
                .Quarter = Me.GameEngine.Clock.Quarter
                .Time = Me.GameEngine.Clock.GetSummaryTime
                .Description = .Abbreviation & ": "
                .ItemID = Me.InnerList.Count
            End With
            Return Item
        End Function



    End Class
End Namespace
