'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
Imports ISoccerSim.Players


Namespace Ratings

    Public Class PlayerAttribute
        Dim mPlayerID As Integer
        Dim mACT_DUR As Byte
        Dim mACT_DEF As Byte
        Dim mACT_END As Byte
        Dim mACT_GK As Byte
        Dim mACT_MOB As Byte
        Dim mACT_PAS As Byte
        Dim mACT_AGR As Byte
        Dim mACT_SHO As Byte
        Dim mACT_DRI As Byte
        Dim mACT_TAC As Byte
        Dim mACT_FK As Byte
        Dim mACT_DET As Byte
        Dim mACT_INF As Byte
        Dim mACT_PSN As Byte

        Dim mPOT_DUR As Byte
        Dim mPOT_DEF As Byte
        Dim mPOT_END As Byte
        Dim mPOT_GK As Byte
        Dim mPOT_MOB As Byte
        Dim mPOT_PAS As Byte
        Dim mPOT_AGR As Byte
        Dim mPOT_SHO As Byte
        Dim mPOT_DRI As Byte
        Dim mPOT_TAC As Byte
        Dim mPOT_FK As Byte
        Dim mPOT_DET As Byte
        Dim mPOT_INF As Byte
        Dim mPOT_PSN As Byte

        Dim mGAME_DUR As Byte
        Dim mGAME_DEF As Byte
        Dim mGAME_END As Byte
        Dim mGAME_GK As Byte
        Dim mGAME_MOB As Byte
        Dim mGAME_PAS As Byte
        Dim mGAME_AGR As Byte
        Dim mGAME_SHO As Byte
        Dim mGAME_DRI As Byte
        Dim mGAME_TAC As Byte
        Dim mGAME_FK As Byte
        Dim mGAME_DET As Byte
        Dim mGAME_INF As Byte
        Dim mGAME_PSN As Byte

        Public Sub New()

        End Sub

        Public Sub New(ByVal PlayerID As Integer)
            Me.PlayerID = PlayerID
        End Sub

        Public Property PlayerID() As Integer
            Get
                Return mPlayerID
            End Get
            Set(ByVal Value As Integer)
                mPlayerID = Value
            End Set
        End Property

        Public Property POT_DUR() As Byte
            Get
                Return mPOT_DUR
            End Get
            Set(ByVal Value As Byte)
                mPOT_DUR = Value
            End Set
        End Property

        Public Property ACT_DUR() As Byte
            Get
                Return mACT_DUR
            End Get
            Set(ByVal Value As Byte)
                mACT_DUR = Value
            End Set
        End Property

        Public Property GAME_DUR() As Byte
            Get
                Return mGAME_DUR
            End Get
            Set(ByVal Value As Byte)
                mGAME_DUR = Value
            End Set
        End Property

        Public Property POT_DEF() As Byte
            Get
                Return mPOT_DEF
            End Get
            Set(ByVal Value As Byte)
                mPOT_DEF = Value
            End Set
        End Property

        Public Property ACT_DEF() As Byte
            Get
                Return mACT_DEF
            End Get
            Set(ByVal Value As Byte)
                mACT_DEF = Value
            End Set
        End Property

        Public Property GAME_DEF() As Byte
            Get
                Return mGAME_DEF
            End Get
            Set(ByVal Value As Byte)
                mGAME_DEF = Value
            End Set
        End Property

        Public Property POT_END() As Byte
            Get
                Return mPOT_END
            End Get
            Set(ByVal Value As Byte)
                mPOT_END = Value
            End Set
        End Property

        Public Property ACT_END() As Byte
            Get
                Return mACT_END
            End Get
            Set(ByVal Value As Byte)
                mACT_END = Value
            End Set
        End Property

        Public Property GAME_END() As Byte
            Get
                Return mGAME_END
            End Get
            Set(ByVal Value As Byte)
                mGAME_END = Value
            End Set
        End Property

        Public Property POT_GK() As Byte
            Get
                Return mPOT_GK
            End Get
            Set(ByVal Value As Byte)
                mPOT_GK = Value
            End Set
        End Property

        Public Property ACT_GK() As Byte
            Get
                Return mACT_GK
            End Get
            Set(ByVal Value As Byte)
                mACT_GK = Value
            End Set
        End Property

        Public Property GAME_GK() As Byte
            Get
                Return mGAME_GK
            End Get
            Set(ByVal Value As Byte)
                mGAME_GK = Value
            End Set
        End Property

        Public Property POT_MOB() As Byte
            Get
                Return mPOT_MOB
            End Get
            Set(ByVal Value As Byte)
                mPOT_MOB = Value
            End Set
        End Property

        Public Property ACT_MOB() As Byte
            Get
                Return mACT_MOB
            End Get
            Set(ByVal Value As Byte)
                mACT_MOB = Value
            End Set
        End Property

        Public Property GAME_MOB() As Byte
            Get
                Return mGAME_MOB
            End Get
            Set(ByVal Value As Byte)
                mGAME_MOB = Value
            End Set
        End Property

        Public Property POT_PAS() As Byte
            Get
                Return mPOT_PAS
            End Get
            Set(ByVal Value As Byte)
                mPOT_PAS = Value
            End Set
        End Property

        Public Property ACT_PAS() As Byte
            Get
                Return mACT_PAS
            End Get
            Set(ByVal Value As Byte)
                mACT_PAS = Value
            End Set
        End Property

        Public Property GAME_PAS() As Byte
            Get
                Return mGAME_PAS
            End Get
            Set(ByVal Value As Byte)
                mGAME_PAS = Value
            End Set
        End Property

        Public Property POT_AGR() As Byte
            Get
                Return mPOT_AGR
            End Get
            Set(ByVal Value As Byte)
                mPOT_AGR = Value
            End Set
        End Property

        Public Property ACT_AGR() As Byte
            Get
                Return mACT_AGR
            End Get
            Set(ByVal Value As Byte)
                mACT_AGR = Value
            End Set
        End Property

        Public Property GAME_AGR() As Byte
            Get
                Return mGAME_AGR
            End Get
            Set(ByVal Value As Byte)
                mGAME_AGR = Value
            End Set
        End Property

        Public Property POT_SHO() As Byte
            Get
                Return mPOT_SHO
            End Get
            Set(ByVal Value As Byte)
                mPOT_SHO = Value
            End Set
        End Property

        Public Property ACT_SHO() As Byte
            Get
                Return mACT_SHO
            End Get
            Set(ByVal Value As Byte)
                mACT_SHO = Value
            End Set
        End Property

        Public Property GAME_SHO() As Byte
            Get
                Return mGAME_SHO
            End Get
            Set(ByVal Value As Byte)
                mGAME_SHO = Value
            End Set
        End Property
        Public Property POT_DRI() As Byte
            Get
                Return mPOT_DRI
            End Get
            Set(ByVal Value As Byte)
                mPOT_DRI = Value
            End Set
        End Property

        Public Property ACT_DRI() As Byte
            Get
                Return mACT_DRI
            End Get
            Set(ByVal Value As Byte)
                mACT_DRI = Value
            End Set
        End Property

        Public Property GAME_DRI() As Byte
            Get
                Return mGAME_DRI
            End Get
            Set(ByVal Value As Byte)
                mGAME_DRI = Value
            End Set
        End Property

        Public Property POT_TAC() As Byte
            Get
                Return mPOT_TAC
            End Get
            Set(ByVal Value As Byte)
                mPOT_TAC = Value
            End Set
        End Property

        Public Property ACT_TAC() As Byte
            Get
                Return mACT_TAC
            End Get
            Set(ByVal Value As Byte)
                mACT_TAC = Value
            End Set
        End Property

        Public Property GAME_TAC() As Byte
            Get
                Return mGAME_TAC
            End Get
            Set(ByVal Value As Byte)
                mGAME_TAC = Value
            End Set
        End Property

        Public Property POT_FK() As Byte
            Get
                Return mPOT_FK
            End Get
            Set(ByVal Value As Byte)
                mPOT_FK = Value
            End Set
        End Property

        Public Property ACT_FK() As Byte
            Get
                Return mACT_FK
            End Get
            Set(ByVal Value As Byte)
                mACT_FK = Value
            End Set
        End Property

        Public Property GAME_FK() As Byte
            Get
                Return mGAME_FK
            End Get
            Set(ByVal Value As Byte)
                mGAME_FK = Value
            End Set
        End Property

        Public Property POT_DET() As Byte
            Get
                Return mPOT_DET
            End Get
            Set(ByVal Value As Byte)
                mPOT_DET = Value
            End Set
        End Property

        Public Property ACT_DET() As Byte
            Get
                Return mACT_DET
            End Get
            Set(ByVal Value As Byte)
                mACT_DET = Value
            End Set
        End Property

        Public Property GAME_DET() As Byte
            Get
                Return mGAME_DET
            End Get
            Set(ByVal Value As Byte)
                mGAME_DET = Value
            End Set
        End Property

        Public Property POT_INF() As Byte
            Get
                Return mPOT_INF
            End Get
            Set(ByVal Value As Byte)
                mPOT_INF = Value
            End Set
        End Property

        Public Property ACT_INF() As Byte
            Get
                Return mACT_INF
            End Get
            Set(ByVal Value As Byte)
                mACT_INF = Value
            End Set
        End Property

        Public Property GAME_INF() As Byte
            Get
                Return mGAME_INF
            End Get
            Set(ByVal Value As Byte)
                mGAME_INF = Value
            End Set
        End Property

        Public Property POT_PSN() As Byte
            Get
                Return mPOT_PSN
            End Get
            Set(ByVal Value As Byte)
                mPOT_PSN = Value
            End Set
        End Property

        Public Property ACT_PSN() As Byte
            Get
                Return mACT_PSN
            End Get
            Set(ByVal Value As Byte)
                mACT_PSN = Value
            End Set
        End Property

        Public Property GAME_PSN() As Byte
            Get
                Return mGAME_PSN
            End Get
            Set(ByVal Value As Byte)
                mGAME_PSN = Value
            End Set
        End Property

        Public Sub SetRating(ByVal Rating As ISS_Rating, ByVal RatingType As ISS_RatingType, ByVal Value As Byte)
            Select Case RatingType
                Case ISS_RatingType.Actual
                    SetActualRating(Rating, Value)
                Case ISS_RatingType.Potential
                    SetPotentialRating(Rating, Value)
                Case ISS_RatingType.Game
                    SetGameRating(Rating, Value)
                Case Else
                    Throw New Exception("Unknown rating type")
            End Select
        End Sub

        Private Function SetActualRating(ByVal Rating As ISS_Rating, ByVal Value As Byte)
            Select Case Rating
                Case ISS_Rating.Aggression
                    Me.ACT_AGR = Value
                Case ISS_Rating.Defense
                    Me.ACT_DEF = Value
                Case ISS_Rating.Determination
                    Me.ACT_DET = Value
                Case ISS_Rating.Dribbling
                    Me.ACT_DRI = Value
                Case ISS_Rating.Durability
                    Me.ACT_DUR = Value
                Case ISS_Rating.Endurance
                    Me.ACT_END = Value
                Case ISS_Rating.FreeKick
                    Me.ACT_FK = Value
                Case ISS_Rating.Goalkeeper
                    Me.ACT_GK = Value
                Case ISS_Rating.Influence
                    Me.ACT_INF = Value
                Case ISS_Rating.Mobility
                    Me.ACT_MOB = Value
                Case ISS_Rating.Passing
                    Me.ACT_PAS = Value
                Case ISS_Rating.Positioning
                    Me.ACT_PSN = Value
                Case ISS_Rating.Shooting
                    Me.ACT_SHO = Value
                Case ISS_Rating.Tackling
                    Me.ACT_TAC = Value
                Case Else
                    Throw New Exception("Unknown rating type.")
            End Select
        End Function

        Private Function SetPotentialRating(ByVal Rating As ISS_Rating, ByVal Value As Byte)
            Select Case Rating
                Case ISS_Rating.Aggression
                    Me.POT_AGR = Value
                Case ISS_Rating.Defense
                    Me.POT_DEF = Value
                Case ISS_Rating.Determination
                    Me.POT_DET = Value
                Case ISS_Rating.Dribbling
                    Me.POT_DRI = Value
                Case ISS_Rating.Durability
                    Me.POT_DUR = Value
                Case ISS_Rating.Endurance
                    Me.POT_END = Value
                Case ISS_Rating.FreeKick
                    Me.POT_FK = Value
                Case ISS_Rating.Goalkeeper
                    Me.POT_GK = Value
                Case ISS_Rating.Influence
                    Me.POT_INF = Value
                Case ISS_Rating.Mobility
                    Me.POT_MOB = Value
                Case ISS_Rating.Passing
                    Me.POT_PAS = Value
                Case ISS_Rating.Positioning
                    Me.POT_PSN = Value
                Case ISS_Rating.Shooting
                    Me.POT_SHO = Value
                Case ISS_Rating.Tackling
                    Me.POT_TAC = Value
                Case Else
                    Throw New Exception("Unknown rating type.")
            End Select
        End Function

        Private Function SetGameRating(ByVal Rating As ISS_Rating, ByVal Value As Byte)
            Select Case Rating
                Case ISS_Rating.Aggression
                    Me.GAME_AGR = Value
                Case ISS_Rating.Defense
                    Me.GAME_DEF = Value
                Case ISS_Rating.Determination
                    Me.GAME_DET = Value
                Case ISS_Rating.Dribbling
                    Me.GAME_DRI = Value
                Case ISS_Rating.Durability
                    Me.GAME_DUR = Value
                Case ISS_Rating.Endurance
                    Me.GAME_END = Value
                Case ISS_Rating.FreeKick
                    Me.GAME_FK = Value
                Case ISS_Rating.Goalkeeper
                    Me.GAME_GK = Value
                Case ISS_Rating.Influence
                    Me.GAME_INF = Value
                Case ISS_Rating.Mobility
                    Me.GAME_MOB = Value
                Case ISS_Rating.Passing
                    Me.GAME_PAS = Value
                Case ISS_Rating.Positioning
                    Me.GAME_PSN = Value
                Case ISS_Rating.Shooting
                    Me.GAME_SHO = Value
                Case ISS_Rating.Tackling
                    Me.GAME_TAC = Value
                Case Else
                    Throw New Exception("Unknown rating type.")
            End Select
        End Function


        Public Function GetRating(ByVal Rating As ISoccerSim.ratings.ISS_Rating, ByVal RatingType As ISoccerSim.Ratings.ISS_RatingType) As Integer
            Select Case RatingType
                Case ISS_RatingType.Actual
                    Return GetPotentialRating(Rating)
                Case ISS_RatingType.Potential
                    Return GetPotentialRating(Rating)
                Case Else
                    Throw New Exception("Unknown rating type")
            End Select
        End Function

        Private Function GetPotentialRating(ByVal Rating As ISS_Rating) As Byte
            Select Case Rating
                Case ISS_Rating.Aggression
                    Return Me.POT_AGR
                Case ISS_Rating.Defense
                    Return Me.POT_DEF
                Case ISS_Rating.Determination
                    Return Me.POT_DET
                Case ISS_Rating.Dribbling
                    Return Me.POT_DRI
                Case ISS_Rating.Durability
                    Return Me.POT_DUR
                Case ISS_Rating.Endurance
                    Return Me.POT_END
                Case ISS_Rating.FreeKick
                    Return Me.POT_FK
                Case ISS_Rating.Goalkeeper
                    Return Me.POT_GK
                Case ISS_Rating.Influence
                    Return Me.POT_INF
                Case ISS_Rating.Mobility
                    Return Me.POT_MOB
                Case ISS_Rating.Passing
                    Return Me.POT_PAS
                Case ISS_Rating.Positioning
                    Return Me.POT_PSN
                Case ISS_Rating.Shooting
                    Return Me.POT_SHO
                Case ISS_Rating.Tackling
                    Return Me.POT_TAC
                Case Else
                    Throw New Exception("Unknown rating type.")
            End Select
        End Function

        Private Function GetGameRating(ByVal Rating As ISS_Rating) As Byte
            Select Case Rating
                Case ISS_Rating.Aggression
                    Return Me.GAME_AGR
                Case ISS_Rating.Defense
                    Return Me.GAME_DEF
                Case ISS_Rating.Determination
                    Return Me.GAME_DET
                Case ISS_Rating.Dribbling
                    Return Me.GAME_DRI
                Case ISS_Rating.Durability
                    Return Me.GAME_DUR
                Case ISS_Rating.Endurance
                    Return Me.GAME_END
                Case ISS_Rating.FreeKick
                    Return Me.GAME_FK
                Case ISS_Rating.Goalkeeper
                    Return Me.GAME_GK
                Case ISS_Rating.Influence
                    Return Me.GAME_INF
                Case ISS_Rating.Mobility
                    Return Me.GAME_MOB
                Case ISS_Rating.Passing
                    Return Me.GAME_PAS
                Case ISS_Rating.Positioning
                    Return Me.GAME_PSN
                Case ISS_Rating.Shooting
                    Return Me.GAME_SHO
                Case ISS_Rating.Tackling
                    Return Me.GAME_TAC
                Case Else
                    Throw New Exception("Unknown rating type.")
            End Select
        End Function

        Private Function GetActualRating(ByVal Rating As ISS_Rating) As Byte
            Select Case Rating
                Case ISS_Rating.Aggression
                    Return Me.ACT_AGR
                Case ISS_Rating.Defense
                    Return Me.ACT_DEF
                Case ISS_Rating.Determination
                    Return Me.ACT_DET
                Case ISS_Rating.Dribbling
                    Return Me.ACT_DRI
                Case ISS_Rating.Durability
                    Return Me.ACT_DUR
                Case ISS_Rating.Endurance
                    Return Me.ACT_END
                Case ISS_Rating.FreeKick
                    Return Me.ACT_FK
                Case ISS_Rating.Goalkeeper
                    Return Me.ACT_GK
                Case ISS_Rating.Influence
                    Return Me.ACT_INF
                Case ISS_Rating.Mobility
                    Return Me.ACT_MOB
                Case ISS_Rating.Passing
                    Return Me.ACT_PAS
                Case ISS_Rating.Positioning
                    Return Me.ACT_PSN
                Case ISS_Rating.Shooting
                    Return Me.ACT_SHO
                Case ISS_Rating.Tackling
                    Return Me.ACT_TAC
                Case Else
                    Throw New Exception("Unknown rating type.")
            End Select
        End Function

        Default Public ReadOnly Property Item(ByVal Index As ISS_Rating) As Byte
            Get
                Return Me.GetActualRating(Index)
            End Get
        End Property


        Function GetDBColumnName(ByVal Rating As ISS_Rating, ByVal RatingType As ISS_RatingType)
            Select Case RatingType
                Case ISS_RatingType.Actual
                    Return GetActualRatingDBColumnName(Rating)
                Case ISS_RatingType.Potential
                    Return GetPotentialRatingDBColumnName(Rating)
                Case Else
                    Throw New Exception("Illegal rating type")
            End Select
        End Function


        Private Function GetActualRatingDBColumnName(ByVal Rating As ISS_Rating) As String
            Select Case Rating
                Case ISS_Rating.Aggression
                    Return "ACT_AGR"
                Case ISS_Rating.Defense
                    Return "ACT_DEF"
                Case ISS_Rating.Determination
                    Return "ACT_DET"
                Case ISS_Rating.Dribbling
                    Return "ACT_DRI"
                Case ISS_Rating.Durability
                    Return "ACT_DUR"
                Case ISS_Rating.Endurance
                    Return "ACT_END"
                Case ISS_Rating.FreeKick
                    Return "ACT_FK"
                Case ISS_Rating.Goalkeeper
                    Return "ACT_GK"
                Case ISS_Rating.Influence
                    Return "ACT_INF"
                Case ISS_Rating.Mobility
                    Return "ACT_MOB"
                Case ISS_Rating.Passing
                    Return "ACT_PAS"
                Case ISS_Rating.Positioning
                    Return "ACT_PSN"
                Case ISS_Rating.Shooting
                    Return "ACT_SHO"
                Case ISS_Rating.Tackling
                    Return "ACT_TAC"
                Case Else
                    Throw New Exception("Unknown rating type.")
            End Select
        End Function


        Private Function GetPotentialRatingDBColumnName(ByVal Rating As ISS_Rating) As String
            Select Case Rating
                Case ISS_Rating.Aggression
                    Return "POT_AGR"
                Case ISS_Rating.Defense
                    Return "POT_DEF"
                Case ISS_Rating.Determination
                    Return "POT_DET"
                Case ISS_Rating.Dribbling
                    Return "POT_DRI"
                Case ISS_Rating.Durability
                    Return "POT_DUR"
                Case ISS_Rating.Endurance
                    Return "POT_END"
                Case ISS_Rating.FreeKick
                    Return "POT_FK"
                Case ISS_Rating.Goalkeeper
                    Return "POT_GK"
                Case ISS_Rating.Influence
                    Return "POT_INF"
                Case ISS_Rating.Mobility
                    Return "POT_MOB"
                Case ISS_Rating.Passing
                    Return "POT_PAS"
                Case ISS_Rating.Positioning
                    Return "POT_PSN"
                Case ISS_Rating.Shooting
                    Return "POT_SHO"
                Case ISS_Rating.Tackling
                    Return "POT_TAC"
                Case Else
                    Throw New Exception("Unknown rating type.")
            End Select
        End Function

        Function GetRatingName(ByVal Rating As ISS_Rating) As String
            Select Case Rating
                Case ISS_Rating.Passing
                    Return "Passing"

                Case ISS_Rating.Defense
                    Return "Defense"

                Case ISS_Rating.Aggression
                    Return "Aggression"

                Case ISS_Rating.Shooting
                    Return "Shooting"

                Case ISS_Rating.Goalkeeper
                    Return "Goalkeeper"

                Case ISS_Rating.Endurance
                    Return "Endurance"

                Case ISS_Rating.Durability
                    Return "Durability"

                Case ISS_Rating.Mobility
                    Return "Mobility"

                Case ISS_Rating.Determination
                    Return "Determination"

                Case ISS_Rating.Dribbling
                    Return "Dribbling"

                Case ISS_Rating.FreeKick
                    Return "Free Kick"

                Case ISS_Rating.Influence
                    Return "Influence"

                Case ISS_Rating.Positioning
                    Return "Positioning"

                Case ISS_Rating.Tackling
                    Return "Tackling"
            End Select
        End Function

        Sub Save()
            Dim Data As New DataServices.PlayerTables
            Data.InsertPlayerAttribute(Me)
            Data.Close()
        End Sub

        Public Sub Load(ByVal PlayerID As Integer)
            Dim Data As New DataServices.PlayerTables
            Dim dr As OleDb.OleDbDataReader = Data.GetPlayerAttributes(PlayerID)
            Dim i As Integer
            ' Read attributes in...
            Do While dr.Read()
                For i = 1 To 14
                    Me.SetActualRating(i, dr.Item(Me.GetDBColumnName(i, ISS_RatingType.Actual)))
                    Me.SetPotentialRating(i, dr.Item(Me.GetDBColumnName(i, ISS_RatingType.Potential)))
                    Me.SetGameRating(i, Me.GetActualRating(i))
                Next
            Loop
            dr.Close()

        End Sub

        Function GetRatingSetValue(ByVal intPositionID As Integer) As Integer
            Dim i As Integer
            Dim Total As Integer
            Dim Sim As Simulation = Simulation.GetInstance()
            For i = 1 To 14
                Total = Total + Sim.PositionValues.GetValueByPair(intPositionID, i)
            Next
            Return Total
        End Function

        Function IsPhysicalAttribute(ByVal Rating As ISS_Rating) As Boolean
            Select Case Rating
                Case ISS_Rating.Positioning, ISS_Rating.FreeKick, ISS_Rating.Tackling, _
                    ISS_Rating.Dribbling, ISS_Rating.Shooting, ISS_Rating.Passing, _
                    ISS_Rating.Mobility, ISS_Rating.Goalkeeper, ISS_Rating.Defense
                    Return True
                Case Else
                    Return False
            End Select
        End Function

        Sub ChangeRatingBasedOnEnergy(ByVal Multiplier As Double)
            Dim i As Integer
            Dim NewValue As Byte

            For i = 1 To 14
                If Me.IsPhysicalAttribute(i) Then
                    NewValue = Int(Me.GetRating(i, ISS_RatingType.Actual) * (Multiplier))
                    Me.SetRating(i, ISS_RatingType.Game, NewValue)
                End If
            Next
        End Sub

        Function CreateAttributeSet(ByVal Player As Player, ByVal Age As PlayerAge, ByVal Skill As PlayerSkillLevel) As PlayerAttribute
            Dim i As Integer
            Dim pdblSkillModifier As Double
            Dim pdblAgeMultiplier As Double
            Dim r As MathService = MathService.GetInstance
            Dim Sim As Simulation = Simulation.GetInstance

            Dim PlayerSkill As PlayerSkillLevel = Sim.PlayerSkillSet.GetRandomItemByProbability
            Dim ActualRating As Integer
            Dim PotentialRating As Integer

            Dim pa As New PlayerAttribute(Player.ID)
            Try
                For i = 1 To 14
                    pdblAgeMultiplier = r.RandomNumber(Age.PotentialMin, Age.PotentialMax)
                    pdblSkillModifier = Skill.Multiplier

                    ActualRating = Sim.RateDistSet.GetRatingDistribution(Player.Position, i).GetRating
                    PotentialRating = GetPotential(Age, ActualRating)
                    pa.SetRating(i, ISS_RatingType.Actual, ActualRating)
                    pa.SetRating(i, ISS_RatingType.Potential, PotentialRating)
                Next
                pa.Save()
                Return pa
            Catch ex As Exception
                MsgBox("Stop")
            End Try
        End Function

        Private Function GetPotential(ByVal objAge As PlayerAge, ByVal iLow As Integer) As Integer
            Dim Low As Integer
            Dim High As Integer
            Dim Ceiling As Integer
            Dim X As Integer
            Dim Out As Integer
            Dim r As MathService = MathService.GetInstance

            'Set aging ceiling...
            Low = objAge.PotentialMin
            High = objAge.PotentialMax
            Ceiling = r.RandomNumber(Low, High)

            X = r.RandomNumber(iLow, 100)
            X = (X) * (Ceiling * 0.01)

            Out = iLow + X
            If Out > 100 Then Out = 100
            Return Out
        End Function
    End Class
End Namespace