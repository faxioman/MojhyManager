Namespace Schedules.Playoffs
    Public Class Series
        Public SeriesID As Integer
        Public TopSeed As Integer
        Public BottomSeed As Integer
        Public AdvanceToSeriesID As Integer
        Public Round As Integer
        Public TopTeamID As Integer
        Public BottomTeamID As Integer

        Public Const HIGH_SEED = -1
        Public Const LOW_SEED = -2


        Public Sub New()

        End Sub

        Public Sub New(ByVal SeriesID As Integer, ByVal TopSeed As Integer, ByVal BottomSeed As Integer, _
                       ByVal AdvanceToSeriesID As Integer, ByVal Round As Integer)

            Me.SeriesID = SeriesID
            Me.TopSeed = TopSeed
            Me.BottomSeed = BottomSeed
            Me.AdvanceToSeriesID = AdvanceToSeriesID
            Me.Round = Round

        End Sub



    End Class
End Namespace