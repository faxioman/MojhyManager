'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
'

Imports System.Data
Imports ISoccerSim.DataServices

Namespace Statistics

    Public Class StatLookup

        Dim Season As Integer

        Public Function GetPlayerStats() As String

        End Function

        Public Sub New(ByVal SeasonID As Integer)
            Me.Season = SeasonID
        End Sub

        Public Function GetLeadingScorerForTeam(ByVal TeamID As Integer, ByVal TeamRank As Integer) As LeadingScorer
            Dim stat As New DataServices.AdvancedStats.Leaderboard
            Dim ds As DataSet = stat.GetBaseLeagueStat(Me.Season)
            Dim dt As DataTable = ds.Tables(0)
            Dim Result As New LeadingScorer
            Dim Rank As Integer = 1
            Dim RunningTeamRank As Integer = 1
            Dim RunningTotal As Integer = -1

            Dim i As Integer
            For i = 0 To dt.Rows.Count - 1
                If dt.Rows(i).Item("TeamID") = TeamID Then
                    If RunningTeamRank = TeamRank Then
                        Result.Assists = dt.Rows(i).Item("A")
                        Result.FirstName = dt.Rows(i).Item("FirstName")
                        Result.LastName = dt.Rows(i).Item("LastName")
                        Result.PlayerName = Result.FirstName & " " & Result.LastName
                        Result.PlayerID = dt.Rows(i).Item("PlayerID")
                        Result.Team = dt.Rows(i).Item("Team")
                        Result.Total = dt.Rows(i).Item("Total")
                        Result.Goals = dt.Rows(i).Item("G")
                        Result.Position = dt.Rows(i).Item("POS")
                        Result.LeagueRank = Rank
                        Return Result
                    Else
                        RunningTeamRank = RunningTeamRank + 1
                    End If
                End If

                If dt.Rows(i).Item("Total") <> RunningTotal Then
                    Rank = Rank + 1
                    RunningTotal = dt.Rows(i).Item("Total")
                End If
            Next
            Return Result
        End Function

        Public Function GetLeadingDefenderForTeam(ByVal TeamID As Integer, ByVal TeamRank As Integer) As LeadingDefender
            Dim stat As New DataServices.StatTables
            Dim ds As DataSet = stat.GetBaseLeagueStat(ISMStat.Block, Me.Season)
            Dim dt As DataTable = ds.Tables(0)
            Dim Result As New LeadingDefender
            Dim Rank As Integer = 1
            Dim RunningTeamRank As Integer = 1
            Dim RunningTotal As Integer = -1

            Dim i As Integer
            For i = 0 To dt.Rows.Count - 1
                If dt.Rows(i).Item("TeamID") = TeamID Then
                    If RunningTeamRank = TeamRank Then
                        Result.FirstName = dt.Rows(i).Item("FirstName")
                        Result.LastName = dt.Rows(i).Item("LastName")
                        Result.PlayerName = Result.FirstName & " " & Result.LastName
                        Result.PlayerID = dt.Rows(i).Item("PlayerID")
                        Result.Team = dt.Rows(i).Item("Team")
                        Result.Blocks = dt.Rows(i).Item("Value")
                        Result.Position = dt.Rows(i).Item("POS")
                        Result.LeagueRank = Rank
                        Return Result
                    Else
                        RunningTeamRank = RunningTeamRank + 1
                    End If
                End If

                If dt.Rows(i).Item("Value") <> RunningTotal Then
                    Rank = Rank + 1
                    RunningTotal = dt.Rows(i).Item("Value")
                End If
            Next
            Return Result
        End Function

        Public Function GetLeadingGoalieForTeam(ByVal TeamID As Integer, ByVal TeamRank As Integer) As LeadingGoalkeeper
            Dim stat As New DataServices.AdvancedStats.LeadingGoalkeepers
            Dim ds As DataSet = stat.GetBaseLeagueStat(Me.Season)
            Dim dt As DataTable = ds.Tables(0)
            Dim Result As New LeadingGoalkeeper
            Dim Rank As Integer = 1
            Dim RunningTeamRank As Integer = 1
            Dim RunningTotal As Integer = -1

            Dim i As Integer
            For i = 0 To dt.Rows.Count - 1
                If dt.Rows(i).Item("TeamID") = TeamID Then
                    If RunningTeamRank = TeamRank Then
                        Result.FirstName = dt.Rows(i).Item("FirstName")
                        Result.LastName = dt.Rows(i).Item("LastName")
                        Result.PlayerName = Result.FirstName & " " & Result.LastName
                        Result.PlayerID = dt.Rows(i).Item("PlayerID")
                        Result.Team = dt.Rows(i).Item("Team")
                        Result.Goals = dt.Rows(i).Item("G")
                        Result.Position = dt.Rows(i).Item("POS")
                        Result.LeagueRank = Rank
                        'SF, SV, G, PTS, W, L, Avg
                        Result.Goals = dt.Rows(i).Item("G")
                        Result.Points = dt.Rows(i).Item("PTS")
                        Result.ShotsFaced = dt.Rows(i).Item("SF")
                        Result.Saves = dt.Rows(i).Item("SV")
                        Result.Wins = dt.Rows(i).Item("W")
                        Result.Losses = dt.Rows(i).Item("L")
                        Result.Avg = dt.Rows(i).Item("Avg")

                        Return Result
                    Else
                        RunningTeamRank = RunningTeamRank + 1
                    End If
                End If

                If dt.Rows(i).Item("Avg") <> RunningTotal Then
                    Rank = Rank + 1
                    RunningTotal = dt.Rows(i).Item("Avg")
                End If
            Next
            Return Result
        End Function
    End Class

    Public Class StatBase
        Public LastName As String
        Public FirstName As String
        Public PlayerName As String
        Public Team As String
        Public PlayerID As Integer = -1
        Public LeagueRank As Integer = -1
        Public Position As String

        Public Function IsValid() As Boolean
            Return IIf(PlayerID <> -1, True, False)
        End Function
    End Class

    Public Class LeadingScorer
        Inherits StatBase

        Public Goals As Integer
        Public Assists As Integer
        Public Total As Integer
    End Class

    Public Class LeadingDefender
        Inherits StatBase

        Public Blocks As Integer
    End Class

    Public Class LeadingGoalkeeper
        Inherits StatBase

        'SF, SV, G, PTS, W, L, Avg
        Public ShotsFaced As Integer
        Public Saves As Integer
        Public Goals As Integer
        Public Points As Integer
        Public Wins As Integer
        Public Losses As Integer
        Public Avg As Double
    End Class
End Namespace