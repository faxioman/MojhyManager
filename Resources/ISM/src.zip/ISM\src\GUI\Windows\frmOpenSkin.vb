'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports System.IO

Public Class frmOpenSkin
	Inherits System.Windows.Forms.Form

    Dim mblnLoading As Boolean

    Dim Sim As Simulation = Simulation.GetInstance()
    Dim fs As FileService = FileService.GetInstance()
    Dim gs As GUIService = GUIService.GetInstance()
#Region " Windows Form Designer generated code "

    Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        mblnLoading = True
        Call SetScreen()
        mblnLoading = False
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Public WithEvents grpContent As System.Windows.Forms.GroupBox
    Public WithEvents lstLeagues As System.Windows.Forms.ListBox
    Public WithEvents lblText As System.Windows.Forms.Label
    Public WithEvents btnClose As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.grpContent = New System.Windows.Forms.GroupBox()
        Me.lblText = New System.Windows.Forms.Label()
        Me.lstLeagues = New System.Windows.Forms.ListBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.grpContent.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpContent
        '
        Me.grpContent.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
           Or System.Windows.Forms.AnchorStyles.Left) _
           Or System.Windows.Forms.AnchorStyles.Right)
        Me.grpContent.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblText, Me.lstLeagues})
        Me.grpContent.Location = New System.Drawing.Point(8, 8)
        Me.grpContent.Name = "grpContent"
        Me.grpContent.Size = New System.Drawing.Size(504, 288)
        Me.grpContent.TabIndex = 2
        Me.grpContent.TabStop = False
        '
        'lblText
        '
        Me.lblText.Location = New System.Drawing.Point(16, 16)
        Me.lblText.Name = "lblText"
        Me.lblText.Size = New System.Drawing.Size(480, 24)
        Me.lblText.TabIndex = 1
        Me.lblText.Text = "Please click on the skin you would like to open below."
        Me.lblText.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lstLeagues
        '
        Me.lstLeagues.ItemHeight = 14
        Me.lstLeagues.Location = New System.Drawing.Point(16, 40)
        Me.lstLeagues.Name = "lstLeagues"
        Me.lstLeagues.Size = New System.Drawing.Size(480, 242)
        Me.lstLeagues.TabIndex = 1
        '
        'btnClose
        '
        Me.btnClose.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnClose.Location = New System.Drawing.Point(392, 304)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(112, 24)
        Me.btnClose.TabIndex = 1
        Me.btnClose.Text = "&OK"
        '
        'frmOpenSkin
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.FromArgb(CType(43, Byte), CType(72, Byte), CType(142, Byte))
        Me.ClientSize = New System.Drawing.Size(520, 341)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnClose, Me.grpContent})
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Gainsboro
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmOpenSkin"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Open League..."
        Me.grpContent.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmDialogBase_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Add standard error handler
        AddHandler Application.ThreadException, New ThreadExceptionEventHandler(AddressOf HandleException)
    End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Sub SetMainFrameText(ByVal strText As String)
        Me.grpContent.Text = strText
    End Sub

    Private Sub SetScreen()

        Dim Dir As New DirectoryInfo(fs.GetCurrentDirectory() & "\Skins\")
        Dim pdirInfo As DirectoryInfo

        gs.SetCursor(Me)
        gs.SkinForm(Me)

        If Dir.Exists Then
            For Each pdirInfo In Dir.GetDirectories
                Me.lstLeagues.Items.Add(pdirInfo.Name)
                If pdirInfo.Name = Sim.Skin.SkinDir Then
                    Me.lstLeagues.SelectedIndex = Me.lstLeagues.Items.Count - 1
                End If
            Next
        Else
            ShowMessageBox("Error", "Your skin directory does not exist or does not contain any existing leagues.", Me)
        End If

    End Sub

    Private Sub lstLeagues_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstLeagues.SelectedIndexChanged
        If mblnLoading Then Exit Sub
        If Me.lstLeagues.SelectedIndex <> -1 Then
            gs.SetCursor(True, Me)
            Sim.Skin.Load(Me.lstLeagues.SelectedItem)
            gs.SetCursor(False, Me)
        End If
    End Sub

    Private Sub lstLeagues_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstLeagues.MouseEnter
        Me.Cursor = System.Windows.Forms.Cursors.Hand
    End Sub

    Private Sub lstLeagues_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstLeagues.MouseLeave
        Me.Cursor = System.Windows.Forms.Cursors.Default
    End Sub

End Class
