'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Finances.Team

Public Class frmTeamMedia
    Inherits System.Windows.Forms.Form

    Dim gs As GUIService = GUIService.GetInstance

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    Public Sub New(ByVal TeamID As Integer)
        MyBase.New()
        InitializeComponent()
        Call gs.SetCursor(me)
        Call SetScreen(TeamID)
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Public WithEvents btnOK As System.Windows.Forms.Button
    Public WithEvents grpBasic As System.Windows.Forms.GroupBox
    Public WithEvents Label1 As System.Windows.Forms.Label
    Public WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents Label3 As System.Windows.Forms.Label
    Public WithEvents Label4 As System.Windows.Forms.Label
    Public WithEvents Label5 As System.Windows.Forms.Label
    Public WithEvents Label6 As System.Windows.Forms.Label
    Public WithEvents Label7 As System.Windows.Forms.Label
    Public WithEvents Label8 As System.Windows.Forms.Label

    Public WithEvents grpLocalMedia As System.Windows.Forms.GroupBox
    Public WithEvents grpNationalMedia As System.Windows.Forms.GroupBox
    Public WithEvents grpRegionalMedia As System.Windows.Forms.GroupBox
    Public WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Public WithEvents Label9 As System.Windows.Forms.Label
    Public WithEvents btnInternet As System.Windows.Forms.Button
    Public WithEvents btnOutdoor As System.Windows.Forms.Button
    Public WithEvents btnRadio As System.Windows.Forms.Button
    Public WithEvents btnNewsprint As System.Windows.Forms.Button
    Public WithEvents btnRegionalTV As System.Windows.Forms.Button
    Public WithEvents btnLocalTV As System.Windows.Forms.Button
    Public WithEvents btnPrimeTV As System.Windows.Forms.Button
    Public WithEvents btnNationalTV As System.Windows.Forms.Button
    Public WithEvents lblBooster2 As System.Windows.Forms.Label
    Public WithEvents lblOutdoor22 As System.Windows.Forms.Label
    Public WithEvents lblInternet As System.Windows.Forms.Label
    Public WithEvents lblOutdoor As System.Windows.Forms.Label
    Public WithEvents lblBooster As System.Windows.Forms.Label
    Public WithEvents lblBasic As System.Windows.Forms.Label
    Public WithEvents lblRadio As System.Windows.Forms.Label
    Public WithEvents lblNewsprint As System.Windows.Forms.Label
    Public WithEvents lblRegionalTV As System.Windows.Forms.Label
    Public WithEvents lblLocalTV As System.Windows.Forms.Label
    Public WithEvents lblPrimeTV As System.Windows.Forms.Label
    Public WithEvents lblNationalTV As System.Windows.Forms.Label
    Public WithEvents Label10 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.grpBasic = New System.Windows.Forms.GroupBox()
        Me.lblBooster = New System.Windows.Forms.Label()
        Me.lblBasic = New System.Windows.Forms.Label()
        Me.lblOutdoor = New System.Windows.Forms.Label()
        Me.lblInternet = New System.Windows.Forms.Label()
        Me.btnOutdoor = New System.Windows.Forms.Button()
        Me.btnInternet = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblBooster2 = New System.Windows.Forms.Label()
        Me.lblOutdoor22 = New System.Windows.Forms.Label()
        Me.grpLocalMedia = New System.Windows.Forms.GroupBox()
        Me.lblRadio = New System.Windows.Forms.Label()
        Me.lblNewsprint = New System.Windows.Forms.Label()
        Me.btnRadio = New System.Windows.Forms.Button()
        Me.btnNewsprint = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.grpNationalMedia = New System.Windows.Forms.GroupBox()
        Me.lblPrimeTV = New System.Windows.Forms.Label()
        Me.lblNationalTV = New System.Windows.Forms.Label()
        Me.btnPrimeTV = New System.Windows.Forms.Button()
        Me.btnNationalTV = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.grpRegionalMedia = New System.Windows.Forms.GroupBox()
        Me.lblRegionalTV = New System.Windows.Forms.Label()
        Me.lblLocalTV = New System.Windows.Forms.Label()
        Me.btnRegionalTV = New System.Windows.Forms.Button()
        Me.btnLocalTV = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.grpBasic.SuspendLayout()
        Me.grpLocalMedia.SuspendLayout()
        Me.grpNationalMedia.SuspendLayout()
        Me.grpRegionalMedia.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnOK
        '
        Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnOK.Location = New System.Drawing.Point(386, 258)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(112, 24)
        Me.btnOK.TabIndex = 14
        Me.btnOK.Text = "&OK"
        '
        'grpBasic
        '
        Me.grpBasic.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblBooster, Me.lblBasic, Me.lblOutdoor, Me.lblInternet, Me.btnOutdoor, Me.btnInternet, Me.Label1, Me.Label2, Me.lblBooster2, Me.lblOutdoor22})
        Me.grpBasic.Location = New System.Drawing.Point(8, 16)
        Me.grpBasic.Name = "grpBasic"
        Me.grpBasic.Size = New System.Drawing.Size(240, 120)
        Me.grpBasic.TabIndex = 23
        Me.grpBasic.TabStop = False
        Me.grpBasic.Text = "Basic Marketing"
        '
        'lblBooster
        '
        Me.lblBooster.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblBooster.Location = New System.Drawing.Point(72, 40)
        Me.lblBooster.Name = "lblBooster"
        Me.lblBooster.Size = New System.Drawing.Size(104, 20)
        Me.lblBooster.TabIndex = 36
        Me.lblBooster.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblBasic
        '
        Me.lblBasic.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblBasic.Location = New System.Drawing.Point(72, 16)
        Me.lblBasic.Name = "lblBasic"
        Me.lblBasic.Size = New System.Drawing.Size(104, 20)
        Me.lblBasic.TabIndex = 35
        Me.lblBasic.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblOutdoor
        '
        Me.lblOutdoor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutdoor.Location = New System.Drawing.Point(72, 88)
        Me.lblOutdoor.Name = "lblOutdoor"
        Me.lblOutdoor.Size = New System.Drawing.Size(104, 20)
        Me.lblOutdoor.TabIndex = 34
        Me.lblOutdoor.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblInternet
        '
        Me.lblInternet.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblInternet.Location = New System.Drawing.Point(72, 64)
        Me.lblInternet.Name = "lblInternet"
        Me.lblInternet.Size = New System.Drawing.Size(104, 20)
        Me.lblInternet.TabIndex = 33
        Me.lblInternet.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnOutdoor
        '
        Me.btnOutdoor.Location = New System.Drawing.Point(184, 88)
        Me.btnOutdoor.Name = "btnOutdoor"
        Me.btnOutdoor.Size = New System.Drawing.Size(40, 20)
        Me.btnOutdoor.TabIndex = 32
        Me.btnOutdoor.Text = "..."
        '
        'btnInternet
        '
        Me.btnInternet.Location = New System.Drawing.Point(184, 64)
        Me.btnInternet.Name = "btnInternet"
        Me.btnInternet.Size = New System.Drawing.Size(40, 20)
        Me.btnInternet.TabIndex = 31
        Me.btnInternet.Text = "..."
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 16)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "Internet"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 16)
        Me.Label2.TabIndex = 28
        Me.Label2.Text = "Basic"
        '
        'lblBooster2
        '
        Me.lblBooster2.Location = New System.Drawing.Point(8, 40)
        Me.lblBooster2.Name = "lblBooster2"
        Me.lblBooster2.Size = New System.Drawing.Size(64, 16)
        Me.lblBooster2.TabIndex = 26
        Me.lblBooster2.Text = "Booster"
        '
        'lblOutdoor22
        '
        Me.lblOutdoor22.Location = New System.Drawing.Point(8, 88)
        Me.lblOutdoor22.Name = "lblOutdoor22"
        Me.lblOutdoor22.Size = New System.Drawing.Size(64, 16)
        Me.lblOutdoor22.TabIndex = 24
        Me.lblOutdoor22.Text = "Outdoor"
        '
        'grpLocalMedia
        '
        Me.grpLocalMedia.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblRadio, Me.lblNewsprint, Me.btnRadio, Me.btnNewsprint, Me.Label3, Me.Label4})
        Me.grpLocalMedia.Location = New System.Drawing.Point(256, 16)
        Me.grpLocalMedia.Name = "grpLocalMedia"
        Me.grpLocalMedia.Size = New System.Drawing.Size(240, 72)
        Me.grpLocalMedia.TabIndex = 24
        Me.grpLocalMedia.TabStop = False
        Me.grpLocalMedia.Text = "Local Media"
        '
        'lblRadio
        '
        Me.lblRadio.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRadio.Location = New System.Drawing.Point(72, 40)
        Me.lblRadio.Name = "lblRadio"
        Me.lblRadio.Size = New System.Drawing.Size(104, 20)
        Me.lblRadio.TabIndex = 37
        Me.lblRadio.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblNewsprint
        '
        Me.lblNewsprint.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNewsprint.Location = New System.Drawing.Point(72, 16)
        Me.lblNewsprint.Name = "lblNewsprint"
        Me.lblNewsprint.Size = New System.Drawing.Size(104, 20)
        Me.lblNewsprint.TabIndex = 36
        Me.lblNewsprint.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnRadio
        '
        Me.btnRadio.Location = New System.Drawing.Point(184, 40)
        Me.btnRadio.Name = "btnRadio"
        Me.btnRadio.Size = New System.Drawing.Size(40, 20)
        Me.btnRadio.TabIndex = 35
        Me.btnRadio.Text = "..."
        '
        'btnNewsprint
        '
        Me.btnNewsprint.Location = New System.Drawing.Point(184, 16)
        Me.btnNewsprint.Name = "btnNewsprint"
        Me.btnNewsprint.Size = New System.Drawing.Size(40, 20)
        Me.btnNewsprint.TabIndex = 34
        Me.btnNewsprint.Text = "..."
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 16)
        Me.Label3.TabIndex = 32
        Me.Label3.Text = "Newsprint"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(8, 40)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 16)
        Me.Label4.TabIndex = 31
        Me.Label4.Text = "Radio"
        '
        'grpNationalMedia
        '
        Me.grpNationalMedia.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblPrimeTV, Me.lblNationalTV, Me.btnPrimeTV, Me.btnNationalTV, Me.Label5, Me.Label6})
        Me.grpNationalMedia.Location = New System.Drawing.Point(256, 176)
        Me.grpNationalMedia.Name = "grpNationalMedia"
        Me.grpNationalMedia.Size = New System.Drawing.Size(240, 72)
        Me.grpNationalMedia.TabIndex = 25
        Me.grpNationalMedia.TabStop = False
        Me.grpNationalMedia.Text = "National Media"
        '
        'lblPrimeTV
        '
        Me.lblPrimeTV.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPrimeTV.Location = New System.Drawing.Point(72, 40)
        Me.lblPrimeTV.Name = "lblPrimeTV"
        Me.lblPrimeTV.Size = New System.Drawing.Size(104, 20)
        Me.lblPrimeTV.TabIndex = 37
        Me.lblPrimeTV.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblNationalTV
        '
        Me.lblNationalTV.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNationalTV.Location = New System.Drawing.Point(72, 16)
        Me.lblNationalTV.Name = "lblNationalTV"
        Me.lblNationalTV.Size = New System.Drawing.Size(104, 20)
        Me.lblNationalTV.TabIndex = 36
        Me.lblNationalTV.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnPrimeTV
        '
        Me.btnPrimeTV.Location = New System.Drawing.Point(184, 40)
        Me.btnPrimeTV.Name = "btnPrimeTV"
        Me.btnPrimeTV.Size = New System.Drawing.Size(40, 20)
        Me.btnPrimeTV.TabIndex = 35
        Me.btnPrimeTV.Text = "..."
        '
        'btnNationalTV
        '
        Me.btnNationalTV.Location = New System.Drawing.Point(184, 16)
        Me.btnNationalTV.Name = "btnNationalTV"
        Me.btnNationalTV.Size = New System.Drawing.Size(40, 20)
        Me.btnNationalTV.TabIndex = 34
        Me.btnNationalTV.Text = "..."
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(8, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 16)
        Me.Label5.TabIndex = 32
        Me.Label5.Text = "National TV"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(8, 40)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(72, 16)
        Me.Label6.TabIndex = 31
        Me.Label6.Text = "Prime TV"
        '
        'grpRegionalMedia
        '
        Me.grpRegionalMedia.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblRegionalTV, Me.lblLocalTV, Me.btnRegionalTV, Me.btnLocalTV, Me.Label7, Me.Label8})
        Me.grpRegionalMedia.Location = New System.Drawing.Point(256, 96)
        Me.grpRegionalMedia.Name = "grpRegionalMedia"
        Me.grpRegionalMedia.Size = New System.Drawing.Size(240, 72)
        Me.grpRegionalMedia.TabIndex = 26
        Me.grpRegionalMedia.TabStop = False
        Me.grpRegionalMedia.Text = "Regional Media"
        '
        'lblRegionalTV
        '
        Me.lblRegionalTV.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRegionalTV.Location = New System.Drawing.Point(72, 40)
        Me.lblRegionalTV.Name = "lblRegionalTV"
        Me.lblRegionalTV.Size = New System.Drawing.Size(104, 20)
        Me.lblRegionalTV.TabIndex = 37
        Me.lblRegionalTV.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblLocalTV
        '
        Me.lblLocalTV.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblLocalTV.Location = New System.Drawing.Point(72, 16)
        Me.lblLocalTV.Name = "lblLocalTV"
        Me.lblLocalTV.Size = New System.Drawing.Size(104, 20)
        Me.lblLocalTV.TabIndex = 36
        Me.lblLocalTV.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnRegionalTV
        '
        Me.btnRegionalTV.Location = New System.Drawing.Point(184, 40)
        Me.btnRegionalTV.Name = "btnRegionalTV"
        Me.btnRegionalTV.Size = New System.Drawing.Size(40, 20)
        Me.btnRegionalTV.TabIndex = 35
        Me.btnRegionalTV.Text = "..."
        '
        'btnLocalTV
        '
        Me.btnLocalTV.Location = New System.Drawing.Point(184, 16)
        Me.btnLocalTV.Name = "btnLocalTV"
        Me.btnLocalTV.Size = New System.Drawing.Size(40, 20)
        Me.btnLocalTV.TabIndex = 34
        Me.btnLocalTV.Text = "..."
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(8, 16)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(64, 16)
        Me.Label7.TabIndex = 32
        Me.Label7.Text = "Local TV"
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(8, 40)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(72, 16)
        Me.Label8.TabIndex = 31
        Me.Label8.Text = "Regional TV"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label10, Me.Label9})
        Me.GroupBox1.Location = New System.Drawing.Point(8, 144)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(240, 104)
        Me.GroupBox1.TabIndex = 27
        Me.GroupBox1.TabStop = False
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(8, 16)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(224, 32)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Note:  Most marketing and media items are negotiated at the beginning of the seas" & _
        "on. "
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(8, 56)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(224, 40)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Also, smaller markets may not have exposure to regional, national or prime televi" & _
        "sion coverage."
        '
        'frmTeamMedia
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(506, 287)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox1, Me.grpBasic, Me.btnOK, Me.grpLocalMedia, Me.grpRegionalMedia, Me.grpNationalMedia})
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmTeamMedia"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Team Media"
        Me.grpBasic.ResumeLayout(False)
        Me.grpLocalMedia.ResumeLayout(False)
        Me.grpNationalMedia.ResumeLayout(False)
        Me.grpRegionalMedia.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub SetScreen(ByVal TeamID As Integer)
        Dim tm As New MediaSet
        gs.SkinForm(Me)
        tm.Load(TeamID)

        With tm
            Me.lblBasic.Text = Format(.Item(MediaSet.MediaType.Basic).GetDollars, MONEY_FORMAT)
            Me.lblBooster.Text = Format(.Item(MediaSet.MediaType.Booster).GetDollars, MONEY_FORMAT)
            Me.lblInternet.Text = Format(.Item(MediaSet.MediaType.Internet).GetDollars, MONEY_FORMAT)
            Me.lblLocalTV.Text = Format(.Item(MediaSet.MediaType.LocalTV).GetDollars, MONEY_FORMAT)
            Me.lblNationalTV.Text = Format(.Item(MediaSet.MediaType.NationalTV).GetDollars, MONEY_FORMAT)
            Me.lblNewsprint.Text = Format(.Item(MediaSet.MediaType.Newsprint).GetDollars, MONEY_FORMAT)
            Me.lblOutdoor.Text = Format(.Item(MediaSet.MediaType.Outdoor).GetDollars, MONEY_FORMAT)
            Me.lblPrimeTV.Text = Format(.Item(MediaSet.MediaType.PrimeTV).GetDollars, MONEY_FORMAT)
            Me.lblRadio.Text = Format(.Item(MediaSet.MediaType.Radio).GetDollars, MONEY_FORMAT)
            Me.lblRegionalTV.Text = Format(.Item(MediaSet.MediaType.RegionalTV).GetDollars, MONEY_FORMAT)
        End With
    End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Me.Close()
    End Sub
End Class
