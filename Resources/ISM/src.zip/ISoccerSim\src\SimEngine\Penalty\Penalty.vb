'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace SimEngine.Penalty

    Public Enum ISM_PenaltyType
        Player = 0
        Team = 1
        Goalie = 2
    End Enum

    Public Enum ISM_CardThrown
        Regular = 0
        Blue = 1
        Yellow = 2
        Red = 3
    End Enum

    Public Class Penalty
        Implements ICloneable

        Public Name As String
        Public IsAutomaticBlue As Boolean
        Public IsAutomaticRed As Boolean
        Public Type As ISM_PenaltyType
        Public Severity As ISM_CardThrown

        Dim r As MathService = MathService.GetInstance

        Public Sub SetSeverity(ByVal Player As Players.Player)
            If Me.IsAutomaticBlue Then
                Me.Severity = ISM_CardThrown.Blue
                Exit Sub
            End If

            If Me.IsAutomaticRed Then
                Me.Severity = ISM_CardThrown.Red
                Exit Sub
            End If

            Dim Aggression As Integer = Player.Ratings(Ratings.ISS_Rating.Aggression)
            Me.Severity = IIf(((Aggression + 1) / 3) > r.RandomNumber(1, 100), ISM_CardThrown.Blue, ISM_CardThrown.Regular)
        End Sub

        Public Function IsTimePenalty() As Boolean
            Return IIf(Me.Severity <> ISM_CardThrown.Regular, True, False)
        End Function

        Public Sub AugmentPenaltyMinutes(ByVal Player As Players.Player)
            Select Case Me.Severity
                Case ISM_CardThrown.Blue
                    Player.Stats.Augment(Statistics.ISMStat.PenaltyMinutes, 2)
                Case ISM_CardThrown.Red
                    Player.Stats.Augment(Statistics.ISMStat.PenaltyMinutes, 5)
            End Select
        End Sub

        Public Function GetAbsoluteSeconds() As Integer
            If Me.IsTimePenalty Then
                If Me.Severity = ISM_CardThrown.Blue Then Return 2 * 60
                If Me.Severity = ISM_CardThrown.Yellow Then Return 5 * 60
            End If
        End Function

        Public Function IsPowerPlay() As Integer
            Return IIf(Me.Severity = ISM_CardThrown.Blue, True, False)
        End Function

        Public Function CanSubstituteAnotherPlayer() As Integer
            Return IIf(Me.Severity <> ISM_CardThrown.Blue, True, False)
        End Function

        Function Clone() As Object Implements ICloneable.Clone
            Return Me.MemberwiseClone
        End Function
    End Class
End Namespace