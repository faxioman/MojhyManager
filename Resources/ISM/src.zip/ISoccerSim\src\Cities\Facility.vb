'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Cities
    Public Class Facility
        Public City As City
        Public Name As String
        Public Capacity As Integer
        Public FacilityID As Integer
        Public CityID As Integer

        Dim r As MathService = MathService.GetInstance


        Sub New()
            'Pass
        End Sub

        Sub InsertRandom(ByVal City As City)
            Me.City = City
            Me.CityID = City.CityID
            Me.Name = Me.GetFacilityName
            Me.Capacity = Me.GetFacilityCapacity
            Me.Insert()
        End Sub

        Function GetFacilityName() As String

            Dim I As Integer
            I = r.RandomNumber(1, 100)
            Select Case I
                Case Is < 40
                    GetFacilityName = Me.City.City & " Convention Center"
                Case Is < 80
                    GetFacilityName = Me.City.City & " Arena"
                Case Else
                    GetFacilityName = Me.City.City & " Civic Center"
            End Select

        End Function

        Function GetFacilityCapacity() As Integer

            If Me.City.Population > 800000 Then
                Return GetLargeMarketCapacity()
            Else
                Return GetSmallMarketCapacity()
            End If

        End Function

        Private Function GetSmallMarketCapacity()
            Dim x As Integer = Me.City.Population / 100
            Dim g As New GaussService(x, 4000, Me.City.Population / 90, Me.City.Population / 110)
            Dim Result As Integer
            Result = g.GetNextInt
            If Result < 4000 Then Result = r.RandomNumber(4000, 4100)
            Return Result

        End Function

        Public Function GetExpectedAttendance() As Integer
            If Me.City.Population > 800000 Then
                Return GetLargeMarketExpectedAttendance()
            Else
                Return GetSmallMarketExpectedAttendance()
            End If
        End Function

        Private Function GetLargeMarketExpectedAttendance() As Integer
            Return (r.RandomNumber(25, 35) * 0.01) * Me.Capacity
        End Function

        Private Function GetSmallMarketExpectedAttendance() As Integer
            Return (r.RandomNumber(35, 45) * 0.01) * Me.Capacity
        End Function

        Private Function GetLargeMarketCapacity() As Integer
            Dim Result As Integer
            Dim g As New GaussService(18000, 1500, 12000, 24000)
            Result = g.GetNextInt
            If Result < 11000 Then Result = r.RandomNumber(11000, 12500)

            Return Result
        End Function

        Sub Load()
            Dim Data As New DataServices.TeamTables()
            Dim DR As OleDb.OleDbDataReader = Data.GetFacility(Me.FacilityID)

            Do While DR.Read()
                With DR
                    Me.CityID = .Item("CityID")
                    Me.FacilityID = .Item("FacilityID")
                    Me.Name = .Item("Name")
                    Me.Capacity = .Item("Capacity")
                End With
            Loop
            DR.Close()
            Data.Close()

        End Sub

        Sub Load(ByVal intFacilityID As Integer)
            Me.FacilityID = intFacilityID
            Call Load()
        End Sub

        Public Function Insert() As Integer
            Dim Data As New DataServices.TeamTables()
            Me.FacilityID = Data.InsertFacility(Me)
            Return Me.FacilityID
        End Function

    End Class
End Namespace