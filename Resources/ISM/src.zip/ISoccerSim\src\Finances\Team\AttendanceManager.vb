'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Namespace Finances.Team
    Public Class AttendanceManager
        Public LeagueAverageAttendance As Integer = 5400
        Public MediaSet As New MediaSet
        Public Capacity As Integer = 14512

        Public StarPlayer As New AttendanceMatchup(0.03, 0, 0.1)
        Public DivisionRival As New AttendanceMatchup(0.04, 0)
        Public ConferenceRival As New AttendanceMatchup(0.02, 0)
        Public PivotalGame As New AttendanceMatchup(0.06, 0)
        Public PlayoffRival As New AttendanceMatchup(0.07, 0)
        Public LeadingRival As New AttendanceMatchup(0.08, 0)
        Public HomeTeamWinning As New AttendanceMatchup(0.1, 0)
        Public HomeTeamLeading As New AttendanceMatchup(0.15, 0)
        Public ChampionshipGame As New AttendanceMatchup(0.5, 0, 0.4)
        Public FirstHomeGame As New AttendanceMatchup(0.4, 0, 0.3)
        Public MiddlePackTeam As New AttendanceMatchup(0.05, 0)
        Public LosingTeam As New AttendanceMatchup(0.4, 0, 0.2)
        Public FacilityModifier As New AttendanceMatchup
        Public IsSellout As Boolean

        Dim r As MathService = MathService.GetInstance

        Public Sub New(ByVal MediaSet As MediaSet)
            Me.MediaSet = MediaSet
        End Sub

        Public Enum HomeTeamRecord
            Leading = 1
            Winning = 2
            MiddlePack = 3
            LosingTeam = 4
            EarlySeason = 5
        End Enum


        Public Function Compute() As Integer
            Dim Result As Integer
            Result = LeagueAverageAttendance + Me.GetMediaContribution + Me.GetGameNightContribution
            IsSellout = False
            If Result > Capacity Then
                Result = Capacity
                IsSellout = True
            End If

            If Result < Capacity * 0.1 Then Result = Capacity * 0.1 + r.RandomNumber(1, 400)
            Return Result
        End Function

        Public Function GetMediaContribution() As Integer
            Return (Me.LeagueAverageAttendance * MediaSet.GetActualAttendanceBonus())
        End Function

        Public Function GetGameNightContribution() As Integer
            Return Me.LeagueAverageAttendance * Me.GetGameNightModifiers
        End Function

        Public Function GetGameNightModifiers() As Double
            Return Me.ChampionshipGame.GetRandomModifier + Me.ConferenceRival.GetRandomModifier + _
                    Me.DivisionRival.GetRandomModifier + Me.FirstHomeGame.GetRandomModifier + _
                    Me.HomeTeamLeading.GetRandomModifier + Me.HomeTeamWinning.GetRandomModifier + _
                    Me.LeadingRival.GetRandomModifier + Me.PivotalGame.GetRandomModifier + _
                    Me.PlayoffRival.GetRandomModifier + Me.StarPlayer.GetRandomModifier - _
                    Me.LosingTeam.GetRandomModifier() + Me.FacilityModifier.GetRandomModifier
        End Function

        Public Sub SetAmounts(ByVal ChampionshipGame As Boolean, ByVal ConferenceRival As Boolean, _
                    ByVal DivisionRival As Boolean, ByVal FirstHomeGame As Boolean, _
                    ByVal LeadingRival As Boolean, ByVal PivotalGame As Boolean, _
                    ByVal PlayoffRival As Boolean, ByVal StarPlayers As Integer, _
                    ByVal TeamStanding As HomeTeamRecord, ByVal FacilityPercentage As Double)

            Me.ChampionshipGame.Amount = IIf(ChampionshipGame, 1, 0)
            Me.ConferenceRival.Amount = IIf(ConferenceRival, 1, 0)
            Me.DivisionRival.Amount = IIf(DivisionRival, 1, 0)
            Me.FirstHomeGame.Amount = IIf(FirstHomeGame, 1, 0)
            Me.LeadingRival.Amount = IIf(LeadingRival, 1, 0)
            Me.PlayoffRival.Amount = IIf(PlayoffRival, 1, 0)
            Me.PivotalGame.Amount = IIf(PivotalGame, 1, 0)
            Me.StarPlayer.Amount = StarPlayers

            Me.FacilityModifier.Percentage = FacilityPercentage
            Me.FacilityModifier.MinimumPercentage = FacilityPercentage * 0.75

            Call SetTeamStanding(TeamStanding)
        End Sub

        Public Sub SetTeamStanding(ByVal TeamStanding)
            Select Case TeamStanding
                Case HomeTeamRecord.Leading
                    Me.HomeTeamLeading.Amount = 1
                    Me.HomeTeamWinning.Amount = 1
                    Me.MiddlePackTeam.Amount = 1
                    Me.LosingTeam.Amount = 0
                Case HomeTeamRecord.Winning
                    Me.HomeTeamLeading.Amount = 0
                    Me.HomeTeamWinning.Amount = 1
                    Me.MiddlePackTeam.Amount = 1
                    Me.LosingTeam.Amount = 0
                Case HomeTeamRecord.MiddlePack
                    Me.HomeTeamLeading.Amount = 0
                    Me.HomeTeamWinning.Amount = 0
                    Me.MiddlePackTeam.Amount = 1
                    Me.LosingTeam.Amount = 0

                Case HomeTeamRecord.EarlySeason
                    Me.HomeTeamLeading.Amount = 0
                    Me.HomeTeamWinning.Amount = 1
                    Me.MiddlePackTeam.Amount = 1
                    Me.LosingTeam.Amount = 0

                Case HomeTeamRecord.LosingTeam
                    Me.HomeTeamLeading.Amount = 0
                    Me.HomeTeamWinning.Amount = 0
                    Me.MiddlePackTeam.Amount = 0
                    Me.LosingTeam.Amount = 1
            End Select

        End Sub
    End Class
End Namespace
