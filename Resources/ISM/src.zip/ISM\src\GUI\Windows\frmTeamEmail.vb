'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Email
Imports ISoccerSim.Utility.GUI
Imports ISoccerSim.Utility.DataGrid

Public Class frmTeamEmail
    Inherits System.Windows.Forms.Form

    Dim gs As GUIService = GUIService.GetInstance
    Dim mTotalRows As Integer = 0

    Sub SetScreen()
        Me.tcmbTeam.LoadTeams()
        gs.SkinForm(Me)
        LoadGrid()
    End Sub

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Call SetScreen()
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Public WithEvents grpContent As System.Windows.Forms.GroupBox
    Public WithEvents btnOK As System.Windows.Forms.Button
    Public WithEvents Label3 As System.Windows.Forms.Label
    Public WithEvents tcmbTeam As TeamCombo
    Public WithEvents dgEmail As System.Windows.Forms.DataGrid
    Public WithEvents btnEmptyInbox As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.grpContent = New System.Windows.Forms.GroupBox
        Me.tcmbTeam = New TeamCombo
        Me.Label3 = New System.Windows.Forms.Label
        Me.dgEmail = New System.Windows.Forms.DataGrid
        Me.btnOK = New System.Windows.Forms.Button
        Me.btnEmptyInbox = New System.Windows.Forms.Button
        Me.grpContent.SuspendLayout()
        CType(Me.dgEmail, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grpContent
        '
        Me.grpContent.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpContent.Controls.Add(Me.tcmbTeam)
        Me.grpContent.Controls.Add(Me.Label3)
        Me.grpContent.Controls.Add(Me.dgEmail)
        Me.grpContent.Location = New System.Drawing.Point(8, 24)
        Me.grpContent.Name = "grpContent"
        Me.grpContent.Size = New System.Drawing.Size(688, 272)
        Me.grpContent.TabIndex = 3
        Me.grpContent.TabStop = False
        Me.grpContent.Text = "Messages"
        '
        'tcmbTeam
        '
        Me.tcmbTeam.Location = New System.Drawing.Point(88, 16)
        Me.tcmbTeam.Name = "tcmbTeam"
        Me.tcmbTeam.Size = New System.Drawing.Size(256, 24)
        Me.tcmbTeam.TabIndex = 25
        Me.tcmbTeam.TeamID = -1
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 24)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "Team:"
        '
        'dgEmail
        '
        Me.dgEmail.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgEmail.DataMember = ""
        Me.dgEmail.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgEmail.Location = New System.Drawing.Point(8, 48)
        Me.dgEmail.Name = "dgEmail"
        Me.dgEmail.Size = New System.Drawing.Size(672, 216)
        Me.dgEmail.TabIndex = 0
        '
        'btnOK
        '
        Me.btnOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnOK.Location = New System.Drawing.Point(584, 304)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(112, 24)
        Me.btnOK.TabIndex = 4
        Me.btnOK.Text = "&OK"
        '
        'btnEmptyInbox
        '
        Me.btnEmptyInbox.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnEmptyInbox.Location = New System.Drawing.Point(8, 304)
        Me.btnEmptyInbox.Name = "btnEmptyInbox"
        Me.btnEmptyInbox.Size = New System.Drawing.Size(112, 24)
        Me.btnEmptyInbox.TabIndex = 5
        Me.btnEmptyInbox.Text = "&Empty Inbox"
        '
        'frmTeamEmail
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(704, 341)
        Me.Controls.Add(Me.btnEmptyInbox)
        Me.Controls.Add(Me.grpContent)
        Me.Controls.Add(Me.btnOK)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmTeamEmail"
        Me.Text = "frmEmail"
        Me.grpContent.ResumeLayout(False)
        CType(Me.dgEmail, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Sub LoadGrid()
        gs.SetCursor(True, Me)
        Dim View As New DataViewUtility

        Dim dg As DataGrid = Me.dgEmail
        Dim Base As New DataServices.BaseTables

        View.Standardize(Base.GetEmailsForGrid(Me.tcmbTeam.TeamID))
        mTotalRows = View.Table.Rows.Count

        With dg
            .DataSource = View
            .CaptionText = Me.tcmbTeam.Text & " Inbox"
        End With

        Dim Helper As New DataGridUtility(dg, "Emails")
        With Helper
            .SetEmailGrid()
            .Commit()
        End With

        gs.SetCursor(False, Me)

    End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Me.Close()
        
    End Sub

    Private Sub dgEmail_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgEmail.MouseUp
        Dim pt As New Point(e.X, e.Y)
        Dim hti As DataGrid.HitTestInfo = Me.dgEmail.HitTest(pt)
        Dim ID As Integer

        If hti.Type = DataGrid.HitTestType.Cell Or hti.Type = DataGrid.HitTestType.RowHeader Then
            Me.dgEmail.CurrentCell = New DataGridCell(hti.Row, hti.Column)
            If hti.Column <> 2 Then 'ignore zoom for checkbox column.
                Me.dgEmail.Select(hti.Row)

                If e.Button = MouseButtons.Left Then
                    ID = Int(Me.dgEmail(hti.Row, 0))
                    Dim f As New frmEmailDetail(ID)
                    f.ShowDialog()
                    Call LoadGrid()
                End If
            End If
        End If
    End Sub

    Private Sub tcmbTeam_SelectionChanged(ByVal sender As Object, ByVal e As TeamSelectedEventArgs) Handles tcmbTeam.SelectionChanged
        Call LoadGrid()
    End Sub

    Private Sub btnEmptyInbox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEmptyInbox.Click
        Dim i As Integer
        Dim es As New EmailSet

        For i = 0 To mTotalRows - 1
            es.RemoveByID(Me.dgEmail(i, 0))
        Next
        Call LoadGrid()
    End Sub
End Class
