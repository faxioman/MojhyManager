'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.SimEngine

Public Class frmGameResults
	Inherits System.Windows.Forms.Form

	Private GameEngine As GameEngine
	Private mintGameID As Integer
    Dim Sim As Simulation = Simulation.GetInstance()
    Dim gs As GUIService = GUIService.GetInstance
    Dim fs As FileService = FileService.GetInstance

#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		SetScreen()
	End Sub


	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Public WithEvents btnOK As System.Windows.Forms.Button
	Public WithEvents grpSummary As System.Windows.Forms.GroupBox
	Public WithEvents webGameLog As AxSHDocVw.AxWebBrowser
	Public WithEvents btnBoxScore As System.Windows.Forms.Button
	Public WithEvents btnGameLog As System.Windows.Forms.Button
	Public WithEvents btnPlayByPlay As System.Windows.Forms.Button
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmGameResults))
		Me.btnOK = New System.Windows.Forms.Button()
		Me.btnBoxScore = New System.Windows.Forms.Button()
		Me.btnGameLog = New System.Windows.Forms.Button()
		Me.grpSummary = New System.Windows.Forms.GroupBox()
		Me.webGameLog = New AxSHDocVw.AxWebBrowser()
		Me.btnPlayByPlay = New System.Windows.Forms.Button()
		Me.grpSummary.SuspendLayout()
		CType(Me.webGameLog, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'btnOK
		'
		Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnOK.Location = New System.Drawing.Point(664, 488)
		Me.btnOK.Name = "btnOK"
		Me.btnOK.Size = New System.Drawing.Size(112, 24)
		Me.btnOK.TabIndex = 2
		Me.btnOK.Text = "OK"
		'
		'btnBoxScore
		'
		Me.btnBoxScore.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)
		Me.btnBoxScore.Location = New System.Drawing.Point(8, 488)
		Me.btnBoxScore.Name = "btnBoxScore"
		Me.btnBoxScore.Size = New System.Drawing.Size(112, 24)
		Me.btnBoxScore.TabIndex = 12
		Me.btnBoxScore.Text = "&Box Score"
		'
		'btnGameLog
		'
		Me.btnGameLog.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)
		Me.btnGameLog.Location = New System.Drawing.Point(128, 488)
		Me.btnGameLog.Name = "btnGameLog"
		Me.btnGameLog.Size = New System.Drawing.Size(112, 24)
		Me.btnGameLog.TabIndex = 13
		Me.btnGameLog.Text = "&Event Log"
		'
		'grpSummary
		'
		Me.grpSummary.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
					Or System.Windows.Forms.AnchorStyles.Left) _
					Or System.Windows.Forms.AnchorStyles.Right)
		Me.grpSummary.Controls.AddRange(New System.Windows.Forms.Control() {Me.webGameLog})
		Me.grpSummary.Location = New System.Drawing.Point(8, 8)
		Me.grpSummary.Name = "grpSummary"
		Me.grpSummary.Size = New System.Drawing.Size(768, 472)
		Me.grpSummary.TabIndex = 14
		Me.grpSummary.TabStop = False
		'
		'webGameLog
		'
		Me.webGameLog.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
					Or System.Windows.Forms.AnchorStyles.Left) _
					Or System.Windows.Forms.AnchorStyles.Right)
		Me.webGameLog.ContainingControl = Me
		Me.webGameLog.Enabled = True
		Me.webGameLog.Location = New System.Drawing.Point(8, 16)
		Me.webGameLog.OcxState = CType(resources.GetObject("webGameLog.OcxState"), System.Windows.Forms.AxHost.State)
		Me.webGameLog.Size = New System.Drawing.Size(752, 448)
		Me.webGameLog.TabIndex = 0
		'
		'btnPlayByPlay
		'
		Me.btnPlayByPlay.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)
		Me.btnPlayByPlay.Location = New System.Drawing.Point(248, 488)
		Me.btnPlayByPlay.Name = "btnPlayByPlay"
		Me.btnPlayByPlay.Size = New System.Drawing.Size(112, 24)
		Me.btnPlayByPlay.TabIndex = 15
		Me.btnPlayByPlay.Text = "&Play By Play"
		'
		'frmGameResults
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.BackColor = System.Drawing.Color.FromArgb(CType(43, Byte), CType(72, Byte), CType(142, Byte))
		Me.ClientSize = New System.Drawing.Size(784, 517)
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnPlayByPlay, Me.btnGameLog, Me.btnBoxScore, Me.btnOK, Me.grpSummary})
		Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.ForeColor = System.Drawing.Color.Gainsboro
		Me.MinimizeBox = False
		Me.Name = "frmGameResults"
		Me.ShowInTaskbar = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.Text = "Game Results"
		Me.grpSummary.ResumeLayout(False)
		CType(Me.webGameLog, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub frmDialog_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
		'Add standard error handler
		AddHandler Application.ThreadException, New ThreadExceptionEventHandler(AddressOf HandleException)
	End Sub

	Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		Me.Close()

	End Sub

	Public Sub LoadData(ByVal GameEngine As GameEngine)
        Me.webGameLog.Navigate2(fs.GetTempBoxScoreFilePath(Sim.League.Name))
        Me.btnGameLog.Enabled = fs.Exists(fs.GetTempGameEventLogFilePath(Sim.League.Name))
        Me.btnPlayByPlay.Enabled = fs.Exists(fs.GetTempGameLogFilePath(Sim.League.Name))
		mintGameID = 0
	End Sub

	Public Sub LoadGame(ByVal GameID As Integer)
		mintGameID = GameID
        Me.webGameLog.Navigate2(fs.GetScheduledGameBoxFileName(Sim.League.Name, GameID))
        Me.btnGameLog.Enabled = fs.Exists(fs.GetScheduledEventLogFileName(Sim.League.Name, GameID))
        Me.btnPlayByPlay.Enabled = fs.Exists(fs.GetScheduledPBPFileName(Sim.League.Name, GameID))
	End Sub

	Private Sub SetScreen()
		Call gs.SetCursor(me)
        Call gs.SkinForm(Me)
	End Sub

	Private Sub btnGameLog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGameLog.Click
		If mintGameID = 0 Then
            Me.webGameLog.Navigate2(fs.GetTempGameEventLogFilePath(Sim.League.Name))
		Else
            Me.webGameLog.Navigate2(fs.GetScheduledEventLogFileName(Sim.League.Name, mintGameID))
		End If
	End Sub

	Private Sub btnBoxScore_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBoxScore.Click
		If mintGameID = 0 Then
            Me.webGameLog.Navigate2(fs.GetTempBoxScoreFilePath(Sim.League.Name))
		Else
            Me.webGameLog.Navigate2(fs.GetScheduledGameBoxFileName(Sim.League.Name, mintGameID))
        End If
	End Sub

	Private Sub btnPlayByPlay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPlayByPlay.Click
		If mintGameID = 0 Then
            Me.webGameLog.Navigate2(fs.GetTempGameLogFilePath(Sim.League.Name))
		Else
            Me.webGameLog.Navigate2(fs.GetScheduledPBPFileName(Sim.League.Name, mintGameID))
		End If
	End Sub
End Class
