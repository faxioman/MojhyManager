'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports System.Collections

Namespace SimEngine
	Public Class Clock

		Public Quarter As Integer
		Public Time As New Date(2, 1, 1, 0, 15, 0, 0)
		Public Scoreboard As New Scoreboard()
		Public Posession As New Posession(Me.GameEngine)
		Public GameEngine As GameEngine

        Private mblnQuarterToggle As Boolean = False
        Dim r As MathService = MathService.GetInstance

		Sub New(ByVal GameEngine As GameEngine)
			Me.GameEngine = GameEngine
		End Sub

		Public Event EndOfGame()
		Public Event EndOfQuarter()

		Sub Tick(ByVal intLow As Integer, ByVal intHigh As Integer)
            Dim x As Integer = r.RandomNumber(intLow, intHigh)
			Call Tick(x)
		End Sub

		Sub Tick(ByVal intSeconds As Integer)
            intSeconds = intSeconds + r.RandomNumber(2, 4)   '4

			If Me.Time.Minute = 0 And Me.Time.Second < intSeconds Then
				intSeconds = Me.Time.Second
			End If

			Me.GameEngine.Posession.Defense.FieldManager.Field.AddFieldMinutes(intSeconds)
			Me.GameEngine.Posession.Offense.FieldManager.Field.AddFieldMinutes(intSeconds)
			Me.Time = Me.Time.AddSeconds(-(intSeconds))
			'Console.WriteLine(Me.ToString())
			If Me.Time.Year = 1 Then
				Me.Time = New Date(2, 1, 1, 0, 0, 0, 0)
				If Me.Quarter >= 4 Then
					If IsTied() = False Then
						RaiseEvent EndOfGame()
					Else
						RaiseEvent EndOfQuarter()
					End If
				Else
					RaiseEvent EndOfQuarter()
				End If
			End If
		End Sub

		Sub Start()
			Me.Quarter = 1
		End Sub

		Sub Reset()
			Me.Quarter = Me.Quarter + 1
			Me.Time = New Date(2, 1, 1, 0, 15, 0, 0)
		End Sub

		Function IsClockEnd() As Boolean
			Return Me.IsEndOfGame Or Me.IsEndOfQuarter
		End Function

		Function IsEndOfHalf() As Boolean
			Select Case Me.Quarter
				Case 2, 4, 6, 8, 10
					Return True
			End Select
		End Function

		Function IsEndOfQuarter() As Boolean
			If Me.Time.Minute = 0 And Me.Time.Second = 0 Then
				Return True
			Else
				Return False
			End If
		End Function

		Function IsEndOfGame() As Boolean
			If Me.Time.Minute = 0 And Me.Time.Second = 0 Then
				If Me.Quarter >= 4 Then
					If IsTied() = False Then
						Return True
					End If
				End If
			Else
				If Me.Quarter > 4 Then
					If IsTied() = False Then
						Return True
					End If
				End If
			End If
			Return False

		End Function

		Private Function IsTied() As Boolean
			If Me.GameEngine.Posession.HomeTeam.Scoreboard.Score = Me.GameEngine.Posession.AwayTeam.Scoreboard.Score Then
				Return True
			Else
				Return False
			End If
		End Function

		Function GetOrdinal() As String
			Select Case Me.Quarter
				Case 1
					Return "1st Quarter"
				Case 2
					Return "2nd Quarter"
				Case 3
					Return "3rd Quarter"
				Case 4
					Return "4th Quarter"
				Case Is > 4
					Return "Overtime"
			End Select
		End Function

		Function GetSituationMinute() As Integer
			Select Case Me.Quarter
				Case 2, 4
					Return 15 - Me.Time.Minute
				Case 1, 3
					Return 30 - Me.Time.Minute
				Case 5
					Return 1
			End Select
		End Function

		Overrides Function ToString() As String
			Return Me.Time.Minute & ":" & Format(Me.Time.Second, "00")
		End Function

		Public Function GetSummaryTime() As String
			Return Me.Time.Minute & ":" & Format(Me.Time.Second, "00")
        End Function

        Public Function GetAbsoluteTime() As Integer
            Return ((Me.Quarter - 1) * 60) + Me.Time.Minute + Me.Time.Second
        End Function

    End Class
End Namespace


