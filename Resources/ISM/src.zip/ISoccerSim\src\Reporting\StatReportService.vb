'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Utility.DataGrid

Namespace Reporting
    Public Class StatReportService

        Public Sub Create(ByVal Title As String, ByVal Stat As String, _
                          ByVal dg As System.Windows.Forms.DataGrid, _
                          ByVal Filename As String, _
                          ByVal RptFormatService As Reporting.ReportFormatService)

            Dim ColumnsToShow As New ArrayList
            Dim dt As System.Data.DataTable = CType(dg.DataSource, DataViewUtility).GetDataTable
            Dim r As New Report
            Dim rt As ReportTable = GetGenericTableHeader(dg)
            Dim Sim As Simulation = Simulation.GetInstance()

            r.Header = Sim.League.Name & " - " & Title
            rt.Data.Fill(dg, rt)
            rt.Header = Stat
            r.Add(rt)
            r.Generate(RptFormatService)
            r.Save(Filename)
        End Sub

        Public Function GetGenericTableHeader(ByVal dg As DataGrid) As ReportTable

            Dim Result As New ReportTable
            Dim service As New DataGridToReportService
            Dim col As DataGridReportColumn

            Dim i As Integer
            service.Create(dg)

            For i = 0 To service.Count - 1
                col = service.Item(i)
                Result.Create(col.HeaderText, col.Width, "", False, col.MappingName, col.MappingIndex)
            Next

            Return Result

        End Function


    End Class
End Namespace