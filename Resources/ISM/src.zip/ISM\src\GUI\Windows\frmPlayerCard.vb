'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.Positions
Imports ISoccerSim.Players
Imports ISoccerSim.Utility.DataGrid

Public Class frmPlayerCard
	Inherits System.Windows.Forms.Form

	Private mblnLoading As Boolean
	Private mblnDirty As Boolean
	Private mblnSaved As Boolean
	Private mintPlayerID As Integer
	Private marrPlayerArray As New ArrayList()
    Private mintArrayPos As Integer
    Private mintPosition As ISMPlayerPosition
    Private mstrCurrentTeam As String
    Private mstrPhotoName As String

    Dim gs As GUIService = GuiService.GetInstance


#Region " Windows Form Designer generated code "

	Sub New(ByVal intPlayerID As Integer, ByVal arlPlayersInGrid As ArrayList)
		MyBase.New()
		mintPlayerID = intPlayerID
		marrPlayerArray = arlPlayersInGrid

		'This call is required by the Windows Form Designer.
		InitializeComponent()


		'Add any initialization after the InitializeComponent() call
		Call SetScreen()
		Call LoadPlayer()
		Call NavigatePlayer(0)

	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Public WithEvents tipLeague As System.Windows.Forms.ToolTip
	Public WithEvents btnOK As System.Windows.Forms.Button
    Public WithEvents grpRatings As System.Windows.Forms.GroupBox
	Public WithEvents dgRatings As System.Windows.Forms.DataGrid
	Public WithEvents grpPlayerName As System.Windows.Forms.GroupBox
	Public WithEvents lblPlayerName As System.Windows.Forms.Label
	Public WithEvents btnPrev As System.Windows.Forms.Button
	Public WithEvents btnNext As System.Windows.Forms.Button
	Public WithEvents grpGeneral As System.Windows.Forms.GroupBox
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents lblPosition As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents txtAge As System.Windows.Forms.TextBox
	Public WithEvents txtFirstName As System.Windows.Forms.TextBox
	Public WithEvents txtLastName As System.Windows.Forms.TextBox
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents txtHometown As System.Windows.Forms.TextBox
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents txtHighSchool As System.Windows.Forms.TextBox
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents txtCollege As System.Windows.Forms.TextBox
    Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents txtJersey As System.Windows.Forms.TextBox
    Public WithEvents grpStatistics As System.Windows.Forms.GroupBox
    Public WithEvents dgScoring As System.Windows.Forms.DataGrid
    Public WithEvents dgDefense As System.Windows.Forms.DataGrid
    Public WithEvents txtHighlights As System.Windows.Forms.TextBox
    Public WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents picPhoto As System.Windows.Forms.PictureBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.btnOK = New System.Windows.Forms.Button
        Me.tipLeague = New System.Windows.Forms.ToolTip(Me.components)
        Me.grpRatings = New System.Windows.Forms.GroupBox
        Me.dgRatings = New System.Windows.Forms.DataGrid
        Me.grpPlayerName = New System.Windows.Forms.GroupBox
        Me.lblPlayerName = New System.Windows.Forms.Label
        Me.btnPrev = New System.Windows.Forms.Button
        Me.btnNext = New System.Windows.Forms.Button
        Me.grpGeneral = New System.Windows.Forms.GroupBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtJersey = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtCollege = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtHighSchool = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtHometown = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtAge = New System.Windows.Forms.TextBox
        Me.lblPosition = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtFirstName = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtLastName = New System.Windows.Forms.TextBox
        Me.grpStatistics = New System.Windows.Forms.GroupBox
        Me.txtHighlights = New System.Windows.Forms.TextBox
        Me.dgDefense = New System.Windows.Forms.DataGrid
        Me.dgScoring = New System.Windows.Forms.DataGrid
        Me.btnSave = New System.Windows.Forms.Button
        Me.picPhoto = New System.Windows.Forms.PictureBox
        Me.grpRatings.SuspendLayout()
        CType(Me.dgRatings, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpPlayerName.SuspendLayout()
        Me.grpGeneral.SuspendLayout()
        Me.grpStatistics.SuspendLayout()
        CType(Me.dgDefense, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgScoring, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnOK
        '
        Me.btnOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnOK.Location = New System.Drawing.Point(722, 498)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(112, 24)
        Me.btnOK.TabIndex = 4
        Me.btnOK.Text = "&OK"
        '
        'grpRatings
        '
        Me.grpRatings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpRatings.Controls.Add(Me.dgRatings)
        Me.grpRatings.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpRatings.Location = New System.Drawing.Point(496, 40)
        Me.grpRatings.Name = "grpRatings"
        Me.grpRatings.Size = New System.Drawing.Size(344, 448)
        Me.grpRatings.TabIndex = 15
        Me.grpRatings.TabStop = False
        Me.grpRatings.Text = "Ratings"
        '
        'dgRatings
        '
        Me.dgRatings.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgRatings.DataMember = ""
        Me.dgRatings.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgRatings.Location = New System.Drawing.Point(8, 16)
        Me.dgRatings.Name = "dgRatings"
        Me.dgRatings.Size = New System.Drawing.Size(328, 424)
        Me.dgRatings.TabIndex = 11
        '
        'grpPlayerName
        '
        Me.grpPlayerName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpPlayerName.Controls.Add(Me.lblPlayerName)
        Me.grpPlayerName.Location = New System.Drawing.Point(8, 8)
        Me.grpPlayerName.Name = "grpPlayerName"
        Me.grpPlayerName.Size = New System.Drawing.Size(832, 32)
        Me.grpPlayerName.TabIndex = 16
        Me.grpPlayerName.TabStop = False
        '
        'lblPlayerName
        '
        Me.lblPlayerName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblPlayerName.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlayerName.Location = New System.Drawing.Point(16, 8)
        Me.lblPlayerName.Name = "lblPlayerName"
        Me.lblPlayerName.Size = New System.Drawing.Size(800, 16)
        Me.lblPlayerName.TabIndex = 0
        Me.lblPlayerName.Text = "Player Name"
        Me.lblPlayerName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnPrev
        '
        Me.btnPrev.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPrev.Location = New System.Drawing.Point(8, 496)
        Me.btnPrev.Name = "btnPrev"
        Me.btnPrev.Size = New System.Drawing.Size(112, 24)
        Me.btnPrev.TabIndex = 17
        Me.btnPrev.Text = "&Previous"
        '
        'btnNext
        '
        Me.btnNext.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNext.Location = New System.Drawing.Point(128, 496)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(112, 24)
        Me.btnNext.TabIndex = 18
        Me.btnNext.Text = "&Next"
        '
        'grpGeneral
        '
        Me.grpGeneral.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpGeneral.Controls.Add(Me.Label8)
        Me.grpGeneral.Controls.Add(Me.txtJersey)
        Me.grpGeneral.Controls.Add(Me.Label7)
        Me.grpGeneral.Controls.Add(Me.txtCollege)
        Me.grpGeneral.Controls.Add(Me.Label6)
        Me.grpGeneral.Controls.Add(Me.txtHighSchool)
        Me.grpGeneral.Controls.Add(Me.Label5)
        Me.grpGeneral.Controls.Add(Me.txtHometown)
        Me.grpGeneral.Controls.Add(Me.Label4)
        Me.grpGeneral.Controls.Add(Me.txtAge)
        Me.grpGeneral.Controls.Add(Me.lblPosition)
        Me.grpGeneral.Controls.Add(Me.Label3)
        Me.grpGeneral.Controls.Add(Me.Label2)
        Me.grpGeneral.Controls.Add(Me.txtFirstName)
        Me.grpGeneral.Controls.Add(Me.Label1)
        Me.grpGeneral.Controls.Add(Me.txtLastName)
        Me.grpGeneral.Location = New System.Drawing.Point(80, 40)
        Me.grpGeneral.Name = "grpGeneral"
        Me.grpGeneral.Size = New System.Drawing.Size(408, 120)
        Me.grpGeneral.TabIndex = 19
        Me.grpGeneral.TabStop = False
        Me.grpGeneral.Text = "General"
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(192, 64)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(56, 16)
        Me.Label8.TabIndex = 23
        Me.Label8.Text = "Jersey #:"
        '
        'txtJersey
        '
        Me.txtJersey.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtJersey.Location = New System.Drawing.Point(264, 64)
        Me.txtJersey.MaxLength = 2
        Me.txtJersey.Name = "txtJersey"
        Me.txtJersey.Size = New System.Drawing.Size(32, 20)
        Me.txtJersey.TabIndex = 22
        Me.txtJersey.Text = ""
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(192, 88)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(64, 16)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "College:"
        '
        'txtCollege
        '
        Me.txtCollege.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCollege.Location = New System.Drawing.Point(264, 88)
        Me.txtCollege.MaxLength = 50
        Me.txtCollege.Name = "txtCollege"
        Me.txtCollege.Size = New System.Drawing.Size(136, 20)
        Me.txtCollege.TabIndex = 15
        Me.txtCollege.Text = ""
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(192, 40)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(72, 16)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "High School:"
        '
        'txtHighSchool
        '
        Me.txtHighSchool.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHighSchool.Location = New System.Drawing.Point(264, 40)
        Me.txtHighSchool.MaxLength = 50
        Me.txtHighSchool.Name = "txtHighSchool"
        Me.txtHighSchool.Size = New System.Drawing.Size(136, 20)
        Me.txtHighSchool.TabIndex = 13
        Me.txtHighSchool.Text = ""
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(192, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 16)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Home town:"
        '
        'txtHometown
        '
        Me.txtHometown.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHometown.Location = New System.Drawing.Point(264, 16)
        Me.txtHometown.MaxLength = 50
        Me.txtHometown.Name = "txtHometown"
        Me.txtHometown.Size = New System.Drawing.Size(136, 20)
        Me.txtHometown.TabIndex = 11
        Me.txtHometown.Text = ""
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(8, 88)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 16)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Age:"
        '
        'txtAge
        '
        Me.txtAge.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAge.Location = New System.Drawing.Point(80, 88)
        Me.txtAge.MaxLength = 2
        Me.txtAge.Name = "txtAge"
        Me.txtAge.Size = New System.Drawing.Size(32, 20)
        Me.txtAge.TabIndex = 9
        Me.txtAge.Text = ""
        '
        'lblPosition
        '
        Me.lblPosition.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPosition.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPosition.Location = New System.Drawing.Point(80, 64)
        Me.lblPosition.Name = "lblPosition"
        Me.lblPosition.Size = New System.Drawing.Size(32, 16)
        Me.lblPosition.TabIndex = 8
        Me.lblPosition.Text = "PO"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 16)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Position:"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(8, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 16)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "First name:"
        '
        'txtFirstName
        '
        Me.txtFirstName.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFirstName.Location = New System.Drawing.Point(80, 40)
        Me.txtFirstName.MaxLength = 50
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(104, 20)
        Me.txtFirstName.TabIndex = 4
        Me.txtFirstName.Text = ""
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 16)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Last name:"
        '
        'txtLastName
        '
        Me.txtLastName.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLastName.Location = New System.Drawing.Point(80, 16)
        Me.txtLastName.MaxLength = 50
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(104, 20)
        Me.txtLastName.TabIndex = 2
        Me.txtLastName.Text = ""
        '
        'grpStatistics
        '
        Me.grpStatistics.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpStatistics.Controls.Add(Me.txtHighlights)
        Me.grpStatistics.Controls.Add(Me.dgDefense)
        Me.grpStatistics.Controls.Add(Me.dgScoring)
        Me.grpStatistics.Location = New System.Drawing.Point(8, 160)
        Me.grpStatistics.Name = "grpStatistics"
        Me.grpStatistics.Size = New System.Drawing.Size(480, 328)
        Me.grpStatistics.TabIndex = 20
        Me.grpStatistics.TabStop = False
        Me.grpStatistics.Text = "Statistics/Highlights"
        '
        'txtHighlights
        '
        Me.txtHighlights.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtHighlights.Location = New System.Drawing.Point(8, 160)
        Me.txtHighlights.Multiline = True
        Me.txtHighlights.Name = "txtHighlights"
        Me.txtHighlights.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtHighlights.Size = New System.Drawing.Size(464, 160)
        Me.txtHighlights.TabIndex = 22
        Me.txtHighlights.Text = ""
        '
        'dgDefense
        '
        Me.dgDefense.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgDefense.DataMember = ""
        Me.dgDefense.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgDefense.Location = New System.Drawing.Point(8, 16)
        Me.dgDefense.Name = "dgDefense"
        Me.dgDefense.ParentRowsVisible = False
        Me.dgDefense.Size = New System.Drawing.Size(464, 144)
        Me.dgDefense.TabIndex = 2
        '
        'dgScoring
        '
        Me.dgScoring.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgScoring.DataMember = ""
        Me.dgScoring.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgScoring.Location = New System.Drawing.Point(8, 16)
        Me.dgScoring.Name = "dgScoring"
        Me.dgScoring.ParentRowsVisible = False
        Me.dgScoring.Size = New System.Drawing.Size(464, 144)
        Me.dgScoring.TabIndex = 1
        '
        'btnSave
        '
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSave.Location = New System.Drawing.Point(248, 496)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(104, 24)
        Me.btnSave.TabIndex = 22
        Me.btnSave.Text = "&Save"
        '
        'picPhoto
        '
        Me.picPhoto.BackColor = System.Drawing.Color.Black
        Me.picPhoto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picPhoto.Location = New System.Drawing.Point(8, 48)
        Me.picPhoto.Name = "picPhoto"
        Me.picPhoto.Size = New System.Drawing.Size(60, 80)
        Me.picPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPhoto.TabIndex = 30
        Me.picPhoto.TabStop = False
        '
        'frmPlayerCard
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(848, 525)
        Me.Controls.Add(Me.picPhoto)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.btnPrev)
        Me.Controls.Add(Me.grpPlayerName)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.grpStatistics)
        Me.Controls.Add(Me.grpGeneral)
        Me.Controls.Add(Me.grpRatings)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmPlayerCard"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Player Card"
        Me.grpRatings.ResumeLayout(False)
        CType(Me.dgRatings, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpPlayerName.ResumeLayout(False)
        Me.grpGeneral.ResumeLayout(False)
        Me.grpStatistics.ResumeLayout(False)
        CType(Me.dgDefense, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgScoring, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

	Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		Me.Close()
	End Sub

#Region "CustomSetup"

	Private Sub SetScreen()
		Call InitializeDefaults()
        Call gs.SetCursor(Me)
        gs.SkinForm(Me)
		Call SetPlayerArray()

	End Sub

	Private Sub SetPlayerArray()

		Dim i As Integer
		Dim pblnShowNav As Boolean = True

		For i = 0 To marrPlayerArray.Count - 1
			If marrPlayerArray.Item(i) = mintPlayerID Then
				mintArrayPos = i
			End If
		Next

		If marrPlayerArray.Count = 1 Then
			pblnShowNav = False
		End If

		Me.btnNext.Visible = pblnShowNav
		Me.btnPrev.Visible = pblnShowNav

	End Sub

	Private Sub InitializeDefaults()
		mblnLoading = True
        Me.btnSave.Enabled = False
		mblnSaved = True
		mblnLoading = False
	End Sub

	Private Sub LoadPlayer()

		Call LoadRatings()
        Call LoadGeneralInfo()
        Call LoadHighlights()
        Call LoadStats()
        Call LoadPhoto()
		mblnDirty = False
		Me.btnSave.Enabled = False

    End Sub

    Private Sub LoadPhoto()
        Dim photo As PhotoService = PhotoService.GetInstance
        Dim Filename As String = photo.GetPicture(mstrPhotoName)
        If mstrPhotoName <> "" And Dir(Filename) <> "" Then
            Me.picPhoto.Image = Image.FromFile(Filename)
            Me.picPhoto.Visible = True
        Else
            Me.picPhoto.Visible = False
        End If
    End Sub

    Private Sub LoadRatings()
        If Not mblnLoading Then
            gs.SetCursor(True, Me)
            Dim dg As DataGrid = Me.dgRatings

            Dim DataSet As New DataSet
            DataSet = GetGridToShow()

            Dim View As New DataViewUtility
            View.Standardize(DataSet)
            With dg
                .DataSource = View
                .CaptionText = "Player Ratings"
            End With


            gs.SetCursor(False, Me)
        End If
    End Sub

    Private Sub LoadGeneralInfo()
        Dim Player As New Player
        Dim Pos As New Position

        Player.Load(mintPlayerID)

        With Player
            Me.txtAge.Text = .Age
            Me.txtFirstName.Text = .FirstName
            Me.txtLastName.Text = .LastName
            Me.lblPosition.Text = Pos.GetAbbr(.Position)
            Me.lblPlayerName.Text = .ToString
            Me.txtHighSchool.Text = .HighSchool
            Me.txtHometown.Text = .Hometown
            Me.txtCollege.Text = .College
            Me.txtJersey.Text = .Jersey
            mstrCurrentTeam = IIf(.GetCurrentTeam = "", "None", .GetCurrentTeam)
            mintPosition = .Position
            mstrPhotoName = .LastName & .FirstName
        End With
    End Sub



#End Region
    Private Function GetGridToShow() As DataSet
        Dim DS As New DataServices.PlayerTables
        Dim Helper As New DataGridUtility(Me.dgRatings, "Player Ratings")
        Dim DataSet As New DataSet
        DataSet = DS.GetPlayerCardRatings(mintPlayerID)
        Helper.SetPlayerCardRatingGrid()
        Helper.Commit()
        Return DataSet
    End Function


    Private Sub btnPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrev.Click
        Call NavigatePlayer(-1)
    End Sub

    Private Sub NavigatePlayer(ByVal intAmount As Integer)
        If mblnDirty Then
            If Not mblnSaved Then
                Dim Response As MsgBoxResult = MsgBox("Do you wish to save your changes?", MsgBoxStyle.YesNoCancel, "Save player?")
                If Response = MsgBoxResult.Cancel Then
                    Exit Sub
                ElseIf Response = MsgBoxResult.Yes Then
                    Call Save()
                End If
            End If
        End If

        If intAmount = -1 Then
            If mintArrayPos <> 0 Then
                mintArrayPos = mintArrayPos + intAmount
            End If
        End If

        If intAmount = 1 Then
            If mintArrayPos <> marrPlayerArray.Count - 1 Then
                mintArrayPos = mintArrayPos + intAmount
            End If
        End If

        mintPlayerID = marrPlayerArray(mintArrayPos)
        Call LoadPlayer()
        If mintArrayPos = 0 Then
            Me.btnPrev.Enabled = False
        Else
            Me.btnPrev.Enabled = True
        End If

        If mintArrayPos = marrPlayerArray.Count - 1 Then
            Me.btnNext.Enabled = False
        Else
            Me.btnNext.Enabled = True
        End If

    End Sub

    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        Call NavigatePlayer(1)
    End Sub


    Private Sub LoadHighlights()
        Dim pe As New PlayerEventSet
        pe.Load(mintPlayerID)
        Me.txtHighlights.Text = pe.GetHighlight()

    End Sub

    Private Sub DirtyForm(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtAge.TextChanged, txtCollege.TextChanged, txtFirstName.TextChanged, txtHighSchool.TextChanged, txtHometown.TextChanged, txtLastName.TextChanged, txtJersey.TextChanged
        If Not mblnLoading Then
            mblnDirty = True
            Me.btnSave.Enabled = True
            mblnSaved = False
        End If
    End Sub

    Private Sub Save()
        If Not mblnSaved Then
            If mblnDirty Then
                Dim Player As New Player
                With Player
                    .Load(mintPlayerID)
                    .Age = Me.txtAge.Text
                    .College = Me.txtCollege.Text
                    .FirstName = Me.txtFirstName.Text
                    .LastName = Me.txtLastName.Text
                    .HighSchool = Me.txtHighSchool.Text
                    .Hometown = Me.txtHometown.Text
                    .Jersey = Me.txtJersey.Text
                    .Update()
                End With
                mblnDirty = False

            End If
        End If
    End Sub

    Private Sub LoadStats()
        Call LoadScoringGrid()
        Call LoadDefenseGrid()

        If mintPosition = ISMPlayerPosition.Goalie Then
            Me.dgDefense.Visible = True
            Me.dgScoring.Visible = False
        Else
            Me.dgDefense.Visible = False
            Me.dgScoring.Visible = True
        End If
    End Sub

    Private Sub LoadDefenseGrid()
        Dim sm As New Statistics.StatisticManager
        Dim DS As New DataServices.PlayerTables
        Dim Helper As New DataGridUtility(Me.dgDefense, "Career Goalkeeping")
        Dim DataSet As New DataSet
        Dim View As New DataViewUtility
        Dim Sim As Simulation = Simulation.GetInstance

        DataSet = sm.GetCareerGoalkeepingHistory(mintPlayerID, Sim.League.Season, mstrCurrentTeam)
        View.Standardize(DataSet)
        Helper.SetPlayerCardGoalkeepingGrid()
        Helper.Commit()
        Me.dgDefense.Text = "Career Goalkeeping"
        Me.dgDefense.DataSource = View
        Me.dgDefense.CaptionText = "Career Goalkeeping"
    End Sub

    Private Sub LoadScoringGrid()
        Dim sm As New Statistics.StatisticManager
        Dim DS As New DataServices.PlayerTables
        Dim Helper As New DataGridUtility(Me.dgScoring, "Career Scoring")
        Dim DataSet As New DataSet
        Dim View As New DataViewUtility
        Dim Sim As Simulation = Simulation.GetInstance

        DataSet = sm.GetCareerScoringHistory(mintPlayerID, Sim.League.Season, mstrCurrentTeam)
        View.Standardize(DataSet)
        Helper.SetPlayerCardScoringGrid()
        Helper.Commit()
        Me.dgScoring.Text = "Career Scoring"
        Me.dgScoring.DataSource = View
        Me.dgScoring.CaptionText = "Career Scoring"

    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Call Save()
    End Sub
End Class
