'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
Imports ISoccerSim.Utility.DataGrid

Namespace Reporting
    Public Class ReportData
        Inherits CollectionBase

        Sub Add(ByVal objItem As ReportRow)
            Me.InnerList.Add(objItem)
        End Sub

        Default Public Property Item(ByVal Index As Integer) As ReportRow
            Get
                Return CType(Me.InnerList.Item(Index), ReportRow)
            End Get
            Set(ByVal Value As ReportRow)
                Me.InnerList.Item(Index) = Value
            End Set
        End Property

        Sub Fill(ByVal Text As String)
            Dim Item As New ReportRow()
            Dim Array As New ArrayList

            Array.Add(Text)
            Item.Data = Array
            Me.Add(Item)
        End Sub

        Sub Fill(ByVal ParamArray args())

            Dim i As Object
            Dim Item As New ReportRow
            Dim Array As New ArrayList

            For Each i In args
                Array.Add(i)
            Next i
            Item.Data = Array
            Me.Add(Item)
        End Sub

        Sub Fill(ByVal objArrayList As ArrayList)
            Dim Item As New ReportRow
            Item.Data = objArrayList
            Me.Add(Item)
        End Sub

        Sub Fill(ByVal dt As Data.DataTable, ByVal rt As ReportTable)
            Dim i As Integer
            Dim dr As Data.DataRow

            For Each dr In dt.Rows
                Call Me.Fill(dr, rt)
            Next
        End Sub

        Sub Fill(ByVal dg As DataGrid, ByVal rt As ReportTable)
            Dim x As Integer
            Dim y As Integer
            Dim parrList As ArrayList
            Dim dt As Data.DataTable = CType(dg.DataSource, DataViewUtility).GetDataTable
            Dim rr As ReportRow
            Dim Value As Object

            For y = 0 To dt.Rows.Count - 1
                parrList = New ArrayList
                rr = New ReportRow
                For x = 0 To rt.Count - 1
                    Value = dg(y, rt(x).MappingIndex)
                    parrList.Add(Value)
                Next
                rr.Add(parrList)
                Me.Add(rr)
            Next
        End Sub
        Sub Fill(ByVal dr As Data.DataRow, ByVal rt As ReportTable)
            Dim i As Integer
            Dim parrList As New ArrayList
            Dim Value As String
            Dim x As Integer

            For i = 0 To dr.ItemArray.GetUpperBound(0) - 1
                If TypeOf (dr.Item(i)) Is DBNull Then
                    Value = "0"
                Else
                    Value = dr.ItemArray(i)
                End If

                For x = 0 To rt.Count - 1
                    If rt.Item(x).MappingIndex = i Then
                        parrList.Add(Value)
                        Exit For
                    End If
                Next

            Next
            Me.Fill(parrList)
        End Sub

        Sub Fill(ByVal dr As Data.DataRow, ByVal ColumnsToShow As ArrayList)
            Dim i As Integer
            Dim parrList As New ArrayList

            For i = 0 To dr.ItemArray.GetUpperBound(0)
                If ColumnsToShow.Contains(i) Then
                    If TypeOf (dr.Item(i)) Is DBNull Then
                        parrList.Add("0")
                    Else
                        parrList.Add(dr.ItemArray(i))
                    End If
                End If
            Next
            Me.Fill(parrList)
        End Sub

        Sub FillRange(ByVal objArrayList As ArrayList)
            Dim i As Integer
            Dim Item As ReportRow

            For i = 0 To objArrayList.Count - 1
                Item = New ReportRow
                If TypeOf (objArrayList.Item(i)) Is DBNull Then
                    objArrayList.Item(i) = 0
                End If
                Item.Add(objArrayList.Item(i))
                Me.Add(Item)
            Next

        End Sub
    End Class
End Namespace