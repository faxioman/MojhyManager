'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Reporting
    Public Class TextReportFormatService
        Inherits ReportFormatService


        Public Overrides Sub Generate()
            Call WriteHeader()
            Call WriteBody()
            Call WriteFooter()
        End Sub

        Private Sub WriteBody()
            Dim Table As ReportTable
            For Each Table In Me.Report
                Me.Build("")
                Me.Build(Table.Header)
                Me.Build("")
                Call WriteTableColumns(Table)
                Call WriteTableData(Table)
                Me.Build(GetDivider())
            Next
        End Sub

        Private Function WriteTableColumns(ByVal objReportTable As ReportTable) As String
            Dim Out As New String(" ", Me.ReportWidth)
            Dim Col As ReportColumn
            Dim Header As String
            Dim i As Integer = 1

            For Each Col In objReportTable
                If Col.Width > 0 Then
                    Header = Left(Col.Column, Col.Width - 1)
                    Mid(Out, i, Header.Length) = Header
                    i = i + Col.Width
                End If
            Next
            Me.Build(Out)
        End Function

        Private Function WriteTableData(ByVal objReportTable As ReportTable) As String
            Dim Item As ReportRow
            Dim Out As String

            For Each Item In objReportTable.Data
                Out = Out & WriteTableRow(objReportTable, Item)
            Next
            Me.Build(Out)
            Return Out
        End Function

        Private Function WriteTableRow(ByVal objTable As ReportTable, ByVal objRow As ReportRow) As String
            Dim intCols As Integer = objTable.Count - 1
            Dim i As Integer
            Dim Col As ReportColumn
            Dim Out As New String(" ", Me.ReportWidth)
            Dim Value As Object
            Dim x As Integer = 1

            For i = 0 To intCols
                Col = objTable.Item(i)
                If Col.Width > 0 Then
                    Value = objRow.Data(i)
                    If Len(Value) > Col.Width - 1 Then
                        Value = Left(Value, Col.Width - 1)
                    End If

                    If Col.RightAlign Then
                        Value = CStr(Value)
                        Mid(Out, x, Col.Width) = Value.PadLeft(Col.Width - Len(Value), " ")
                    Else
                        Mid(Out, x, Len(Value)) = Value
                    End If

                    x = x + Col.Width
                End If
            Next
            Out = Out & vbCrLf
            Return Out

        End Function

        Private Sub WriteHeader()
            Me.Build(Report.Header)
            Me.Build(GetDivider())
            Me.Build("")
        End Sub

        Private Sub WriteFooter()
            Me.Build("")
            Me.Build("Indoor Soccer Manager - 2004 - To-Paw Software")
            Me.Build(GetDivider())
        End Sub

        Private Function GetDivider() As String
            Dim Out As New String("-", Me.ReportWidth)
            Return Out
        End Function

    End Class
End Namespace