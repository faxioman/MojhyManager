Namespace Schedules.Playoffs
    Public Class PlayoffTree
        Inherits System.Collections.CollectionBase

        Public Standings As Standings = Simulation.GetInstance.League.Standings

        Public Sub Add(ByVal s As Seed)
            Me.InnerList.Add(s)
        End Sub

        Public Sub Add(ByVal p As PlayoffTree)
            Dim s As Seed
            For Each s In p
                If Not Me.InnerList.Contains(s) Then
                    Me.InnerList.Add(s)
                End If
            Next
        End Sub

        Public Sub Add(ByVal TeamID As Integer, ByVal Name As String, ByVal Wins As Integer, _
                       ByVal ConferenceID As Integer, ByVal DivisionID As Integer)

            Dim s As New Seed
            s.ConferenceID = ConferenceID
            s.DivisionID = DivisionID
            s.Seed = 0
            s.TeamID = TeamID
            s.Wins = Wins
            s.Name = Name
            Me.InnerList.Add(s)
        End Sub

        Public Sub Add(ByVal TeamID As Integer, ByVal Name As String, ByVal Wins As Integer, _
                       ByVal ConferenceID As Integer, ByVal DivisionID As Integer, ByVal Seed As Integer)

            Dim s As New Seed
            s.ConferenceID = ConferenceID
            s.DivisionID = DivisionID
            s.Seed = Seed
            s.TeamID = TeamID
            s.Wins = Wins
            s.Name = Name
            Me.InnerList.Add(s)
        End Sub

        Default Property Item(ByVal index As Integer) As Seed
            Get
                Return CType(InnerList.Item(index), Seed)
            End Get
            Set(ByVal Value As Seed)
                InnerList.Item(index) = Value
            End Set
        End Property

        Sub SortByWins()
            Me.InnerList.Sort(Me.SortWins)
        End Sub

        Sub SortByMultipleWins()
            Me.InnerList.Sort(Me.SortMultipleWins)
        End Sub

        Function SortWins() As IComparer
            Return CType(New RegularWinSort, IComparer)
        End Function

        Function SortMultipleWins() As IComparer
            Return CType(New MultipleWinSort, IComparer)
        End Function

        Sub TagSeeds()
            Dim i As Integer
            Dim Rank As Integer
            Dim Wins As Integer

            Dim IsTied As Boolean
            Dim TeamsToBreak As New PlayoffTree

            If Me.Count > 1 Then
                Rank = 0
                Wins = Me.Item(0).Wins
                IsTied = False

                For i = 0 To Me.InnerList.Count - 1
                    If Me.Item(i).Wins < Wins Or i = 0 Then
                        If IsTied = True Then
                            'Process tie...
                            TeamsToBreak.SetRankForTiedTeams(TeamsToBreak, Standings)
                            Rank = Rank + TeamsToBreak.Count - 1
                            TeamsToBreak.Clear()
                        End If
                        Wins = Me.Item(i).Wins
                        IsTied = False
                    Else
                        TeamsToBreak.Add(Me.Item(i))
                        If Not TeamsToBreak.Contains(Me.Item(i - 1).TeamID) Then
                            TeamsToBreak.Add(Me.Item(i - 1))
                        End If
                        IsTied = True
                    End If

                    Me.Item(i).Seed = Rank
                    Rank = Rank + 1
                Next
            End If

            If Me.Count > 0 Then
                If Me.Item(0).Seed = 0 Then
                    For i = 0 To Me.Count - 1
                        Me.Item(i).Seed = Me.Item(i).Seed + 1
                    Next
                End If
            End If
        End Sub

        Public Function Contains(ByVal TeamID As Integer) As Boolean
            Dim s As Seed
            For Each s In Me.InnerList
                If s.TeamID = TeamID Then
                    Return True
                End If
            Next
            Return False
        End Function

        Private Function SetRankForTiedTeams(ByVal pt As PlayoffTree, _
                                             ByVal Standings As Standings) As PlayoffTree

            'The object is to break down a tie first by common tie breaker, then
            'down to head to head.  For the purposes of the sim, this is the
            'tiebreaker ruleset...

            '1.  Head-to-head.
            '2.  Point differential
            '
            'If there are more than two teams, then point differential against
            'each other is used (i.e. if (#1 = +10, #2 = -10, #3 = +15), then
            'team #1 would win the tie breaker.  If it were (#1 = +10, #2 = -10,
            '#3 = +10), then #1 and #3 would advance to a head to head.
            '
            'This routine is called recursively outside of this procedure.

            Dim MathService As MathService = MathService.GetInstance
            Dim Result As New PlayoffTree
            Dim Winner As Integer
            Dim StartSeed As Integer = pt.Item(0).Seed
            Dim i As Integer


            For i = 0 To pt.Count - 1
                If Not pt.Item(i).IsTestMode Then
                    pt.Item(i).WinPctVsMultiple = IIf(pt.Count > 2, 0, Standings.GetWinPercentage(pt.Item(i).TeamID, Standings.enuPhase.Season, pt.GetArrayList(pt.Item(i).TeamID, pt)))
                    pt.Item(i).NetPointsVsMultiple = Standings.GetPointMargin(pt.Item(i).TeamID, Standings.enuPhase.Season, pt.GetArrayList(pt.Item(i).TeamID, pt))
                    pt.Item(i).LowestPointsGivenUpVsMultiple = Standings.GetPointsAgainst(pt.Item(i).TeamID, Standings.enuPhase.Season, pt.GetArrayList(pt.Item(i).TeamID, pt))
                End If
            Next

            pt.SortByMultipleWins()
            pt.Item(0).Seed = StartSeed

            For i = 1 To pt.Count - 1
                StartSeed = StartSeed + 1
                pt.Item(i).Seed = StartSeed
            Next

            For i = 0 To pt.Count - 1
                Result.Add(pt.Item(i).Clone)
            Next
            Return Result

        End Function

        Function GetTopTeams(ByVal NumberOfTeams As Integer) As PlayoffTree
            Dim Result As New PlayoffTree
            Dim s As Seed

            For Each s In Me.InnerList
                If s.Seed <= NumberOfTeams Then
                    Result.Add(s.Clone)
                End If
            Next
            If Result.Count <> NumberOfTeams Then Stop
            Return Result

        End Function

        Function GetArrayList(ByVal TeamNotToIncludeID As Integer, ByVal Opponents As PlayoffTree) As ArrayList
            Dim Result As New ArrayList
            Dim s As Seed
            For Each s In Opponents
                If s.TeamID <> TeamNotToIncludeID Then
                    Result.Add(s.TeamID)
                End If
            Next
            Return Result
        End Function

        Function GetDivision(ByVal DivisionID As Integer) As PlayoffTree
            Dim Result As New PlayoffTree
            Dim s As Seed
            For Each s In Me.InnerList
                If s.DivisionID = DivisionID Then
                    Result.Add(s.Clone)
                End If
            Next
            Return Result
        End Function

        Function GetConference(ByVal ConferenceID As Integer) As PlayoffTree
            Dim Result As New PlayoffTree
            Dim s As Seed
            For Each s In Me.InnerList
                If s.ConferenceID = ConferenceID Then
                    Result.Add(s.Clone)
                End If
            Next
            Return Result
        End Function

        Public Function LoadTreeFromLeague() As PlayoffTree
            Dim Result As New PlayoffTree
            Dim Sim As Simulation = Simulation.GetInstance
            Dim t As Teams.Team
            Dim Wins As Integer

            For Each t In Sim.League
                Wins = Sim.League.Standings.GetWins(t.TeamID, Standings.enuPhase.Season, 0)
                Result.Add(t.TeamID, t.Name, Wins, t.ConferenceID, t.DivisionID)
            Next
            Return Result


        End Function

        Public Function LoadTreeFromPlayoffs() As PlayoffTree
            Dim Result As New PlayoffTree
            Dim Sim As Simulation = Simulation.GetInstance
            Dim ds As New DataServices.LeagueTables
            Dim dr As OleDb.OleDbDataReader = ds.GetTeamsRemainingInPlayoffs
            Dim Wins As Integer
            Dim t As Teams.Team
            Dim TeamID As Integer

            Do While dr.Read
                TeamID = dr.Item("WinnerID")
                t = Sim.League.GetTeamByID(TeamID)
                Wins = Sim.League.Standings.GetWins(TeamID, Standings.enuPhase.Season, 0)
                Result.Add(dr.Item("WinnerID"), t.Name, Wins, t.ConferenceID, t.DivisionID, dr.Item("WinnerSeed"))
            Loop
            dr.Close()
            Return Result
        End Function

        Public Sub SaveSeeds()
            Dim t As Teams.Team
            Dim Sim As Simulation = Simulation.GetInstance
            Dim s As Seed

            For Each s In Me.InnerList
                t = Sim.League.GetTeamByID(s.TeamID)
                t.PlayoffSeed = s.Seed
                t.UpdatePlayoffSeed()
            Next
        End Sub

    End Class

    Public Class RegularWinSort
        Implements IComparer

        Function Compare(ByVal obj1 As Object, ByVal obj As Object) As Integer Implements IComparer.Compare
            If obj Is Nothing Then Return 1

            Dim first As Seed = CType(obj1, Seed)
            Dim other As Seed = CType(obj, Seed)

            If first.Wins > other.Wins Then
                Return -1
            ElseIf first.Wins < other.Wins Then
                Return 1
            Else
                Return 0
            End If

        End Function
    End Class

    Public Class MultipleWinSort
        Implements IComparer

        Public Function Compare(ByVal x As Object, ByVal y As Object) As Integer Implements System.Collections.IComparer.Compare
            Dim first As Seed = CType(x, Seed)
            Dim other As Seed = CType(y, Seed)

            If first.NetPointsVsMultiple > other.NetPointsVsMultiple Then
                Return -1
            ElseIf first.NetPointsVsMultiple < other.NetPointsVsMultiple Then
                Return 1
            Else
                If first.LowestPointsGivenUpVsMultiple > other.LowestPointsGivenUpVsMultiple Then
                    Return -1
                ElseIf first.LowestPointsGivenUpVsMultiple < other.LowestPointsGivenUpVsMultiple Then
                    Return 1
                Else
                    Return 0
                End If
            End If
            Return 0
        End Function

    End Class


End Namespace