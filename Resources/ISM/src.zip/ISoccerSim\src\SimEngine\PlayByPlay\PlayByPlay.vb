'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports Microsoft.VisualBasic
Imports ISoccerSim.Players
Imports ISoccerSim.Teams

Namespace SimEngine.PlayByPlay

	Public Class PlayByPlay
		Inherits CollectionBase
		Implements IComparable

		Public Name As String
		Public Abbreviation As String
		Public PlayByPlayID As Integer
		Public Total As Double
		Public GameEngine As GameEngine

		Public PlayerPassTo As Player
		Public BallHandler As Player
		Public Defender As Player
		Public Goalie As Player
		Public ActivePlayer As Player
		Public Clock As Clock
        Public Posession As Posession

        Dim r As MathService = MathService.GetInstance

		Sub Add(ByVal objItem As PlayByPlayComment)
			Me.InnerList.Add(objItem)
		End Sub

		Default Public Property Item(ByVal Index As Integer) As PlayByPlayComment
			Get
				Return CType(Me.InnerList.Item(Index), PlayByPlayComment)
			End Get
			Set(ByVal Value As PlayByPlayComment)
				Me.InnerList.Item(Index) = Value
			End Set
		End Property

		Sub Create(ByVal PlayByPlayCommentID As Integer, ByVal Narrative As String, ByVal Probability As Double)
			Dim Item As New PlayByPlayComment()
			With Item
				.PlayByPlayID = Me.PlayByPlayID
				.PlayByPlayCommentID = PlayByPlayCommentID
				.Narrative = Narrative
				.Probability = Me.Total + Probability
			End With
			Me.Add(Item)
			Me.Total = Me.Total + Probability
		End Sub

		Sub Load()
			Dim Data As New DataServices.BaseTables()
			Dim DR As OleDb.OleDbDataReader = Data.GetPlayByPlayItems(Me.PlayByPlayID)
			Do While DR.Read()
				Me.Create(DR.Item("ItemID"), DR.Item("Description"), DR.Item("Probability"))
			Loop
			DR.Close()
		End Sub

		Function GetNarrative() As String
			Dim Item As PlayByPlayComment

			Dim i As Integer
            Dim x As Integer = r.RandomNumber(1, Me.Total)

			For i = 0 To Me.InnerList.Count - 1
				Item = Me.InnerList.Item(i)
                If x <= Item.Probability Then
                    Return Item.Narrative
                End If
            Next
			Debug.Assert(False)
		End Function

		Overrides Function ToString() As String
			Return Me.Name
		End Function

		Private Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
			If obj Is Nothing Then Return 1
			Dim other As PlayByPlay = CType(obj, PlayByPlay)
			Return StrComp(Me.ToString, other.ToString, CompareMethod.Text)
		End Function



	End Class




End Namespace