Namespace Schedules.Playoffs
    Public Class PlayoffManager

        Public Enum ISMPlayoffMethod
            None = 0
            ConferenceOnly = 1
            DivisionOnly = 2
            TopNTeams = 4
        End Enum

        Public Function Calculate(ByVal pt As PlayoffTree, ByVal TeamsInPlayoffs As Integer, _
                                  ByVal PlayoffMode As ISMPlayoffMethod) As PlayoffTree

            Dim Result As New PlayoffTree
            Select Case PlayoffMode
                Case ISMPlayoffMethod.None
                    Return Result
                Case ISMPlayoffMethod.DivisionOnly
                    Return Me.GetDivisionWinners(pt)
                Case ISMPlayoffMethod.ConferenceOnly
                    Return Me.GetConferenceWinners(pt)
                Case ISMPlayoffMethod.TopNTeams
                    Return Me.GetDivisionAndTopNTeams(pt, TeamsInPlayoffs)
                Case Else
                    'Pass...
            End Select
        End Function

        Private Function GetDivisionWinners(ByVal pt As PlayoffTree) As PlayoffTree
            Dim Result As New PlayoffTree
            Dim DivisionsUsed As New ArrayList
            Dim Division As New PlayoffTree
            Dim i As Integer

            For i = 0 To pt.Count - 1
                If Not DivisionsUsed.Contains(pt.Item(i).DivisionID) Then
                    DivisionsUsed.Add(pt.Item(i).DivisionID)
                    Division = pt.GetDivision(pt.Item(i).DivisionID)
                    Division.SortByWins()
                    Division.TagSeeds()
                    Result.Add(Division.GetTopTeams(1))
                End If
            Next

            Result.SortByWins()
            Result.TagSeeds()

            Return Result
        End Function

        Private Function GetDivisionAndTopNTeams(ByVal pt As PlayoffTree, ByVal TopTeams As Integer) As PlayoffTree
            Dim Result As New PlayoffTree
            Dim DivisionsUsed As New ArrayList
            Dim Division As New PlayoffTree
            Dim i As Integer
            Dim TeamsLeft As Integer

            For i = 0 To pt.Count - 1
                If Not DivisionsUsed.Contains(pt.Item(i).DivisionID) Then
                    DivisionsUsed.Add(pt.Item(i).DivisionID)
                    Division = pt.GetDivision(pt.Item(i).DivisionID)
                    Division.SortByWins()
                    Division.TagSeeds()
                    Result.Add(Division.GetTopTeams(1))
                End If
            Next

            TeamsLeft = TopTeams - DivisionsUsed.Count
            pt.SortByWins()
            pt.TagSeeds()

            If TeamsLeft > 0 Then
                For i = 0 To pt.Count - 1
                    If Not Result.Contains(pt.Item(i).TeamID) Then
                        If TeamsLeft > 0 Then
                            Result.Add(pt.Item(i).Clone)
                            TeamsLeft = TeamsLeft - 1
                            If TeamsLeft <= 0 Then Exit For
                        End If
                    End If
                Next
            End If

            Result.SortByWins()
            Result.TagSeeds()

            Return Result
        End Function


        Private Function GetConferenceWinners(ByVal pt As PlayoffTree) As PlayoffTree
            Dim Result As New PlayoffTree
            Dim ConferencesUsed As New ArrayList
            Dim Conference As New PlayoffTree
            Dim i As Integer

            For i = 0 To pt.Count - 1
                If Not ConferencesUsed.Contains(pt.Item(i).ConferenceID) Then
                    ConferencesUsed.Add(pt.Item(i).ConferenceID)
                    Conference = pt.GetConference(pt.Item(i).ConferenceID)
                    Conference.SortByWins()
                    Conference.TagSeeds()
                    Result.Add(Conference.GetTopTeams(1))
                End If
            Next

            Result.SortByWins()
            Result.TagSeeds()

            Return Result
        End Function


    End Class
End Namespace
