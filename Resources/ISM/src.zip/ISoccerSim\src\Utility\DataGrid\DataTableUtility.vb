'--------------------------------------------------------------------
'Copyright (c) 2004 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Utility.DataGrid

    Public Class DataTableUtility
        Private Function CreateBaseTable(ByVal strName As String, ByVal intInitialCapacity As Integer) As DataTable

            'Set Table...
            Dim Table As New DataTable
            With Table
                .CaseSensitive = False
                .MinimumCapacity = intInitialCapacity
            End With

            Return Table

        End Function

        Function GetStandingStructure() As DataTable

            'Set up initial table stuff...
            Dim Table As DataTable = CreateBaseTable("Standings", 12)

            'Set Columns...
            With Table.Columns
                .Add("ID", GetType(Integer))
                .Add("Team", GetType(String))
                .Add("W", GetType(Integer))
                .Add("L", GetType(Integer))
                .Add("GB", GetType(Double))
                .Add("PF", GetType(Integer))
                .Add("PA", GetType(Integer))
                .Add("Streak", GetType(String))
                .Add("Last10", GetType(String))
                .Add("PCT", GetType(Double))
                .Add("Home", GetType(String))
                .Add("Away", GetType(String))
                .Add("DIV", GetType(String))
                .Add("CONF", GetType(String))
            End With
            Table.TableName = "Standings"
            Return Table
        End Function

        Function GetScheduleStructure() As DataTable
            Dim Table As DataTable = CreateBaseTable("Schedule", 4)
            With Table.Columns
                .Add("ID", GetType(Integer))
                .Add("GameDate", GetType(Date))
                .Add("Game", GetType(String))
                .Add("Attendance", GetType(Integer))
            End With
            Table.TableName = "Schedule"
            Return Table
        End Function




    End Class

    Public Module DataTableHelper
        Sub SafelyAddColumn(ByRef DataSet As DataSet, ByVal FieldName As String, ByVal Type As System.Type, ByVal Expression As String)
            Dim i As Integer

            For i = 0 To DataSet.Tables(0).Columns.Count - 1
                If DataSet.Tables(0).Columns(i).ColumnName = FieldName Then
                    Exit Sub
                End If
            Next

            DataSet.Tables(0).Columns.Add(FieldName, Type, Expression)
        End Sub
    End Module
End Namespace