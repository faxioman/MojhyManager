'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.Data.OleDb
Imports ISoccerSim.Tactical
Imports ISoccerSim.Statistics

Namespace DataServices

	Friend Class StatTables
		Inherits DataService

		Function GetStatistics() As OleDbDataReader
			Dim SQL As String = "SELECT StatID, Abbreviation, Name FROM Statistics ORDER BY StatID"
			Return GetDataReader(SQL)
		End Function

		Function InsertGameStat(ByVal GameStat As GameStat) As Integer
			Dim SQL As String
			With GameStat
				SQL = "INSERT INTO GameStats " & _
				 "(StatisticID, PlayerID, TeamID, ScheduleID, [Value], SeasonID) " & _
				 "VALUES (" & _
				FormatField(.StatisticID, False, True) & _
				FormatField(.PlayerID, False, True) & _
				FormatField(.TeamID, False, True) & _
				FormatField(.ScheduleID, False, True) & _
				FormatField(.Value, False, True) & _
				FormatField(.SeasonID, False, False) & _
				")"

			End With

			RunCommand(SQL)
			Return Me.GetID("GameStats", "GameStatID")

		End Function

		Function GetBaseLeagueStat(ByVal Stat As ISMStat) As DataSet
			Dim SQL As String
			SQL = GetBaseLeagueQuery("WHERE (((s.StatID) = " & Stat & ")) ")
			Return Me.GetDataSet(SQL, "Stats")
		End Function

		Function GetBaseLeagueStatForTeam(ByVal Stat As ISMStat, ByVal TeamID As Integer) As DataSet
			Dim SQL As String
			SQL = GetBaseLeagueQuery("WHERE s.StatID = " & Stat & " AND t.TeamID = " & TeamID)
			Return Me.GetDataSet(SQL, "Stats")
		End Function

		Function GetBaseLeagueStatForConference(ByVal Stat As ISMStat, ByVal ConferenceID As Integer) As DataSet
			Dim SQL As String
			SQL = GetBaseLeagueQuery("WHERE s.StatID = " & Stat & " AND t.ConferenceID = " & ConferenceID)
			Return Me.GetDataSet(SQL, "Stats")
		End Function

		Function GetBaseLeagueStatForDivision(ByVal Stat As ISMStat, ByVal DivisionID As Integer) As DataSet
			Dim SQL As String = GetBaseLeagueQuery(" WHERE s.StatID = " & Stat & " AND t.DivisionID = " & DivisionID)
			Return Me.GetDataSet(SQL, "Stats")
		End Function

		Private Function GetBaseLeagueQuery(ByVal strWhere As String) As String
			Return "SELECT po.Abbr AS Pos, p.PlayerID, p.LastName+', '+p.FirstName AS PlayerName, Sum(gs.Value) AS [Value], s.Abbreviation, t.Abbreviation AS TEAM, s.StatID " & _
			 " FROM (Positions AS po INNER JOIN (Statistics AS s INNER JOIN (Players AS p INNER JOIN GameStats AS gs ON p.PlayerID = gs.PlayerID) ON s.StatID = gs.StatisticID) ON po.PositionID = p.PositionID) INNER JOIN (Teams AS t INNER JOIN Rosters AS r ON t.TeamID = r.TeamID) ON p.PlayerID = r.PlayerID " & _
			strWhere & _
			" GROUP BY po.Abbr, p.PlayerID, p.LastName+', '+p.FirstName, s.Abbreviation, t.Abbreviation, s.StatID, p.LastName, p.FirstName " & _
			" ORDER BY Sum(gs.Value) DESC , p.LastName, p.FirstName "
		End Function


		Function GetBaseTeamStat(ByVal Stat As ISMStat) As DataSet
			Dim SQL As String
			SQL = GetBaseTeamQuery("WHERE (((s.StatID) = " & Stat & ")) ")
			Return Me.GetDataSet(SQL, "Stats")
		End Function

		Function GetBaseTeamStatForConference(ByVal Stat As ISMStat, ByVal ConferenceID As Integer) As DataSet
			Dim SQL As String
			SQL = GetBaseTeamQuery("WHERE s.StatID = " & Stat & " AND t.ConferenceID = " & ConferenceID)
			Return Me.GetDataSet(SQL, "Stats")
		End Function

		Function GetBaseTeamStatForDivision(ByVal Stat As ISMStat, ByVal DivisionID As Integer) As DataSet
			Dim SQL As String = GetBaseTeamQuery(" WHERE s.StatID = " & Stat & " AND t.DivisionID = " & DivisionID)
			Return Me.GetDataSet(SQL, "Stats")
		End Function


		Private Function GetBaseTeamQuery(ByVal strWhere As String) As String
			Return "SELECT t.TeamID, t.Name AS TEAM, Sum(gs.Value) AS [Value], s.Abbreviation, s.StatID " & _
			 " FROM Statistics s INNER JOIN (Teams t INNER JOIN GameStats gs  ON t.TeamID = gs.TeamID) ON s.StatID = gs.StatisticID " & _
			strWhere & _
			" GROUP BY t.TeamID, t.Name, s.Abbreviation, s.StatID " & _
			" ORDER BY Sum(gs.Value) DESC , t.Name "
		End Function
	End Class

End Namespace
