
'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
Imports System.Data.OleDb
Imports ISoccerSim.Ratings
Imports ISoccerSim.Players

Namespace DataServices

	Friend Class PlayerTables
		Inherits DataServices.DataService

		Function InsertReferee(ByVal objRef As Referee) As Integer
			Dim SQL As String
			With objRef
				SQL = "INSERT INTO Referees (FirstName, LastName, Age, HomeTown, Knowledge, Vision, Respect)" & _
				 "VALUES (" & _
				FormatField(.FirstName, True, True) & _
				FormatField(.LastName, True, True) & _
				FormatField(.Age, False, True) & _
				FormatField(.Hometown, True, True) & _
				FormatField(.Knowledge, False, True) & _
				FormatField(.Vision, False, True) & _
				FormatField(.Respect, False, False) & ")"

			End With

			RunCommand(SQL)
			Return GetID("Referees", "RefereeID")

		End Function

		Function InsertPlayer(ByVal objPlayer As Player) As Integer

			Dim SQL As String
			With objPlayer
                SQL = "INSERT INTO Players (FirstName, LastName, Jersey, " & _
                "HighSchool, College, Hometown, Age, StarPlayer, PositionID)" & _
                 "VALUES (" & _
                 FormatField(.FirstName, True, True) & _
                 FormatField(.LastName, True, True) & _
                FormatField(.Jersey, False, True) & _
                FormatField(.HighSchool, True, True) & _
                FormatField(.College, True, True) & _
                FormatField(.Hometown, True, True) & _
                FormatField(.Age, False, True) & _
                            FormatField(.StarPlayer, False, True) & _
                FormatField(.Position, False, False) & ")"
			End With

			RunCommand(SQL)
			Return GetID("Players", "PlayerID")

		End Function

		Function InsertRating(ByVal objRating As Rating) As Integer
			Dim SQL As String
			With objRating
				SQL = "INSERT INTO PlayerRatings (RatingID, RatingTypeID, ScoutID, Rating, PlayerID)" & _
				 "VALUES (" & _
				 FormatField(.RatingID, False, True) & _
				 FormatField(.RatingType, False, True) & _
				 FormatField(.ScoutID, False, True) & _
				 FormatField(.Value, False, True) & _
				 FormatField(.PlayerID, False, False) & ")"
			End With
			RunCommand(SQL)
			Return GetID("Players", "PlayerID")
        End Function

        Function InsertPlayerEvent(ByVal PlayerEvent As PlayerEvent) As Integer
            Dim SQL As String
            With PlayerEvent
                SQL = "INSERT INTO PlayerEvents (PlayerID, Description, EventDate) VALUES ( " & _
                FormatField(.PlayerID, False, True) & _
                FormatField(.Description, True, True) & _
                FormatField(.EventDate, True, False) & ")"
            End With
            RunCommand(SQL)
            Return GetID("PlayerEvents", "PlayerEventID")
        End Function

        Function GetPlayerCardRatings(ByVal intPlayerID As Integer) As DataSet
            Dim SQL As String
            Dim Where As String

            SQL = "TRANSFORM Sum(pr.Rating) AS SumOfRating " & _
             "SELECT pl.PlayerID, ra.Name, '' AS Graph " & _
             "FROM ((Players AS pl INNER JOIN (Ratings AS ra INNER JOIN PlayerRatings AS pr ON ra.RatingID = pr.RatingID) ON pl.PlayerID = pr.PlayerID)) INNER JOIN Positions ON pl.PositionID = Positions.PositionID" & _
            " WHERE(((pl.PlayerID) = " & intPlayerID & "))" & _
            " GROUP BY pl.PlayerID, ra.Name, '' " & _
            " PIVOT pr.RatingTypeID"

            Return Me.GetDataSet(SQL, "Player Ratings")


        End Function

        Function GetPlayer(ByVal intPlayerID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT * FROM Players Where PlayerID=" & intPlayerID
            Return GetDataReader(SQL)
        End Function

        Function GetReferee(ByVal intRefereeID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT * FROM Referees Where RefereeID=" & intRefereeID
            Return GetDataReader(SQL)
        End Function

        Function GetReferees() As OleDbDataReader
            Dim SQL As String = "SELECT * FROM Referees"
            Return GetDataReader(SQL)
        End Function

        Function GetPlayerRatings(ByVal intPlayerID As Integer) As OleDbDataReader
            Dim SQL As String = _
             "SELECT * FROM PlayerRatings WHERE PlayerID= " & intPlayerID
            Return GetDataReader(SQL)
        End Function


        Sub UpdatePlayerCard(ByVal objPlayer As Player)
            Dim SQL As String
            With objPlayer
                SQL = "UPDATE Players SET " & _
                " LastName = " & FormatField(objPlayer.LastName, True, True) & _
                " FirstName = " & FormatField(objPlayer.FirstName, True, True) & _
                " Hometown = " & FormatField(objPlayer.Hometown, True, True) & _
                " College = " & FormatField(objPlayer.College, True, True) & _
                " HighSchool = " & FormatField(objPlayer.HighSchool, True, True) & _
                " Jersey = " & FormatField(objPlayer.Jersey, False, True) & _
                " Age = " & FormatField(objPlayer.Age, False, False) & _
                 " WHERE PlayerID = " & objPlayer.ID
            End With

            RunCommand(SQL)
        End Sub

        Function GetPlayerEvents(ByVal intPlayerID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT * FROM PlayerEvents WHERE PlayerID = " & intPlayerID & " ORDER BY EventDate ASC"
            Return GetDataReader(SQL)
        End Function

    End Class
End Namespace