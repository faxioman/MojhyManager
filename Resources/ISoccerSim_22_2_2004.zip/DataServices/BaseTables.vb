'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.Data.OleDb
Imports ISoccerSim.Tactical

Namespace DataServices

	Friend Class BaseTables
		Inherits DataService

		Function GetFirstNames() As OleDbDataReader
			Dim SQL As String = "SELECT NameID, FirstName FROM FirstNames ORDER BY FirstName"
			Return GetDataReader(SQL)
		End Function

		Function GetLastNames() As OleDbDataReader
			Dim SQL As String = "SELECT NameID, LastName FROM LastNames ORDER BY LastName"
			Return GetDataReader(SQL)
		End Function

		Function GetColleges() As OleDbDataReader
			Dim SQL As String = "SELECT CollegeID, College FROM Colleges ORDER BY College"
			Return GetDataReader(SQL)
		End Function

		Function GetNicknames() As OleDbDataReader
			Dim SQL As String = "SELECT NicknameID, Nickname FROM Nicknames ORDER BY Nickname"
			Return GetDataReader(SQL)
		End Function

		Function GetMascots() As OleDbDataReader
			Dim SQL As String = "SELECT MascotID, Mascot FROM Mascots ORDER BY Mascot"
			Return GetDataReader(SQL)
		End Function

		Function GetTweaks() As OleDbDataReader
			Dim SQL As String = "SELECT TweakID, [Key], [Value] FROM Tweaks ORDER BY [Key]"
			Return GetDataReader(SQL)
		End Function

		Function GetPlayerAging() As OleDbDataReader
			Dim SQL As String = _
			  "SELECT PlayerAgingID, Age, InitialCurve, PotentialMin, PotentialMax " & _
			  "FROM PlayerAging ORDER BY Age"
			Return GetDataReader(SQL)
		End Function

		Function GetPositions() As OleDbDataReader
			Dim SQL As String = _
			  "SELECT p.PositionID, p.[Name], p.Abbr, p.SalaryModifier, " & _
			  "p.AIDraftInitialStarters, p.AIDraftInitialMid, p.AIDraftInitialLate, p.AutoStockProb " & _
			  "FROM Positions AS p " & _
			  "ORDER BY p.[Name]"
			Return GetDataReader(SQL)
		End Function

		Function GetPositionValues() As OleDbDataReader
			Dim SQL As String = _
			 "SELECT * FROM PositionValues ORDER BY PositionValueID " 
			Return GetDataReader(SQL)
		End Function

		Function GetGamePositionValues() As OleDbDataReader
			Dim SQL As String = _
			 "SELECT * FROM GamePositions ORDER BY GamePositionID "
			Return GetDataReader(SQL)
		End Function

		Function GetPlayerSkills() As OleDbDataReader
			Dim SQL As String = _
			 "SELECT PlayerSKillID, Description, Multiplier, Probability " & _
			 "FROM PlayerSkills ORDER BY Multiplier"
			Return GetDataReader(SQL)
		End Function

		Function GetRatingDistribution() As OleDbDataReader
			Dim SQL As String = _
			"SELECT RatingDistID, RatingID, PositionID, Mean, StdDev, [Min], [Max]" & _
			"FROM RatingDistributions ORDER BY PositionID"
			Return GetDataReader(SQL)
		End Function

		Function GetCities() As OleDbDataReader
			Dim SQL As String = _
			"SELECT * FROM Cities ORDER BY City"
			Return GetDataReader(SQL)
		End Function

		Function GetTactics() As OleDbDataReader
			Dim SQL As String = "SELECT * FROM Tactics ORDER BY TacticID"
			Return GetDataReader(SQL)
		End Function

		Function GetMedia() As OleDbDataReader
			Dim SQL As String = "SELECT * FROM Media ORDER By MediaID"
			Return GetDataReader(SQL)
        End Function

        Function GetSituations() As OleDbDataReader
            Dim SQL As String = "SELECT * FROM Situations ORDER BY SituationID"
            Return GetDataReader(SQL)
        End Function

        Function GetPlayByPlay() As OleDbDataReader
            Dim SQL As String = "SELECT * FROM PlayByPlay ORDER BY PlayByPlayID"
            Return GetDataReader(SQL)
        End Function

        Function GetPlayByPlayItems(ByVal intID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT * FROM PlayByPlayItems WHERE PlayByPlayID = " & intID & " ORDER BY ItemID "
            Return GetDataReader(SQL)
        End Function

        Function GetPlayByPlayItemDataSet(ByVal intID As Integer) As DataSet
            Dim SQL As String = "SELECT * FROM PlayByPlayItems WHERE PlayByPlayID = " & intID & " ORDER BY ItemID "
            Return GetDataSet(SQL, "Play By Play")
        End Function

        Function GetPlayByPlayComment(ByVal intID As Integer) As OleDbDataReader
            Dim SQL As String = "SELECT * FROM PLayByPlayItems WHERE ItemID = " & intID
            Return GetDataReader(SQL)
        End Function

        Sub UpdatePlayByPlayComment(ByVal PBP As SimEngine.PlayByPlay.PlayByPlayComment)
            Dim SQL As String
            SQL = "UPDATE PlayByPlayItems SET " & _
               " Description = " & FormatField(PBP.Narrative, True, True) & _
               " Probability = " & FormatField(PBP.Probability, False, True) & _
               " PlayByPlayID = " & FormatField(PBP.PlayByPlayID, False, False) & _
               " WHERE ItemID = " & PBP.PlayByPlayCommentID
            Me.RunCommand(SQL)
        End Sub

        Sub InsertPlayByPlayComment(ByVal PBP As SimEngine.PlayByPlay.PlayByPlayComment)
            Dim SQL As String
            SQL = "INSERT INTO PlayByPlayItems " & _
               " (Description, Probability, PlayByPlayID) " & _
               " VALUES (" & _
             FormatField(PBP.Narrative, True, True) & _
             FormatField(PBP.Probability, False, True) & _
             FormatField(PBP.PlayByPlayID, False, False) & ")"
            Me.RunCommand(SQL)
        End Sub

        Sub DeletePlayByPlayComment(ByVal ID As Integer)
            Dim SQL As String
            SQL = "DELETE FROM PlayByPlayItems WHERE ItemID = " & ID
            Me.RunCommand(SQL)
        End Sub

        'Function GetRegionForCity(ByVal intCityID As Integer) As OleDbDataReader
        '	Dim Where As String

        '	Dim SQL As String = " SELECT r.RegionID, c.ID " & _
        '	   "FROM Cities AS c INNER JOIN (Regions AS r INNER JOIN States AS s ON r.RegionID = s.RegionID) ON c.State = s.Abbr " & _
        '	   "WHERE c.ID = " & intCityID
        '	Return GetDataReader(SQL)
        'End Function

        Function GetStates() As OleDbDataReader
            Dim SQL As String = "SELECT * FROM States ORDER BY StateID"
            Return GetDataReader(SQL)
        End Function


        Sub UpdateTactic(ByVal objTactic As Tactic)
            Dim SQL As String
            With objTactic
                SQL = "Update Tactics SET " & _
                "Abbreviation = " & FormatField(.Abbreviation, True, False) & _
                ", CreasePlay = " & FormatField(.CreasePlay, False, False) & _
                ", CrossPassing = " & FormatField(.CrossPassing, False, False) & _
                ", DefenseEngagement = " & FormatField(.DefensiveEngagement, False, False) & _
                ", Description = " & FormatField(.Description, True, False) & _
                ", ForwardPassing = " & FormatField(.ForwardPassing, False, False) & _
                ", GoalieRoving = " & FormatField(.GoalieRoving, False, False) & _
                ", LongBall = " & FormatField(.LongBall, False, False) & _
                ", [Name] = " & FormatField(.Name, True, False) & _
                ", [Parameter] = " & FormatField(.Parameter, False, False) & _
                ", Posture = " & FormatField(.Posture, False, False) & _
                ", Regroup = " & FormatField(.Regroup, False, False) & _
                ", ZoneToMan = " & FormatField(.ZoneToMan, False, False) & _
                 " WHERE TacticID=" & .TacticID
            End With

            RunCommand(SQL)
        End Sub


        Sub UpdateSituation(ByVal objSituation As Situation)
            Dim SQL As String
            With objSituation
                SQL = "Update Situations SET " & _
                "Abbreviation = " & FormatField(.Abbreviation, True, False) & _
                ", BuiltIn = " & FormatField(.BuiltIn, False, False) & _
                ", Half = " & FormatField(.Half, False, False) & _
                ", IsPenaltyKill = " & FormatField(.IsPenaltyKill, False, False) & _
                ", IsPowerPlay = " & FormatField(.IsPowerPlay, False, False) & _
                ", MinuteFrom = " & FormatField(.MinuteFrom, False, False) & _
                ", MinuteTo = " & FormatField(.MinuteTo, False, False) & _
                ", [MultiNetHigh] = " & FormatField(.MultiNetHigh, False, False) & _
                ", [MultiNetLow] = " & FormatField(.MultiNetLow, False, False) & _
                ", [Name] = " & FormatField(.Name, True, False) & _
                ", NetHigh = " & FormatField(.NetHigh, False, False) & _
                ", NetLow = " & FormatField(.NetLow, False, False) & _
                 " WHERE SituationID=" & .SituationID
            End With

            RunCommand(SQL)
        End Sub


        Sub ClearDB()
            Dim SQL As String
            SQL = "DELETE * FROM Players"
            RunCommand(SQL)
            SQL = "DELETE * FROM PlayerRatings"
            RunCommand(SQL)
            SQL = "DELETE * FROM Teams"
            RunCommand(SQL)
            SQL = "DELETE * FROM Rosters"
            RunCommand(SQL)
            SQL = "DELETE * FROM Schedule"
            RunCommand(SQL)
            SQL = "DELETE * FROM Leagues"
            RunCommand(SQL)
            SQL = "DELETE * FROM FreeAgentPool"
            RunCommand(SQL)
            SQL = "DELETE * FROM RookiePool"
            RunCommand(SQL)
            SQL = "DELETE * FROM Conferences"
            RunCommand(SQL)
            SQL = "DELETE * FROM Divisions"
            RunCommand(SQL)
        End Sub
    End Class

End Namespace
