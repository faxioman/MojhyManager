'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.Data.OleDb
Imports ISoccerSim.Tactical
Imports ISoccerSim.Statistics

Namespace DataServices.AdvancedStats

	Friend Class LeaderboardMPS
		Inherits AdvancedStatService


		Overrides Function GetBaseLeagueStat() As DataSet
			Dim SQL As String
			Dim pobjDS As DataSet
			Dim pobjTable As DataTable


			SQL = GetBaseLeagueQuery("")
			pobjDS = AddCalculatedColumns(Me.GetDataSet(SQL, "Stats"))
			Return pobjDS
		End Function

		Overrides Function GetBaseLeagueStatForTeam(ByVal Stat As ISMStat, ByVal TeamID As Integer) As DataSet
			Dim SQL As String
			Dim pobjDS As DataSet
			Dim pobjTable As DataTable

			SQL = GetBaseLeagueQuery(" AND t.TeamID = " & TeamID)
			pobjDS = AddCalculatedColumns(Me.GetDataSet(SQL, "Stats"))
			Return pobjDS
		End Function

		Overrides Function GetBaseLeagueStatForConference(ByVal Stat As ISMStat, ByVal ConferenceID As Integer) As DataSet
			Dim SQL As String
			Dim pobjDS As DataSet
			Dim pobjTable As DataTable

			SQL = GetBaseLeagueQuery(" AND t.ConferenceID = " & ConferenceID)
			pobjDS = AddCalculatedColumns(Me.GetDataSet(SQL, "Stats"))
			Return pobjDS
		End Function

		Overrides Function GetBaseLeagueStatForDivision(ByVal Stat As ISMStat, ByVal DivisionID As Integer) As DataSet
			Dim SQL As String = GetBaseLeagueQuery(" AND t.DivisionID = " & DivisionID)
			Dim pobjDS As DataSet
			Dim pobjTable As DataTable

			pobjDS = AddCalculatedColumns(Me.GetDataSet(SQL, "Stats"))
			Return pobjDS
		End Function


		Overrides Function GetBaseTeamStat(ByVal Stat As ISMStat) As DataSet
			Dim SQL As String = GetBaseTeamQuery("")
			Dim pobjDS As DataSet
			Dim pobjTable As DataTable

			pobjDS = AddCalculatedColumns(Me.GetDataSet(SQL, "Stats"))
			Return pobjDS
		End Function

		Overrides Function GetBaseTeamStatForConference(ByVal Stat As ISMStat, ByVal ConferenceID As Integer) As DataSet
			Dim SQL As String = GetBaseTeamQuery(" AND t.ConferenceID = " & ConferenceID)
			Dim pobjDS As DataSet
			Dim pobjTable As DataTable

			pobjDS = AddCalculatedColumns(Me.GetDataSet(SQL, "Stats"))
			Return pobjDS
		End Function

		Overrides Function GetBaseTeamStatForDivision(ByVal Stat As ISMStat, ByVal DivisionID As Integer) As DataSet
			Dim SQL As String = GetBaseTeamQuery(" AND t.DivisionID = " & DivisionID)
			Dim pobjDS As DataSet
			Dim pobjTable As DataTable

			pobjDS = AddCalculatedColumns(Me.GetDataSet(SQL, "Stats"))
			Return pobjDS
		End Function

		Private Function GetBaseLeagueQuery(ByVal strWhere As String) As String

			Return "TRANSFORM Sum(gs.Value) AS [Value] " & _
			  " SELECT pl.FirstName, pl.LastName, t.Abbreviation AS Team, Positions.Abbr AS POS, pl.PlayerID " & _
			  " FROM ((Teams AS t INNER JOIN Rosters AS r ON t.TeamID = r.TeamID) INNER JOIN (Statistics AS s INNER JOIN (Players AS pl INNER JOIN GameStats AS gs ON pl.PlayerID = gs.PlayerID) ON s.StatID = gs.StatisticID) ON r.PlayerID = pl.PlayerID) INNER JOIN Positions ON pl.PositionID = Positions.PositionID " & _
			  " WHERE ((s.StatID) IN (29, 2, 27, 25, 2, 1) " & strWhere & ")" & _
			  " GROUP BY pl.FirstName, pl.LastName, t.Abbreviation, Positions.Abbr, pl.PlayerID " & _
			  " PIVOT s.StatID "
		End Function


		Private Function GetBaseTeamQuery(ByVal strWhere As String) As String
			Return "TRANSFORM Sum(gs.Value) AS [Value]" & _
			" SELECT t.Name AS Team, t.TeamID " & _
			" FROM Teams AS t INNER JOIN (Statistics AS s INNER JOIN GameStats AS gs ON s.StatID = gs.StatisticID) ON t.TeamID = gs.TeamID " & _
			" WHERE ((s.StatID) IN (29, 2, 27, 25, 2, 1) " & strWhere & ")" & _
			" GROUP BY t.Name, t.TeamID " & _
			" PIVOT s.StatID; "
		End Function


		Private Function AddCalculatedColumns(ByVal pobjDS As DataSet) As DataSet
			SafelyAddColumn(pobjDS, "2", System.Type.GetType("System.Int32"), "0")
			SafelyAddColumn(pobjDS, "27", System.Type.GetType("System.Int32"), "0")
			SafelyAddColumn(pobjDS, "25", System.Type.GetType("System.Int32"), "0")
			SafelyAddColumn(pobjDS, "29", System.Type.GetType("System.Int32"), "0")
			SafelyAddColumn(pobjDS, "1", System.Type.GetType("System.Int32"), "0")

			SafelyAddColumn(pobjDS, "LastName", System.Type.GetType("System.String"), "''")
			SafelyAddColumn(pobjDS, "FirstName", System.Type.GetType("System.String"), "''")
			SafelyAddColumn(pobjDS, "PlayerName", System.Type.GetType("System.String"), "[LastName] + ', ' + [FirstName]")

			SafelyAddColumn(pobjDS, "GP", System.Type.GetType("System.Int32"), "IsNull([1], 0)")
			SafelyAddColumn(pobjDS, "A", System.Type.GetType("System.Int32"), "IsNull([2], 0)")
			SafelyAddColumn(pobjDS, "3PT", System.Type.GetType("System.Int32"), "IsNull([25], 0)")
			SafelyAddColumn(pobjDS, "2PT", System.Type.GetType("System.Int32"), "IsNull([27], 0)")
			SafelyAddColumn(pobjDS, "1PT", System.Type.GetType("System.Int32"), "IsNull([29], 0)")

			SafelyAddColumn(pobjDS, "Total", System.Type.GetType("System.Int32"), "([3PT] * 3) + ([2PT] * 2) + [1PT] + [A]")
			SafelyAddColumn(pobjDS, "Avg", System.Type.GetType("System.Single"), "[Total]/[GP]")

			Return pobjDS
		End Function

	End Class

End Namespace

