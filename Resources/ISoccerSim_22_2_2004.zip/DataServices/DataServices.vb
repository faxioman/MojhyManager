'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.Data.OleDb

Namespace DataServices

    Interface IStatReport
        Function GetBaseLeagueStat() As DataSet
        Function GetBaseLeagueStatForTeam(ByVal Stat As ISoccerSim.Statistics.ISMStat, ByVal TeamID As Integer) As DataSet
        Function GetBaseLeagueStatForConference(ByVal Stat As ISoccerSim.Statistics.ISMStat, ByVal ConferenceID As Integer) As DataSet
        Function GetBaseLeagueStatForDivision(ByVal Stat As ISoccerSim.Statistics.ISMStat, ByVal DivisionID As Integer) As DataSet
        Function GetBaseTeamStat(ByVal Stat As ISoccerSim.Statistics.ISMStat) As DataSet
        Function GetBaseTeamStatForConference(ByVal Stat As ISoccerSim.Statistics.ISMStat, ByVal ConferenceID As Integer) As DataSet
        Function GetBaseTeamStatForDivision(ByVal Stat As ISoccerSim.Statistics.ISMStat, ByVal DivisionID As Integer) As DataSet
    End Interface

    Friend Class DataService

        Sub Reconnect()
            DBConnect.Reconnect()

        End Sub

        Private Sub Connect()
            DBConnect = DBConnect.GetInstance()
            DBConnect.Connect()
        End Sub
        Sub New()
            Call Connect()
        End Sub

        Sub Close()
            'DBConnect.cn.Close()
        End Sub


        Friend Function GetDataReader(ByVal strSQL As String) As OleDbDataReader
            Try
                'Console.WriteLine("OK:  " & DBConnect.TotalCalls & " - " & strSQL)
                Dim cmd As New OleDbCommand(strSQL, DBConnect.cn)
                Dim dr As OleDbDataReader = cmd.ExecuteReader()
                Return dr
            Catch ex As Exception
                Call HandleException(Me, ex)

            End Try

        End Function

        Friend Function GetDataSet(ByVal strSQL As String, ByVal strName As String) As DataSet
            Try
                Dim ds As New DataSet()
                Dim da As New OleDbDataAdapter(strSQL, DBConnect.cn)
                da.Fill(ds, strName)
                Return ds
            Catch ex As Exception
                Call HandleException(Me, ex)
            End Try
        End Function


        Friend Function RunCommand(ByVal strSQL As String)
            Dim pobjCmd As New OleDbCommand(strSQL, DBConnect.cn)

            Try
                pobjCmd.ExecuteNonQuery()
            Catch ex As Exception
                Call HandleException(Me, ex)
            End Try
        End Function

        Friend Function FormatField(ByVal varIn As Object, ByVal IsString As Boolean, ByVal UseComma As Boolean) As String
            Dim strOut As String

            strOut = CStr(varIn)

            If strOut.IndexOf("'") > -1 Then
                strOut = Replace(strOut, "'", "''")
            End If

            If IsString Then
                strOut = "'" & strOut & "'"
            End If

            If UseComma Then
                strOut = strOut & ", "
            End If
            Return strOut
        End Function

        Friend Function GetID(ByVal Table As String, ByVal IDField As String) As Integer
            Dim Out As Integer
            Dim SQL As String = _
             "SELECT TOP 1 " & IDField & " FROM " & Table & _
              " ORDER BY " & IDField & " DESC "

            Dim pobjDR As OleDbDataReader = GetDataReader(SQL)
            Do While pobjDR.Read
                Out = pobjDR.Item(IDField)
            Loop
            pobjDR.Close()
            Return Out


        End Function


    End Class
End Namespace

