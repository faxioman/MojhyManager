'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Leagues

Namespace Schedules
	Friend Class Schedule
		Inherits System.Collections.CollectionBase

		Friend Total As Double
		Friend mobjLeague As League
		Friend Year As Integer
		Friend TotalWeeks As Integer

        Friend Function GetHomeGamesForTeam(ByVal TeamID As Integer) As Integer
            Dim objGame As Game
            Dim Result As Integer


            For Each objGame In Me.InnerList
                If objGame.HomeTeamID = TeamID Then
                    If objGame.Phase = ISMPhase.RegSeason Then
                        Result += 1
                    End If
                End If
            Next
            Return Result
        End Function

        Friend Function IsGameHomeOpener(ByVal TeamID As Integer, ByVal GameID As Integer) As Boolean
            Dim objGame As Game

            Me.InnerList.Sort()
            For Each objGame In Me.InnerList
                If objGame.HomeTeamID = TeamID Then
                    If objGame.GameID = GameID Then
                        Return True
                    Else
                        Return False
                    End If
                End If
            Next
        End Function

        Default Property Item(ByVal index As Integer) As Game
            Get
                Return CType(InnerList.Item(index), Game)
            End Get
            Set(ByVal Value As Game)
                InnerList.Item(index) = Value
            End Set
        End Property

        Sub Add(ByVal value As Game)
            InnerList.Add(value)
        End Sub

        Function ReverseSort() As IComparer
            Return CType(New ReverseDateSort(), IComparer)
        End Function

        Sub Create(ByVal AwayTeamID As Integer, ByVal GameID As Integer, ByVal Phase As ISMPhase, ByVal Season As Integer, ByVal WeekID As Integer)
            Dim pobjItem As New Game()
            With pobjItem
                .Attendance = 0
                .AwayScore = 0
                .AwayTeamID = AwayTeamID
                .GameID = GameID
                .HomeScore = 0
                .HomeTeamID = 0
                .Overtime = 0
                .Phase = Phase
                .Season = Season
                .Status = 0
                .Used = 0
                Me.Total = Me.Total + 1
            End With

            InnerList.Add(pobjItem)
        End Sub

        Sub LoadGame(ByVal AwayTeamID As Integer, ByVal GameID As Integer, ByVal Phase As ISMPhase, ByVal Season As Integer, ByVal WeekID As Integer, _
         ByVal Attendance As Integer, ByVal AwayScore As Integer, ByVal HomeScore As Integer, ByVal HomeTeamID As Integer, _
         ByVal OverTime As Boolean, ByVal Status As Integer, ByVal GameDate As Date)
            Dim pobjItem As New Game()
            With pobjItem
                .Attendance = Attendance
                .AwayScore = AwayScore
                .AwayTeamID = AwayTeamID
                .GameID = GameID
                .GameDate = GameDate
                .HomeScore = HomeScore
                .HomeTeamID = HomeTeamID
                .Overtime = OverTime
                .Phase = Phase
                .Season = Season
                .Status = Status
                .Used = 1

                Me.Total = Me.Total + 1
            End With

            InnerList.Add(pobjItem)
        End Sub





        Sub Save()
            Dim i As Integer
            Dim pobjGame As New Game()
            For Each pobjGame In InnerList
                pobjGame.Save()
            Next

        End Sub

        Sub Load()
            Me.InnerList.Clear()
            Dim pobjDR As Data.OleDb.OleDbDataReader
            Dim pobjDS As New DataServices.LeagueTables()
            pobjDR = pobjDS.GetSchedule()

            Me.InnerList.Clear()
            Do While pobjDR.Read()
                With pobjDR
                    Me.LoadGame(.Item("AwayTeamID"), .Item("ScheduleID"), .Item("Phase"), .Item("Season"), _
                     .Item("WeekID"), .Item("Attendance"), .Item("AwayScore"), .Item("HomeScore"), _
                     .Item("HomeTeamID"), .Item("Overtime"), .Item("Status"), .Item("GameDate"))
                    Me.TotalWeeks = .Item("WeekID")
                End With
            Loop
            pobjDR.Close()
        End Sub

        Sub CreateSchedule()
            Dim pobjSched As New ScheduleMaker(Me.mobjLeague)
            Dim pobjGame As Game
            pobjSched.Create()
            Me.InnerList.Clear()
            Dim intID As Integer

            For Each pobjGame In pobjSched
                intID = intID + 1
                pobjGame.GameID = intID
                Me.Add(pobjGame)
            Next

        End Sub

        Function IsSeasonDone() As Boolean
            Dim pobjGame As Game
            Me.InnerList.Sort()

            For Each pobjGame In Me.InnerList
                If pobjGame.Status = ISMGameScheduleStatus.NotPlayed Then
                    Return False
                End If
            Next
            Return True
        End Function

        Function GetCurrentDate() As Date
            Dim pobjGame As Game
            Me.InnerList.Sort()

            For Each pobjGame In Me.InnerList
                If pobjGame.Status = ISMGameScheduleStatus.NotPlayed Then
                    Return pobjGame.GameDate
                End If
            Next
        End Function

        Function GetFirstGameOfSeason() As Date
            Me.InnerList.Sort()
            Return CType(Me.InnerList(0), Game).GameDate
        End Function

        Function GetLastGameOfSeason() As Date
            Me.InnerList.Sort()
            Return CType(Me.InnerList(Me.InnerList.Count - 1), Game).GameDate
        End Function

        Function GetMonthArray() As ArrayList
            Dim parrOut As New ArrayList()

            Dim pobjGame As Game
            Dim pdatBreak As Date
            'Dim pobjItem As ScheduleMonthItem()
            Me.InnerList.Sort()
            For Each pobjGame In Me.InnerList
                If pdatBreak <> pobjGame.GameDate Then
                    If pdatBreak.Month <> pobjGame.GameDate.Month Then
                        Dim pobjItem As New ScheduleMonthItem()
                        pobjItem.ItemData = pobjGame.GameDate.Month & "/1/" & pobjGame.GameDate.Year
                        pobjItem.IsMonth = True
                        parrOut.Add(pobjItem)
                    End If

                    Dim pobjItem2 As New ScheduleMonthItem()
                    pobjItem2.ItemData = pobjGame.GameDate
                    pobjItem2.IsMonth = False
                    parrOut.Add(pobjItem2)

                    pdatBreak = pobjGame.GameDate
                End If
            Next
            Return parrOut
        End Function

        Function GetCurrentGame() As Game
            Dim pobjGame As Game
            Me.InnerList.Sort()

            For Each pobjGame In Me.InnerList
                If pobjGame.Status = ISMGameScheduleStatus.NotPlayed Then
                    Return pobjGame
                End If
            Next
        End Function

        Function GetGamesForMonth(ByVal datMonth As Date) As DataTable
            Dim pobjDTUtility As New DataTableUtility()
            Dim I As Integer

            Dim pobjTable As New DataTable()
            pobjTable = pobjDTUtility.GetScheduleStructure()

            Dim pobjGame As New Game()
            For Each pobjGame In Me.InnerList()
                If pobjGame.GameDate.Month = datMonth.Month Then
                    Dim pobjRow As DataRow = pobjTable.NewRow()
                    With pobjRow
                        .Item("ID") = pobjGame.GameID
                        .Item("GameDate") = pobjGame.GameDate
                        .Item("Game") = pobjGame.GetScheduleText
                    End With
                    pobjTable.Rows.Add(pobjRow)
                End If
            Next
            pobjTable.TableName = "Schedule"
            Return pobjTable
        End Function

        Function GetGamesForDate(ByVal datMonth As Date) As DataTable
            Dim pobjDTUtility As New DataTableUtility()
            Dim I As Integer

            Dim pobjTable As New DataTable()
            pobjTable = pobjDTUtility.GetScheduleStructure()

            Dim pobjGame As New Game()
            For Each pobjGame In Me.InnerList()
                If pobjGame.GameDate = datMonth Then
                    Dim pobjRow As DataRow = pobjTable.NewRow()
                    With pobjRow
                        .Item("ID") = pobjGame.GameID
                        .Item("GameDate") = pobjGame.GameDate
                        .Item("Game") = pobjGame.GetScheduleText
                    End With
                    pobjTable.Rows.Add(pobjRow)
                End If
            Next
            pobjTable.TableName = "Schedule"
            Return pobjTable
        End Function

        Function GetGameByID(ByVal GameID As Integer) As Game
            Dim pobjGame As Game
            For Each pobjGame In Me.InnerList
                If pobjGame.GameID = GameID Then
                    Return pobjGame
                End If
            Next
        End Function

    End Class

	Friend Class ScheduleMonthItem

		Friend ItemData As Date
		Friend IsMonth As Boolean

		'Sub New(ByVal datIn As Date)
		'	Me.ItemData = datIn
		'End Sub

		Function GetMonthText() As String
			If Me.IsMonth Then
				Return Format(Me.ItemData, "MMMM")
			Else
				Return "  " & Format(Me.ItemData, "M/d/yy")
			End If
		End Function

		Public Overrides Function ToString() As String
			If Me.IsMonth Then
				Return Format(Me.ItemData, "MMMM")
			Else
				Return "  " & Format(Me.ItemData, "M/d/yy")
			End If
        End Function



    End Class
End Namespace