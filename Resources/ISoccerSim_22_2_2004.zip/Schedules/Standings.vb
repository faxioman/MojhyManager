'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Teams

Namespace Schedules
	Friend Class Standings
		Inherits Schedule

		Private mintTotalGames As Integer

		Friend Enum enuPhase
			Season = 0
			Preseason = -1
			PostSeason = 1
		End Enum

		Function GetWinPercentage(ByVal intTeamID As Integer, ByVal intPhase As enuPhase, ByVal intOppID As Integer) As Double
			Dim pdblOut As Double
			Dim Wins As Integer
			Dim Losses As Integer

			Wins = GetWins(intTeamID, intPhase, intOppID)
			Losses = GetLosses(intTeamID, intPhase, intOppID)

			If Wins + Losses = 0 Then
				pdblOut = 0
			Else
				pdblOut = Wins / (Wins + Losses)
			End If

			GetWinPercentage = pdblOut


		End Function


		Function GetWins(ByVal intTeamID As Integer, ByVal intPhase As enuPhase, ByVal intOppID As Integer) As Integer
			Dim I As Integer
			Dim Result As Integer
			Dim pobjGame As Game

			For Each pobjGame In Me.InnerList
				With pobjGame
					If .AwayTeamID = intTeamID Then
						If intOppID = 0 Or .HomeTeamID = intOppID Then
							If .AwayScore > .HomeScore Then
								If .Phase = intPhase Then
									Result = Result + 1
								End If
							End If
						End If
					End If

					If .HomeTeamID = intTeamID Then
						If intOppID = 0 Or .AwayTeamID = intOppID Then
							If .HomeScore > .AwayScore Then
								If .Phase = intPhase Then
									Result = Result + 1
								End If
							End If
						End If
					End If
				End With
			Next
			GetWins = Result
		End Function


		Function GetLosses(ByVal intTeamID As Integer, ByVal intPhase As enuPhase, ByVal intOppID As Integer) As Integer
			Dim I As Integer
			Dim Result As Integer
			Dim pobjGame As Game
			For Each pobjGame In Me.InnerList
				With pobjGame
					If .AwayTeamID = intTeamID Then
						If intOppID = 0 Or .HomeTeamID = intOppID Then
							If .AwayScore < .HomeScore Then
								If .Phase = intPhase Then
									Result = Result + 1
								End If
							End If
						End If
					End If

					If .HomeTeamID = intTeamID Then
						If intOppID = 0 Or .AwayTeamID = intOppID Then
							If .HomeScore < .AwayScore Then
								If .Phase = intPhase Then
									Result = Result + 1
								End If
							End If
						End If
					End If
				End With
			Next
			GetLosses = Result
		End Function


		Function GetPointsFor(ByVal intTeamID As Integer, ByVal intPhase As enuPhase, ByVal intOppID As Integer) As Integer
			Dim I As Integer
			Dim Result As Integer
			Dim pobjGame As Game

			For Each pobjGame In Me.InnerList
				With pobjGame
					If .AwayTeamID = intTeamID Then
						If intOppID = 0 Or .HomeTeamID = intOppID Then
							If .Phase = intPhase Then
								Result = Result + .AwayScore
							End If
						End If
					End If

					If .HomeTeamID = intTeamID Then
						If intOppID = 0 Or .AwayTeamID = intOppID Then
							If .Phase = intPhase Then
								Result = Result + .HomeScore
							End If
						End If
					End If
				End With
			Next
			GetPointsFor = Result

		End Function

		Function GetPointsAgainst(ByVal intTeamID As Integer, ByVal intPhase As enuPhase, ByVal intOppID As Integer) As Integer
			Dim I As Integer
			Dim Result As Integer
			Dim pobjGame As Game

			For Each pobjGame In Me.InnerList
				With pobjGame
					If .AwayTeamID = intTeamID Then
						If intOppID = 0 Or .HomeTeamID = intOppID Then
							If .Phase = intPhase Then
								Result = Result + .HomeScore
							End If
						End If
					End If

					If .HomeTeamID = intTeamID Then
						If intOppID = 0 Or .AwayTeamID = intOppID Then
							If .Phase = intPhase Then
								Result = Result + .AwayScore
							End If
						End If
					End If
				End With
			Next
			GetPointsAgainst = Result

		End Function


		Function GetWinningStreak(ByVal intTeamID As Integer, ByVal intPhase As enuPhase, ByVal intOppID As Integer) As Integer
			Dim pobjSchedule As New Schedule()
			Dim pobjGame As Game
			Dim Total As Integer

			pobjSchedule = Me.GetReverseGameList(intTeamID)
			For Each pobjGame In pobjSchedule
				If pobjGame.AwayTeamID = intTeamID Then
					If pobjGame.AwayScore > pobjGame.HomeScore Then
						Total = Total + 1
					Else
						Return Total
					End If
				Else
					If pobjGame.HomeScore > pobjGame.AwayScore Then
						Total = Total + 1
					Else
						Return Total
					End If
				End If
			Next
			Return Total

		End Function

		Function GetLastTenGames(ByVal intTeamID As Integer) As String
			Dim pobjSchedule As New Schedule()
			Dim pobjGame As Game
			Dim Win As Integer
			Dim Loss As Integer
			Dim Out As String
			Dim Count As Integer


			pobjSchedule = Me.GetReverseGameList(intTeamID)
			For Each pobjGame In pobjSchedule
				If pobjGame.AwayTeamID = intTeamID Then
					If pobjGame.AwayScore > pobjGame.HomeScore Then
						Win += 1
						Count += 1
					Else
						Loss += 1
						Count += 1
					End If
				Else
					If pobjGame.HomeScore > pobjGame.AwayScore Then
						Win += 1
						Count += 1
					Else
						Loss += 1
						Count += 1
					End If
				End If
				If Count = 10 Then Exit For
			Next
			Out = Win & " - " & Loss
			Return FixSort(Win, Out)
		End Function

		Function GetHomeRecord(ByVal intTeamID As Integer)
			Dim pobjSchedule As New Schedule()
			Dim pobjGame As Game
			Dim Win As Integer
			Dim Loss As Integer
			Dim Out As String
			Dim Count As Integer

			pobjSchedule = Me.GetReverseGameList(intTeamID)
			For Each pobjGame In pobjSchedule
				If pobjGame.HomeTeamID = intTeamID Then
					If pobjGame.HomeScore > pobjGame.AwayScore Then
						Win += 1
						Count += 1
					Else
						Loss += 1
						Count += 1
					End If
				End If
			Next
			Out = Win & " - " & Loss
			Return FixSort(Win, Out)
		End Function

		Function GetAwayRecord(ByVal intTeamID As Integer)
			Dim pobjSchedule As New Schedule()
			Dim pobjGame As Game
			Dim Win As Integer
			Dim Loss As Integer
			Dim Out As String
			Dim Count As Integer

			pobjSchedule = Me.GetReverseGameList(intTeamID)
			For Each pobjGame In pobjSchedule
				If pobjGame.AwayTeamID = intTeamID Then
					If pobjGame.AwayScore > pobjGame.HomeScore Then
						Win += 1
						Count += 1
					Else
						Loss += 1
						Count += 1
					End If
				End If
			Next
			Out = Win & " - " & Loss
			Return FixSort(Win, Out)

		End Function

		Function GetDivisionRecord(ByVal intTeamID As Integer)
			Dim pobjSchedule As New Schedule()
			Dim pobjGame As Game
			Dim Win As Integer
			Dim Loss As Integer
			Dim Out As String
			Dim Count As Integer
			Dim DivisionID As Integer = GetDivisionFromTeamID(intTeamID)

			pobjSchedule = Me.GetReverseGameList(intTeamID)
			For Each pobjGame In pobjSchedule
				If pobjGame.HomeTeamID = intTeamID Then
					If GetDivisionFromTeamID(pobjGame.AwayTeamID) = DivisionID Then
						If pobjGame.HomeScore > pobjGame.AwayScore Then
							Win += 1
							Count += 1
						Else
							Loss += 1
							Count += 1
						End If
					End If
				ElseIf pobjGame.AwayTeamID = intTeamID Then
					If GetDivisionFromTeamID(pobjGame.HomeTeamID) = DivisionID Then
						If pobjGame.AwayScore > pobjGame.HomeScore Then
							Win += 1
							Count += 1
						Else
							Loss += 1
							Count += 1
						End If
					End If
				End If
			Next
			Out = Win & " - " & Loss
			Return FixSort(Win, Out)
		End Function

		Function GetConferenceRecord(ByVal intTeamID As Integer)
			Dim pobjSchedule As New Schedule()
			Dim pobjGame As Game
			Dim Win As Integer
			Dim Loss As Integer
			Dim Out As String
			Dim Count As Integer
			Dim ConferenceID As Integer = GetConferenceFromTeamID(intTeamID)

			pobjSchedule = Me.GetReverseGameList(intTeamID)
			For Each pobjGame In pobjSchedule
				If pobjGame.HomeTeamID = intTeamID Then
					If GetConferenceFromTeamID(pobjGame.AwayTeamID) = ConferenceID Then
						If pobjGame.HomeScore > pobjGame.AwayScore Then
							Win += 1
							Count += 1
						Else
							Loss += 1
							Count += 1
						End If
					End If
				ElseIf pobjGame.AwayTeamID = intTeamID Then
					If GetConferenceFromTeamID(pobjGame.HomeTeamID) = ConferenceID Then
						If pobjGame.AwayScore > pobjGame.HomeScore Then
							Win += 1
							Count += 1
						Else
							Loss += 1
							Count += 1
						End If
					End If
				End If
			Next
			Out = Win & " - " & Loss
			Return FixSort(Win, Out)
		End Function


		Function GetLosingStreak(ByVal intTeamID As Integer, ByVal intPhase As enuPhase, ByVal intOppID As Integer) As Integer
			Dim pobjSchedule As New Schedule()
			Dim pobjGame As Game
			Dim Total As Integer

			pobjSchedule = Me.GetReverseGameList(intTeamID)
			For Each pobjGame In pobjSchedule
				If pobjGame.AwayTeamID = intTeamID Then
					If pobjGame.AwayScore < pobjGame.HomeScore Then
						Total = Total + 1
					Else
						Return Total
					End If
				Else
					If pobjGame.HomeScore < pobjGame.AwayScore Then
						Total = Total + 1
					Else
						Return Total
					End If
				End If
			Next
			Return Total

		End Function

		Function GetStreakText(ByVal intTeamID As Integer, ByVal intPhase As enuPhase, ByVal intOppID As Integer) As String

			Dim Out As String
			Dim W As Integer
			Dim L As Integer

			'If intTeamID = 7 Then Stop
			W = GetWinningStreak(intTeamID, intPhase, intOppID)
			L = GetLosingStreak(intTeamID, intPhase, intOppID)

			If W > 0 Then
				Out = "W" & W
			End If

			If L > 0 Then
				Out = "L" & L
			End If

			If Out = "" Then Out = "W0"

			GetStreakText = Out

			Exit Function

		End Function

		Function GetTotalGames(ByVal intTeamID As Integer, ByVal intPhase As enuPhase) As Integer
			Dim I As Integer
			Dim Result As Integer
			Dim pobjGame As Game

			For Each pobjGame In Me.InnerList
				With pobjGame
					If .Phase = intPhase Then
						If .HomeTeamID = intTeamID Or .AwayTeamID = intTeamID Then
							'MsgBox .HomeTeamID & " v " & .AwayTeamID
							Result = Result + 1
						End If
					End If
				End With
			Next

			GetTotalGames = Result

		End Function

		Function GetDivisionStandings(ByVal intDivisionID As Integer) As DataTable
			Dim pobjDTUtility As New DataTableUtility()
			Dim I As Integer
			Dim LeaderID As Integer = Me.GetLeaderInDivision(intDivisionID)

			Dim pobjTable As New DataTable()
			pobjTable = pobjDTUtility.GetStandingStructure()

			Dim pobjTeam As New Team()
			For Each pobjTeam In mobjLeague
				If pobjTeam.DivisionID = intDivisionID Then
					I = pobjTeam.TeamID
					Dim pobjRow As DataRow = pobjTable.NewRow()
					With pobjRow
						.Item("ID") = I
						.Item("Team") = pobjTeam.Name
						.Item("W") = Me.GetWins(I, enuPhase.Season, 0)
						.Item("L") = Me.GetLosses(I, enuPhase.Season, 0)
						.Item("PF") = Me.GetPointsFor(I, enuPhase.Season, 0)
						.Item("PA") = Me.GetPointsAgainst(I, enuPhase.Season, 0)
						.Item("Streak") = Me.GetStreakText(I, enuPhase.Season, 0)
						.Item("GB") = Me.GetGamesBehind(pobjTeam.TeamID, LeaderID)
						.Item("PCT") = Format(Me.GetWinPercentage(I, enuPhase.Season, 0), "0.000")
						.Item("Last10") = Me.GetLastTenGames(I)
						.Item("Home") = Me.GetHomeRecord(I)
						.Item("Away") = Me.GetAwayRecord(I)
						.Item("DIV") = Me.GetDivisionRecord(I)
						.Item("CONF") = Me.GetConferenceRecord(I)
					End With
					pobjTable.Rows.Add(pobjRow)
				End If
            Next
            pobjTable.TableName = "Standings"
            Return pobjTable
		End Function

		Private Function GetGamesBehind(ByVal W1 As Integer, ByVal L1 As Integer, ByVal W2 As Integer, ByVal L2 As Integer) As Double
			Dim pdblOut As Double

			pdblOut = ((-(W1 + L2) / 2 + Math.Sqrt((W1 + L2) ^ 2 - (4 * W1 * L2) + (4 * W2 * L1)) / 2))

			Return pdblOut
		End Function

		Private Function GetGamesBehind(ByVal LeaderID As Integer, ByVal OtherID As Integer) As Double
			Dim pdblOut As Double

			If LeaderID = OtherID Then
				Return 0
			Else
				pdblOut = GetGamesBehind(GetWins(LeaderID, enuPhase.Season, 0), GetLosses(LeaderID, enuPhase.Season, 0), _
				 GetWins(OtherID, enuPhase.Season, 0), GetLosses(OtherID, enuPhase.Season, 0))
				Return (RoundGamesBehind(pdblOut))
			End If
		End Function

		Private Function RoundGamesBehind(ByVal GamesBehind As Double) As Double
			Dim FirstPart As Integer = Int(GamesBehind)
			Dim SecondPart As Double = Math.Round(GamesBehind, 1) - FirstPart

			If SecondPart >= 0.5 Then
				Return FirstPart + 0.5
			Else
				Return FirstPart
			End If


        End Function

        Friend Function GetLeaderInLeague() As Integer
            Dim pobjTeam As New Team()
            Dim Out As Integer

            Dim W As Integer
            Dim L As Integer
            Dim ID As Integer
            Dim Pct As Double

            Dim WThreshold As Double
            Dim Total As Integer
            Dim TotalThreshold As Integer = 1000000

            For Each pobjTeam In mobjLeague
                ID = pobjTeam.TeamID
                W = Me.GetWins(ID, enuPhase.Season, 0)
                L = Me.GetLosses(ID, enuPhase.Season, 0)

                If L + W > 0 Then
                    Pct = W / (W + L)
                Else
                    Pct = 0
                End If

                Total = W + L

                If Pct > WThreshold Then
                    'If Total <= TotalThreshold Then
                    Out = ID
                    WThreshold = Pct
                    TotalThreshold = Total
                    'End If
                End If
            Next

            Return Out
        End Function

        Friend Function GetLeaderInDivision(ByVal intDivisionID As Integer) As Integer
            Dim pobjTeam As New Team()
            Dim Out As Integer

            Dim W As Integer
            Dim L As Integer
            Dim ID As Integer
            Dim Pct As Double

            Dim WThreshold As Double
            Dim Total As Integer
            Dim TotalThreshold As Integer = 1000000

            For Each pobjTeam In mobjLeague
                If pobjTeam.DivisionID = intDivisionID Then
                    ID = pobjTeam.TeamID
                    W = Me.GetWins(ID, enuPhase.Season, 0)
                    L = Me.GetLosses(ID, enuPhase.Season, 0)

                    If L + W > 0 Then
                        Pct = W / (W + L)
                    Else
                        Pct = 0
                    End If

                    Total = W + L

                    If Pct > WThreshold Then
                        'If Total <= TotalThreshold Then
                        Out = ID
                        WThreshold = Pct
                        TotalThreshold = Total
                        'End If
                    End If
                End If
            Next

            Return Out

        End Function

        Private Function GetReverseGameList(ByVal intTeamID As Integer) As Schedule
            Dim pobjSchedule As New Schedule()
            Dim pobjGame As Game

            For Each pobjGame In Me.InnerList
                If pobjGame.AwayTeamID = intTeamID Or pobjGame.HomeTeamID = intTeamID Then
                    If pobjGame.Status = ISMGameScheduleStatus.Played Then
                        pobjSchedule.Add(pobjGame)
                    End If
                End If
            Next
            pobjSchedule.ReverseSort()
            Return pobjSchedule
        End Function

        Private Function FixSort(ByVal SortValue As Integer, ByVal Output As String)
            If SortValue < 10 Then
                Return " " & Output
            Else
                Return Output
            End If
        End Function

        Private Function GetDivisionFromTeamID(ByVal intTeamID As Integer) As Integer
            Return gobjLeague.GetTeamByID(intTeamID).DivisionID
        End Function

        Private Function GetConferenceFromTeamID(ByVal intTeamID As Integer) As Integer
            Return gobjLeague.GetTeamByID(intTeamID).ConferenceID
        End Function

        Friend Function GetTeamStanding(ByVal intTeamID As Integer) As Finances.AttendanceManager.HomeTeamRecord
            If Me.GetWins(intTeamID, enuPhase.Season, 0) + Me.GetLosses(intTeamID, enuPhase.Season, 0) / Me.GetTotalGames(intTeamID, enuPhase.Season) <= 0.33 Then
                Return Finances.AttendanceManager.HomeTeamRecord.EarlySeason
            End If

            Dim WinPercentage As Double
            If WinPercentage < 0.4 Then
                Return Finances.AttendanceManager.HomeTeamRecord.LosingTeam
            ElseIf WinPercentage >= 0.4 And WinPercentage <= 0.6 Then
                Return Finances.AttendanceManager.HomeTeamRecord.MiddlePack
            ElseIf WinPercentage > 0.6 Then
                Return Finances.AttendanceManager.HomeTeamRecord.Winning
            End If

            If Me.GetLeaderInLeague() = intTeamID Then
                Return Finances.AttendanceManager.HomeTeamRecord.Leading
            End If
        End Function

    End Class
End Namespace