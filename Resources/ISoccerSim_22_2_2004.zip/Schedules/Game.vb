'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Teams

Namespace Schedules

	Friend Enum ISMPhase
		RegSeason = 0
		Preseason = -1
		PostSeason = 1
	End Enum

	Friend Enum ISMGameScheduleStatus
		Played = 1
		NotPlayed = 0
		Postponed = 2
	End Enum

	Friend Class Game
		Implements IComparable

		Friend GameID As Integer
		Friend HomeTeamID As Integer
		Friend AwayTeamID As Integer
		Friend HomeScore As Integer
		Friend AwayScore As Integer
		Friend Overtime As Boolean
		Friend Status As ISMGameScheduleStatus
		Friend Phase As ISMPhase
		Friend Attendance As Integer
		Friend Used As Boolean
		Friend Season As Integer
		Friend GameDate As Date
		Friend WinnerID As Integer
		Friend LoserID As Integer
		Friend WinnerScore As Integer
		Friend LoserScore As Integer


		Sub Save()
			Dim pobjData As New DataServices.LeagueTables()
			pobjData.InsertGame(Me)
			pobjData.Close()
		End Sub

		Sub UpdateResult()
			Dim pobjData As New DataServices.LeagueTables()
			pobjData.UpdateGame(Me)
			pobjData.Close()
		End Sub

		Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
			If obj Is Nothing Then Return 1

			Dim other As Game = CType(obj, Game)
			If Me.GameDate = other.GameDate Then
				If Me.GameID > other.GameID Then
					Return 1
				Else
					Return -1
				End If
			Else
				Return DateTime.Compare(Me.GameDate, other.GameDate)
			End If

		End Function

		Function GetScheduleText() As String
			Dim pobjHomeTeam As Team = gobjLeague.GetTeamByID(Me.HomeTeamID)
			Dim pobjAwayTeam As Team = gobjLeague.GetTeamByID(Me.AwayTeamID)

			If Me.Status = ISMGameScheduleStatus.NotPlayed Then
				Return pobjAwayTeam.Name & " at " & pobjHomeTeam.Name
			Else
				Return pobjAwayTeam.Name & " " & Me.AwayScore & ", " & _
				  pobjHomeTeam.Name & " " & Me.HomeScore
			End If

		End Function

	End Class

	Friend Class ReverseDateSort
		Implements IComparer

		Function Compare(ByVal obj1 As Object, ByVal obj As Object) As Integer Implements IComparer.Compare
			If obj Is Nothing Then Return 1

			Dim other As Game = CType(obj, Game)
			Dim first As Game = CType(obj1, Game)

			If first.GameDate = other.GameDate Then
				If first.GameID > other.GameID Then
					Return 1
				Else
					Return -1
				End If
			Else
				Return -(DateTime.Compare(first.GameDate, other.GameDate))
			End If
			Return 0

		End Function
	End Class

	Friend Class RegularDateSort
		Implements IComparer

		Function Compare(ByVal obj1 As Object, ByVal obj As Object) As Integer Implements IComparer.Compare
			If obj Is Nothing Then Return 1

			Dim other As Game = CType(obj, Game)
			Dim first As Game = CType(obj, Game)

			If first.GameDate = other.GameDate Then
				If first.GameID > other.GameID Then
					Return -1
				Else
					Return 1
				End If
			Else
				Return (DateTime.Compare(first.GameDate, other.GameDate))
			End If
			Return 0

		End Function
	End Class


End Namespace