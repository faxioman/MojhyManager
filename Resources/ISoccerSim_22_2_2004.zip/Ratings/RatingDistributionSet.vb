'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Ratings
    Friend Class RatingDistributionSet
        Inherits System.Collections.CollectionBase

        Friend Total As Double

        Default Property Item(ByVal index As Integer) As RatingDistribution
            Get
                Return CType(InnerList.Item(index), RatingDistribution)
            End Get
            Set(ByVal Value As RatingDistribution)
                InnerList.Item(index) = Value
            End Set
        End Property

        Sub Add(ByVal value As RatingDistribution)
            InnerList.Add(value)
        End Sub

        Sub Create(ByVal RatingDistributionID As Integer, ByVal Maximum As Integer, ByVal Minimum As Integer, ByVal Mean As Double, _
          ByVal PositionID As Integer, ByVal RatingID As Integer, ByVal StandardDeviation As Double)
            Dim pobjItem As New RatingDistribution()
            With pobjItem
                .RatingDistributionID = RatingDistributionID
                .Maximum = Maximum
                .Mean = Mean
                .Minimum = Minimum
                .PositionID = PositionID
                .RatingID = RatingID
                .StandardDeviation = StandardDeviation
                Me.Total = Me.Total + 1
            End With

            InnerList.Add(pobjItem)
        End Sub

        Sub Load()
            Dim pobjDR As OleDb.OleDbDataReader = gData.GetRatingDistribution

            Me.Clear()
            With pobjDR
                Do While .Read()
                    Me.Create(.Item("RatingDistID"), .Item("Max"), .Item("Min"), _
                     .Item("Mean"), .Item("PositionID"), .Item("RatingID"), .Item("StdDev"))
                Loop
            End With
            pobjDR.Close()

        End Sub

        Function GetRatingDistribution(ByVal PositionID As Integer, ByVal RatingID As Integer) As RatingDistribution
            Dim pobjRateDist As New RatingDistribution()
            Dim pobjRateDistOut As New RatingDistribution()

            For Each pobjRateDist In InnerList
                With pobjRateDist
                    If .PositionID = 0 And .RatingID = RatingID Then
                        pobjRateDistOut = pobjRateDist
                    ElseIf .PositionID = PositionID And .RatingID = RatingID Then
                        Return pobjRateDist
                        Exit Function
                    End If
                End With
            Next

            Return pobjRateDistOut

        End Function






    End Class
End Namespace