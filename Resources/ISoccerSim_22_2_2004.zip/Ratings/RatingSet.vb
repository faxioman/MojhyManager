'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Players

Namespace Ratings
	Friend Class RatingSet
		Inherits System.Collections.CollectionBase
		Friend Total As Double


		Default Property Item(ByVal index As ISS_Rating) As Rating
			Get
				Return CType(InnerList.Item(index), Rating)
			End Get
			Set(ByVal Value As Rating)
				InnerList.Item(index) = Value
			End Set
		End Property

		Sub Add(ByVal value As Rating)
			InnerList.Add(value)
		End Sub

		Friend ReadOnly Property MaxRating() As Integer
			Get
				Return 14
			End Get
		End Property

		Sub CreateSet(ByVal Player As Player, ByVal Age As PlayerAge, ByVal Skill As PlayerSkillLevel)
			Dim i As Integer
			Dim pdblSkillModifier As Double
			Dim pdblAgeMultiplier As Double
			Dim pobjPlayerSkill As PlayerSkillLevel = gobjPlayerSkillSet.GetRandomItemByProbability

			Dim ActualRating As Integer
			Dim PotentialRating As Integer

			Dim pobjActualRating As New Rating()
			Dim pobjPotentialRating As New Rating()

			Try
				For i = 1 To Me.MaxRating
					pdblAgeMultiplier = RandomNumber(Age.PotentialMin, Age.PotentialMax)
					pdblSkillModifier = Skill.Multiplier

					ActualRating = gobjRateDistSet.GetRatingDistribution(Player.Position, i).GetRating
					PotentialRating = GetPotential(Age, ActualRating)

					pobjActualRating.Create(i, ISS_RatingType.Actual, Player.ID, 0, ActualRating)
					pobjPotentialRating.Create(i, ISS_RatingType.Potential, Player.ID, 0, PotentialRating)
					pobjActualRating.Save()
					pobjPotentialRating.Save()
				Next
			Catch ex As Exception
				MsgBox("Stop")
			End Try
		End Sub

		Private Function GetPotential(ByVal objAge As PlayerAge, ByVal iLow As Integer) As Integer
			Dim Low As Integer
			Dim High As Integer
			Dim Ceiling As Integer
			Dim X As Integer
			Dim Out As Integer

			'Set aging ceiling...
			Low = objAge.PotentialMin
			High = objAge.PotentialMax
			Ceiling = RandomNumber(Low, High)

			X = RandomNumber(iLow, 100)
			X = (X) * (Ceiling * 0.01)

			Out = iLow + X
			If Out > 100 Then Out = 100
			Return Out
		End Function


		Sub Load(ByVal intPlayerID As Integer)
			Dim pobjData As New DataServices.PlayerTables()
			Dim pobjDR As OleDb.OleDbDataReader = pobjData.GetPlayerRatings(intPlayerID)
			Dim pobjRating As Rating

			Me.Clear()
			Do While pobjDR.Read()
				With pobjDR
					pobjRating = New Rating()
					pobjRating.PlayerID = .Item("PlayerID")
					pobjRating.RatingID = .Item("RatingID")
					pobjRating.RatingType = .Item("RatingTypeID")
					pobjRating.Value = .Item("Rating")
					pobjRating.ScoutID = .Item("ScoutID")
					Me.Add(pobjRating)
					If pobjRating.RatingType = ISS_RatingType.Actual Then
						Dim pobjCurrent As Rating = pobjRating.Clone()
						pobjCurrent.RatingType = ISS_RatingType.Game
						Me.Add(pobjCurrent)
					End If
				End With
			Loop
			pobjDR.Close()
			pobjData.Close()


		End Sub

		Function GetRatingSetValue(ByVal intPositionID As Integer, ByVal intRatingType As ISS_RatingType) As Integer
			Dim pobjRating As Rating
			Dim Total As Integer

			For Each pobjRating In Me.InnerList
				If pobjRating.RatingType = intRatingType Then
					Total = Total + (gobjPositionValues.GetValueByPair(intPositionID, pobjRating.RatingID) * pobjRating.Value)
				End If
			Next
			Return Total
		End Function

		Function GetRatingSetValue(ByVal intPositionID As Integer) As Integer
			Dim pobjRating As Rating
			Dim Total As Integer

			For Each pobjRating In Me.InnerList
				Total = Total + gobjPositionValues.GetValueByPair(intPositionID, pobjRating.RatingID)
			Next
			Return Total
		End Function

		Sub ChangeRatingBasedOnEnergy(ByVal Multiplier As Double)
			Dim pobjItem As Rating
			For Each pobjItem In Me.InnerList
				If pobjItem.RatingType = ISS_RatingType.Actual And pobjItem.IsPhysical Then
					Dim pobjFind As Rating
					For Each pobjFind In Me.InnerList
						If pobjFind.RatingType = ISS_RatingType.Game And pobjItem.RatingID = pobjFind.RatingID Then
							pobjItem.Value = Int(pobjFind.Value * Multiplier)
						End If
					Next
				End If
			Next
		End Sub

	End Class
End Namespace