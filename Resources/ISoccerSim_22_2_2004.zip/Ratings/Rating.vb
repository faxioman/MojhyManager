'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Namespace Ratings

	Friend Enum ISS_RatingType
		Actual = 0
		Current = 64
		Potential = 128
		Game = 256
	End Enum

	Friend Enum ISS_Rating
		Passing = 6
		Defense = 2
		Aggression = 7
		Shooting = 8
		Goalkeeper = 4
		Endurance = 3
		Durability = 1
		Mobility = 5
		Dribbling = 9
		Tackling = 10
		FreeKick = 11
		Determination = 12
		Influence = 13
		Positioning = 14
	End Enum


	Friend Class Rating
		Implements ICloneable

		Friend RatingID As ISS_Rating
		Friend RatingType As ISS_RatingType
		Friend PlayerID As Integer
		Friend ScoutID As Integer
		Friend IsPhysical As Boolean

		Private mbytValue As Byte

		Friend Property Value() As Byte
			Get
				Return mbytValue
			End Get
			Set(ByVal bytValue As Byte)
				If bytValue > 100 Then bytValue = 100
				If bytValue < 1 Then bytValue = 1
				mbytValue = bytValue
			End Set
		End Property

		Function GetKey() As String
			Dim Type As String
			Dim Out As String
			Dim I As Integer

			If I > 256 Then
				Type = "Game_"
				I = I - 256
			End If

			If I > 128 Then
				Out = "Potential_"
				I = I - 128
			End If

			If I > 64 Then
				Out = "Current_"
				I = I - 64
			End If

			Select Case I
				Case ISS_Rating.Passing
					Out = "Passing"

				Case ISS_Rating.Defense
					Out = "Defense"

				Case ISS_Rating.Aggression
					Out = "Aggression"

				Case ISS_Rating.Shooting
					Out = "Shooting"

				Case ISS_Rating.Goalkeeper
					Out = "Goalkeeper"

				Case ISS_Rating.Endurance
					Out = "Endurance"

				Case ISS_Rating.Durability
					Out = "Durability"

				Case ISS_Rating.Mobility
					Out = "Mobility"

				Case ISS_Rating.Determination
					Out = "Determination"

				Case ISS_Rating.Dribbling
					Out = "Dribbling"

				Case ISS_Rating.FreeKick
					Out = "Free Kick"

				Case ISS_Rating.Influence
					Out = "Influence"

				Case ISS_Rating.Positioning
					Out = "Positioning"

				Case ISS_Rating.Tackling
					Out = "Tackling"

			End Select

			GetKey = Type & Out

		End Function

		Sub Create(ByVal RatingID As ISS_Rating, ByVal RatingTypeID As ISS_RatingType, ByVal PlayerID As Integer, ByVal ScoutID As Integer, ByVal Value As Byte)
			With Me
				.PlayerID = PlayerID
				.RatingID = RatingID
				.RatingType = RatingTypeID
				.ScoutID = ScoutID
				.Value = Value
			End With
		End Sub

		Sub Save()
			Dim pobjData As New DataServices.PlayerTables()
			pobjData.InsertRating(Me)
			pobjData.Close()
		End Sub

		Function Clone() Implements ICloneable.Clone
			Dim pobjItem As New Rating()
			pobjItem = Me
			Return pobjItem
		End Function

	End Class
End Namespace