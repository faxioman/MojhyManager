'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Tactical

    Friend Enum ISMDefaultSituation
        [Default] = 0
    End Enum

    Friend Class SituationSet
        Inherits System.Collections.CollectionBase
        Implements ICloneable

        Default Property Item(ByVal index As Integer) As Situation
            Get
                Return CType(InnerList.Item(index), Situation)
            End Get
            Set(ByVal Value As Situation)
                InnerList.Item(index) = Value
            End Set
        End Property

        Sub Add(ByVal value As Situation)
            InnerList.Add(value)
        End Sub

        Sub Sort()
            Me.InnerList.Sort()
        End Sub

        Sub Create(ByVal Abbreviation As String, ByVal Name As String, ByVal BuiltIn As Boolean, _
         ByVal Half As Integer, ByVal IsPenaltyKill As Boolean, ByVal IsPowerPlay As Boolean, _
         ByVal MinuteFrom As Integer, ByVal MinuteTo As Integer, ByVal MultiNetLow As Integer, _
         ByVal MultiNetHigh As Integer, ByVal NetHigh As Integer, ByVal NetLow As Integer, _
         ByVal SituationID As Integer)
            Dim pobjItem As New Situation()
            With pobjItem
                .Abbreviation = Abbreviation
                .Name = Name
                .BuiltIn = BuiltIn
                .Half = Half
                .IsPenaltyKill = IsPenaltyKill
                .IsPowerPlay = IsPowerPlay
                .MinuteFrom = MinuteFrom
                .MinuteTo = MinuteTo
                .MultiNetLow = MultiNetLow
                .MultiNetHigh = MultiNetHigh
                .NetHigh = NetHigh
                .NetLow = NetLow
                .SituationID = SituationID
            End With
            Me.InnerList.Add(pobjItem)
        End Sub

        Sub Load()
            Dim pobjDS As New DataServices.BaseTables()
            Dim pobjDR As OleDb.OleDbDataReader = pobjDS.GetSituations
            Me.InnerList.Clear()

            Do While pobjDR.Read()
                With pobjDR
                    Call Create(.Item("Abbreviation"), .Item("Name"), .Item("BuiltIn"), .Item("Half"), _
                     .Item("IsPenaltyKill"), .Item("IsPowerPlay"), .Item("MinuteFrom"), .Item("MinuteTo"), _
                     .Item("MultiNetLow"), .Item("MultiNetHigh"), .Item("NetHigh"), .Item("NetLow"), _
                     .Item("SituationID"))
                End With
            Loop
            pobjDR.Close()
        End Sub

        Function Clone() As Object Implements ICloneable.Clone
            Dim pobjClone As New SituationSet()
            pobjClone = Me
            Return pobjClone
        End Function

        Function GetNewID() As Integer
            Dim pobjItem As Situation
            Dim Out As Integer

            For Each pobjItem In Me.InnerList
                If pobjItem.SituationID > Out Then Out = pobjItem.SituationID
            Next
            Out = Out + 1
            Return Out
        End Function




    End Class
End Namespace