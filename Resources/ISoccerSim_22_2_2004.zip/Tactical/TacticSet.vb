'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Tactical
    Friend Class TacticSet
        Inherits System.Collections.CollectionBase
        Implements ICloneable

        Default Property Item(ByVal index As Integer) As Tactic
            Get
                Return CType(InnerList.Item(index), Tactic)
            End Get
            Set(ByVal Value As Tactic)
                InnerList.Item(index) = Value
            End Set
        End Property

        Sub Add(ByVal value As Tactic)
            InnerList.Add(value)
        End Sub

        Sub Create(ByVal Abbreviation As String, ByVal CreasePlay As Integer, ByVal CrossPassing As Integer, _
         ByVal DefensiveEngagement As Integer, ByVal ForwardPassing As Integer, ByVal GoalieRoving As Integer, _
         ByVal LongBall As Integer, ByVal Name As String, ByVal ParameterSetup As Integer, ByVal Posture As Integer, _
         ByVal Regroup As Integer, ByVal ZoneToMan As Integer, ByVal Description As String, ByVal TacticID As Integer)
            Dim pobjItem As New Tactic()
            With pobjItem
                .Abbreviation = Abbreviation
                .CreasePlay = CreasePlay
                .CrossPassing = CrossPassing
                .DefensiveEngagement = DefensiveEngagement
                .ForwardPassing = ForwardPassing
                .GoalieRoving = GoalieRoving
                .LongBall = LongBall
                .Name = Name
                .Parameter = ParameterSetup
                .Posture = Posture
                .Regroup = Regroup
                .ZoneToMan = ZoneToMan
                .Description = Description
                .TacticID = TacticID
            End With
            Me.InnerList.Add(pobjItem)
        End Sub

        Function GetTacticNameByID(ByVal intID As Integer)
            Dim pobjItem As Tactic
            For Each pobjItem In Me.InnerList
                If pobjItem.TacticID = intID Then
                    Return pobjItem.Name
                End If
            Next

        End Function

        Sub Sort()
            Me.InnerList.Sort()
        End Sub

        Sub Load()
            Dim pobjDS As New DataServices.BaseTables()
            Dim pobjDR As OleDb.OleDbDataReader = pobjDS.GetTactics
            Me.InnerList.Clear()

            Do While pobjDR.Read()
                With pobjDR
                    Call Create(.Item("Abbreviation"), .Item("CreasePlay"), .Item("CrossPassing"), _
                      .Item("DefenseEngagement"), .Item("ForwardPassing"), .Item("GoalieRoving"), _
                      .Item("LongBall"), .Item("Name"), .Item("Parameter"), .Item("Posture"), _
                      .Item("Regroup"), .Item("ZoneToMan"), .Item("Description"), .Item("TacticID"))
                End With
            Loop
            pobjDR.Close()
        End Sub

        Function Clone() As Object Implements ICloneable.Clone
            Dim pobjClone As New TacticSet()
            pobjClone = Me
            Return pobjClone
        End Function

        Function GetNewID() As Integer
            Dim pobjItem As Tactic
            Dim Out As Integer

            For Each pobjItem In Me.InnerList
                If pobjItem.TacticID > Out Then Out = pobjItem.TacticID
            Next
            Out = Out + 1
            Return Out
        End Function

        Function IsValid(ByVal pobjTactic As Tactic) As Boolean
            Dim pobjItem As Tactic
            For Each pobjItem In Me.InnerList
                If pobjItem.Abbreviation = pobjTactic.Abbreviation Then
                    Return False
                End If

                If pobjItem.Name = pobjTactic.Name Then
                    Return False
                End If
            Next
            Return True
        End Function

    End Class
End Namespace