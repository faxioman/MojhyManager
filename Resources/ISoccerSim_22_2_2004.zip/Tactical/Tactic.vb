'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Tactical
    Friend Class Tactic
        Implements IComparable, ICloneable, IDefault

        Friend TacticID As Integer
        Friend Name As String
        Friend Abbreviation As String
        Friend Description As String
        Friend LongBall As Integer
        Friend ForwardPassing As Integer
        Friend CrossPassing As Integer
        Friend Regroup As Integer
        Friend GoalieRoving As Integer
        Friend Parameter As Integer
        Friend Posture As Integer
        Friend DefensiveEngagement As Integer
        Friend ZoneToMan As Integer
        Friend CreasePlay As Integer

        Public Overrides Function ToString() As String
            Return Me.Name
        End Function

        Function IsValid() As Boolean
            If Me.Description.Length = 0 Or Me.Abbreviation.Length = 0 Then
                Return False
            Else
                Return True
            End If
        End Function

        Sub Update()
            Dim pobjDS As New DataServices.BaseTables()
            pobjDS.UpdateTactic(Me)
        End Sub


        Function Clone() As Object Implements ICloneable.Clone
            Dim pobjItem As New Tactic()
            pobjItem = Me
            Return pobjItem
        End Function

        Sub SetDefault(ByVal ID As Integer) Implements IDefault.SetDefault
            With Me
                .Abbreviation = "NEW"
                .Name = "... Add New Tactic"
                .CreasePlay = 50
                .CrossPassing = 50
                .DefensiveEngagement = 50
                .Description = "Description."
                .ForwardPassing = 50
                .GoalieRoving = 50
                .LongBall = 50
                .Parameter = 50
                .Posture = 50
                .Regroup = 50
                .TacticID = ID
                .ZoneToMan = 50
            End With
        End Sub

        Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo

            If obj Is Nothing Then Return 1
            Dim other As Tactic = CType(obj, Tactic)
            Return StrComp(Me.Name, other.Name, CompareMethod.Text)

        End Function

    End Class
End Namespace