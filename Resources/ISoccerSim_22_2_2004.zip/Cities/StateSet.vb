'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Cities
    Friend Class StateSet
        Inherits System.Collections.CollectionBase
        Implements ICloneable

        Friend Total As Double

        Default Property Item(ByVal index As Integer) As State
            Get
                Return CType(InnerList.Item(index), State)
            End Get
            Set(ByVal Value As State)
                InnerList.Item(index) = Value
            End Set
        End Property

        Sub Add(ByVal value As State)
            InnerList.Add(value)
        End Sub

        Sub Create(ByVal Abbreviation As String, ByVal RegionID As Integer, ByVal State As String, ByVal StateID As Integer)
            Dim pobjItem As New State()
            With pobjItem
                .Abbreviation = Abbreviation
                .RegionID = RegionID
                .State = State
                .StateID = StateID
            End With
            Me.Total = Me.Total + 1
            InnerList.Add(pobjItem)
        End Sub

        Sub Load()
            Dim pobjDR As OleDb.OleDbDataReader = gData.GetStates

            Me.Clear()
            With pobjDR
                Do While .Read()
                    Me.Create(.Item("Abbr"), .Item("RegionID"), .Item("State"), .Item("StateID"))
                Loop
            End With
            pobjDR.Close()

        End Sub

        Function GetRandomItemByProbability() As State
            Dim pobjItem As New State()
            Dim pobjRandom As New Random()
            Dim i As Integer
            Dim pdblTotal As Double
            Dim pdblCheck As Double

            pdblCheck = pobjRandom.NextDouble() * Me.Total
            For i = 0 To Innerlist.Count - 1
                pobjItem = InnerList.Item(i)
                pdblTotal = pdblTotal + 1
                If pdblTotal >= pdblCheck Then
                    Return pobjItem
                End If
            Next

        End Function



        Function GetItemByKey(ByVal Key As String) As State
            Dim pobjItem As New State()
            Dim i As Integer
            For Each pobjItem In InnerList
                If pobjItem.State = Key Then
                    Return pobjItem
                    Exit Function
                End If
            Next
        End Function

        Function GetStateByID(ByVal ID As Integer) As State
            Dim pobjItem As State
            For Each pobjItem In Me.InnerList
                If pobjItem.StateID = ID Then
                    Return pobjItem
                End If
            Next

        End Function

        Function Clone() As Object Implements ICloneable.Clone
            Return Me.MemberwiseClone
        End Function

    End Class

End Namespace