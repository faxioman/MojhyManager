'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Cities.CitySet

Namespace Cities
	Friend Class City
		Implements IComparable

		Friend City As String
		Friend Population As Integer
		Friend CityID As Integer
		Friend State As String

		Sub New()

		End Sub

		Friend Property GetCity()
			Get
				Return Me.City
			End Get
			Set(ByVal Value)
				Me.City = Value
			End Set
		End Property

		Friend Property GetPopulation() As Integer
			Get
				Return Me.Population
			End Get
			Set(ByVal Value As Integer)
				Me.Population = Value
			End Set
		End Property

		Function GetAbbreviation()
			'If a city is a split word, use the first two initials, otherwise, 
			'use the first three letters...

			Dim Out As String
			Out = Me.City

			If Me.City.IndexOf(" ") > 0 Then
				Out = Left(Me.City, 1) + Mid(Me.City, Me.City.IndexOf(" ") + 2, 1)
			Else
				Out = Left(Me.City, 3)
			End If

			Out = Out.ToUpper
			Return Out

		End Function



		Public Overrides Function ToString() As String
			Return Me.City
		End Function


		Private Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
			If obj Is Nothing Then Return 1
			Dim other As City = CType(obj, City)
			Return StrComp(Me.ToString, other.ToString, CompareMethod.Text)
		End Function

	End Class
End Namespace
