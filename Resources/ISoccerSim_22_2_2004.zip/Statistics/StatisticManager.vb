'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.DataServices
Imports System.Data
Imports ISoccerSim.DataServices.AdvancedStats.Leaderboard


Namespace Statistics

	Friend Enum ISMStatScope
		League = 0
		Conference = 1
		Division = 2
		Team = 3
	End Enum

	Friend Enum ISMStatType
		Individual = 0
		League = 1
	End Enum



	Friend Class StatisticManager

		Private DataTable As New StatTables()
		Friend StatReports As New StatReportItemSet()


		Friend Scope As ISMStatScope
		Friend StatType As ISMStatType
		Friend ConferenceID As Integer
		Friend DivisionID As Integer
		Friend TeamID As Integer
		Friend Report As StatReportItem

		Friend Sub New()
			Me.StatReports.Load()
		End Sub

		Friend Function GetData(ByVal Report As StatReportItem) As DataSet
			Me.Report = Report

			If Report.IsBase Then
				Return RunBaseReport()
			Else
				'Do something more complicated....
				Return RunAdvancedReport(Report)
			End If
		End Function


		Private Function RunBaseReport() As DataSet

			If Me.StatType = ISMStatType.Individual Then
				Select Case Me.Scope
					Case ISMStatScope.Conference
						Return Me.DataTable.GetBaseLeagueStatForConference(Report.ISMStat, Me.ConferenceID)
					Case ISMStatScope.Division
						Return Me.DataTable.GetBaseLeagueStatForDivision(Report.ISMStat, Me.DivisionID)
					Case ISMStatScope.League
						Return Me.DataTable.GetBaseLeagueStat(Report.ISMStat)
					Case ISMStatScope.Team
						Return Me.DataTable.GetBaseLeagueStatForTeam(Report.ISMStat, Me.TeamID)
				End Select
			Else
				Select Case Me.Scope
					Case ISMStatScope.Conference
						Return Me.DataTable.GetBaseTeamStatForConference(Report.ISMStat, Me.ConferenceID)
					Case ISMStatScope.Division
						Return Me.DataTable.GetBaseTeamStatForDivision(Report.ISMStat, Me.DivisionID)
					Case Else
						Return Me.DataTable.GetBaseTeamStat(Report.ISMStat)
				End Select
			End If

		End Function

		Private Function RunAdvancedReport(ByVal Report As StatReportItem) As DataSet

			If Report.ID = ISMStatReport.ScoringLeaders Then
				Return GetAdvancedTable(New AdvancedStats.Leaderboard())
			ElseIf Report.ID = ISMStatReport.MPS_ScoringLeaders Then
				Return GetAdvancedTable(New AdvancedStats.LeaderboardMPS())
			ElseIf Report.ID = ISMStatReport.GoalieLeaders Then
				Return GetAdvancedTable(New AdvancedStats.LeadingGoalkeepers())
			ElseIf Report.ID = ISMStatReport.MPS_GoalieLeaders Then
				Return GetAdvancedTable(New AdvancedStats.LeadingGoalkeepersMPS())
			End If

		End Function


		Private Function GetAdvancedTable(ByVal pobjTable As AdvancedStats.AdvancedStatService) As DataSet

			If Me.StatType = ISMStatType.Individual Then
				Select Case Me.Scope
					Case ISMStatScope.Conference
						Return pobjTable.GetBaseLeagueStatForConference(Report.ISMStat, Me.ConferenceID)
					Case ISMStatScope.Division
						Return pobjTable.GetBaseLeagueStatForDivision(Report.ISMStat, Me.DivisionID)
					Case ISMStatScope.League
						Return pobjTable.GetBaseLeagueStat()
					Case ISMStatScope.Team
						Return pobjTable.GetBaseLeagueStatForTeam(Report.ISMStat, Me.TeamID)
				End Select
			Else
				Select Case Me.Scope
					Case ISMStatScope.Conference
						Return pobjTable.GetBaseTeamStatForConference(Report.ISMStat, Me.ConferenceID)
					Case ISMStatScope.Division
						Return pobjTable.GetBaseTeamStatForDivision(Report.ISMStat, Me.DivisionID)
					Case Else
						Return pobjTable.GetBaseTeamStat(Report.ISMStat)
				End Select
			End If
		End Function



	End Class
End Namespace