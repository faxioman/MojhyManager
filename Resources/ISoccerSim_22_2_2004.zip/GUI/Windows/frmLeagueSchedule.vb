'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.Schedules
Imports ISoccerSim.SimEngine

Public Class frmLeagueSchedule
	Inherits System.Windows.Forms.Form

	Private WithEvents InProgress As frmInProgress
	Private WithEvents x As SimEngine.GameEngine

	Dim mblnStopSimulating As Boolean = False

#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		Call SetScreen()
	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Friend WithEvents grpContent As System.Windows.Forms.GroupBox
	Friend WithEvents btnOK As System.Windows.Forms.Button
	Friend WithEvents lstMonth As System.Windows.Forms.ListBox
	Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
	Friend WithEvents radCurrentDate As System.Windows.Forms.RadioButton
	Friend WithEvents radRegularSeason As System.Windows.Forms.RadioButton
	Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
	Friend WithEvents dgSchedule As System.Windows.Forms.DataGrid
	Friend WithEvents btnSimulate As System.Windows.Forms.Button
	Friend WithEvents radSelectedDate As System.Windows.Forms.RadioButton
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.grpContent = New System.Windows.Forms.GroupBox()
		Me.GroupBox1 = New System.Windows.Forms.GroupBox()
		Me.radSelectedDate = New System.Windows.Forms.RadioButton()
		Me.btnSimulate = New System.Windows.Forms.Button()
		Me.RadioButton1 = New System.Windows.Forms.RadioButton()
		Me.radRegularSeason = New System.Windows.Forms.RadioButton()
		Me.radCurrentDate = New System.Windows.Forms.RadioButton()
		Me.lstMonth = New System.Windows.Forms.ListBox()
		Me.dgSchedule = New System.Windows.Forms.DataGrid()
		Me.btnOK = New System.Windows.Forms.Button()
		Me.grpContent.SuspendLayout()
		Me.GroupBox1.SuspendLayout()
		CType(Me.dgSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'grpContent
		'
		Me.grpContent.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
					Or System.Windows.Forms.AnchorStyles.Left) _
					Or System.Windows.Forms.AnchorStyles.Right)
		Me.grpContent.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox1, Me.lstMonth, Me.dgSchedule})
		Me.grpContent.Location = New System.Drawing.Point(8, 8)
		Me.grpContent.Name = "grpContent"
		Me.grpContent.Size = New System.Drawing.Size(600, 344)
		Me.grpContent.TabIndex = 0
		Me.grpContent.TabStop = False
		Me.grpContent.Text = "Schedule"
		'
		'GroupBox1
		'
		Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.radSelectedDate, Me.btnSimulate, Me.RadioButton1, Me.radRegularSeason, Me.radCurrentDate})
		Me.GroupBox1.Location = New System.Drawing.Point(16, 192)
		Me.GroupBox1.Name = "GroupBox1"
		Me.GroupBox1.Size = New System.Drawing.Size(128, 144)
		Me.GroupBox1.TabIndex = 22
		Me.GroupBox1.TabStop = False
		Me.GroupBox1.Text = "Simulate..."
		'
		'radSelectedDate
		'
		Me.radSelectedDate.Location = New System.Drawing.Point(8, 40)
		Me.radSelectedDate.Name = "radSelectedDate"
		Me.radSelectedDate.Size = New System.Drawing.Size(104, 16)
		Me.radSelectedDate.TabIndex = 4
		Me.radSelectedDate.Text = "Selected Date"
		'
		'btnSimulate
		'
		Me.btnSimulate.Location = New System.Drawing.Point(8, 112)
		Me.btnSimulate.Name = "btnSimulate"
		Me.btnSimulate.Size = New System.Drawing.Size(112, 24)
		Me.btnSimulate.TabIndex = 3
		Me.btnSimulate.Text = "&Simulate"
		'
		'RadioButton1
		'
		Me.RadioButton1.Enabled = False
		Me.RadioButton1.Location = New System.Drawing.Point(8, 88)
		Me.RadioButton1.Name = "RadioButton1"
		Me.RadioButton1.Size = New System.Drawing.Size(104, 16)
		Me.RadioButton1.TabIndex = 2
		Me.RadioButton1.Text = "Playoffs"
		'
		'radRegularSeason
		'
		Me.radRegularSeason.Location = New System.Drawing.Point(8, 64)
		Me.radRegularSeason.Name = "radRegularSeason"
		Me.radRegularSeason.Size = New System.Drawing.Size(104, 16)
		Me.radRegularSeason.TabIndex = 1
		Me.radRegularSeason.Text = "Regular Season"
		'
		'radCurrentDate
		'
		Me.radCurrentDate.Checked = True
		Me.radCurrentDate.Location = New System.Drawing.Point(8, 16)
		Me.radCurrentDate.Name = "radCurrentDate"
		Me.radCurrentDate.Size = New System.Drawing.Size(104, 16)
		Me.radCurrentDate.TabIndex = 0
		Me.radCurrentDate.TabStop = True
		Me.radCurrentDate.Text = "Current Date"
		'
		'lstMonth
		'
		Me.lstMonth.ItemHeight = 14
		Me.lstMonth.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"})
		Me.lstMonth.Location = New System.Drawing.Point(16, 16)
		Me.lstMonth.Name = "lstMonth"
		Me.lstMonth.Size = New System.Drawing.Size(128, 172)
		Me.lstMonth.TabIndex = 1
		'
		'dgSchedule
		'
		Me.dgSchedule.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
					Or System.Windows.Forms.AnchorStyles.Right)
		Me.dgSchedule.DataMember = ""
		Me.dgSchedule.HeaderForeColor = System.Drawing.SystemColors.ControlText
		Me.dgSchedule.Location = New System.Drawing.Point(160, 16)
		Me.dgSchedule.Name = "dgSchedule"
		Me.dgSchedule.Size = New System.Drawing.Size(432, 320)
		Me.dgSchedule.TabIndex = 0
		'
		'btnOK
		'
		Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnOK.Location = New System.Drawing.Point(496, 360)
		Me.btnOK.Name = "btnOK"
		Me.btnOK.Size = New System.Drawing.Size(112, 24)
		Me.btnOK.TabIndex = 2
		Me.btnOK.Text = "&OK"
		'
		'frmLeagueSchedule
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.BackColor = System.Drawing.Color.FromArgb(CType(43, Byte), CType(72, Byte), CType(142, Byte))
		Me.ClientSize = New System.Drawing.Size(616, 397)
		Me.ControlBox = False
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.grpContent, Me.btnOK})
		Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.ForeColor = System.Drawing.Color.Gainsboro
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.Name = "frmLeagueSchedule"
		Me.ShowInTaskbar = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.Text = "League Schedule"
		Me.grpContent.ResumeLayout(False)
		Me.GroupBox1.ResumeLayout(False)
		CType(Me.dgSchedule, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub frmDialogBase_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
		'Add standard error handler
		AddHandler Application.ThreadException, New ThreadExceptionEventHandler(AddressOf HandleException)
	End Sub

	Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		Me.Close()
	End Sub

	Private Sub SetScreen()

		SkinForm(Me)
		InProgress = New frmInProgress()
		Me.AddOwnedForm(InProgress)

		Call LoadMonths()
		Call SetInitialDay()
	End Sub

	Private Sub SetInitialDay()
		Dim pobjDate As Date = gobjLeague.Standings.GetCurrentDate
		Dim pobjItem As ScheduleMonthItem
		For Each pobjItem In Me.lstMonth.Items
			If IsDate(pobjItem.GetMonthText) Then
				If pobjItem.GetMonthText = pobjDate Then
					Me.lstMonth.SelectedItem = pobjItem
					Exit Sub
				End If
			End If
		Next
	End Sub


	Private Sub LoadMonths()
		Dim parrMonth As ArrayList = gobjLeague.Schedule.GetMonthArray()
		Dim i As Integer

		Me.lstMonth.Items.Clear()

		For i = 0 To parrMonth.Count - 1
			Me.lstMonth.Items.Add(parrMonth.Item(i))
		Next
	End Sub

	Private Sub lstMonth_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstMonth.SelectedIndexChanged
		Call LoadSchedule()
		If IsDate(CType(Me.lstMonth.SelectedItem, ScheduleMonthItem).GetMonthText) Then
			If DateDiff(DateInterval.Day, CType(Me.lstMonth.SelectedItem, ScheduleMonthItem).ItemData, gobjLeague.Standings.GetCurrentDate) > 0 Then
				Me.radSelectedDate.Enabled = False
			Else
				Me.radSelectedDate.Enabled = True
			End If
		Else
			Me.radSelectedDate.Enabled = False
		End If


	End Sub

	Private Sub LoadSchedule()
		Call LoadSchedule(Me.dgSchedule)
	End Sub

	Private Sub LoadSchedule(ByRef dg As DataGrid)
		SetCursor(True, Me)
		Dim pobjView As New DataViewUtility()
		'pobjView.Standardize(gobjLeague.Schedule.GetMonthlySchedule(Me.lstMonth.SelectedItem))
		Dim pobjItem As ScheduleMonthItem = CType(Me.lstMonth.SelectedItem, ScheduleMonthItem)
		If pobjItem.IsMonth Then
			pobjView.Standardize(gobjLeague.Schedule.GetGamesForMonth(pobjItem.ItemData))
		Else
			pobjView.Standardize(gobjLeague.Schedule.GetGamesForDate(pobjItem.ItemData))
		End If

		With dg
			.DataSource = pobjView
			.CaptionText = CType(Me.lstMonth.SelectedItem, ScheduleMonthItem).GetMonthText & " Games"
		End With

		Dim pobjHelper As New DataGridUtility(dg, "Schedule")
		With pobjHelper
			.SetLeagueScheduleGrid()
			.Commit()
		End With
		SetCursor(False, Me)
	End Sub

	Private Sub dgRoster_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgSchedule.MouseDown
		Dim pt As New Point(e.X, e.Y)
		Dim hti As DataGrid.HitTestInfo = Me.dgSchedule.HitTest(pt)

		If hti.Type = DataGrid.HitTestType.Cell Or hti.Type = DataGrid.HitTestType.RowHeader Then
			Me.dgSchedule.CurrentCell = New DataGridCell(hti.Row, hti.Column)
			Me.dgSchedule.Select(hti.Row)

			Call GetGameDetail(Int(Me.dgSchedule(hti.Row, 0)))
		End If
	End Sub

	Private Sub GetGameDetail(ByVal GameID As Integer)
		Dim pobjGame As Game = gobjLeague.Schedule.GetGameByID(GameID)
		If pobjGame.Status = ISMGameScheduleStatus.NotPlayed Then
			If pobjGame.GameDate = gobjLeague.Schedule.GetCurrentDate Then
				InProgress.Show()
				Call SimulateGame(pobjGame)
                InProgress.Hide()
                Call LoadSchedule()
            Else
                Call PreviewGame(pobjGame)
            End If
        Else
			Call ShowResults(pobjGame)
		End If
	End Sub

	Private Sub SimulateGame(ByVal objGame As Game)
		App.SetCursor(True, Me)


		x = New GameEngine()
		x.Load(objGame)

		InProgress.UpdateBoard(x)
		InProgress.Refresh()

		Do Until x.Status = ISMGameStatus.GameOver
			x.Step()
		Loop
		x.StatSave.Commit()
		App.SetCursor(False, Me)

	End Sub

	Private Sub PreviewGame(ByVal objGame As Game)

	End Sub

	Private Sub ShowResults(ByVal objGame As Game)
		Dim f As New frmGameResults()
		f.LoadGame(objGame.GameID)
		f.ShowDialog(Me)
	End Sub

	Private Sub btnSimulate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimulate.Click
		If Me.radCurrentDate.Checked = True Then SimulateCurrentDate()
		If Me.radRegularSeason.Checked = True Then SimulateRegularSeason()
		If Me.radSelectedDate.Checked = True Then SimulateToSelectedDate()
	End Sub

	Private Sub SimulateCurrentDate()
		Dim pobjGame As Game
		Dim i As Integer
		Dim CurrentDate As Date = gobjLeague.Schedule.GetCurrentDate

		For i = 0 To gobjLeague.Schedule.Count - 1
			pobjGame = gobjLeague.Schedule.Item(i)
			If pobjGame.GameDate = CurrentDate Then
				If pobjGame.Status = ISMGameScheduleStatus.NotPlayed Then
					InProgress.Show()
					Call SimulateGame(pobjGame)
				End If
			End If
		Next
		InProgress.Hide()
		Call LoadSchedule()
	End Sub

	Private Sub SimulateToSelectedDate()
		Dim pobjGame As Game
		Dim i As Integer
		Dim SelectedDate As Date
		If IsDate(CType(Me.lstMonth.SelectedItem, ScheduleMonthItem).GetMonthText) Then
			SelectedDate = CType(Me.lstMonth.SelectedItem, ScheduleMonthItem).GetMonthText
		Else
			Exit Sub
		End If

		For i = 0 To gobjLeague.Schedule.Count - 1
			pobjGame = gobjLeague.Schedule.Item(i)
			If DateDiff(DateInterval.Day, pobjGame.GameDate, SelectedDate) >= 0 Then
				If pobjGame.Status = ISMGameScheduleStatus.NotPlayed Then
					If InProgress.Visible Then
						InProgress.Refresh()
					Else
						InProgress.Show()
					End If
					Call SimulateGame(pobjGame)
				End If
			End If
		Next
		InProgress.Hide()
		Call LoadSchedule()
	End Sub

	Private Sub SimulateRegularSeason()
		Dim pobjGame As Game
		Dim i As Integer
		Dim CurrentDate As Date = gobjLeague.Schedule.GetCurrentDate

		For i = 0 To gobjLeague.Schedule.Count - 1
			pobjGame = gobjLeague.Schedule.Item(i)
			If pobjGame.Status = ISMGameScheduleStatus.NotPlayed Then
				InProgress.Show()
				Call SimulateGame(pobjGame)
			End If
		Next
		InProgress.Hide()
		Call LoadSchedule()
	End Sub

	Private Sub UpdateBoard() Handles x.QuarterOver, x.ScoreMade, x.PosessionChanged, x.GameOver
		InProgress.UpdateBoard(x)
	End Sub


End Class
