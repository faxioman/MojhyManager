'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.SimEngine.PlayByPlay

Public Class frmPBP
	Inherits System.Windows.Forms.Form

	Dim mobjPBP As New PlayByPlaySet()


#Region " Windows Form Designer generated code "
	Private WithEvents dataGrid As System.Windows.Forms.DataGrid
	Private WithEvents btnOK As System.Windows.Forms.Button
	Private WithEvents btnAdd As System.Windows.Forms.Button
	Private WithEvents grpPBP As System.Windows.Forms.GroupBox
	Private WithEvents btnRemove As System.Windows.Forms.Button
	Private WithEvents lstEvent As System.Windows.Forms.ListBox

	Public Sub New()
		MyBase.New()
		' Must be called for initialization
		Me.InitializeComponent()
		'
		' TODO : Add constructor code after InitializeComponents
		'

		Call App.SkinForm(Me)
		mobjPBP.Load()
		mobjPBP.Sort()
		Me.lstEvent.DataSource = mobjPBP
	End Sub


	Private Sub InitializeComponent()
		Me.dataGrid = New System.Windows.Forms.DataGrid()
		Me.btnOK = New System.Windows.Forms.Button()
		Me.btnAdd = New System.Windows.Forms.Button()
		Me.grpPBP = New System.Windows.Forms.GroupBox()
		Me.btnRemove = New System.Windows.Forms.Button()
		Me.lstEvent = New System.Windows.Forms.ListBox()
		CType(Me.dataGrid, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.grpPBP.SuspendLayout()
		Me.SuspendLayout()
		'
		'dataGrid
		'
		Me.dataGrid.AccessibleName = "DataGrid"
		Me.dataGrid.AccessibleRole = System.Windows.Forms.AccessibleRole.Table
		Me.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
					Or System.Windows.Forms.AnchorStyles.Left) _
					Or System.Windows.Forms.AnchorStyles.Right)
		Me.dataGrid.DataMember = ""
		Me.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText
		Me.dataGrid.Location = New System.Drawing.Point(8, 16)
		Me.dataGrid.Name = "dataGrid"
		Me.dataGrid.Size = New System.Drawing.Size(448, 336)
		Me.dataGrid.TabIndex = 0
		'
		'btnOK
		'
		Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnOK.Location = New System.Drawing.Point(568, 376)
		Me.btnOK.Name = "btnOK"
		Me.btnOK.Size = New System.Drawing.Size(112, 24)
		Me.btnOK.TabIndex = 2
		Me.btnOK.Text = "&OK"
		'
		'btnAdd
		'
		Me.btnAdd.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnAdd.Location = New System.Drawing.Point(464, 16)
		Me.btnAdd.Name = "btnAdd"
		Me.btnAdd.Size = New System.Drawing.Size(56, 24)
		Me.btnAdd.TabIndex = 3
		Me.btnAdd.Text = "Add"
		'
		'grpPBP
		'
		Me.grpPBP.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnRemove, Me.btnAdd, Me.dataGrid})
		Me.grpPBP.Location = New System.Drawing.Point(152, 8)
		Me.grpPBP.Name = "grpPBP"
		Me.grpPBP.Size = New System.Drawing.Size(528, 360)
		Me.grpPBP.TabIndex = 0
		Me.grpPBP.TabStop = False
		Me.grpPBP.Text = "Play By Play"
		'
		'btnRemove
		'
		Me.btnRemove.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnRemove.Location = New System.Drawing.Point(464, 48)
		Me.btnRemove.Name = "btnRemove"
		Me.btnRemove.Size = New System.Drawing.Size(56, 24)
		Me.btnRemove.TabIndex = 4
		Me.btnRemove.Text = "Remove"
		'
		'lstEvent
		'
		Me.lstEvent.ItemHeight = 14
		Me.lstEvent.Location = New System.Drawing.Point(8, 8)
		Me.lstEvent.Name = "lstEvent"
		Me.lstEvent.Size = New System.Drawing.Size(136, 354)
		Me.lstEvent.TabIndex = 1
		'
		'frmPBP
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(688, 405)
		Me.ControlBox = False
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnOK, Me.lstEvent, Me.grpPBP})
		Me.Font = New System.Drawing.Font("Arial", 8.0!)
		Me.Name = "frmPBP"
		Me.ShowInTaskbar = False
		Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
		Me.Text = "Play By Play"
		CType(Me.dataGrid, System.ComponentModel.ISupportInitialize).EndInit()
		Me.grpPBP.ResumeLayout(False)
		Me.ResumeLayout(False)

	End Sub
#End Region

	Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		Me.Close()
	End Sub

	Private Sub LoadGrid()
		SetCursor(True, Me)
		Dim pobjView As New DataViewUtility()
		Dim pobjItem As PlayByPlay
		Dim dg As DataGrid = Me.dataGrid
		Dim pobjBase As New DataServices.BaseTables()

		pobjItem = CType(Me.lstEvent.SelectedItem, PlayByPlay)

		pobjView.Standardize(pobjBase.GetPlayByPlayItemDataSet(CType(Me.lstEvent.SelectedItem, PlayByPlay).PlayByPlayID))
		pobjView.Sort = "Probability DESC"
		With dg
			.DataSource = pobjView
			.CaptionText = CType(Me.lstEvent.SelectedItem, PlayByPlay).Name
		End With

		Dim pobjHelper As New DataGridUtility(dg, "Play By Play")
		With pobjHelper
			.SetPBPGrid()
			.Commit()
		End With

		If CType(Me.lstEvent.SelectedItem, PlayByPlay).Count > 1 Then
			Me.btnRemove.Enabled = True
		Else
			Me.btnRemove.Enabled = False
		End If
		SetCursor(False, Me)
	End Sub


	Private Sub lstEvent_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstEvent.SelectedIndexChanged
		Call LoadGrid()
	End Sub

	Private Sub dataGrid_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dataGrid.MouseUp
		Dim pt As New Point(e.X, e.Y)
		Dim hti As DataGrid.HitTestInfo = Me.dataGrid.HitTest(pt)
		Dim CommentID As Integer

		If hti.Type = dataGrid.HitTestType.Cell Or hti.Type = dataGrid.HitTestType.RowHeader Then
			Me.dataGrid.CurrentCell = New DataGridCell(hti.Row, hti.Column)
			Me.dataGrid.Select(hti.Row)

			If e.Button = MouseButtons.Left Then
				CommentID = Int(Me.dataGrid(hti.Row, 0))
				Dim f As New frmPBPDetail(CommentID, False)
				f.ShowDialog()
				Call LoadGrid()
			End If
		End If
	End Sub

	Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
		Dim f As New frmPBPDetail(CType(Me.lstEvent.SelectedItem, PlayByPlay).PlayByPlayID, True)
		f.ShowDialog()
		Call LoadGrid()
	End Sub

	Private Sub btnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemove.Click
		Dim ID As Integer = Me.dataGrid(Me.dataGrid.CurrentCell.RowNumber, 0)
		Dim pobjDS As New DataServices.BaseTables()

		pobjDS.DeletePlayByPlayComment(ID)
		Call LoadGrid()



	End Sub
End Class
