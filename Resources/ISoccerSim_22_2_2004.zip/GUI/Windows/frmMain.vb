'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Leagues

Public Class frmMain
	Inherits System.Windows.Forms.Form

	Private WithEvents mobjLeague As New League()

#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		Call SetScreen()
	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
	Friend WithEvents mnuFileExit As System.Windows.Forms.MenuItem
	Friend WithEvents mnuGame As System.Windows.Forms.MenuItem
	Friend WithEvents mnuGameLeague As System.Windows.Forms.MenuItem
	Friend WithEvents mnuGameTeam As System.Windows.Forms.MenuItem
	Friend WithEvents mnuGameOptions As System.Windows.Forms.MenuItem
	Friend WithEvents mnuMain As System.Windows.Forms.MainMenu
	Friend WithEvents stbMain As System.Windows.Forms.StatusBar
	Friend WithEvents stbMainPanel As System.Windows.Forms.StatusBarPanel
	Friend WithEvents mnuHelp As System.Windows.Forms.MenuItem
	Friend WithEvents mnuHelpAbout As System.Windows.Forms.MenuItem
    Friend WithEvents tmrFade As System.Windows.Forms.Timer
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMain))
        Me.mnuMain = New System.Windows.Forms.MainMenu()
        Me.mnuFile = New System.Windows.Forms.MenuItem()
        Me.mnuFileExit = New System.Windows.Forms.MenuItem()
        Me.mnuGame = New System.Windows.Forms.MenuItem()
        Me.mnuGameLeague = New System.Windows.Forms.MenuItem()
        Me.mnuGameTeam = New System.Windows.Forms.MenuItem()
        Me.mnuGameOptions = New System.Windows.Forms.MenuItem()
        Me.mnuHelp = New System.Windows.Forms.MenuItem()
        Me.mnuHelpAbout = New System.Windows.Forms.MenuItem()
        Me.stbMain = New System.Windows.Forms.StatusBar()
        Me.stbMainPanel = New System.Windows.Forms.StatusBarPanel()
        Me.tmrFade = New System.Windows.Forms.Timer(Me.components)
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        CType(Me.stbMainPanel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mnuMain
        '
        Me.mnuMain.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile, Me.mnuGame, Me.mnuHelp})
        '
        'mnuFile
        '
        Me.mnuFile.Index = 0
        Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFileExit})
        Me.mnuFile.Text = "File"
        '
        'mnuFileExit
        '
        Me.mnuFileExit.Index = 0
        Me.mnuFileExit.Text = "Exit"
        '
        'mnuGame
        '
        Me.mnuGame.Index = 1
        Me.mnuGame.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuGameLeague, Me.mnuGameTeam, Me.mnuGameOptions})
        Me.mnuGame.Text = "Game"
        '
        'mnuGameLeague
        '
        Me.mnuGameLeague.Index = 0
        Me.mnuGameLeague.Text = "League"
        '
        'mnuGameTeam
        '
        Me.mnuGameTeam.Index = 1
        Me.mnuGameTeam.Text = "Team"
        '
        'mnuGameOptions
        '
        Me.mnuGameOptions.Index = 2
        Me.mnuGameOptions.Text = "Options"
        '
        'mnuHelp
        '
        Me.mnuHelp.Index = 2
        Me.mnuHelp.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuHelpAbout, Me.MenuItem1})
        Me.mnuHelp.Text = "Help"
        '
        'mnuHelpAbout
        '
        Me.mnuHelpAbout.Index = 0
        Me.mnuHelpAbout.Text = "About"
        '
        'stbMain
        '
        Me.stbMain.Location = New System.Drawing.Point(0, 483)
        Me.stbMain.Name = "stbMain"
        Me.stbMain.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.stbMainPanel})
        Me.stbMain.Size = New System.Drawing.Size(664, 22)
        Me.stbMain.TabIndex = 1
        '
        'stbMainPanel
        '
        Me.stbMainPanel.Text = "Ready"
        '
        'tmrFade
        '
        Me.tmrFade.Interval = 10
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 1
        Me.MenuItem1.Text = "Quick Test"
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(664, 505)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.stbMain})
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.Menu = Me.mnuMain
        Me.Name = "frmMain"
        Me.Text = "[Indoor Soccer Manager]"
        CType(Me.stbMainPanel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

	Private IsLoaded As Boolean

	Private Sub mnuFileExit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuFileExit.Click
		Me.Close()
	End Sub

	Private Sub SetScreen()
		If Me.WindowState = FormWindowState.Normal Then
			Me.WindowState = FormWindowState.Maximized
		End If
		mobjLeague = gobjLeague
		If gobjLeague.Name <> "" Then
			Me.stbMain.Text = gobjLeague.Name & "loaded."
		Else
			Me.stbMain.Text = "No league loaded."
		End If
		Call App.SkinForm(Me)
		Me.tmrFade.Enabled = True
		If gobjUserSettings.ShowGuideAtStartup Then
			ShowGuide()
		End If

		Call ShowAllMenus()
	End Sub

	Private Sub ShowGuide()
		Dim objGuide As New ProgramGuideService(ISMGuideServiceContext.MainMenu)
		Dim frmGuide As New frmGuide(objGuide)
		frmGuide.MdiParent = Me
		frmGuide.Left = 0		  'Me.Width - frmGuide.Width - 10
		frmGuide.Top = 0		  'Me.Height - frmGuide.Height - 10
		frmGuide.Show()
	End Sub

	Private Sub ShowAllMenus()
		Call Me.mnuGameLeague_Click(Me, New System.EventArgs())
		Call Me.mnuGameOptions_Click(Me, New System.EventArgs())
		Call Me.mnuGameTeam_Click(Me, New System.EventArgs())
	End Sub


	Private Sub mnuGameLeague_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuGameLeague.Click
		Dim n As Control
		For Each n In Me.MdiChildren
			If n.Text.StartsWith("League") Then
				Exit Sub
			End If
		Next

		Dim lstPicks As ListPicks = gnavMainMenu.GetLeagueMenu()
		Dim frmLeaguePick As New frmListPick(lstPicks)
		frmLeaguePick.MdiParent = Me
		frmLeaguePick.Show()
	End Sub


	Private Sub mnuGameTeam_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuGameTeam.Click

		Dim n As Control
		For Each n In Me.MdiChildren
			If n.Text.StartsWith("Team") Then
				Exit Sub
			End If
		Next
		Dim lstPicks As ListPicks = gnavMainMenu.GetTeamMenu()
		Dim frmLeaguePick As New frmListPick(lstPicks)
		frmLeaguePick.MdiParent = Me
		frmLeaguePick.Show()

	End Sub


	Private Sub frmMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load

		'Add custom code for background image redraw...
		''SetStyle(ControlStyles.UserPaint, True)
		''SetStyle(ControlStyles.ResizeRedraw, True)
		''SetStyle(ControlStyles.DoubleBuffer, True)
		''SetStyle(ControlStyles.AllPaintingInWmPaint, True)

	End Sub

	Private Sub frmMain_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
		gData.Close()
	End Sub

	Private Sub mobjLeague_Loaded(ByVal sender As Object, ByVal e As ISoccerSim.LeagueLoadedEventArgs) Handles mobjLeague.Loaded
		Call RefreshStatusText()
	End Sub

	Sub RefreshStatusText()
		If gobjLeague Is Nothing Then
			Me.stbMain.Text = "No league loaded."
		ElseIf gobjLeague.Name = "" Then
			Me.stbMain.Text = "No league loaded."
		Else
			Me.stbMain.Text = gobjLeague.Name & " loaded."
			mobjLeague = gobjLeague
		End If

	End Sub

	Private Sub mnuGameOptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuGameOptions.Click

		Dim n As Control
		For Each n In Me.MdiChildren
			If n.Text.StartsWith("Options") Then
				Exit Sub
			End If
		Next

		Dim lstPicks As ListPicks = gnavMainMenu.GetOptionsMenu
		Dim frmLeaguePick As New frmListPick(lstPicks)
		frmLeaguePick.MdiParent = Me
		frmLeaguePick.Show()
	End Sub

	Private Sub frmMain_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
		Call RefreshStatusText()
	End Sub

	'Private Sub RedrawBackground()
	'	Dim myImage As New Bitmap(Me.Width, Me.Height)
	'	Dim mypix As Bitmap = Me.imgBack.Images(0)

	'	Dim g As Graphics = Graphics.FromImage(myImage)
	'	If Me.Width > mypix.Width And Me.Height > mypix.Height Then
	'		g.DrawImage(mypix, 0, 0, Me.Width, Me.Height)
	'	Else
	'		g.DrawImage(mypix, 0, 0, mypix.Width, mypix.Height)
	'	End If
	'	Me.BackgroundImage = CType(myImage, Bitmap)
	'	g.Dispose()
	'End Sub

	'Private Sub frmMain_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize

	'	Me.RedrawBackground()
	'	Me.Refresh()


	'End Sub


    Private Sub mnuHelpAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuHelpAbout.Click
        Dim f As New frmAbout()
        f.ShowDialog()
    End Sub

    Private Sub tmrFade_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles tmrFade.Tick
        If Me.Opacity < 1 Then
            Me.Opacity = Me.Opacity + 0.05
            Console.WriteLine(Me.Opacity)
        Else
            Me.tmrFade.Enabled = False
        End If
    End Sub

    Private Sub MenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem1.Click
        'Dim t As New NUnit.Tests.TestRosterMovement()
        't.TestDumpToFA()
    End Sub
End Class
