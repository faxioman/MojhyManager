'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.Teams
Imports ISoccerSim.Leagues

Public Class frmLeagueSettings
	Inherits System.Windows.Forms.Form

	Dim mblnLoading As Boolean
	Dim mblnDirty As Boolean
	Dim mintTabMode As ISS_TabMode

	Private Enum ISS_NodeType
		ConferenceNode
		DivisionNode
		TeamNode
		RootNode
	End Enum

	Private Enum ISS_TabMode
		General
		[Structure]
		Schedule
		Rules

	End Enum
#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()
		mblnLoading = True
		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		Call SetScreen()
		mblnLoading = False

	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Friend WithEvents lstOptions As System.Windows.Forms.ListBox
	Friend WithEvents grpGeneral As System.Windows.Forms.GroupBox
	Friend WithEvents Label13 As System.Windows.Forms.Label
	Friend WithEvents txtChampionship As System.Windows.Forms.TextBox
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents cmbLeagueSize As System.Windows.Forms.ComboBox
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents txtAbbreviation As System.Windows.Forms.TextBox
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents txtLeagueName As System.Windows.Forms.TextBox
	Friend WithEvents grpSchedule As System.Windows.Forms.GroupBox
	Friend WithEvents lblTotalGames As System.Windows.Forms.Label
	Friend WithEvents Label10 As System.Windows.Forms.Label
	Friend WithEvents cmbTeamsInPlayoffs As System.Windows.Forms.ComboBox
	Friend WithEvents Label9 As System.Windows.Forms.Label
	Friend WithEvents cmbGamesInChampionshipRound As System.Windows.Forms.ComboBox
	Friend WithEvents Label8 As System.Windows.Forms.Label
	Friend WithEvents cmbGamesInPlayoffSeries As System.Windows.Forms.ComboBox
	Friend WithEvents Label7 As System.Windows.Forms.Label
	Friend WithEvents cmbOtherConfGames As System.Windows.Forms.ComboBox
	Friend WithEvents Label6 As System.Windows.Forms.Label
	Friend WithEvents cmbConfGames As System.Windows.Forms.ComboBox
	Friend WithEvents grpRules As System.Windows.Forms.GroupBox
	Friend WithEvents Label11 As System.Windows.Forms.Label
	Friend WithEvents cmbMultiPoint As System.Windows.Forms.ComboBox
	Friend WithEvents btnClose As System.Windows.Forms.Button
	Friend WithEvents btnSave As System.Windows.Forms.Button
	Friend WithEvents grpTeams As System.Windows.Forms.GroupBox
	Friend WithEvents txtConfDivName As System.Windows.Forms.TextBox
	Friend WithEvents trvStructure As System.Windows.Forms.TreeView
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.lstOptions = New System.Windows.Forms.ListBox()
		Me.grpGeneral = New System.Windows.Forms.GroupBox()
		Me.Label13 = New System.Windows.Forms.Label()
		Me.txtChampionship = New System.Windows.Forms.TextBox()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.cmbLeagueSize = New System.Windows.Forms.ComboBox()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.txtAbbreviation = New System.Windows.Forms.TextBox()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.txtLeagueName = New System.Windows.Forms.TextBox()
		Me.grpSchedule = New System.Windows.Forms.GroupBox()
		Me.lblTotalGames = New System.Windows.Forms.Label()
		Me.Label10 = New System.Windows.Forms.Label()
		Me.cmbTeamsInPlayoffs = New System.Windows.Forms.ComboBox()
		Me.Label9 = New System.Windows.Forms.Label()
		Me.cmbGamesInChampionshipRound = New System.Windows.Forms.ComboBox()
		Me.Label8 = New System.Windows.Forms.Label()
		Me.cmbGamesInPlayoffSeries = New System.Windows.Forms.ComboBox()
		Me.Label7 = New System.Windows.Forms.Label()
		Me.cmbOtherConfGames = New System.Windows.Forms.ComboBox()
		Me.Label6 = New System.Windows.Forms.Label()
		Me.cmbConfGames = New System.Windows.Forms.ComboBox()
		Me.grpRules = New System.Windows.Forms.GroupBox()
		Me.Label11 = New System.Windows.Forms.Label()
		Me.cmbMultiPoint = New System.Windows.Forms.ComboBox()
		Me.btnClose = New System.Windows.Forms.Button()
		Me.btnSave = New System.Windows.Forms.Button()
		Me.grpTeams = New System.Windows.Forms.GroupBox()
		Me.txtConfDivName = New System.Windows.Forms.TextBox()
		Me.trvStructure = New System.Windows.Forms.TreeView()
		Me.grpGeneral.SuspendLayout()
		Me.grpSchedule.SuspendLayout()
		Me.grpRules.SuspendLayout()
		Me.grpTeams.SuspendLayout()
		Me.SuspendLayout()
		'
		'lstOptions
		'
		Me.lstOptions.ItemHeight = 14
		Me.lstOptions.Items.AddRange(New Object() {"General", "Structure", "Schedule", "Rules"})
		Me.lstOptions.Location = New System.Drawing.Point(16, 16)
		Me.lstOptions.Name = "lstOptions"
		Me.lstOptions.Size = New System.Drawing.Size(136, 354)
		Me.lstOptions.TabIndex = 13
		'
		'grpGeneral
		'
		Me.grpGeneral.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label13, Me.txtChampionship, Me.Label3, Me.cmbLeagueSize, Me.Label2, Me.txtAbbreviation, Me.Label1, Me.txtLeagueName})
		Me.grpGeneral.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.grpGeneral.Location = New System.Drawing.Point(160, 16)
		Me.grpGeneral.Name = "grpGeneral"
		Me.grpGeneral.Size = New System.Drawing.Size(408, 352)
		Me.grpGeneral.TabIndex = 12
		Me.grpGeneral.TabStop = False
		Me.grpGeneral.Text = "General"
		'
		'Label13
		'
		Me.Label13.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label13.Location = New System.Drawing.Point(16, 160)
		Me.Label13.Name = "Label13"
		Me.Label13.Size = New System.Drawing.Size(376, 16)
		Me.Label13.TabIndex = 11
		Me.Label13.Text = "Championship:"
		'
		'txtChampionship
		'
		Me.txtChampionship.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtChampionship.Location = New System.Drawing.Point(16, 176)
		Me.txtChampionship.MaxLength = 50
		Me.txtChampionship.Name = "txtChampionship"
		Me.txtChampionship.Size = New System.Drawing.Size(368, 20)
		Me.txtChampionship.TabIndex = 10
		Me.txtChampionship.Text = "MSL Championship"
		'
		'Label3
		'
		Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label3.Location = New System.Drawing.Point(16, 112)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(376, 16)
		Me.Label3.TabIndex = 5
		Me.Label3.Text = "Total number of teams:"
		'
		'cmbLeagueSize
		'
		Me.cmbLeagueSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbLeagueSize.Enabled = False
		Me.cmbLeagueSize.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbLeagueSize.ItemHeight = 14
		Me.cmbLeagueSize.Items.AddRange(New Object() {"6", "8", "10", "12"})
		Me.cmbLeagueSize.Location = New System.Drawing.Point(16, 128)
		Me.cmbLeagueSize.Name = "cmbLeagueSize"
		Me.cmbLeagueSize.Size = New System.Drawing.Size(56, 22)
		Me.cmbLeagueSize.TabIndex = 4
		'
		'Label2
		'
		Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.Location = New System.Drawing.Point(16, 64)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(376, 16)
		Me.Label2.TabIndex = 3
		Me.Label2.Text = "League Abbreviation:"
		'
		'txtAbbreviation
		'
		Me.txtAbbreviation.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtAbbreviation.Location = New System.Drawing.Point(16, 80)
		Me.txtAbbreviation.MaxLength = 10
		Me.txtAbbreviation.Name = "txtAbbreviation"
		Me.txtAbbreviation.Size = New System.Drawing.Size(64, 20)
		Me.txtAbbreviation.TabIndex = 2
		Me.txtAbbreviation.Text = "MSL"
		'
		'Label1
		'
		Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.Location = New System.Drawing.Point(16, 16)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(376, 16)
		Me.Label1.TabIndex = 1
		Me.Label1.Text = "League Name:"
		'
		'txtLeagueName
		'
		Me.txtLeagueName.Enabled = False
		Me.txtLeagueName.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtLeagueName.Location = New System.Drawing.Point(16, 32)
		Me.txtLeagueName.MaxLength = 50
		Me.txtLeagueName.Name = "txtLeagueName"
		Me.txtLeagueName.Size = New System.Drawing.Size(368, 20)
		Me.txtLeagueName.TabIndex = 0
		Me.txtLeagueName.Text = "My Soccer League"
		'
		'grpSchedule
		'
		Me.grpSchedule.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblTotalGames, Me.Label10, Me.cmbTeamsInPlayoffs, Me.Label9, Me.cmbGamesInChampionshipRound, Me.Label8, Me.cmbGamesInPlayoffSeries, Me.Label7, Me.cmbOtherConfGames, Me.Label6, Me.cmbConfGames})
		Me.grpSchedule.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.grpSchedule.Location = New System.Drawing.Point(160, 16)
		Me.grpSchedule.Name = "grpSchedule"
		Me.grpSchedule.Size = New System.Drawing.Size(408, 352)
		Me.grpSchedule.TabIndex = 14
		Me.grpSchedule.TabStop = False
		Me.grpSchedule.Text = "Schedule"
		'
		'lblTotalGames
		'
		Me.lblTotalGames.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblTotalGames.Location = New System.Drawing.Point(8, 112)
		Me.lblTotalGames.Name = "lblTotalGames"
		Me.lblTotalGames.Size = New System.Drawing.Size(352, 16)
		Me.lblTotalGames.TabIndex = 15
		Me.lblTotalGames.Text = "Total schedule:"
		'
		'Label10
		'
		Me.Label10.Location = New System.Drawing.Point(8, 256)
		Me.Label10.Name = "Label10"
		Me.Label10.Size = New System.Drawing.Size(352, 16)
		Me.Label10.TabIndex = 14
		Me.Label10.Text = "Number of teams in league that can qualify for league playoffs:"
		'
		'cmbTeamsInPlayoffs
		'
		Me.cmbTeamsInPlayoffs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbTeamsInPlayoffs.Enabled = False
		Me.cmbTeamsInPlayoffs.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbTeamsInPlayoffs.ItemHeight = 14
		Me.cmbTeamsInPlayoffs.Items.AddRange(New Object() {"2", "4", "6", "8"})
		Me.cmbTeamsInPlayoffs.Location = New System.Drawing.Point(8, 272)
		Me.cmbTeamsInPlayoffs.Name = "cmbTeamsInPlayoffs"
		Me.cmbTeamsInPlayoffs.Size = New System.Drawing.Size(56, 22)
		Me.cmbTeamsInPlayoffs.TabIndex = 13
		'
		'Label9
		'
		Me.Label9.Location = New System.Drawing.Point(8, 192)
		Me.Label9.Name = "Label9"
		Me.Label9.Size = New System.Drawing.Size(352, 16)
		Me.Label9.TabIndex = 12
		Me.Label9.Text = "Maximum number of games in championship round:"
		'
		'cmbGamesInChampionshipRound
		'
		Me.cmbGamesInChampionshipRound.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbGamesInChampionshipRound.Enabled = False
		Me.cmbGamesInChampionshipRound.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbGamesInChampionshipRound.ItemHeight = 14
		Me.cmbGamesInChampionshipRound.Items.AddRange(New Object() {"1", "3", "5", "7"})
		Me.cmbGamesInChampionshipRound.Location = New System.Drawing.Point(8, 208)
		Me.cmbGamesInChampionshipRound.Name = "cmbGamesInChampionshipRound"
		Me.cmbGamesInChampionshipRound.Size = New System.Drawing.Size(56, 22)
		Me.cmbGamesInChampionshipRound.TabIndex = 11
		'
		'Label8
		'
		Me.Label8.Location = New System.Drawing.Point(8, 144)
		Me.Label8.Name = "Label8"
		Me.Label8.Size = New System.Drawing.Size(352, 16)
		Me.Label8.TabIndex = 10
		Me.Label8.Text = "Maximum number of games in playoff series:"
		'
		'cmbGamesInPlayoffSeries
		'
		Me.cmbGamesInPlayoffSeries.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbGamesInPlayoffSeries.Enabled = False
		Me.cmbGamesInPlayoffSeries.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbGamesInPlayoffSeries.ItemHeight = 14
		Me.cmbGamesInPlayoffSeries.Items.AddRange(New Object() {"1", "3", "5", "7"})
		Me.cmbGamesInPlayoffSeries.Location = New System.Drawing.Point(8, 160)
		Me.cmbGamesInPlayoffSeries.Name = "cmbGamesInPlayoffSeries"
		Me.cmbGamesInPlayoffSeries.Size = New System.Drawing.Size(56, 22)
		Me.cmbGamesInPlayoffSeries.TabIndex = 9
		'
		'Label7
		'
		Me.Label7.Location = New System.Drawing.Point(8, 64)
		Me.Label7.Name = "Label7"
		Me.Label7.Size = New System.Drawing.Size(352, 16)
		Me.Label7.TabIndex = 8
		Me.Label7.Text = "Number of games against opposite conference opponents:"
		'
		'cmbOtherConfGames
		'
		Me.cmbOtherConfGames.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbOtherConfGames.Enabled = False
		Me.cmbOtherConfGames.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbOtherConfGames.ItemHeight = 14
		Me.cmbOtherConfGames.Items.AddRange(New Object() {"2", "4", "6", "8", "10"})
		Me.cmbOtherConfGames.Location = New System.Drawing.Point(8, 80)
		Me.cmbOtherConfGames.Name = "cmbOtherConfGames"
		Me.cmbOtherConfGames.Size = New System.Drawing.Size(56, 22)
		Me.cmbOtherConfGames.TabIndex = 7
		'
		'Label6
		'
		Me.Label6.Location = New System.Drawing.Point(8, 16)
		Me.Label6.Name = "Label6"
		Me.Label6.Size = New System.Drawing.Size(352, 16)
		Me.Label6.TabIndex = 6
		Me.Label6.Text = "Number of games against conference opponents:"
		'
		'cmbConfGames
		'
		Me.cmbConfGames.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbConfGames.Enabled = False
		Me.cmbConfGames.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbConfGames.ItemHeight = 14
		Me.cmbConfGames.Items.AddRange(New Object() {"2", "4", "6", "8", "10"})
		Me.cmbConfGames.Location = New System.Drawing.Point(8, 32)
		Me.cmbConfGames.Name = "cmbConfGames"
		Me.cmbConfGames.Size = New System.Drawing.Size(56, 22)
		Me.cmbConfGames.TabIndex = 5
		'
		'grpRules
		'
		Me.grpRules.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label11, Me.cmbMultiPoint})
		Me.grpRules.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.grpRules.Location = New System.Drawing.Point(160, 16)
		Me.grpRules.Name = "grpRules"
		Me.grpRules.Size = New System.Drawing.Size(408, 352)
		Me.grpRules.TabIndex = 15
		Me.grpRules.TabStop = False
		Me.grpRules.Text = "Rules"
		'
		'Label11
		'
		Me.Label11.Location = New System.Drawing.Point(16, 24)
		Me.Label11.Name = "Label11"
		Me.Label11.Size = New System.Drawing.Size(376, 16)
		Me.Label11.TabIndex = 6
		Me.Label11.Text = "Multi-point scoring?"
		'
		'cmbMultiPoint
		'
		Me.cmbMultiPoint.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbMultiPoint.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbMultiPoint.ItemHeight = 14
		Me.cmbMultiPoint.Items.AddRange(New Object() {"Yes", "No"})
		Me.cmbMultiPoint.Location = New System.Drawing.Point(16, 40)
		Me.cmbMultiPoint.Name = "cmbMultiPoint"
		Me.cmbMultiPoint.Size = New System.Drawing.Size(56, 22)
		Me.cmbMultiPoint.TabIndex = 5
		'
		'btnClose
		'
		Me.btnClose.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnClose.Location = New System.Drawing.Point(456, 384)
		Me.btnClose.Name = "btnClose"
		Me.btnClose.Size = New System.Drawing.Size(112, 24)
		Me.btnClose.TabIndex = 16
		Me.btnClose.Text = "Close"
		'
		'btnSave
		'
		Me.btnSave.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnSave.Location = New System.Drawing.Point(328, 384)
		Me.btnSave.Name = "btnSave"
		Me.btnSave.Size = New System.Drawing.Size(112, 24)
		Me.btnSave.TabIndex = 17
		Me.btnSave.Text = "Save"
		'
		'grpTeams
		'
		Me.grpTeams.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
					Or System.Windows.Forms.AnchorStyles.Left) _
					Or System.Windows.Forms.AnchorStyles.Right)
		Me.grpTeams.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtConfDivName, Me.trvStructure})
		Me.grpTeams.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.grpTeams.Location = New System.Drawing.Point(160, 16)
		Me.grpTeams.Name = "grpTeams"
		Me.grpTeams.Size = New System.Drawing.Size(408, 352)
		Me.grpTeams.TabIndex = 18
		Me.grpTeams.TabStop = False
		Me.grpTeams.Text = "Teams"
		'
		'txtConfDivName
		'
		Me.txtConfDivName.Location = New System.Drawing.Point(16, 320)
		Me.txtConfDivName.Name = "txtConfDivName"
		Me.txtConfDivName.Size = New System.Drawing.Size(152, 20)
		Me.txtConfDivName.TabIndex = 18
		Me.txtConfDivName.Text = ""
		'
		'trvStructure
		'
		Me.trvStructure.HideSelection = False
		Me.trvStructure.ImageIndex = -1
		Me.trvStructure.LabelEdit = True
		Me.trvStructure.Location = New System.Drawing.Point(16, 16)
		Me.trvStructure.Name = "trvStructure"
		Me.trvStructure.SelectedImageIndex = -1
		Me.trvStructure.Size = New System.Drawing.Size(376, 296)
		Me.trvStructure.TabIndex = 16
		'
		'frmLeagueSettings
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(592, 421)
		Me.ControlBox = False
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.grpTeams, Me.btnSave, Me.btnClose, Me.lstOptions, Me.grpGeneral, Me.grpRules, Me.grpSchedule})
		Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Name = "frmLeagueSettings"
		Me.ShowInTaskbar = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.Text = "League Settings"
		Me.grpGeneral.ResumeLayout(False)
		Me.grpSchedule.ResumeLayout(False)
		Me.grpRules.ResumeLayout(False)
		Me.grpTeams.ResumeLayout(False)
		Me.ResumeLayout(False)

	End Sub

#End Region


	Private Sub SetScreen()
		Me.grpGeneral.BringToFront()
		Call LoadLeague()
		Call App.SkinForm(Me)

	End Sub

	Private Sub SetTotalGamesText(ByVal sender As System.Object, ByVal e As System.EventArgs) _
	Handles cmbConfGames.SelectedIndexChanged, cmbGamesInChampionshipRound.SelectedIndexChanged, cmbGamesInPlayoffSeries.SelectedIndexChanged, cmbOtherConfGames.SelectedIndexChanged, cmbLeagueSize.SelectedIndexChanged
		Call SetTotalGamesText()
	End Sub

	Private Sub SetTotalGamesText()
		If mblnLoading = False Then
			Me.lblTotalGames.Text = (Int(Me.cmbConfGames.Text) * ((Int(Me.cmbLeagueSize.Text) / 2) - 1) + _
			  Int(Me.cmbOtherConfGames.Text) * (Int(Me.cmbLeagueSize.Text) / 2)) & " games per team."
		End If
	End Sub

	Private Sub LoadLeague()
		With gobjLeague
			mblnLoading = True
			Me.cmbConfGames.SelectedItem = .IntraconferenceMatchups.ToString
			Me.cmbGamesInChampionshipRound.Text = .ChampionshipSeries.ToString
			Me.cmbGamesInPlayoffSeries.Text = .PlayoffSeries.ToString
			Me.cmbLeagueSize.Text = .Total.ToString
			Me.cmbMultiPoint.Text = IIf(.MultiPoint = True, "Yes", "No")
			Me.cmbOtherConfGames.Text = .InterconferenceMatchups.ToString
			Me.cmbTeamsInPlayoffs.Text = .TeamsInPlayoff.ToString
			Me.txtAbbreviation.Text = .Abbreviation
			Me.txtChampionship.Text = .Championship
			Me.txtLeagueName.Text = .Name
			Me.grpGeneral.BringToFront()
			Call LoadLeagueTree()
			mblnLoading = False
			Call SetTotalGamesText()

		End With
	End Sub

	Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
		Me.Close()
	End Sub

	Private Sub lstOptions_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstOptions.SelectedIndexChanged

		Select Case lstOptions.SelectedItem
			Case "General"
				Me.grpGeneral.BringToFront()
				mintTabMode = ISS_TabMode.General
			Case "Schedule"
				Me.grpSchedule.BringToFront()
				mintTabMode = ISS_TabMode.Schedule
			Case "Rules"
				Me.grpRules.BringToFront()
				mintTabMode = ISS_TabMode.Rules
			Case "Structure"
				Me.grpTeams.BringToFront()
				Call LoadLeagueTree()
				mintTabMode = ISS_TabMode.Structure
		End Select
	End Sub

	Private Sub LeagueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtAbbreviation.TextChanged, txtChampionship.TextChanged
		If mblnLoading = False Then
			mblnDirty = True
		End If
	End Sub

#Region "League Tree"
	Private Sub LoadLeagueTree()
		Dim i As Integer = 1
		Dim intTeamID As Integer = 1
		With Me.trvStructure
			.BeginUpdate()
			.Nodes.Clear()

			Dim RootNode As New TreeNode(Me.txtLeagueName.Text)
			RootNode.Tag = "Root"
			.Nodes.Add(RootNode)

			'Create conference nodes...
			If gobjLeague.Conferences.Count = 1 Then
				Dim Conference1Node As New TreeNode("Teams")
				Conference1Node.Tag = New Conference(0, "Teams")
				RootNode.Nodes.Add(Conference1Node)
			End If

			If gobjLeague.Conferences.Count = 2 Then
				Dim Conference1Node As New TreeNode("American Conference")
				Conference1Node.Tag = gobjLeague.Conferences(0)
				RootNode.Nodes.Add(Conference1Node)

				Dim Conference2Node As New TreeNode("National Conference")
				Conference2Node.Tag = gobjLeague.Conferences(1)
				RootNode.Nodes.Add(Conference2Node)
			End If

			'Create division nodes...
			Dim pobjNode As TreeNode
			For Each pobjNode In RootNode.Nodes
				If TypeOf pobjNode.Tag Is Conference Then
					'Add children divisions...
					Dim x As Integer
					For x = 0 To gobjLeague.Divisions.Count - 1
						Dim DivisionNode As New TreeNode(gobjLeague.Divisions(x).Name & " Division")
						DivisionNode.Tag = gobjLeague.Divisions(x)
						pobjNode.Nodes.Add(DivisionNode)
						DivisionNode.Collapse()

						'Add children teams...
						Dim y As Integer
						For y = 0 To gobjLeague.Count - 1
							If gobjLeague.Item(y).DivisionID = CType(DivisionNode.Tag, Division).ID Then
								Dim pobjTeam As Team = gobjLeague.Item(y)
								Dim TeamNode As New TreeNode(pobjTeam.Name)
								TeamNode.Tag = pobjTeam.TeamID
								DivisionNode.Nodes.Add(TeamNode)
							End If
						Next
						pobjNode.Expand()
					Next
				End If
			Next
			RootNode.Expand()
			.SelectedNode = RootNode
			.EndUpdate()
		End With


	End Sub

	Private Sub trvStructure_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles trvStructure.AfterSelect
		Dim Type As ISS_NodeType
		Type = GetNodeType(e.Node)
		Dim pobjNodeTag As Object = e.Node.Tag

		If Type = ISS_NodeType.ConferenceNode Then
			Me.txtConfDivName.Text = CType(pobjNodeTag, Conference).Name
			Me.txtConfDivName.Visible = True
		ElseIf Type = ISS_NodeType.DivisionNode Then
			Me.txtConfDivName.Text = CType(pobjNodeTag, Division).Name
			Me.txtConfDivName.Visible = True
		ElseIf Type = ISS_NodeType.TeamNode Then
			Me.txtConfDivName.Visible = False
		ElseIf Type = ISS_NodeType.RootNode Then
			Me.txtConfDivName.Visible = False
		Else
		End If
	End Sub

	Private Sub txtConfDivName_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtConfDivName.TextChanged
		Dim Type As ISS_NodeType
		Type = GetNodeType(Me.trvStructure.SelectedNode)
		If Type = ISS_NodeType.DivisionNode Then
			Me.trvStructure.SelectedNode.Text = Me.txtConfDivName.Text & " Division"
		ElseIf Type = ISS_NodeType.ConferenceNode Then
			Me.trvStructure.SelectedNode.Text = Me.txtConfDivName.Text & " Conference"
		End If
	End Sub

	Private Function GetNodeType(ByVal objNode As TreeNode) As ISS_NodeType
		If TypeOf objNode.Tag Is Conference Then
			Return ISS_NodeType.ConferenceNode
		ElseIf TypeOf objNode.Tag Is Division Then
			Return ISS_NodeType.DivisionNode
		ElseIf TypeOf objNode.Tag Is Integer Then
			Return ISS_NodeType.TeamNode
		Else
			Return ISS_NodeType.RootNode
		End If
	End Function


#End Region

	Private Sub SaveNode()
		Dim pobjNode As TreeNode = Me.trvStructure.SelectedNode
		If TypeOf pobjNode.Tag Is Conference Then
			Dim pobjConference As Conference = CType(pobjNode.Tag, Conference)
			pobjConference.Name = Me.txtConfDivName.Text()
			pobjConference.Update()
		ElseIf TypeOf pobjNode.Tag Is Division Then
			Dim pobjDivision As Division = CType(pobjNode.Tag, Division)
			pobjDivision.Name = Me.txtConfDivName.Text()
			pobjDivision.Update()
		End If

	End Sub

	Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
		If Me.txtConfDivName.Visible = True Then
			Call SaveNode()
		End If
	End Sub

	Private Sub txtConfDivName_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtConfDivName.Validated
		'Call SaveNode()
	End Sub
End Class
