'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports System.IO
Imports ISoccerSim.Teams
Imports ISoccerSim.SimEngine

Public Class frmLeagueExhibition
	Inherits System.Windows.Forms.Form

	Private mblnLoading As Boolean = False

#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		Call SetScreen()
	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Friend WithEvents grpContent As System.Windows.Forms.GroupBox
	Friend WithEvents lblText As System.Windows.Forms.Label
	Friend WithEvents cmbHomeTeam As System.Windows.Forms.ComboBox
	Friend WithEvents cmbAwayTeam As System.Windows.Forms.ComboBox
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents btnClose As System.Windows.Forms.Button
	Friend WithEvents btnOK As System.Windows.Forms.Button
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.grpContent = New System.Windows.Forms.GroupBox()
		Me.btnOK = New System.Windows.Forms.Button()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.cmbAwayTeam = New System.Windows.Forms.ComboBox()
		Me.cmbHomeTeam = New System.Windows.Forms.ComboBox()
		Me.lblText = New System.Windows.Forms.Label()
		Me.btnClose = New System.Windows.Forms.Button()
		Me.grpContent.SuspendLayout()
		Me.SuspendLayout()
		'
		'grpContent
		'
		Me.grpContent.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnOK, Me.Label1, Me.cmbAwayTeam, Me.cmbHomeTeam, Me.lblText})
		Me.grpContent.Location = New System.Drawing.Point(8, 8)
		Me.grpContent.Name = "grpContent"
		Me.grpContent.Size = New System.Drawing.Size(352, 112)
		Me.grpContent.TabIndex = 2
		Me.grpContent.TabStop = False
		Me.grpContent.Text = "Exhibition Setup"
		'
		'btnOK
		'
		Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnOK.Location = New System.Drawing.Point(232, 80)
		Me.btnOK.Name = "btnOK"
		Me.btnOK.Size = New System.Drawing.Size(112, 24)
		Me.btnOK.TabIndex = 5
		Me.btnOK.Text = "&Simulate"
		'
		'Label1
		'
		Me.Label1.Location = New System.Drawing.Point(16, 16)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(72, 24)
		Me.Label1.TabIndex = 4
		Me.Label1.Text = "Away Team:"
		'
		'cmbAwayTeam
		'
		Me.cmbAwayTeam.Location = New System.Drawing.Point(96, 16)
		Me.cmbAwayTeam.Name = "cmbAwayTeam"
		Me.cmbAwayTeam.Size = New System.Drawing.Size(248, 22)
		Me.cmbAwayTeam.TabIndex = 3
		'
		'cmbHomeTeam
		'
		Me.cmbHomeTeam.Location = New System.Drawing.Point(96, 48)
		Me.cmbHomeTeam.Name = "cmbHomeTeam"
		Me.cmbHomeTeam.Size = New System.Drawing.Size(248, 22)
		Me.cmbHomeTeam.TabIndex = 2
		'
		'lblText
		'
		Me.lblText.Location = New System.Drawing.Point(16, 48)
		Me.lblText.Name = "lblText"
		Me.lblText.Size = New System.Drawing.Size(72, 24)
		Me.lblText.TabIndex = 1
		Me.lblText.Text = "Home Team:"
		'
		'btnClose
		'
		Me.btnClose.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnClose.Location = New System.Drawing.Point(248, 128)
		Me.btnClose.Name = "btnClose"
		Me.btnClose.Size = New System.Drawing.Size(112, 24)
		Me.btnClose.TabIndex = 12
		Me.btnClose.Text = "&Close"
		'
		'frmLeagueExhibition
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.BackColor = System.Drawing.Color.FromArgb(CType(43, Byte), CType(72, Byte), CType(142, Byte))
		Me.ClientSize = New System.Drawing.Size(368, 157)
		Me.ControlBox = False
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnClose, Me.grpContent})
		Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.ForeColor = System.Drawing.Color.Gainsboro
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.Name = "frmLeagueExhibition"
		Me.ShowInTaskbar = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.Text = "Simulate Exhibition Game..."
		Me.grpContent.ResumeLayout(False)
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub InitializeDefaults()
		Call InitializeTeam(Me.cmbAwayTeam)
		Call InitializeTeam(Me.cmbHomeTeam)
	End Sub

	Private Sub InitializeTeam(ByVal objComboBox As ComboBox)
		Dim i As Integer
		Dim objTeam As Team

		objComboBox.Items.Clear()
		For i = 0 To gobjLeague.Count - 1
			objTeam = CType(gobjLeague.Item(i), Team)
			If objTeam.SubstitutionSets.IsLegal(objTeam.TeamID) Then
				objComboBox.Items.Add(objTeam.ToString)
			End If
		Next
		objComboBox.Sorted = True
		objComboBox.DropDownStyle = ComboBoxStyle.DropDownList
		mblnLoading = True
		Me.cmbAwayTeam.SelectedIndex = RandomNumber(0, Me.cmbAwayTeam.Items.Count - 1)
		Me.cmbHomeTeam.SelectedIndex = RandomNumber(0, Me.cmbHomeTeam.Items.Count - 1)
		mblnLoading = False
	End Sub


	Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		Call SimGame()
	End Sub


	Private Sub SetScreen()
		Dim Dir As New DirectoryInfo(GetCurrentDirectory() & "\leagues\")
		Dim pdirInfo As DirectoryInfo

		SkinForm(Me)
		Call InitializeDefaults()

	End Sub

	Private Sub CheckTeams(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbHomeTeam.SelectedIndexChanged, cmbAwayTeam.SelectedIndexChanged
		If Not mblnLoading Then
			If Me.cmbAwayTeam.SelectedIndex = Me.cmbHomeTeam.SelectedIndex Then
				Select Case CType(sender, ComboBox).Name
					Case "cmbHomeTeam"
						SetSafeIndex(Me.cmbHomeTeam, Me.cmbAwayTeam)
					Case "cmbAwayTeam"
						SetSafeIndex(Me.cmbAwayTeam, Me.cmbHomeTeam)
				End Select
			End If
		End If
	End Sub

	Private Sub SetSafeIndex(ByVal objComboFrom As ComboBox, ByVal objComboTo As ComboBox)
		Dim i As Integer
		For i = 0 To objComboTo.Items.Count - 1
			If objComboTo.SelectedItem <> objComboFrom.Items(i) Then
				objComboTo.SelectedItem = objComboTo.Items(i)
				Exit Sub
			End If
		Next
	End Sub


	Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
		Me.Close()
	End Sub

	Private Sub SimGame()
		App.SetCursor(True, Me)
		Console.WriteLine("Start:" & Now)
		Dim x As New GameEngine()
		Dim f As New frmGameResults()

		x.Load(Me.cmbAwayTeam.Text, Me.cmbHomeTeam.Text)
		Console.WriteLine("Load:" & Now)
		Do Until x.Status = ISMGameStatus.GameOver
			x.Step()
		Loop
		Console.WriteLine("Done:" & Now)
		x.StatSave.Commit()
		Console.WriteLine("Stats:" & Now)

		f.LoadData(x)
		Console.WriteLine("Load form:" & Now)
		App.SetCursor(False, Me)
		f.ShowDialog()

	End Sub

End Class
