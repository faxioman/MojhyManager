'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.Cities
Imports ISoccerSim.Leagues

Public Class frmLeagueWizard
	Inherits System.Windows.Forms.Form

	Private mblnLoading As Boolean
	Private marrCities As New ArrayList()
	Private mintLeagueSize As Integer
	Private mintTotalGames As Integer

	Private Enum ISS_NodeType
		ConferenceNode
		DivisionNode
		TeamNode
		RootNode
	End Enum

	Private WithEvents mobjLeague As New League()

#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		Call SetScreen()


	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Friend WithEvents btnCancel As System.Windows.Forms.Button
	Friend WithEvents lstOptions As System.Windows.Forms.ListBox
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents txtLeagueName As System.Windows.Forms.TextBox
	Friend WithEvents grpGeneral As System.Windows.Forms.GroupBox
	Friend WithEvents grpSchedule As System.Windows.Forms.GroupBox
	Friend WithEvents grpRules As System.Windows.Forms.GroupBox
	Friend WithEvents Label6 As System.Windows.Forms.Label
	Friend WithEvents Label7 As System.Windows.Forms.Label
	Friend WithEvents Label8 As System.Windows.Forms.Label
	Friend WithEvents Label9 As System.Windows.Forms.Label
	Friend WithEvents Label10 As System.Windows.Forms.Label
	Friend WithEvents lblTotalGames As System.Windows.Forms.Label
	Friend WithEvents cmbConfGames As System.Windows.Forms.ComboBox
	Friend WithEvents cmbOtherConfGames As System.Windows.Forms.ComboBox
	Friend WithEvents cmbGamesInPlayoffSeries As System.Windows.Forms.ComboBox
	Friend WithEvents cmbGamesInChampionshipRound As System.Windows.Forms.ComboBox
	Friend WithEvents cmbTeamsInPlayoffs As System.Windows.Forms.ComboBox
	Friend WithEvents Label11 As System.Windows.Forms.Label
	Friend WithEvents Label12 As System.Windows.Forms.Label
	Friend WithEvents grpFinish As System.Windows.Forms.GroupBox
	Friend WithEvents btnCreate As System.Windows.Forms.Button
	Friend WithEvents cmbDropToFAPool As System.Windows.Forms.ComboBox
	Friend WithEvents cmbMultiPoint As System.Windows.Forms.ComboBox
	Friend WithEvents lblProgress As System.Windows.Forms.Label
	Friend WithEvents proProgress As System.Windows.Forms.ProgressBar
	Friend WithEvents txtAbbreviation As System.Windows.Forms.TextBox
	Friend WithEvents Label13 As System.Windows.Forms.Label
	Friend WithEvents txtChampionship As System.Windows.Forms.TextBox
	Friend WithEvents lblGreeting As System.Windows.Forms.Label
	Friend WithEvents gructure As System.Windows.Forms.GroupBox
	Friend WithEvents Label14 As System.Windows.Forms.Label
	Friend WithEvents Label15 As System.Windows.Forms.Label
	Friend WithEvents cmbConferences As System.Windows.Forms.ComboBox
	Friend WithEvents Label16 As System.Windows.Forms.Label
	Friend WithEvents Label17 As System.Windows.Forms.Label
	Friend WithEvents grpTeams As System.Windows.Forms.GroupBox
	Friend WithEvents trvStructure As System.Windows.Forms.TreeView
	Friend WithEvents cmbDivisionSize As System.Windows.Forms.ComboBox
	Friend WithEvents cmbDivisions As System.Windows.Forms.ComboBox
	Friend WithEvents lblTotalTeams As System.Windows.Forms.Label
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents tipLeague As System.Windows.Forms.ToolTip
	Friend WithEvents cmbCities As System.Windows.Forms.ComboBox
	Friend WithEvents txtConfDivName As System.Windows.Forms.TextBox
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents cmbDivisionGames As System.Windows.Forms.ComboBox
	Friend WithEvents Label5 As System.Windows.Forms.Label
	Friend WithEvents grpMarkets As System.Windows.Forms.GroupBox
	Friend WithEvents Label20 As System.Windows.Forms.Label
	Friend WithEvents Label21 As System.Windows.Forms.Label
	Friend WithEvents cmbRegionalSetup As System.Windows.Forms.ComboBox
	Friend WithEvents cmbRandomMarket As System.Windows.Forms.ComboBox
	Friend WithEvents btnRandomTeams As System.Windows.Forms.Button
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Me.btnCancel = New System.Windows.Forms.Button()
		Me.lstOptions = New System.Windows.Forms.ListBox()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.txtAbbreviation = New System.Windows.Forms.TextBox()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.txtLeagueName = New System.Windows.Forms.TextBox()
		Me.grpGeneral = New System.Windows.Forms.GroupBox()
		Me.Label13 = New System.Windows.Forms.Label()
		Me.txtChampionship = New System.Windows.Forms.TextBox()
		Me.grpSchedule = New System.Windows.Forms.GroupBox()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.cmbDivisionGames = New System.Windows.Forms.ComboBox()
		Me.lblTotalGames = New System.Windows.Forms.Label()
		Me.Label10 = New System.Windows.Forms.Label()
		Me.cmbTeamsInPlayoffs = New System.Windows.Forms.ComboBox()
		Me.Label9 = New System.Windows.Forms.Label()
		Me.cmbGamesInChampionshipRound = New System.Windows.Forms.ComboBox()
		Me.Label8 = New System.Windows.Forms.Label()
		Me.cmbGamesInPlayoffSeries = New System.Windows.Forms.ComboBox()
		Me.Label7 = New System.Windows.Forms.Label()
		Me.cmbOtherConfGames = New System.Windows.Forms.ComboBox()
		Me.Label6 = New System.Windows.Forms.Label()
		Me.cmbConfGames = New System.Windows.Forms.ComboBox()
		Me.grpRules = New System.Windows.Forms.GroupBox()
		Me.Label12 = New System.Windows.Forms.Label()
		Me.cmbDropToFAPool = New System.Windows.Forms.ComboBox()
		Me.Label11 = New System.Windows.Forms.Label()
		Me.cmbMultiPoint = New System.Windows.Forms.ComboBox()
		Me.grpFinish = New System.Windows.Forms.GroupBox()
		Me.Label5 = New System.Windows.Forms.Label()
		Me.lblProgress = New System.Windows.Forms.Label()
		Me.proProgress = New System.Windows.Forms.ProgressBar()
		Me.btnCreate = New System.Windows.Forms.Button()
		Me.lblGreeting = New System.Windows.Forms.Label()
		Me.gructure = New System.Windows.Forms.GroupBox()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.lblTotalTeams = New System.Windows.Forms.Label()
		Me.Label17 = New System.Windows.Forms.Label()
		Me.Label16 = New System.Windows.Forms.Label()
		Me.cmbDivisionSize = New System.Windows.Forms.ComboBox()
		Me.Label14 = New System.Windows.Forms.Label()
		Me.cmbDivisions = New System.Windows.Forms.ComboBox()
		Me.Label15 = New System.Windows.Forms.Label()
		Me.cmbConferences = New System.Windows.Forms.ComboBox()
		Me.grpTeams = New System.Windows.Forms.GroupBox()
		Me.btnRandomTeams = New System.Windows.Forms.Button()
		Me.txtConfDivName = New System.Windows.Forms.TextBox()
		Me.cmbCities = New System.Windows.Forms.ComboBox()
		Me.trvStructure = New System.Windows.Forms.TreeView()
		Me.tipLeague = New System.Windows.Forms.ToolTip(Me.components)
		Me.grpMarkets = New System.Windows.Forms.GroupBox()
		Me.cmbRandomMarket = New System.Windows.Forms.ComboBox()
		Me.cmbRegionalSetup = New System.Windows.Forms.ComboBox()
		Me.Label21 = New System.Windows.Forms.Label()
		Me.Label20 = New System.Windows.Forms.Label()
		Me.grpGeneral.SuspendLayout()
		Me.grpSchedule.SuspendLayout()
		Me.grpRules.SuspendLayout()
		Me.grpFinish.SuspendLayout()
		Me.gructure.SuspendLayout()
		Me.grpTeams.SuspendLayout()
		Me.grpMarkets.SuspendLayout()
		Me.SuspendLayout()
		'
		'btnCancel
		'
		Me.btnCancel.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnCancel.Location = New System.Drawing.Point(448, 408)
		Me.btnCancel.Name = "btnCancel"
		Me.btnCancel.Size = New System.Drawing.Size(112, 24)
		Me.btnCancel.TabIndex = 4
		Me.btnCancel.Text = "Cancel"
		'
		'lstOptions
		'
		Me.lstOptions.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
					Or System.Windows.Forms.AnchorStyles.Left)
		Me.lstOptions.ItemHeight = 14
		Me.lstOptions.Items.AddRange(New Object() {"General", "Structure", "Markets", "Teams", "Schedule", "Rules", "Finish"})
		Me.lstOptions.Location = New System.Drawing.Point(8, 40)
		Me.lstOptions.Name = "lstOptions"
		Me.lstOptions.Size = New System.Drawing.Size(136, 354)
		Me.lstOptions.TabIndex = 6
		'
		'Label2
		'
		Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.Location = New System.Drawing.Point(16, 72)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(376, 16)
		Me.Label2.TabIndex = 3
		Me.Label2.Text = "What is your league abbreviation?"
		'
		'txtAbbreviation
		'
		Me.txtAbbreviation.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtAbbreviation.Location = New System.Drawing.Point(16, 88)
		Me.txtAbbreviation.MaxLength = 10
		Me.txtAbbreviation.Name = "txtAbbreviation"
		Me.txtAbbreviation.Size = New System.Drawing.Size(64, 20)
		Me.txtAbbreviation.TabIndex = 1
		Me.txtAbbreviation.Text = "MSL"
		'
		'Label1
		'
		Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.Location = New System.Drawing.Point(16, 16)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(376, 16)
		Me.Label1.TabIndex = 1
		Me.Label1.Text = "What is your league name?"
		'
		'txtLeagueName
		'
		Me.txtLeagueName.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtLeagueName.Location = New System.Drawing.Point(16, 32)
		Me.txtLeagueName.MaxLength = 50
		Me.txtLeagueName.Name = "txtLeagueName"
		Me.txtLeagueName.Size = New System.Drawing.Size(368, 20)
		Me.txtLeagueName.TabIndex = 0
		Me.txtLeagueName.Text = "My Soccer League"
		'
		'grpGeneral
		'
		Me.grpGeneral.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
					Or System.Windows.Forms.AnchorStyles.Left) _
					Or System.Windows.Forms.AnchorStyles.Right)
		Me.grpGeneral.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label13, Me.txtChampionship, Me.Label2, Me.txtAbbreviation, Me.Label1, Me.txtLeagueName})
		Me.grpGeneral.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.grpGeneral.Location = New System.Drawing.Point(152, 40)
		Me.grpGeneral.Name = "grpGeneral"
		Me.grpGeneral.Size = New System.Drawing.Size(408, 352)
		Me.grpGeneral.TabIndex = 3
		Me.grpGeneral.TabStop = False
		Me.grpGeneral.Text = "General"
		'
		'Label13
		'
		Me.Label13.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label13.Location = New System.Drawing.Point(16, 128)
		Me.Label13.Name = "Label13"
		Me.Label13.Size = New System.Drawing.Size(376, 16)
		Me.Label13.TabIndex = 11
		Me.Label13.Text = "What is the name of your championship?"
		'
		'txtChampionship
		'
		Me.txtChampionship.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtChampionship.Location = New System.Drawing.Point(16, 144)
		Me.txtChampionship.MaxLength = 50
		Me.txtChampionship.Name = "txtChampionship"
		Me.txtChampionship.Size = New System.Drawing.Size(368, 20)
		Me.txtChampionship.TabIndex = 2
		Me.txtChampionship.Text = "MSL Championship"
		'
		'grpSchedule
		'
		Me.grpSchedule.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
					Or System.Windows.Forms.AnchorStyles.Left) _
					Or System.Windows.Forms.AnchorStyles.Right)
		Me.grpSchedule.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label4, Me.cmbDivisionGames, Me.lblTotalGames, Me.Label10, Me.cmbTeamsInPlayoffs, Me.Label9, Me.cmbGamesInChampionshipRound, Me.Label8, Me.cmbGamesInPlayoffSeries, Me.Label7, Me.cmbOtherConfGames, Me.Label6, Me.cmbConfGames})
		Me.grpSchedule.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.grpSchedule.Location = New System.Drawing.Point(152, 40)
		Me.grpSchedule.Name = "grpSchedule"
		Me.grpSchedule.Size = New System.Drawing.Size(408, 352)
		Me.grpSchedule.TabIndex = 0
		Me.grpSchedule.TabStop = False
		Me.grpSchedule.Text = "Schedule"
		'
		'Label4
		'
		Me.Label4.Location = New System.Drawing.Point(8, 16)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(352, 16)
		Me.Label4.TabIndex = 17
		Me.Label4.Text = "Number of games against division opponents:"
		'
		'cmbDivisionGames
		'
		Me.cmbDivisionGames.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbDivisionGames.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbDivisionGames.ItemHeight = 14
		Me.cmbDivisionGames.Items.AddRange(New Object() {"2", "4", "6", "8", "10"})
		Me.cmbDivisionGames.Location = New System.Drawing.Point(8, 32)
		Me.cmbDivisionGames.Name = "cmbDivisionGames"
		Me.cmbDivisionGames.Size = New System.Drawing.Size(56, 22)
		Me.cmbDivisionGames.TabIndex = 0
		'
		'lblTotalGames
		'
		Me.lblTotalGames.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblTotalGames.Location = New System.Drawing.Point(8, 160)
		Me.lblTotalGames.Name = "lblTotalGames"
		Me.lblTotalGames.Size = New System.Drawing.Size(352, 16)
		Me.lblTotalGames.TabIndex = 15
		Me.lblTotalGames.Text = "Total schedule (Must be less than 50):"
		'
		'Label10
		'
		Me.Label10.Location = New System.Drawing.Point(8, 296)
		Me.Label10.Name = "Label10"
		Me.Label10.Size = New System.Drawing.Size(352, 16)
		Me.Label10.TabIndex = 14
		Me.Label10.Text = "Number of teams in league that can qualify for league playoffs:"
		'
		'cmbTeamsInPlayoffs
		'
		Me.cmbTeamsInPlayoffs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbTeamsInPlayoffs.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbTeamsInPlayoffs.ItemHeight = 14
		Me.cmbTeamsInPlayoffs.Items.AddRange(New Object() {"2", "4", "6", "8"})
		Me.cmbTeamsInPlayoffs.Location = New System.Drawing.Point(8, 312)
		Me.cmbTeamsInPlayoffs.Name = "cmbTeamsInPlayoffs"
		Me.cmbTeamsInPlayoffs.Size = New System.Drawing.Size(56, 22)
		Me.cmbTeamsInPlayoffs.TabIndex = 4
		'
		'Label9
		'
		Me.Label9.Location = New System.Drawing.Point(8, 240)
		Me.Label9.Name = "Label9"
		Me.Label9.Size = New System.Drawing.Size(352, 16)
		Me.Label9.TabIndex = 12
		Me.Label9.Text = "Maximum number of games in championship round:"
		'
		'cmbGamesInChampionshipRound
		'
		Me.cmbGamesInChampionshipRound.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbGamesInChampionshipRound.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbGamesInChampionshipRound.ItemHeight = 14
		Me.cmbGamesInChampionshipRound.Items.AddRange(New Object() {"1", "3", "5", "7"})
		Me.cmbGamesInChampionshipRound.Location = New System.Drawing.Point(8, 264)
		Me.cmbGamesInChampionshipRound.Name = "cmbGamesInChampionshipRound"
		Me.cmbGamesInChampionshipRound.Size = New System.Drawing.Size(56, 22)
		Me.cmbGamesInChampionshipRound.TabIndex = 3
		'
		'Label8
		'
		Me.Label8.Location = New System.Drawing.Point(8, 192)
		Me.Label8.Name = "Label8"
		Me.Label8.Size = New System.Drawing.Size(352, 16)
		Me.Label8.TabIndex = 10
		Me.Label8.Text = "Maximum number of games in playoff series:"
		'
		'cmbGamesInPlayoffSeries
		'
		Me.cmbGamesInPlayoffSeries.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbGamesInPlayoffSeries.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbGamesInPlayoffSeries.ItemHeight = 14
		Me.cmbGamesInPlayoffSeries.Items.AddRange(New Object() {"1", "3", "5", "7"})
		Me.cmbGamesInPlayoffSeries.Location = New System.Drawing.Point(8, 208)
		Me.cmbGamesInPlayoffSeries.Name = "cmbGamesInPlayoffSeries"
		Me.cmbGamesInPlayoffSeries.Size = New System.Drawing.Size(56, 22)
		Me.cmbGamesInPlayoffSeries.TabIndex = 2
		'
		'Label7
		'
		Me.Label7.Location = New System.Drawing.Point(8, 112)
		Me.Label7.Name = "Label7"
		Me.Label7.Size = New System.Drawing.Size(352, 16)
		Me.Label7.TabIndex = 8
		Me.Label7.Text = "Number of games against opposite conference opponents:"
		'
		'cmbOtherConfGames
		'
		Me.cmbOtherConfGames.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbOtherConfGames.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbOtherConfGames.ItemHeight = 14
		Me.cmbOtherConfGames.Items.AddRange(New Object() {"0", "2", "4", "6", "8", "10"})
		Me.cmbOtherConfGames.Location = New System.Drawing.Point(8, 128)
		Me.cmbOtherConfGames.Name = "cmbOtherConfGames"
		Me.cmbOtherConfGames.Size = New System.Drawing.Size(56, 22)
		Me.cmbOtherConfGames.TabIndex = 1
		'
		'Label6
		'
		Me.Label6.Location = New System.Drawing.Point(8, 64)
		Me.Label6.Name = "Label6"
		Me.Label6.Size = New System.Drawing.Size(352, 16)
		Me.Label6.TabIndex = 6
		Me.Label6.Text = "Number of games against conference opponents:"
		'
		'cmbConfGames
		'
		Me.cmbConfGames.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbConfGames.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbConfGames.ItemHeight = 14
		Me.cmbConfGames.Items.AddRange(New Object() {"0", "2", "4", "6", "8", "10"})
		Me.cmbConfGames.Location = New System.Drawing.Point(8, 80)
		Me.cmbConfGames.Name = "cmbConfGames"
		Me.cmbConfGames.Size = New System.Drawing.Size(56, 22)
		Me.cmbConfGames.TabIndex = 5
		'
		'grpRules
		'
		Me.grpRules.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
					Or System.Windows.Forms.AnchorStyles.Left) _
					Or System.Windows.Forms.AnchorStyles.Right)
		Me.grpRules.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label12, Me.cmbDropToFAPool, Me.Label11, Me.cmbMultiPoint})
		Me.grpRules.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.grpRules.Location = New System.Drawing.Point(152, 40)
		Me.grpRules.Name = "grpRules"
		Me.grpRules.Size = New System.Drawing.Size(408, 352)
		Me.grpRules.TabIndex = 9
		Me.grpRules.TabStop = False
		Me.grpRules.Text = "Rules"
		'
		'Label12
		'
		Me.Label12.Location = New System.Drawing.Point(16, 80)
		Me.Label12.Name = "Label12"
		Me.Label12.Size = New System.Drawing.Size(376, 16)
		Me.Label12.TabIndex = 8
		Me.Label12.Text = "Drop players into free agent pool for drafting?"
		'
		'cmbDropToFAPool
		'
		Me.cmbDropToFAPool.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbDropToFAPool.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbDropToFAPool.ItemHeight = 14
		Me.cmbDropToFAPool.Items.AddRange(New Object() {"Yes", "No"})
		Me.cmbDropToFAPool.Location = New System.Drawing.Point(16, 96)
		Me.cmbDropToFAPool.Name = "cmbDropToFAPool"
		Me.cmbDropToFAPool.Size = New System.Drawing.Size(56, 22)
		Me.cmbDropToFAPool.TabIndex = 1
		'
		'Label11
		'
		Me.Label11.Location = New System.Drawing.Point(16, 24)
		Me.Label11.Name = "Label11"
		Me.Label11.Size = New System.Drawing.Size(376, 16)
		Me.Label11.TabIndex = 6
		Me.Label11.Text = "Allow multi-point scoring?"
		'
		'cmbMultiPoint
		'
		Me.cmbMultiPoint.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbMultiPoint.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbMultiPoint.ItemHeight = 14
		Me.cmbMultiPoint.Items.AddRange(New Object() {"Yes", "No"})
		Me.cmbMultiPoint.Location = New System.Drawing.Point(16, 40)
		Me.cmbMultiPoint.Name = "cmbMultiPoint"
		Me.cmbMultiPoint.Size = New System.Drawing.Size(56, 22)
		Me.cmbMultiPoint.TabIndex = 0
		'
		'grpFinish
		'
		Me.grpFinish.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
					Or System.Windows.Forms.AnchorStyles.Left) _
					Or System.Windows.Forms.AnchorStyles.Right)
		Me.grpFinish.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label5, Me.lblProgress, Me.proProgress, Me.btnCreate, Me.lblGreeting})
		Me.grpFinish.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.grpFinish.Location = New System.Drawing.Point(152, 40)
		Me.grpFinish.Name = "grpFinish"
		Me.grpFinish.Size = New System.Drawing.Size(408, 352)
		Me.grpFinish.TabIndex = 11
		Me.grpFinish.TabStop = False
		Me.grpFinish.Text = "Finish"
		'
		'Label5
		'
		Me.Label5.Location = New System.Drawing.Point(16, 64)
		Me.Label5.Name = "Label5"
		Me.Label5.Size = New System.Drawing.Size(376, 32)
		Me.Label5.TabIndex = 10
		Me.Label5.Text = "Note:  Larger leagues may take some time to create depending on the speed of your" & _
		" machine."
		'
		'lblProgress
		'
		Me.lblProgress.Location = New System.Drawing.Point(16, 112)
		Me.lblProgress.Name = "lblProgress"
		Me.lblProgress.Size = New System.Drawing.Size(376, 16)
		Me.lblProgress.TabIndex = 9
		Me.lblProgress.Text = "Progress..."
		Me.lblProgress.Visible = False
		'
		'proProgress
		'
		Me.proProgress.Location = New System.Drawing.Point(16, 136)
		Me.proProgress.Name = "proProgress"
		Me.proProgress.Size = New System.Drawing.Size(376, 16)
		Me.proProgress.TabIndex = 8
		Me.proProgress.Visible = False
		'
		'btnCreate
		'
		Me.btnCreate.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnCreate.Location = New System.Drawing.Point(288, 320)
		Me.btnCreate.Name = "btnCreate"
		Me.btnCreate.Size = New System.Drawing.Size(112, 24)
		Me.btnCreate.TabIndex = 7
		Me.btnCreate.Text = "Create!"
		'
		'lblGreeting
		'
		Me.lblGreeting.Location = New System.Drawing.Point(16, 24)
		Me.lblGreeting.Name = "lblGreeting"
		Me.lblGreeting.Size = New System.Drawing.Size(376, 32)
		Me.lblGreeting.TabIndex = 6
		Me.lblGreeting.Text = "You are now set to create your league.  Press ""Create"" below to begin the process" & _
		"!"
		'
		'gructure
		'
		Me.gructure.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
					Or System.Windows.Forms.AnchorStyles.Left) _
					Or System.Windows.Forms.AnchorStyles.Right)
		Me.gructure.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label3, Me.lblTotalTeams, Me.Label17, Me.Label16, Me.cmbDivisionSize, Me.Label14, Me.cmbDivisions, Me.Label15, Me.cmbConferences})
		Me.gructure.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.gructure.Location = New System.Drawing.Point(152, 40)
		Me.gructure.Name = "gructure"
		Me.gructure.Size = New System.Drawing.Size(408, 352)
		Me.gructure.TabIndex = 12
		Me.gructure.TabStop = False
		Me.gructure.Text = "Structure"
		'
		'Label3
		'
		Me.Label3.Location = New System.Drawing.Point(16, 24)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(376, 32)
		Me.Label3.TabIndex = 13
		Me.Label3.Text = "Set up your league structure here.  Please set up your league structure first bef" & _
		"ore creating your teams or they will be deleted."
		'
		'lblTotalTeams
		'
		Me.lblTotalTeams.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblTotalTeams.Location = New System.Drawing.Point(16, 240)
		Me.lblTotalTeams.Name = "lblTotalTeams"
		Me.lblTotalTeams.Size = New System.Drawing.Size(328, 16)
		Me.lblTotalTeams.TabIndex = 12
		Me.lblTotalTeams.Text = "Total Teams"
		'
		'Label17
		'
		Me.Label17.Location = New System.Drawing.Point(16, 280)
		Me.Label17.Name = "Label17"
		Me.Label17.Size = New System.Drawing.Size(376, 48)
		Me.Label17.TabIndex = 11
		Me.Label17.Text = "Note:  All divisions have an equal number of teams.  Schedules generated for this" & _
		" league will be balanced.  You may create leagues of 30 teams or less."
		'
		'Label16
		'
		Me.Label16.Location = New System.Drawing.Point(16, 184)
		Me.Label16.Name = "Label16"
		Me.Label16.Size = New System.Drawing.Size(376, 16)
		Me.Label16.TabIndex = 10
		Me.Label16.Text = "Number of teams per division?"
		'
		'cmbDivisionSize
		'
		Me.cmbDivisionSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbDivisionSize.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbDivisionSize.ItemHeight = 14
		Me.cmbDivisionSize.Items.AddRange(New Object() {"3", "4", "5", "6"})
		Me.cmbDivisionSize.Location = New System.Drawing.Point(16, 200)
		Me.cmbDivisionSize.Name = "cmbDivisionSize"
		Me.cmbDivisionSize.Size = New System.Drawing.Size(56, 22)
		Me.cmbDivisionSize.TabIndex = 2
		'
		'Label14
		'
		Me.Label14.Location = New System.Drawing.Point(16, 128)
		Me.Label14.Name = "Label14"
		Me.Label14.Size = New System.Drawing.Size(376, 16)
		Me.Label14.TabIndex = 8
		Me.Label14.Text = "Number of divisions per conference in this league?"
		'
		'cmbDivisions
		'
		Me.cmbDivisions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbDivisions.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbDivisions.ItemHeight = 14
		Me.cmbDivisions.Items.AddRange(New Object() {"1", "2", "3", "4"})
		Me.cmbDivisions.Location = New System.Drawing.Point(16, 144)
		Me.cmbDivisions.Name = "cmbDivisions"
		Me.cmbDivisions.Size = New System.Drawing.Size(56, 22)
		Me.cmbDivisions.TabIndex = 1
		'
		'Label15
		'
		Me.Label15.Location = New System.Drawing.Point(16, 72)
		Me.Label15.Name = "Label15"
		Me.Label15.Size = New System.Drawing.Size(376, 16)
		Me.Label15.TabIndex = 6
		Me.Label15.Text = "Number of conferences in your league?"
		'
		'cmbConferences
		'
		Me.cmbConferences.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbConferences.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbConferences.ItemHeight = 14
		Me.cmbConferences.Items.AddRange(New Object() {"1", "2"})
		Me.cmbConferences.Location = New System.Drawing.Point(16, 88)
		Me.cmbConferences.Name = "cmbConferences"
		Me.cmbConferences.Size = New System.Drawing.Size(56, 22)
		Me.cmbConferences.TabIndex = 0
		'
		'grpTeams
		'
		Me.grpTeams.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
					Or System.Windows.Forms.AnchorStyles.Left) _
					Or System.Windows.Forms.AnchorStyles.Right)
		Me.grpTeams.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnRandomTeams, Me.txtConfDivName, Me.cmbCities, Me.trvStructure})
		Me.grpTeams.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.grpTeams.Location = New System.Drawing.Point(152, 40)
		Me.grpTeams.Name = "grpTeams"
		Me.grpTeams.Size = New System.Drawing.Size(408, 352)
		Me.grpTeams.TabIndex = 7
		Me.grpTeams.TabStop = False
		Me.grpTeams.Text = "Teams"
		'
		'btnRandomTeams
		'
		Me.btnRandomTeams.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnRandomTeams.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btnRandomTeams.Location = New System.Drawing.Point(280, 320)
		Me.btnRandomTeams.Name = "btnRandomTeams"
		Me.btnRandomTeams.Size = New System.Drawing.Size(112, 24)
		Me.btnRandomTeams.TabIndex = 28
		Me.btnRandomTeams.Text = "Randomize Cities"
		'
		'txtConfDivName
		'
		Me.txtConfDivName.Location = New System.Drawing.Point(16, 320)
		Me.txtConfDivName.Name = "txtConfDivName"
		Me.txtConfDivName.Size = New System.Drawing.Size(224, 20)
		Me.txtConfDivName.TabIndex = 18
		Me.txtConfDivName.Text = ""
		'
		'cmbCities
		'
		Me.cmbCities.Location = New System.Drawing.Point(16, 320)
		Me.cmbCities.Name = "cmbCities"
		Me.cmbCities.Size = New System.Drawing.Size(224, 22)
		Me.cmbCities.TabIndex = 17
		'
		'trvStructure
		'
		Me.trvStructure.HideSelection = False
		Me.trvStructure.ImageIndex = -1
		Me.trvStructure.LabelEdit = True
		Me.trvStructure.Location = New System.Drawing.Point(16, 16)
		Me.trvStructure.Name = "trvStructure"
		Me.trvStructure.SelectedImageIndex = -1
		Me.trvStructure.Size = New System.Drawing.Size(376, 296)
		Me.trvStructure.TabIndex = 16
		Me.tipLeague.SetToolTip(Me.trvStructure, "Double-click on a conference, division or city to change it.")
		'
		'grpMarkets
		'
		Me.grpMarkets.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
					Or System.Windows.Forms.AnchorStyles.Left) _
					Or System.Windows.Forms.AnchorStyles.Right)
		Me.grpMarkets.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmbRandomMarket, Me.cmbRegionalSetup, Me.Label21, Me.Label20})
		Me.grpMarkets.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.grpMarkets.Location = New System.Drawing.Point(152, 40)
		Me.grpMarkets.Name = "grpMarkets"
		Me.grpMarkets.Size = New System.Drawing.Size(408, 352)
		Me.grpMarkets.TabIndex = 13
		Me.grpMarkets.TabStop = False
		Me.grpMarkets.Text = "Markets"
		'
		'cmbRandomMarket
		'
		Me.cmbRandomMarket.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbRandomMarket.Items.AddRange(New Object() {"Any size", "Small market", "Mid market", "Large market"})
		Me.cmbRandomMarket.Location = New System.Drawing.Point(16, 40)
		Me.cmbRandomMarket.Name = "cmbRandomMarket"
		Me.cmbRandomMarket.Size = New System.Drawing.Size(120, 22)
		Me.cmbRandomMarket.TabIndex = 28
		'
		'cmbRegionalSetup
		'
		Me.cmbRegionalSetup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbRegionalSetup.Items.AddRange(New Object() {"Random regions", "Regional", "Coast to coast"})
		Me.cmbRegionalSetup.Location = New System.Drawing.Point(16, 88)
		Me.cmbRegionalSetup.Name = "cmbRegionalSetup"
		Me.cmbRegionalSetup.Size = New System.Drawing.Size(120, 22)
		Me.cmbRegionalSetup.TabIndex = 26
		Me.cmbRegionalSetup.Visible = False
		'
		'Label21
		'
		Me.Label21.Location = New System.Drawing.Point(16, 72)
		Me.Label21.Name = "Label21"
		Me.Label21.Size = New System.Drawing.Size(368, 16)
		Me.Label21.TabIndex = 25
		Me.Label21.Text = "What is the regional setup of your league?"
		Me.Label21.Visible = False
		'
		'Label20
		'
		Me.Label20.Location = New System.Drawing.Point(16, 24)
		Me.Label20.Name = "Label20"
		Me.Label20.Size = New System.Drawing.Size(368, 16)
		Me.Label20.TabIndex = 24
		Me.Label20.Text = "What is the general market size of your league's member cities?"
		'
		'frmLeagueWizard
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(576, 437)
		Me.ControlBox = False
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.grpMarkets, Me.lstOptions, Me.btnCancel, Me.grpGeneral, Me.grpSchedule, Me.grpFinish, Me.gructure, Me.grpRules, Me.grpTeams})
		Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
		Me.Name = "frmLeagueWizard"
		Me.ShowInTaskbar = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.Text = "Create New League Wizard"
		Me.grpGeneral.ResumeLayout(False)
		Me.grpSchedule.ResumeLayout(False)
		Me.grpRules.ResumeLayout(False)
		Me.grpFinish.ResumeLayout(False)
		Me.gructure.ResumeLayout(False)
		Me.grpTeams.ResumeLayout(False)
		Me.grpMarkets.ResumeLayout(False)
		Me.ResumeLayout(False)

	End Sub

#End Region


	Private Sub lstOptions_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstOptions.SelectedIndexChanged

		Select Case lstOptions.SelectedItem
			Case "General"
				Me.grpGeneral.BringToFront()
			Case "Schedule"
				Me.grpSchedule.BringToFront()
			Case "Rules"
				Me.grpRules.BringToFront()
			Case "Teams"
				Me.grpTeams.BringToFront()
			Case "Structure"
				Me.gructure.BringToFront()
			Case "Markets"
				Me.grpMarkets.BringToFront()

			Case Else
				Me.grpFinish.BringToFront()
		End Select
	End Sub


	Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
		Me.Close()
	End Sub

#Region "CustomSetup"

	Private Sub SetScreen()
		Me.grpGeneral.BringToFront()
		Call InitializeDefaults()
		Call App.SkinForm(Me)

	End Sub

	Private Sub InitializeDefaults()
		mblnLoading = True
		Me.cmbConfGames.Text = "4"
		Me.cmbGamesInChampionshipRound.Text = "5"
		Me.cmbGamesInPlayoffSeries.Text = "3"
		Me.cmbOtherConfGames.Text = "4"
		Me.cmbTeamsInPlayoffs.Text = "4"
		Me.cmbDivisionGames.Text = "2"
		Me.lstOptions.SelectedIndex = 0
		Me.cmbDropToFAPool.Text = "No"
		Me.cmbMultiPoint.Text = "No"
        Me.cmbConferences.Text = "1"
        Me.cmbDivisions.Text = "3"
        Me.cmbDivisionSize.Text = "4"
		Me.cmbRandomMarket.SelectedIndex = 0

		Dim pobjComboHelper As New DropDownUtility()
		With pobjComboHelper
			.DisplayMember = "City"
			.ValueMember = "City"
			.DataSource = App.gobjCities
			.Style = ComboBoxStyle.DropDownList			 'DropDown
			.Sorted = True
			.Fill(Me.cmbCities)
		End With

		mblnLoading = False
		Call SetTotalGamesText()
		Call CalculateLeagueSize()
		Call Me.LoadLeagueTree()

	End Sub

	Private Sub SetTotalGamesText(ByVal sender As System.Object, ByVal e As System.EventArgs) _
	 Handles cmbConfGames.SelectedIndexChanged, cmbGamesInChampionshipRound.SelectedIndexChanged, _
	   cmbGamesInPlayoffSeries.SelectedIndexChanged, cmbOtherConfGames.SelectedIndexChanged, _
	   cmbDivisionGames.SelectedIndexChanged
		Call SetTotalGamesText()
		If Not IsScheduleLegal() Then
			ShowMessageBox("Error", "You need to have each team play 50 games or less.  Please adjust your schedule appropriately.", Me)
			Me.grpSchedule.BringToFront()
			Me.lstOptions.SelectedIndex = 3
			Exit Sub
		End If
	End Sub

	Private Sub SetTotalGamesText()
		If mblnLoading = False Then
			Dim ConfGames As Integer = Int(Me.cmbConfGames.Text)
			Dim DivGames As Integer = Int(Me.cmbDivisionGames.Text)
			Dim OtherConfGames As Integer = Int(Me.cmbOtherConfGames.Text)
			Dim DivisionSize As Integer = Int(Me.cmbDivisionSize.Text)
			Dim TotalDivisions As Integer = Int(Me.cmbDivisions.Text)
			Dim TotalConferences As Integer = Int(Me.cmbConferences.Text)
			Dim TotalGames As Integer

			TotalGames = (DivisionSize - 1) * DivGames

			If TotalConferences > 1 Then
				If TotalDivisions > 1 Then
					TotalGames += (DivisionSize * TotalDivisions - 1) * ConfGames
				Else
					TotalGames += ((DivisionSize * TotalDivisions - 1) * ConfGames)
				End If
			End If

			If TotalConferences = 1 Then
				If TotalDivisions > 1 Then
					TotalGames += (ConfGames * (TotalDivisions - 1) * DivisionSize)
				End If

			End If


			mintTotalGames = TotalGames
			Me.lblTotalGames.Text = TotalGames & " total games for each team."


		End If
	End Sub

#End Region

	Private Sub btnRandomTeams_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRandomTeams.Click
		Call Me.LoadLeagueTree()
	End Sub

	Private Sub btnCreate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreate.Click
		Call BuildLeague()
	End Sub

	Private Sub BuildLeague()

		If IsFileNameLegal(Me.txtLeagueName.Text) = False Then
			ShowMessageBox("Error", "You either have illegal characters in your league's name or it is blank.  Please use alphanumeric characters.", Me)
			Me.grpGeneral.BringToFront()
			Me.lstOptions.SelectedIndex = 0
			Exit Sub
		End If

		If Not IsScheduleLegal() Then
			ShowMessageBox("Error", "You need to have each team play 60 games or less.  Please adjust your schedule appropriately.", Me)
			Me.grpSchedule.BringToFront()
			Me.lstOptions.SelectedIndex = 3
			Exit Sub
		End If

		If Not IsNumberOfTeamsLegal() Then
			ShowMessageBox("Error", "You need to have 30 teams or less in your league.  Please adjust the number of teams as appropriate.", Me)
			Me.gructure.BringToFront()
			Me.lstOptions.SelectedIndex = 1
			Exit Sub
		End If



		If System.IO.Directory.Exists(GetCurrentDirectory() & "\leagues\" & Me.txtLeagueName.Text) Then
			Dim Response As MsgBoxResult

			Response = MsgBox("Do you wish to overwrite your existing league", MsgBoxStyle.Exclamation + MsgBoxStyle.YesNoCancel + MsgBoxStyle.DefaultButton2, "ISM")

			If Response = MsgBoxResult.No Then
				Me.grpGeneral.BringToFront()
				Me.lstOptions.SelectedIndex = 0
				Exit Sub
			ElseIf Response = MsgBoxResult.Cancel Then
				Exit Sub
			End If
		End If

		Me.proProgress.Visible = True
		Me.lblProgress.Visible = True
		Me.btnCreate.Enabled = False
		SetCursor(True, Me)

		With Me.mobjLeague
			.Abbreviation = Me.txtAbbreviation.Text
			.Championship = Me.txtChampionship.Text
			.ChampionshipSeries = Int(Me.cmbGamesInChampionshipRound.Text)
			.DumpToFAPool = IIf(Me.cmbDropToFAPool.Text = "Yes", True, False)
			.InterconferenceMatchups = Int(Me.cmbConfGames.Text)
			.IntraconferenceMatchups = Int(Me.cmbOtherConfGames.Text)
			.InterdivisionMatchups = Int(Me.cmbDivisionGames.Text)
			.LeagueID = 1
			.MultiPoint = IIf(Me.cmbMultiPoint.Text = "Yes", True, False)
			.Name = Me.txtLeagueName.Text
			.PlayoffSeries = Int(Me.cmbGamesInPlayoffSeries.Text)
			.Season = Date.Now.Year
			.TeamsInPlayoff = Int(Me.cmbTeamsInPlayoffs.Text)

			'Add teams from nodes...
			Dim pobjRootNode As TreeNode = Me.trvStructure.Nodes(0)
			Dim pobjConfNode As TreeNode
			Dim pobjDivNode As TreeNode
			Dim pobjNode As TreeNode

			Dim intConfID As Integer
			Dim intDivID As Integer
			Dim strTeamName As String

			For Each pobjConfNode In pobjRootNode.Nodes
				intConfID = CType(pobjConfNode.Tag, Conference).ID
				.Conferences.Add(CType(pobjConfNode.Tag, Conference))
				For Each pobjDivNode In pobjConfNode.Nodes
					intDivID = CType(pobjDivNode.Tag, Division).ID
					.Divisions.Add(CType(pobjDivNode.Tag, Division))
					For Each pobjNode In pobjDivNode.Nodes
						.AddTeamName(pobjNode.Text, intConfID, intDivID)
					Next
				Next
			Next
			.CreateNewLeague()
		End With
        mobjLeague = Nothing
        LoadGlobalAppSettings(False)
		gobjLeague.Load(Me.txtLeagueName.Text)

		Me.proProgress.Visible = False
		Me.lblProgress.Visible = False
		Me.lstOptions.Enabled = False
		Me.btnCancel.Text = "Close"
		Me.lblGreeting.Text = "Your league has been created.  Close this wizard and begin your campaign!  Good luck!"
		SetCursor(False, Me)


	End Sub

	Private Sub mobjLeague_Progress(ByVal sender As Object, ByVal e As ISoccerSim.ProgressEventEventArgs) Handles mobjLeague.Progress
		Me.lblProgress.Text = e.Message
		Me.proProgress.Value = e.PercentDone
		Me.lblProgress.Refresh()
		Me.proProgress.Refresh()
		Me.Refresh()
		'Me.ParentForm.ParentForm.Refresh()
	End Sub

	Private Sub LeagueSizeChange(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbConferences.SelectedIndexChanged, cmbDivisions.SelectedIndexChanged, cmbDivisionSize.SelectedIndexChanged
		Call CalculateLeagueSize()
		If Not IsNumberOfTeamsLegal() Then
			ShowMessageBox("Error", "You need to have 30 teams or less in your league.  Please adjust the number of teams as appropriate.", Me)
			Me.gructure.BringToFront()
			Me.lstOptions.SelectedIndex = 1
			Exit Sub
		Else
			Call Me.SetTotalGamesText()
		End If
	End Sub

	Private Sub CalculateLeagueSize()
		If Not mblnLoading Then
			Dim Total As Integer
			Total = Int(Me.cmbConferences.Text) * Int(Me.cmbDivisions.Text) * Int(Me.cmbDivisionSize.Text)
			Me.lblTotalTeams.Text = "Total teams: " & Total
			mintLeagueSize = Total
			If Int(Me.cmbConferences.Text) = 1 Then
				If Int(Me.cmbDivisions.Text) = 1 Then
					Me.cmbConfGames.Visible = False
					Me.cmbOtherConfGames.Visible = False
				Else
					Me.cmbConfGames.Visible = True
					Me.cmbOtherConfGames.Visible = False
				End If
			Else
				If Int(Me.cmbDivisions.Text) = 1 Then
					Me.cmbConfGames.Visible = False
					Me.cmbOtherConfGames.Visible = True
				Else
					Me.cmbConfGames.Visible = True
					Me.cmbOtherConfGames.Visible = True
				End If
			End If
			Call Me.LoadLeagueTree()

		End If
	End Sub

	Private Sub LoadLeagueTree()
		Dim i As Integer = 1
		Dim intTeamID As Integer = 1
		With Me.trvStructure
			.BeginUpdate()
			.Nodes.Clear()
			marrCities.Clear()

			Dim RootNode As New TreeNode(Me.txtLeagueName.Text)
			RootNode.Tag = "Root"
			.Nodes.Add(RootNode)

			'Create conference nodes...
			If Me.cmbConferences.Text = "1" Then
				Dim Conference1Node As New TreeNode("Teams")
				Conference1Node.Tag = New Conference(1, "Teams")
				RootNode.Nodes.Add(Conference1Node)
			End If

			If Me.cmbConferences.Text = "2" Then
				Dim Conference1Node As New TreeNode("American Conference")
				Conference1Node.Tag = New Conference(1, "American")
				RootNode.Nodes.Add(Conference1Node)

				Dim Conference2Node As New TreeNode("National Conference")
				Conference2Node.Tag = New Conference(2, "National")
				RootNode.Nodes.Add(Conference2Node)
			End If

			'Create division nodes...
			Dim pobjNode As TreeNode
			For Each pobjNode In RootNode.Nodes
				If TypeOf pobjNode.Tag Is Conference Then
					'Add children divisions...
					Dim x As Integer
					For x = 1 To Int(Me.cmbDivisions.Text)
						Dim DivName As String = App.gsetLastNames.GetRandomItem.Value
						Dim DivisionNode As New TreeNode(DivName & " Division")
						DivisionNode.Tag = New Division(i, DivName, CType(pobjNode.Tag, Conference).ID)
						pobjNode.Nodes.Add(DivisionNode)
						DivisionNode.Collapse()

						'Add children teams...
						Dim y As Integer
						For y = 1 To Int(Me.cmbDivisionSize.Text)
							Dim pobjCity As New City()
							Do
								pobjCity = gobjCities.GetRandomItemByMarketSize(Me.cmbRandomMarket.SelectedIndex)
								If marrCities.IndexOf(pobjCity) = -1 Then
									Dim TeamNode As New TreeNode(pobjCity.City)
									TeamNode.Tag = intTeamID
									DivisionNode.Nodes.Add(TeamNode)
									marrCities.Add(pobjCity)
									intTeamID = intTeamID + 1
									Exit Do
								End If
							Loop
						Next
						pobjNode.Expand()
						i = i + 1
					Next
				End If
			Next
			.SelectedNode = RootNode
			.SelectedNode.ExpandAll()
			.EndUpdate()
		End With


	End Sub

	Private Sub trvStructure_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles trvStructure.AfterSelect
		Dim Type As ISS_NodeType
		Type = GetNodeType(e.Node)
		Dim pobjNodeTag As Object = e.Node.Tag

		If Type = ISS_NodeType.ConferenceNode Then
			Me.txtConfDivName.Text = CType(pobjNodeTag, Conference).Name
			Me.txtConfDivName.Visible = True
			Me.cmbCities.Visible = False
		ElseIf Type = ISS_NodeType.DivisionNode Then
			Me.txtConfDivName.Text = CType(pobjNodeTag, Division).Name
			Me.txtConfDivName.Visible = True
			Me.cmbCities.Visible = False
		ElseIf Type = ISS_NodeType.TeamNode Then
			Me.cmbCities.Text = e.Node.Text
			Me.txtConfDivName.Visible = False
			Me.cmbCities.Visible = True
		ElseIf Type = ISS_NodeType.RootNode Then
			Me.txtConfDivName.Visible = False
			Me.cmbCities.Visible = False
		Else
		End If
	End Sub

	Private Sub txtConfDivName_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtConfDivName.TextChanged
		Dim Type As ISS_NodeType
		Type = GetNodeType(Me.trvStructure.SelectedNode)
		If Type = ISS_NodeType.DivisionNode Then
			Me.trvStructure.SelectedNode.Text = Me.txtConfDivName.Text & " Division"
		ElseIf Type = ISS_NodeType.ConferenceNode Then
			Me.trvStructure.SelectedNode.Text = Me.txtConfDivName.Text & " Conference"
		End If
	End Sub

	Private Function GetNodeType(ByVal objNode As TreeNode) As ISS_NodeType
		If TypeOf objNode.Tag Is Conference Then
			Return ISS_NodeType.ConferenceNode
		ElseIf TypeOf objNode.Tag Is Division Then
			Return ISS_NodeType.DivisionNode
		ElseIf TypeOf objNode.Tag Is Integer Then
			Return ISS_NodeType.TeamNode
		Else
			Return ISS_NodeType.RootNode
		End If
	End Function

	Private Sub cmbCities_DisplayMemberChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbCities.SelectedValueChanged
		If Not mblnLoading Then
			If Not (Me.trvStructure.SelectedNode Is Nothing) Then
				Me.trvStructure.SelectedNode.Text = Me.cmbCities.Text
			End If
		End If
	End Sub

	Private Function IsScheduleLegal() As Boolean
		If mintTotalGames > 60 Then
			Return False
		Else
			Return True
		End If
	End Function

	Private Function IsNumberOfTeamsLegal() As Boolean
		If mintLeagueSize > 30 Then
			Return False
		Else
			Return True
		End If
	End Function


	Private Sub cmbRandomMarket_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbRandomMarket.Click
		Call Me.LoadLeagueTree()
	End Sub
End Class
