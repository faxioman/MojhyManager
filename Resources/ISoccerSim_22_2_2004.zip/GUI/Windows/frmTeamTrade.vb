'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Friend Class frmTeamTrade
    Inherits System.Windows.Forms.Form

    Friend TeamID As Integer

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Call SetScreen(2, 1)
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents grpFinish As System.Windows.Forms.GroupBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnPropose As System.Windows.Forms.Button
    Friend WithEvents lstTo As System.Windows.Forms.ListBox
    Friend WithEvents btnAddCashTo As System.Windows.Forms.Button
    Friend WithEvents btnAddPickTo As System.Windows.Forms.Button
    Friend WithEvents btnAddPlayerTo As System.Windows.Forms.Button
    Friend WithEvents lstFrom As System.Windows.Forms.ListBox
    Friend WithEvents btnAddCashFrom As System.Windows.Forms.Button
    Friend WithEvents btnAddPickFrom As System.Windows.Forms.Button
    Friend WithEvents btnAddPlayerFrom As System.Windows.Forms.Button
    Friend WithEvents tcmbFrom As ISoccerSim.TeamCombo
    Friend WithEvents tcmbTo As ISoccerSim.TeamCombo
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.grpFinish = New System.Windows.Forms.GroupBox()
        Me.btnPropose = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.tcmbFrom = New ISoccerSim.TeamCombo()
        Me.lstFrom = New System.Windows.Forms.ListBox()
        Me.btnAddCashFrom = New System.Windows.Forms.Button()
        Me.btnAddPickFrom = New System.Windows.Forms.Button()
        Me.btnAddPlayerFrom = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.tcmbTo = New ISoccerSim.TeamCombo()
        Me.lstTo = New System.Windows.Forms.ListBox()
        Me.btnAddCashTo = New System.Windows.Forms.Button()
        Me.btnAddPickTo = New System.Windows.Forms.Button()
        Me.btnAddPlayerTo = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.grpFinish.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpFinish
        '
        Me.grpFinish.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.grpFinish.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnPropose, Me.GroupBox2, Me.GroupBox1})
        Me.grpFinish.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpFinish.Location = New System.Drawing.Point(8, 16)
        Me.grpFinish.Name = "grpFinish"
        Me.grpFinish.Size = New System.Drawing.Size(618, 248)
        Me.grpFinish.TabIndex = 12
        Me.grpFinish.TabStop = False
        Me.grpFinish.Text = "Trade Details..."
        '
        'btnPropose
        '
        Me.btnPropose.Location = New System.Drawing.Point(520, 216)
        Me.btnPropose.Name = "btnPropose"
        Me.btnPropose.Size = New System.Drawing.Size(86, 24)
        Me.btnPropose.TabIndex = 33
        Me.btnPropose.Text = "&Propose"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.AddRange(New System.Windows.Forms.Control() {Me.tcmbFrom, Me.lstFrom, Me.btnAddCashFrom, Me.btnAddPickFrom, Me.btnAddPlayerFrom, Me.Label2})
        Me.GroupBox2.Location = New System.Drawing.Point(8, 16)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(296, 192)
        Me.GroupBox2.TabIndex = 29
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Team:"
        '
        'tcmbFrom
        '
        Me.tcmbFrom.Location = New System.Drawing.Point(8, 32)
        Me.tcmbFrom.Name = "tcmbFrom"
        Me.tcmbFrom.Size = New System.Drawing.Size(280, 24)
        Me.tcmbFrom.TabIndex = 34
        '
        'lstFrom
        '
        Me.lstFrom.ItemHeight = 14
        Me.lstFrom.Location = New System.Drawing.Point(8, 96)
        Me.lstFrom.Name = "lstFrom"
        Me.lstFrom.Size = New System.Drawing.Size(280, 88)
        Me.lstFrom.TabIndex = 33
        '
        'btnAddCashFrom
        '
        Me.btnAddCashFrom.Location = New System.Drawing.Point(200, 64)
        Me.btnAddCashFrom.Name = "btnAddCashFrom"
        Me.btnAddCashFrom.Size = New System.Drawing.Size(86, 24)
        Me.btnAddCashFrom.TabIndex = 32
        Me.btnAddCashFrom.Text = "&Add Cash"
        '
        'btnAddPickFrom
        '
        Me.btnAddPickFrom.Location = New System.Drawing.Point(104, 64)
        Me.btnAddPickFrom.Name = "btnAddPickFrom"
        Me.btnAddPickFrom.Size = New System.Drawing.Size(86, 24)
        Me.btnAddPickFrom.TabIndex = 31
        Me.btnAddPickFrom.Text = "&Add Pick"
        '
        'btnAddPlayerFrom
        '
        Me.btnAddPlayerFrom.Location = New System.Drawing.Point(8, 64)
        Me.btnAddPlayerFrom.Name = "btnAddPlayerFrom"
        Me.btnAddPlayerFrom.Size = New System.Drawing.Size(86, 24)
        Me.btnAddPlayerFrom.TabIndex = 30
        Me.btnAddPlayerFrom.Text = "&Add Player"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(112, 24)
        Me.Label2.TabIndex = 28
        Me.Label2.Text = "Team:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.tcmbTo, Me.lstTo, Me.btnAddCashTo, Me.btnAddPickTo, Me.btnAddPlayerTo, Me.Label1})
        Me.GroupBox1.Location = New System.Drawing.Point(312, 16)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(296, 192)
        Me.GroupBox1.TabIndex = 28
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Trade Team:"
        '
        'tcmbTo
        '
        Me.tcmbTo.Location = New System.Drawing.Point(8, 32)
        Me.tcmbTo.Name = "tcmbTo"
        Me.tcmbTo.Size = New System.Drawing.Size(280, 24)
        Me.tcmbTo.TabIndex = 35
        '
        'lstTo
        '
        Me.lstTo.ItemHeight = 14
        Me.lstTo.Location = New System.Drawing.Point(8, 96)
        Me.lstTo.Name = "lstTo"
        Me.lstTo.Size = New System.Drawing.Size(280, 88)
        Me.lstTo.TabIndex = 33
        '
        'btnAddCashTo
        '
        Me.btnAddCashTo.Location = New System.Drawing.Point(200, 64)
        Me.btnAddCashTo.Name = "btnAddCashTo"
        Me.btnAddCashTo.Size = New System.Drawing.Size(86, 24)
        Me.btnAddCashTo.TabIndex = 32
        Me.btnAddCashTo.Text = "&Add Cash"
        '
        'btnAddPickTo
        '
        Me.btnAddPickTo.Location = New System.Drawing.Point(104, 64)
        Me.btnAddPickTo.Name = "btnAddPickTo"
        Me.btnAddPickTo.Size = New System.Drawing.Size(86, 24)
        Me.btnAddPickTo.TabIndex = 31
        Me.btnAddPickTo.Text = "&Add Pick"
        '
        'btnAddPlayerTo
        '
        Me.btnAddPlayerTo.Location = New System.Drawing.Point(8, 64)
        Me.btnAddPlayerTo.Name = "btnAddPlayerTo"
        Me.btnAddPlayerTo.Size = New System.Drawing.Size(86, 24)
        Me.btnAddPlayerTo.TabIndex = 30
        Me.btnAddPlayerTo.Text = "&Add Player"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 24)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "Team To Trade With:"
        '
        'btnOK
        '
        Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnOK.Location = New System.Drawing.Point(514, 274)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(112, 24)
        Me.btnOK.TabIndex = 13
        Me.btnOK.Text = "&OK"
        '
        'frmTeamTrade
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(634, 303)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnOK, Me.grpFinish})
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmTeamTrade"
        Me.Text = "Propose Trade"
        Me.grpFinish.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Friend Sub SetScreen(ByVal TeamID As Integer)

        Call App.SkinForm(Me)
        Me.tcmbFrom.LoadTeams(1)
        Me.tcmbTo.LoadTeams(2)
    End Sub

    Friend Sub SetScreen(ByVal TeamID As Integer, ByVal OtherTeamID As Integer)
        Call App.SkinForm(Me)
        Me.tcmbFrom.LoadTeams(1)
        Me.tcmbTo.LoadTeams(2)
    End Sub


    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Me.Close()
    End Sub

    Private Sub btnAddPlayerFrom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddPlayerFrom.Click

    End Sub
End Class
