'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Public Class frmListPick
    Inherits System.Windows.Forms.Form



#Region " Windows Form Designer generated code "

    Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

        'Add standard error handler
        AddHandler Application.ThreadException, New ThreadExceptionEventHandler(AddressOf HandleException)

    End Sub

    Friend Sub New(ByVal lstPicks As ListPicks)
        InitializeComponent()
        SetScreen(lstPicks)
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lstPick As System.Windows.Forms.ListBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lstPick = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'lstPick
        '
        Me.lstPick.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
           Or System.Windows.Forms.AnchorStyles.Left) _
           Or System.Windows.Forms.AnchorStyles.Right)
        Me.lstPick.ItemHeight = 14
        Me.lstPick.Name = "lstPick"
        Me.lstPick.Size = New System.Drawing.Size(120, 228)
        Me.lstPick.TabIndex = 0
        '
        'frmListPick
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(120, 224)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lstPick})
        Me.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmListPick"
        Me.Text = "frmListPick"
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub SetScreen(ByVal lstPicks As ListPicks)
        Dim n As ListPickItem

        If lstPicks.Count > 0 Then
            'Set up custom draw...
            With Me.lstPick
                .DrawMode = DrawMode.OwnerDrawFixed
                .ItemHeight = 13
                .BeginUpdate()
                .Items.Clear()
            End With

            'Add items...

            For Each n In lstPicks
                Me.lstPick.Items.Add(n)
            Next

            Me.lstPick.EndUpdate()
            'Handle form specifics..
            With Me
                .Text = lstPicks.Text
                .Height = ((Me.lstPick.Items.Count + 2) * Me.lstPick.ItemHeight) + 100
            End With
        End If

    End Sub

    Private Sub DrawListBoxItem(ByVal sender As Object, _
     ByVal e As DrawItemEventArgs) Handles lstPick.DrawItem

        Dim rect As Rectangle = e.Bounds
        Dim dfont As System.Drawing.Font

        'Draw window background...
        If CBool((e.State And DrawItemState.Selected)) Then
            e.Graphics.FillRectangle(SystemBrushes.Highlight, rect)
        Else
            e.Graphics.FillRectangle(SystemBrushes.Window, rect)
        End If

        'Draw item background....
        Dim lstItem As New ListPickItem()
        lstItem = Me.lstPick.Items(e.Index)

        Dim ItemName As String = lstItem.Name
        Dim b = New SolidBrush(Color.Aquamarine)
        'rect.Inflate(-16, -2)

        If e.Index / 2 = Int(e.Index / 2) Then
            b = New SolidBrush(gobjOptions.GridCaptionColor)
        Else
            b = New SolidBrush(Color.OldLace)
        End If
        e.Graphics.FillRectangle(b, rect)
        'e.Graphics.DrawRectangle(Pens.Black, rect)

        'Draw text...
        Dim b2 As Brush
        If CInt(b.Color.R) + CInt(b.Color.G) + CInt(b.Color.B) > 128 * 3 Then
            b2 = Brushes.Black
        Else
            b2 = Brushes.White
        End If

        e.Graphics.DrawString(ItemName, e.Font, b2, rect.X, rect.Y)
        b.Dispose()

    End Sub
    Private Sub lstPick_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstPick.SelectedIndexChanged
        Dim lstItem As New ListPickItem()
        Dim frmTarget As New Form()

        lstItem = Me.lstPick.SelectedItem
        If gobjLeague Is Nothing Then
            ShowMessageBox("Error", "A league must be open to select this option." & vbCrLf & vbCrLf & "Please either create a new league or open an existing one.", Me)
            Exit Sub
        ElseIf gobjLeague.Name = "" And lstItem.NeedLeagueLoaded Then
            ShowMessageBox("Error", "A league must be open to select this option." & vbCrLf & vbCrLf & "Please either create a new league or open an existing one.", Me)
            Exit Sub
        ElseIf lstItem.NeedToBeInRegularSeason And lstItem.NeedLeagueLoaded And gobjLeague.CanRunExhibition = False Then
            ShowMessageBox("Error", "You must have a league loaded and be in the preseason, regular season or postseason to select this option.", Me)
            Exit Sub
        End If
        frmTarget = GetTargetForm(lstItem.Item)

        Try
            frmTarget.ShowDialog(Me.ParentForm)
            Me.ParentForm.Refresh()
        Catch ex As System.Exception
            Call HandleException(Me, ex)
        End Try

    End Sub

    Private Function GetTargetForm(ByVal lngItem As ISSimForm) As Form
        Dim f As Form
        Select Case lngItem
            Case ISSimForm.CreateNewLeague
                f = New frmLeagueWizard()
            Case ISSimForm.LeagueStandings
                f = New frmStandings()
            Case ISSimForm.LoadLeague
                f = New frmOpenLeague()
            Case ISSimForm.OpenSkin
                f = New frmOpenSkin()
            Case ISSimForm.LeagueSettings
                f = New frmLeagueSettings()
            Case ISSimForm.TeamRoster
                f = New frmTeamRoster()
            Case ISSimForm.LeagueSchedule
                f = New frmLeagueSchedule()
            Case ISSimForm.TeamSubline
                f = New frmTeamSublines()
            Case ISSimForm.LeagueTactics
                f = New frmTactics()
            Case ISSimForm.LeagueSituations
                f = New frmSituations()
            Case ISSimForm.ProgramGuide
                f = New frmGuide()
            Case ISSimForm.OpenProgramOptions
                f = New frmProgramOptions()
            Case ISSimForm.TeamCoaching
                f = New frmTeamCoaching()
            Case ISSimForm.LeagueExhibition
                f = New frmLeagueExhibition()
            Case ISSimForm.TeamSettings
                f = New frmTeamSettings()
            Case ISSimForm.LeagueStats
                f = New frmLeagueStats()
            Case ISSimForm.OptionsPlayByPlay
                f = New frmPBP()
            Case ISSimForm.TeamFinance
                f = New frmTeamFinance()
            Case ISSimForm.TeamTrade
                f = New frmTeamTrade()
        End Select

        Return f
    End Function


    Private Sub lstPick_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstPick.MouseEnter
        Me.Cursor = System.Windows.Forms.Cursors.Hand
    End Sub

    Private Sub lstPick_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstPick.MouseLeave
        Me.Cursor = System.Windows.Forms.Cursors.Default
    End Sub
End Class

'List Pick class exclusive to this form...

Friend Class ListPicks
    Inherits System.Collections.CollectionBase
    Friend Text As String

    Default Property Item(ByVal index As Integer) As ListPickItem
        Get
            Return CType(InnerList.Item(index), ListPickItem)
        End Get
        Set(ByVal Value As ListPickItem)
            InnerList.Item(index) = Value
        End Set
    End Property

    Sub Add(ByVal value As ListPickItem)
        InnerList.Add(value)
    End Sub

    Sub Create(ByVal Item As ISSimForm, ByVal Name As String, ByVal NeedLeagueLoaded As Boolean, ByVal NeedToBeInRegularSeason As Boolean)
        Dim lstItem As New ListPickItem()
        lstItem.Item = Item
        lstItem.Name = Name
        lstItem.NeedLeagueLoaded = NeedLeagueLoaded
        lstItem.NeedToBeInRegularSeason = NeedToBeInRegularSeason
        InnerList.Add(lstItem)
    End Sub

    Sub Create(ByVal Item As ISSimForm, ByVal Name As String, ByVal NeedLeagueLoaded As Boolean, ByVal Form As Object)
        Dim lstItem As New ListPickItem()
        lstItem.Item = Item
        lstItem.Name = Name
        lstItem.NeedLeagueLoaded = NeedLeagueLoaded
        InnerList.Add(lstItem)
    End Sub
End Class

Friend Class ListPickItem
    Friend Item As ISSimForm
    Friend Name As String
    Friend NeedLeagueLoaded As Boolean
    Friend NeedToBeInRegularSeason As Boolean

    Overrides Function ToString() As String
        Return Me.Name
    End Function
End Class




