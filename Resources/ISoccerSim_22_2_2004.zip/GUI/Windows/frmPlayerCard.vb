'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.Positions
Imports ISoccerSim.Players

Public Class frmPlayerCard
	Inherits System.Windows.Forms.Form

	Private mblnLoading As Boolean
	Private mblnDirty As Boolean
	Private mblnSaved As Boolean
	Private mintPlayerID As Integer
	Private marrPlayerArray As New ArrayList()
	Private mintArrayPos As Integer


#Region " Windows Form Designer generated code "

	Sub New(ByVal intPlayerID As Integer, ByVal arlPlayersInGrid As ArrayList)
		MyBase.New()
		mintPlayerID = intPlayerID
		marrPlayerArray = arlPlayersInGrid

		'This call is required by the Windows Form Designer.
		InitializeComponent()


		'Add any initialization after the InitializeComponent() call
		Call SetScreen()
		Call LoadPlayer()
		Call NavigatePlayer(0)

	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Friend WithEvents tipLeague As System.Windows.Forms.ToolTip
	Friend WithEvents btnOK As System.Windows.Forms.Button
	Friend WithEvents lstOptions As System.Windows.Forms.ListBox
	Friend WithEvents grpRatings As System.Windows.Forms.GroupBox
	Friend WithEvents dgRatings As System.Windows.Forms.DataGrid
	Friend WithEvents grpPlayerName As System.Windows.Forms.GroupBox
	Friend WithEvents lblPlayerName As System.Windows.Forms.Label
	Friend WithEvents btnPrev As System.Windows.Forms.Button
	Friend WithEvents btnNext As System.Windows.Forms.Button
	Friend WithEvents grpGeneral As System.Windows.Forms.GroupBox
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents lblPosition As System.Windows.Forms.Label
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents txtAge As System.Windows.Forms.TextBox
	Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
	Friend WithEvents txtLastName As System.Windows.Forms.TextBox
	Friend WithEvents Label5 As System.Windows.Forms.Label
	Friend WithEvents txtHometown As System.Windows.Forms.TextBox
	Friend WithEvents Label6 As System.Windows.Forms.Label
	Friend WithEvents txtHighSchool As System.Windows.Forms.TextBox
	Friend WithEvents Label7 As System.Windows.Forms.Label
	Friend WithEvents txtCollege As System.Windows.Forms.TextBox
	Friend WithEvents btnSave As System.Windows.Forms.Button
	Friend WithEvents Label8 As System.Windows.Forms.Label
	Friend WithEvents txtJersey As System.Windows.Forms.TextBox
    Friend WithEvents grpStatistics As System.Windows.Forms.GroupBox
    Friend WithEvents dgResults As System.Windows.Forms.DataGrid
    Friend WithEvents grpHighlights As System.Windows.Forms.GroupBox
    Friend WithEvents txtHighlights As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.tipLeague = New System.Windows.Forms.ToolTip(Me.components)
        Me.lstOptions = New System.Windows.Forms.ListBox()
        Me.grpRatings = New System.Windows.Forms.GroupBox()
        Me.dgRatings = New System.Windows.Forms.DataGrid()
        Me.grpPlayerName = New System.Windows.Forms.GroupBox()
        Me.lblPlayerName = New System.Windows.Forms.Label()
        Me.btnPrev = New System.Windows.Forms.Button()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.grpGeneral = New System.Windows.Forms.GroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtJersey = New System.Windows.Forms.TextBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtCollege = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtHighSchool = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtHometown = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtAge = New System.Windows.Forms.TextBox()
        Me.lblPosition = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.grpStatistics = New System.Windows.Forms.GroupBox()
        Me.dgResults = New System.Windows.Forms.DataGrid()
        Me.grpHighlights = New System.Windows.Forms.GroupBox()
        Me.txtHighlights = New System.Windows.Forms.TextBox()
        Me.grpRatings.SuspendLayout()
        CType(Me.dgRatings, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpPlayerName.SuspendLayout()
        Me.grpGeneral.SuspendLayout()
        Me.grpStatistics.SuspendLayout()
        CType(Me.dgResults, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpHighlights.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnOK
        '
        Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnOK.Location = New System.Drawing.Point(456, 400)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(112, 24)
        Me.btnOK.TabIndex = 4
        Me.btnOK.Text = "&OK"
        '
        'lstOptions
        '
        Me.lstOptions.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left)
        Me.lstOptions.ItemHeight = 14
        Me.lstOptions.Items.AddRange(New Object() {"General", "Ratings", "Statistics", "Highlights"})
        Me.lstOptions.Location = New System.Drawing.Point(16, 48)
        Me.lstOptions.Name = "lstOptions"
        Me.lstOptions.Size = New System.Drawing.Size(64, 130)
        Me.lstOptions.TabIndex = 14
        '
        'grpRatings
        '
        Me.grpRatings.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.grpRatings.Controls.AddRange(New System.Windows.Forms.Control() {Me.dgRatings})
        Me.grpRatings.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpRatings.Location = New System.Drawing.Point(96, 48)
        Me.grpRatings.Name = "grpRatings"
        Me.grpRatings.Size = New System.Drawing.Size(472, 336)
        Me.grpRatings.TabIndex = 15
        Me.grpRatings.TabStop = False
        Me.grpRatings.Text = "Ratings"
        '
        'dgRatings
        '
        Me.dgRatings.DataMember = ""
        Me.dgRatings.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgRatings.Location = New System.Drawing.Point(16, 16)
        Me.dgRatings.Name = "dgRatings"
        Me.dgRatings.Size = New System.Drawing.Size(448, 312)
        Me.dgRatings.TabIndex = 11
        '
        'grpPlayerName
        '
        Me.grpPlayerName.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblPlayerName})
        Me.grpPlayerName.Location = New System.Drawing.Point(96, 8)
        Me.grpPlayerName.Name = "grpPlayerName"
        Me.grpPlayerName.Size = New System.Drawing.Size(472, 32)
        Me.grpPlayerName.TabIndex = 16
        Me.grpPlayerName.TabStop = False
        '
        'lblPlayerName
        '
        Me.lblPlayerName.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlayerName.Location = New System.Drawing.Point(8, 8)
        Me.lblPlayerName.Name = "lblPlayerName"
        Me.lblPlayerName.Size = New System.Drawing.Size(456, 16)
        Me.lblPlayerName.TabIndex = 0
        Me.lblPlayerName.Text = "Player Name"
        Me.lblPlayerName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnPrev
        '
        Me.btnPrev.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnPrev.Location = New System.Drawing.Point(96, 400)
        Me.btnPrev.Name = "btnPrev"
        Me.btnPrev.Size = New System.Drawing.Size(112, 24)
        Me.btnPrev.TabIndex = 17
        Me.btnPrev.Text = "&Previous"
        '
        'btnNext
        '
        Me.btnNext.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnNext.Location = New System.Drawing.Point(216, 400)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(112, 24)
        Me.btnNext.TabIndex = 18
        Me.btnNext.Text = "&Next"
        '
        'grpGeneral
        '
        Me.grpGeneral.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label8, Me.txtJersey, Me.btnSave, Me.Label7, Me.txtCollege, Me.Label6, Me.txtHighSchool, Me.Label5, Me.txtHometown, Me.Label4, Me.txtAge, Me.lblPosition, Me.Label3, Me.Label2, Me.txtFirstName, Me.Label1, Me.txtLastName})
        Me.grpGeneral.Location = New System.Drawing.Point(96, 48)
        Me.grpGeneral.Name = "grpGeneral"
        Me.grpGeneral.Size = New System.Drawing.Size(472, 336)
        Me.grpGeneral.TabIndex = 19
        Me.grpGeneral.TabStop = False
        Me.grpGeneral.Text = "General"
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(8, 192)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(96, 16)
        Me.Label8.TabIndex = 23
        Me.Label8.Text = "Jersey #:"
        '
        'txtJersey
        '
        Me.txtJersey.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtJersey.Location = New System.Drawing.Point(112, 192)
        Me.txtJersey.MaxLength = 2
        Me.txtJersey.Name = "txtJersey"
        Me.txtJersey.Size = New System.Drawing.Size(32, 20)
        Me.txtJersey.TabIndex = 22
        Me.txtJersey.Text = ""
        '
        'btnSave
        '
        Me.btnSave.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnSave.Location = New System.Drawing.Point(352, 304)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(112, 24)
        Me.btnSave.TabIndex = 21
        Me.btnSave.Text = "&Save"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(8, 168)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(96, 16)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "College:"
        '
        'txtCollege
        '
        Me.txtCollege.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCollege.Location = New System.Drawing.Point(112, 168)
        Me.txtCollege.MaxLength = 50
        Me.txtCollege.Name = "txtCollege"
        Me.txtCollege.Size = New System.Drawing.Size(336, 20)
        Me.txtCollege.TabIndex = 15
        Me.txtCollege.Text = ""
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(8, 144)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(96, 16)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "High School:"
        '
        'txtHighSchool
        '
        Me.txtHighSchool.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHighSchool.Location = New System.Drawing.Point(112, 144)
        Me.txtHighSchool.MaxLength = 50
        Me.txtHighSchool.Name = "txtHighSchool"
        Me.txtHighSchool.Size = New System.Drawing.Size(336, 20)
        Me.txtHighSchool.TabIndex = 13
        Me.txtHighSchool.Text = ""
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(8, 120)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(96, 16)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Home town:"
        '
        'txtHometown
        '
        Me.txtHometown.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHometown.Location = New System.Drawing.Point(112, 120)
        Me.txtHometown.MaxLength = 50
        Me.txtHometown.Name = "txtHometown"
        Me.txtHometown.Size = New System.Drawing.Size(336, 20)
        Me.txtHometown.TabIndex = 11
        Me.txtHometown.Text = ""
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(8, 88)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(96, 16)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Age:"
        '
        'txtAge
        '
        Me.txtAge.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAge.Location = New System.Drawing.Point(112, 88)
        Me.txtAge.MaxLength = 2
        Me.txtAge.Name = "txtAge"
        Me.txtAge.Size = New System.Drawing.Size(32, 20)
        Me.txtAge.TabIndex = 9
        Me.txtAge.Text = ""
        '
        'lblPosition
        '
        Me.lblPosition.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPosition.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPosition.Location = New System.Drawing.Point(112, 64)
        Me.lblPosition.Name = "lblPosition"
        Me.lblPosition.Size = New System.Drawing.Size(32, 16)
        Me.lblPosition.TabIndex = 8
        Me.lblPosition.Text = "PO"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(96, 16)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Position:"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(8, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 16)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "First name:"
        '
        'txtFirstName
        '
        Me.txtFirstName.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFirstName.Location = New System.Drawing.Point(112, 40)
        Me.txtFirstName.MaxLength = 50
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(336, 20)
        Me.txtFirstName.TabIndex = 4
        Me.txtFirstName.Text = ""
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(96, 16)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Last name:"
        '
        'txtLastName
        '
        Me.txtLastName.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLastName.Location = New System.Drawing.Point(112, 16)
        Me.txtLastName.MaxLength = 50
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(336, 20)
        Me.txtLastName.TabIndex = 2
        Me.txtLastName.Text = ""
        '
        'grpStatistics
        '
        Me.grpStatistics.Controls.AddRange(New System.Windows.Forms.Control() {Me.dgResults})
        Me.grpStatistics.Location = New System.Drawing.Point(96, 48)
        Me.grpStatistics.Name = "grpStatistics"
        Me.grpStatistics.Size = New System.Drawing.Size(472, 336)
        Me.grpStatistics.TabIndex = 20
        Me.grpStatistics.TabStop = False
        Me.grpStatistics.Text = "Statistics"
        '
        'dgResults
        '
        Me.dgResults.DataMember = ""
        Me.dgResults.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgResults.Location = New System.Drawing.Point(8, 16)
        Me.dgResults.Name = "dgResults"
        Me.dgResults.Size = New System.Drawing.Size(456, 312)
        Me.dgResults.TabIndex = 1
        '
        'grpHighlights
        '
        Me.grpHighlights.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.grpHighlights.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtHighlights})
        Me.grpHighlights.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpHighlights.Location = New System.Drawing.Point(96, 48)
        Me.grpHighlights.Name = "grpHighlights"
        Me.grpHighlights.Size = New System.Drawing.Size(472, 336)
        Me.grpHighlights.TabIndex = 21
        Me.grpHighlights.TabStop = False
        Me.grpHighlights.Text = "Highlights"
        '
        'txtHighlights
        '
        Me.txtHighlights.Location = New System.Drawing.Point(8, 16)
        Me.txtHighlights.Multiline = True
        Me.txtHighlights.Name = "txtHighlights"
        Me.txtHighlights.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtHighlights.Size = New System.Drawing.Size(456, 312)
        Me.txtHighlights.TabIndex = 0
        Me.txtHighlights.Text = ""
        '
        'frmPlayerCard
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(582, 427)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.grpHighlights, Me.btnNext, Me.btnPrev, Me.grpPlayerName, Me.lstOptions, Me.btnOK, Me.grpRatings, Me.grpStatistics, Me.grpGeneral})
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "frmPlayerCard"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Player Card"
        Me.grpRatings.ResumeLayout(False)
        CType(Me.dgRatings, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpPlayerName.ResumeLayout(False)
        Me.grpGeneral.ResumeLayout(False)
        Me.grpStatistics.ResumeLayout(False)
        CType(Me.dgResults, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpHighlights.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		Me.Close()
	End Sub

#Region "CustomSetup"

	Private Sub SetScreen()
		Call InitializeDefaults()
		Call App.SkinForm(Me)
		Call SetPlayerArray()

	End Sub

	Private Sub SetPlayerArray()

		Dim i As Integer
		Dim pblnShowNav As Boolean = True

		For i = 0 To marrPlayerArray.Count - 1
			If marrPlayerArray.Item(i) = mintPlayerID Then
				mintArrayPos = i
			End If
		Next

		If marrPlayerArray.Count = 1 Then
			pblnShowNav = False
		End If

		Me.btnNext.Visible = pblnShowNav
		Me.btnPrev.Visible = pblnShowNav

	End Sub

	Private Sub InitializeDefaults()
		mblnLoading = True
		Me.lstOptions.SelectedIndex = 0
		Me.btnSave.Enabled = False
		mblnSaved = True
		mblnLoading = False
	End Sub

	Private Sub LoadPlayer()

		Call LoadRatings()
        Call LoadGeneralInfo()
        Call LoadHighlights()
		mblnDirty = False
		Me.btnSave.Enabled = False

	End Sub

	Private Sub LoadRatings()
		If Not mblnLoading Then
			SetCursor(True, Me)
			Dim dg As DataGrid = Me.dgRatings

			Dim pobjDataSet As New DataSet()
			pobjDataSet = GetGridToShow()

			Dim pobjView As New DataViewUtility()
			pobjView.Standardize(pobjDataSet)
			With dg
				.DataSource = pobjView
				.CaptionText = "Player Ratings"
			End With


			SetCursor(False, Me)
		End If
	End Sub

	Private Sub LoadGeneralInfo()
		Dim pobjPlayer As New Player()
		Dim pobjPos As New Position()

		pobjPlayer.Load(mintPlayerID)

		With pobjPlayer
			Me.txtAge.Text = .Age
			Me.txtFirstName.Text = .FirstName
			Me.txtLastName.Text = .LastName
			Me.lblPosition.Text = pobjPos.GetAbbr(.Position)
			Me.lblPlayerName.Text = .LastName & ", " & .FirstName & " [" & Me.lblPosition.Text & "]"
			Me.txtHighSchool.Text = .HighSchool
			Me.txtHometown.Text = .Hometown
			Me.txtCollege.Text = .College
			Me.txtJersey.Text = .Jersey
		End With

	End Sub



#End Region



	Private Function GetGridToShow() As DataSet
		Dim pobjDS As New DataServices.PlayerTables()
		Dim pobjHelper As New DataGridUtility(Me.dgRatings, "Player Ratings")
		Dim pobjDataSet As New DataSet()
		pobjDataSet = pobjDS.GetPlayerCardRatings(mintPlayerID)
		pobjHelper.SetPlayerCardRatingGrid()
		pobjHelper.Commit()
		Return pobjDataSet
	End Function


	Private Sub btnPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrev.Click
		Call NavigatePlayer(-1)
	End Sub

	Private Sub NavigatePlayer(ByVal intAmount As Integer)
		If mblnDirty Then
			If Not mblnSaved Then
				Dim Response As MsgBoxResult = MsgBox("Do you wish to save your changes?", MsgBoxStyle.YesNoCancel, "Save player?")
				If Response = MsgBoxResult.Cancel Then
					Exit Sub
				ElseIf Response = MsgBoxResult.Yes Then
					Call Save()
				End If
			End If
		End If

		If intAmount = -1 Then
			If mintArrayPos <> 0 Then
				mintArrayPos = mintArrayPos + intAmount
			End If
		End If

		If intAmount = 1 Then
			If mintArrayPos <> marrPlayerArray.Count - 1 Then
				mintArrayPos = mintArrayPos + intAmount
			End If
		End If

		mintPlayerID = marrPlayerArray(mintArrayPos)
		Call LoadPlayer()
		If mintArrayPos = 0 Then
			Me.btnPrev.Enabled = False
		Else
			Me.btnPrev.Enabled = True
		End If

		If mintArrayPos = marrPlayerArray.Count - 1 Then
			Me.btnNext.Enabled = False
		Else
			Me.btnNext.Enabled = True
		End If

	End Sub

	Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
		Call NavigatePlayer(1)
	End Sub

	Private Sub lstOptions_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstOptions.SelectedIndexChanged
		Select Case Me.lstOptions.SelectedItem
			Case "General"
				Me.grpGeneral.BringToFront()
				Call LoadGeneralInfo()

			Case "Ratings"
				Me.grpRatings.BringToFront()
                Call LoadRatings()

            Case "Statistics"
                Me.grpStatistics.BringToFront()
                Call LoadStats()
            Case "Highlights"
                Me.grpHighlights.BringToFront()
                Call LoadHighlights()
        End Select
    End Sub

    Private Sub LoadHighlights()
        Dim pe As New PlayerEventSet()
        pe.Load(mintPlayerID)
        Me.txtHighlights.Text = pe.GetHighlight()

    End Sub

    Private Sub DirtyForm(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtAge.TextChanged, txtCollege.TextChanged, txtFirstName.TextChanged, txtHighSchool.TextChanged, txtHometown.TextChanged, txtLastName.TextChanged, txtJersey.TextChanged
        If Not mblnLoading Then
            mblnDirty = True
            Me.btnSave.Enabled = True
            mblnSaved = False
        End If
    End Sub

    Private Sub Save()
        If Not mblnSaved Then
            If mblnDirty Then
                Dim pobjPlayer As New Player()
                With pobjPlayer
                    .Load(mintPlayerID)
                    .Age = Me.txtAge.Text
                    .College = Me.txtCollege.Text
                    .FirstName = Me.txtFirstName.Text
                    .LastName = Me.txtLastName.Text
                    .HighSchool = Me.txtHighSchool.Text
                    .Hometown = Me.txtHometown.Text
                    .Jersey = Me.txtJersey.Text
                    .Update()
                End With
                mblnDirty = False

            End If
        End If
    End Sub

    Private Sub LoadStats()

    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Call Save()
    End Sub
End Class
