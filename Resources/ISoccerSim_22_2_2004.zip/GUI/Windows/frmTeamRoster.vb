
'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.Positions
Imports ISoccerSim.Teams

Public Class frmTeamRoster
	Inherits System.Windows.Forms.Form

	Private mblnLoading As Boolean
	Private mintPlayerID As Integer

#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		Call SetScreen()


	End Sub

	Friend Sub SetScreen(ByVal objTeam As Team)
		Call SetScreen()
		SetTeamInCombo(objTeam)
		Me.cmbTeams.Enabled = False

	End Sub

	Friend Sub SetScreen(ByVal objTeam As Team, ByVal intSquad As ISMPlayerPosition)
        Call SetScreen(objTeam)
        Me.PlayerPicker.PositionID = intSquad
        Me.PlayerPicker.TeamID = objTeam.TeamID
        Me.cmbTeams.Enabled = False
    End Sub

    Private Sub SetTeamInCombo(ByVal objTeam As Team)
        Dim pobjX As Team
        For Each pobjX In Me.cmbTeams.Items
            If pobjX.TeamID = objTeam.TeamID Then
                Me.cmbTeams.SelectedItem = pobjX
            End If
        Next

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents grpFinish As System.Windows.Forms.GroupBox
    Friend WithEvents tipLeague As System.Windows.Forms.ToolTip
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cmbTeams As System.Windows.Forms.ComboBox
    Friend WithEvents popRoster As System.Windows.Forms.ContextMenu
    Friend WithEvents mnuGridShowDetails As System.Windows.Forms.MenuItem
    Friend WithEvents mnuGridDrop As System.Windows.Forms.MenuItem
    Friend WithEvents PlayerPicker As ISoccerSim.PlayerPicker
    Friend WithEvents lblPosition As System.Windows.Forms.Label
    Friend WithEvents cmbPosition As System.Windows.Forms.ComboBox
    Friend WithEvents cmbRatingType As System.Windows.Forms.ComboBox
    Friend WithEvents lblType As System.Windows.Forms.Label
    Friend WithEvents btnSignFA As System.Windows.Forms.Button
    Friend WithEvents btnProposeTrade As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.grpFinish = New System.Windows.Forms.GroupBox()
        Me.cmbRatingType = New System.Windows.Forms.ComboBox()
        Me.lblType = New System.Windows.Forms.Label()
        Me.cmbPosition = New System.Windows.Forms.ComboBox()
        Me.lblPosition = New System.Windows.Forms.Label()
        Me.PlayerPicker = New ISoccerSim.PlayerPicker()
        Me.cmbTeams = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tipLeague = New System.Windows.Forms.ToolTip(Me.components)
        Me.popRoster = New System.Windows.Forms.ContextMenu()
        Me.mnuGridShowDetails = New System.Windows.Forms.MenuItem()
        Me.mnuGridDrop = New System.Windows.Forms.MenuItem()
        Me.btnSignFA = New System.Windows.Forms.Button()
        Me.btnProposeTrade = New System.Windows.Forms.Button()
        Me.grpFinish.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnOK
        '
        Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnOK.Location = New System.Drawing.Point(616, 408)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(112, 24)
        Me.btnOK.TabIndex = 4
        Me.btnOK.Text = "&OK"
        '
        'grpFinish
        '
        Me.grpFinish.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.grpFinish.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmbRatingType, Me.lblType, Me.cmbPosition, Me.lblPosition, Me.PlayerPicker, Me.cmbTeams, Me.Label3})
        Me.grpFinish.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpFinish.Location = New System.Drawing.Point(16, 32)
        Me.grpFinish.Name = "grpFinish"
        Me.grpFinish.Size = New System.Drawing.Size(710, 368)
        Me.grpFinish.TabIndex = 11
        Me.grpFinish.TabStop = False
        Me.grpFinish.Text = "Player"
        '
        'cmbRatingType
        '
        Me.cmbRatingType.Items.AddRange(New Object() {"General", "Actuals", "Potentials"})
        Me.cmbRatingType.Location = New System.Drawing.Point(96, 72)
        Me.cmbRatingType.Name = "cmbRatingType"
        Me.cmbRatingType.Size = New System.Drawing.Size(80, 22)
        Me.cmbRatingType.TabIndex = 22
        '
        'lblType
        '
        Me.lblType.Location = New System.Drawing.Point(16, 72)
        Me.lblType.Name = "lblType"
        Me.lblType.Size = New System.Drawing.Size(64, 24)
        Me.lblType.TabIndex = 21
        Me.lblType.Text = "Information:"
        '
        'cmbPosition
        '
        Me.cmbPosition.Items.AddRange(New Object() {"All", "GK", "DEF", "FW", "MF"})
        Me.cmbPosition.Location = New System.Drawing.Point(96, 48)
        Me.cmbPosition.Name = "cmbPosition"
        Me.cmbPosition.Size = New System.Drawing.Size(80, 22)
        Me.cmbPosition.TabIndex = 20
        '
        'lblPosition
        '
        Me.lblPosition.Location = New System.Drawing.Point(16, 48)
        Me.lblPosition.Name = "lblPosition"
        Me.lblPosition.Size = New System.Drawing.Size(64, 24)
        Me.lblPosition.TabIndex = 19
        Me.lblPosition.Text = "Position:"
        '
        'PlayerPicker
        '
        Me.PlayerPicker.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PlayerPicker.Location = New System.Drawing.Point(8, 104)
        Me.PlayerPicker.Name = "PlayerPicker"
        Me.PlayerPicker.Size = New System.Drawing.Size(696, 256)
        Me.PlayerPicker.TabIndex = 14
        '
        'cmbTeams
        '
        Me.cmbTeams.Location = New System.Drawing.Point(96, 16)
        Me.cmbTeams.Name = "cmbTeams"
        Me.cmbTeams.Size = New System.Drawing.Size(280, 22)
        Me.cmbTeams.TabIndex = 13
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 24)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Team:"
        '
        'popRoster
        '
        Me.popRoster.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuGridShowDetails, Me.mnuGridDrop})
        '
        'mnuGridShowDetails
        '
        Me.mnuGridShowDetails.DefaultItem = True
        Me.mnuGridShowDetails.Index = 0
        Me.mnuGridShowDetails.Text = "Show Details"
        '
        'mnuGridDrop
        '
        Me.mnuGridDrop.Index = 1
        Me.mnuGridDrop.Text = "Drop"
        '
        'btnSignFA
        '
        Me.btnSignFA.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnSignFA.Location = New System.Drawing.Point(24, 408)
        Me.btnSignFA.Name = "btnSignFA"
        Me.btnSignFA.Size = New System.Drawing.Size(112, 24)
        Me.btnSignFA.TabIndex = 12
        Me.btnSignFA.Text = "Sign &Free Agent"
        '
        'btnProposeTrade
        '
        Me.btnProposeTrade.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnProposeTrade.Location = New System.Drawing.Point(144, 408)
        Me.btnProposeTrade.Name = "btnProposeTrade"
        Me.btnProposeTrade.Size = New System.Drawing.Size(112, 24)
        Me.btnProposeTrade.TabIndex = 13
        Me.btnProposeTrade.Text = "Propose &Trade"
        '
        'frmTeamRoster
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(742, 443)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnProposeTrade, Me.btnSignFA, Me.btnOK, Me.grpFinish})
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "frmTeamRoster"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Team Roster"
        Me.grpFinish.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		Me.Close()
	End Sub

#Region "CustomSetup"

	Private Sub SetScreen()
		Call InitializeDefaults()
        Call App.SkinForm(Me)
        Me.PlayerPicker.Mode = PlayerPicker.ISM_GridMode.Roster
        Call Me.PlayerPicker.SetScreen()
        Call Me.PlayerPicker.LoadRoster()

	End Sub

	Private Sub InitializeDefaults()
		mblnLoading = True

		Dim pobjComboHelper As New DropDownUtility()
		With pobjComboHelper
			.DisplayMember = "City"
			.ValueMember = "City"
			.DataSource = gobjLeague
			.Style = ComboBoxStyle.DropDownList			 'DropDown
			.Sorted = True
			.Fill(Me.cmbTeams)
		End With

        Me.PlayerPicker.PositionID = 0
        Me.PlayerPicker.RosterView = 0
        Me.cmbPosition.SelectedIndex = 0
        Me.cmbRatingType.SelectedIndex = 0

        mblnLoading = False
        Call SetSignFAButton()
        Call LoadRoster()
    End Sub

    Private Sub SetSignFAButton()
        Dim r As New Rosters.Roster()
        r.Load(GetTeamID(Me.cmbTeams))
        Me.btnSignFA.Enabled = r.IsLegalToAdd()
    End Sub

    Private Sub LoadRoster()
        If Not mblnLoading Then
            SetCursor(True, Me)
            Me.PlayerPicker.TeamID = GetTeamID(Me.cmbTeams)
            Me.PlayerPicker.LoadRoster()
            Me.SetSignFAButton()
            SetCursor(False, Me)
        End If
    End Sub



#End Region


    Private Sub ReloadRosters(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbTeams.SelectedIndexChanged
        Call Me.LoadRoster()
    End Sub



    Private Sub cmbRatingType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbRatingType.SelectedIndexChanged
        Me.PlayerPicker.RosterView = Me.cmbRatingType.SelectedIndex
        Call Me.PlayerPicker.LoadRoster()
    End Sub

    Private Sub cmbPosition_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbPosition.SelectedIndexChanged
        Me.PlayerPicker.PositionID = Me.PlayerPicker.GetPositionToShow(Me.cmbPosition.Text)
        Call Me.PlayerPicker.LoadRoster()
    End Sub



    Private Sub btnSignFA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSignFA.Click
        Dim f As New frmSignFA()
        f.SetScreen(GetTeamID(Me.cmbTeams), Me.cmbPosition.SelectedIndex)
        f.ShowDialog(Me)
        Me.LoadRoster()
    End Sub


    Private Sub PlayerPicker_PlayerDropped(ByVal sender As Object, ByVal e As System.EventArgs) Handles PlayerPicker.PlayerDropped
        Me.SetSignFAButton()
    End Sub
End Class
