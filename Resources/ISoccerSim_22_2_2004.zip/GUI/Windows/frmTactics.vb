'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Imports ISoccerSim.Tactical

Public Class frmTactics
	Inherits System.Windows.Forms.Form

	Private mblnLoading As Boolean
	Private mblnDirty As Boolean = False
	Private mintLastIndex As Integer
	Private mintPlayerID As Integer

#Region " Windows Form Designer generated code "

	Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		Call SetScreen()


	End Sub


	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Friend WithEvents grpFinish As System.Windows.Forms.GroupBox
	Friend WithEvents tipLeague As System.Windows.Forms.ToolTip
	Friend WithEvents btnOK As System.Windows.Forms.Button
	Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
	Friend WithEvents iscrZoneToMan As ISoccerSim.ISMScrollBar
	Friend WithEvents Label11 As System.Windows.Forms.Label
	Friend WithEvents iscrPosture As ISoccerSim.ISMScrollBar
	Friend WithEvents Label9 As System.Windows.Forms.Label
	Friend WithEvents iscrParamShooting As ISoccerSim.ISMScrollBar
	Friend WithEvents Label6 As System.Windows.Forms.Label
	Friend WithEvents iscrRegroup As ISoccerSim.ISMScrollBar
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents iscrLongBall As ISoccerSim.ISMScrollBar
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents iscrCreasePlay As ISoccerSim.ISMScrollBar
	Friend WithEvents Label10 As System.Windows.Forms.Label
	Friend WithEvents iscrDefEngagement As ISoccerSim.ISMScrollBar
	Friend WithEvents Label8 As System.Windows.Forms.Label
	Friend WithEvents iscrGoalieRoving As ISoccerSim.ISMScrollBar
	Friend WithEvents Label7 As System.Windows.Forms.Label
	Friend WithEvents iscrCrossPassing As ISoccerSim.ISMScrollBar
	Friend WithEvents Label5 As System.Windows.Forms.Label
	Friend WithEvents iscrForwardPassing As ISoccerSim.ISMScrollBar
	Friend WithEvents lblFwd As System.Windows.Forms.Label
	Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents txtName As System.Windows.Forms.TextBox
	Friend WithEvents lstTactics As System.Windows.Forms.ListBox
	Friend WithEvents Label12 As System.Windows.Forms.Label
	Friend WithEvents txtDescription As System.Windows.Forms.TextBox
	Friend WithEvents txtAbbr As System.Windows.Forms.TextBox
	Friend WithEvents Label13 As System.Windows.Forms.Label
	Friend WithEvents lblExplanation As System.Windows.Forms.Label
	Friend WithEvents btnSave As System.Windows.Forms.Button
	Friend WithEvents btnNewTactic As System.Windows.Forms.Button
	Friend WithEvents hlpProvider As System.Windows.Forms.HelpProvider
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Me.btnOK = New System.Windows.Forms.Button()
		Me.grpFinish = New System.Windows.Forms.GroupBox()
		Me.btnNewTactic = New System.Windows.Forms.Button()
		Me.GroupBox2 = New System.Windows.Forms.GroupBox()
		Me.Label12 = New System.Windows.Forms.Label()
		Me.txtDescription = New System.Windows.Forms.TextBox()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.txtAbbr = New System.Windows.Forms.TextBox()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.txtName = New System.Windows.Forms.TextBox()
		Me.GroupBox1 = New System.Windows.Forms.GroupBox()
		Me.lblExplanation = New System.Windows.Forms.Label()
		Me.Label13 = New System.Windows.Forms.Label()
		Me.iscrZoneToMan = New ISoccerSim.ISMScrollBar()
		Me.Label11 = New System.Windows.Forms.Label()
		Me.iscrPosture = New ISoccerSim.ISMScrollBar()
		Me.Label9 = New System.Windows.Forms.Label()
		Me.iscrParamShooting = New ISoccerSim.ISMScrollBar()
		Me.Label6 = New System.Windows.Forms.Label()
		Me.iscrRegroup = New ISoccerSim.ISMScrollBar()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.iscrLongBall = New ISoccerSim.ISMScrollBar()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.iscrCreasePlay = New ISoccerSim.ISMScrollBar()
		Me.Label10 = New System.Windows.Forms.Label()
		Me.iscrDefEngagement = New ISoccerSim.ISMScrollBar()
		Me.Label8 = New System.Windows.Forms.Label()
		Me.iscrGoalieRoving = New ISoccerSim.ISMScrollBar()
		Me.Label7 = New System.Windows.Forms.Label()
		Me.iscrCrossPassing = New ISoccerSim.ISMScrollBar()
		Me.Label5 = New System.Windows.Forms.Label()
		Me.iscrForwardPassing = New ISoccerSim.ISMScrollBar()
		Me.lblFwd = New System.Windows.Forms.Label()
		Me.lstTactics = New System.Windows.Forms.ListBox()
		Me.tipLeague = New System.Windows.Forms.ToolTip(Me.components)
		Me.btnSave = New System.Windows.Forms.Button()
		Me.hlpProvider = New System.Windows.Forms.HelpProvider()
		Me.grpFinish.SuspendLayout()
		Me.GroupBox2.SuspendLayout()
		Me.GroupBox1.SuspendLayout()
		Me.SuspendLayout()
		'
		'btnOK
		'
		Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnOK.Location = New System.Drawing.Point(536, 464)
		Me.btnOK.Name = "btnOK"
		Me.btnOK.Size = New System.Drawing.Size(112, 24)
		Me.btnOK.TabIndex = 4
		Me.btnOK.Text = "&OK"
		'
		'grpFinish
		'
		Me.grpFinish.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnNewTactic, Me.GroupBox2, Me.GroupBox1, Me.lstTactics})
		Me.grpFinish.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.grpFinish.Location = New System.Drawing.Point(8, 8)
		Me.grpFinish.Name = "grpFinish"
		Me.grpFinish.Size = New System.Drawing.Size(638, 448)
		Me.grpFinish.TabIndex = 11
		Me.grpFinish.TabStop = False
		Me.grpFinish.Text = "Tactics"
		'
		'btnNewTactic
		'
		Me.btnNewTactic.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnNewTactic.Location = New System.Drawing.Point(16, 416)
		Me.btnNewTactic.Name = "btnNewTactic"
		Me.btnNewTactic.Size = New System.Drawing.Size(96, 24)
		Me.btnNewTactic.TabIndex = 15
		Me.btnNewTactic.TabStop = False
		Me.btnNewTactic.Text = "&New Tactic"
		'
		'GroupBox2
		'
		Me.GroupBox2.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label12, Me.txtDescription, Me.Label2, Me.txtAbbr, Me.Label1, Me.txtName})
		Me.GroupBox2.Location = New System.Drawing.Point(120, 16)
		Me.GroupBox2.Name = "GroupBox2"
		Me.GroupBox2.Size = New System.Drawing.Size(504, 112)
		Me.GroupBox2.TabIndex = 0
		Me.GroupBox2.TabStop = False
		Me.GroupBox2.Text = "General"
		'
		'Label12
		'
		Me.Label12.Location = New System.Drawing.Point(8, 64)
		Me.Label12.Name = "Label12"
		Me.Label12.Size = New System.Drawing.Size(72, 16)
		Me.Label12.TabIndex = 24
		Me.Label12.Text = "Description:"
		'
		'txtDescription
		'
		Me.hlpProvider.SetHelpNavigator(Me.txtDescription, System.Windows.Forms.HelpNavigator.Topic)
		Me.txtDescription.Location = New System.Drawing.Point(96, 64)
		Me.txtDescription.MaxLength = 255
		Me.txtDescription.Multiline = True
		Me.txtDescription.Name = "txtDescription"
		Me.hlpProvider.SetShowHelp(Me.txtDescription, True)
		Me.txtDescription.Size = New System.Drawing.Size(392, 40)
		Me.txtDescription.TabIndex = 2
		Me.txtDescription.Text = ""
		'
		'Label2
		'
		Me.Label2.Location = New System.Drawing.Point(8, 40)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(72, 16)
		Me.Label2.TabIndex = 22
		Me.Label2.Text = "Abbreviation:"
		'
		'txtAbbr
		'
		Me.txtAbbr.Location = New System.Drawing.Point(96, 40)
		Me.txtAbbr.MaxLength = 10
		Me.txtAbbr.Name = "txtAbbr"
		Me.txtAbbr.Size = New System.Drawing.Size(56, 20)
		Me.txtAbbr.TabIndex = 1
		Me.txtAbbr.Text = ""
		'
		'Label1
		'
		Me.Label1.Location = New System.Drawing.Point(8, 16)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(40, 16)
		Me.Label1.TabIndex = 20
		Me.Label1.Text = "Name:"
		'
		'txtName
		'
		Me.txtName.Location = New System.Drawing.Point(96, 16)
		Me.txtName.MaxLength = 50
		Me.txtName.Name = "txtName"
		Me.txtName.Size = New System.Drawing.Size(336, 20)
		Me.txtName.TabIndex = 0
		Me.txtName.Text = ""
		'
		'GroupBox1
		'
		Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblExplanation, Me.Label13, Me.iscrZoneToMan, Me.Label11, Me.iscrPosture, Me.Label9, Me.iscrParamShooting, Me.Label6, Me.iscrRegroup, Me.Label4, Me.iscrLongBall, Me.Label3, Me.iscrCreasePlay, Me.Label10, Me.iscrDefEngagement, Me.Label8, Me.iscrGoalieRoving, Me.Label7, Me.iscrCrossPassing, Me.Label5, Me.iscrForwardPassing, Me.lblFwd})
		Me.GroupBox1.Location = New System.Drawing.Point(120, 136)
		Me.GroupBox1.Name = "GroupBox1"
		Me.GroupBox1.Size = New System.Drawing.Size(504, 304)
		Me.GroupBox1.TabIndex = 1
		Me.GroupBox1.TabStop = False
		Me.GroupBox1.Text = "Tendencies"
		'
		'lblExplanation
		'
		Me.lblExplanation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblExplanation.Location = New System.Drawing.Point(112, 256)
		Me.lblExplanation.Name = "lblExplanation"
		Me.lblExplanation.Size = New System.Drawing.Size(376, 40)
		Me.lblExplanation.TabIndex = 71
		'
		'Label13
		'
		Me.Label13.Location = New System.Drawing.Point(8, 256)
		Me.Label13.Name = "Label13"
		Me.Label13.Size = New System.Drawing.Size(120, 16)
		Me.Label13.TabIndex = 70
		Me.Label13.Text = "Explanation:"
		'
		'iscrZoneToMan
		'
		Me.iscrZoneToMan.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.iscrZoneToMan.Location = New System.Drawing.Point(104, 232)
		Me.iscrZoneToMan.Name = "iscrZoneToMan"
		Me.iscrZoneToMan.Size = New System.Drawing.Size(392, 24)
		Me.iscrZoneToMan.TabIndex = 10
		Me.iscrZoneToMan.Tag = "Tendency to play tight man coverage (100) to loose zone (0)."
		Me.tipLeague.SetToolTip(Me.iscrZoneToMan, "Tendency to play tight man coverage (100) to loose zone (0).")
		'
		'Label11
		'
		Me.Label11.Location = New System.Drawing.Point(8, 232)
		Me.Label11.Name = "Label11"
		Me.Label11.Size = New System.Drawing.Size(80, 16)
		Me.Label11.TabIndex = 69
		Me.Label11.Text = "Zone to Man Tendency:"
		'
		'iscrPosture
		'
		Me.iscrPosture.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.iscrPosture.Location = New System.Drawing.Point(104, 184)
		Me.iscrPosture.Name = "iscrPosture"
		Me.iscrPosture.Size = New System.Drawing.Size(392, 24)
		Me.iscrPosture.TabIndex = 7
		Me.iscrPosture.Tag = "Tendency to focus on attacking (100) versus defending (0)."
		Me.tipLeague.SetToolTip(Me.iscrPosture, "Tendency to focus on attacking (100) versus defending (0).")
		'
		'Label9
		'
		Me.Label9.Location = New System.Drawing.Point(8, 184)
		Me.Label9.Name = "Label9"
		Me.Label9.Size = New System.Drawing.Size(88, 16)
		Me.Label9.TabIndex = 67
		Me.Label9.Text = "Posture:"
		'
		'iscrParamShooting
		'
		Me.iscrParamShooting.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.iscrParamShooting.Location = New System.Drawing.Point(104, 160)
		Me.iscrParamShooting.Name = "iscrParamShooting"
		Me.iscrParamShooting.Size = New System.Drawing.Size(392, 24)
		Me.iscrParamShooting.TabIndex = 6
		Me.iscrParamShooting.Tag = "Tendency for taking shots closer to goal (100) versus red line (0)."
		Me.tipLeague.SetToolTip(Me.iscrParamShooting, "Tendency for taking shots closer to goal (100) versus red line (0).")
		'
		'Label6
		'
		Me.Label6.Location = New System.Drawing.Point(8, 160)
		Me.Label6.Name = "Label6"
		Me.Label6.Size = New System.Drawing.Size(112, 16)
		Me.Label6.TabIndex = 65
		Me.Label6.Text = "Parameter Shooting:"
		'
		'iscrRegroup
		'
		Me.iscrRegroup.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.iscrRegroup.Location = New System.Drawing.Point(104, 208)
		Me.iscrRegroup.Name = "iscrRegroup"
		Me.iscrRegroup.Size = New System.Drawing.Size(392, 24)
		Me.iscrRegroup.TabIndex = 8
		Me.iscrRegroup.Tag = "Tendency for offense to force a shot (100) versus passing back to center field (0" & _
		")."
		Me.tipLeague.SetToolTip(Me.iscrRegroup, "Tendency for offense to force a shot (100) versus passing back to center field (0" & _
		").")
		'
		'Label4
		'
		Me.Label4.Location = New System.Drawing.Point(8, 208)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(96, 16)
		Me.Label4.TabIndex = 63
		Me.Label4.Text = "Regroup:"
		'
		'iscrLongBall
		'
		Me.iscrLongBall.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.iscrLongBall.Location = New System.Drawing.Point(104, 136)
		Me.iscrLongBall.Name = "iscrLongBall"
		Me.iscrLongBall.Size = New System.Drawing.Size(392, 24)
		Me.iscrLongBall.TabIndex = 5
		Me.iscrLongBall.Tag = "Tendency to throw long balls down field versus rolling out to immediate defenders" & _
		"."
		Me.tipLeague.SetToolTip(Me.iscrLongBall, "Tendency to throw long balls down field versus rolling out to immediate defenders" & _
		".")
		'
		'Label3
		'
		Me.Label3.Location = New System.Drawing.Point(8, 136)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(72, 16)
		Me.Label3.TabIndex = 61
		Me.Label3.Text = "Long ball:"
		'
		'iscrCreasePlay
		'
		Me.iscrCreasePlay.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.iscrCreasePlay.Location = New System.Drawing.Point(104, 16)
		Me.iscrCreasePlay.Name = "iscrCreasePlay"
		Me.iscrCreasePlay.Size = New System.Drawing.Size(392, 24)
		Me.iscrCreasePlay.TabIndex = 0
		Me.iscrCreasePlay.Tag = "Tendency for offense to force a shot (100) versus passing back to center field (0" & _
		")."
		Me.tipLeague.SetToolTip(Me.iscrCreasePlay, "Tendency for offense to force a shot (100) versus passing back to center field (0" & _
		").")
		'
		'Label10
		'
		Me.Label10.Location = New System.Drawing.Point(8, 16)
		Me.Label10.Name = "Label10"
		Me.Label10.Size = New System.Drawing.Size(120, 16)
		Me.Label10.TabIndex = 59
		Me.Label10.Text = "Crease Play:"
		'
		'iscrDefEngagement
		'
		Me.iscrDefEngagement.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.iscrDefEngagement.Location = New System.Drawing.Point(104, 64)
		Me.iscrDefEngagement.Name = "iscrDefEngagement"
		Me.iscrDefEngagement.Size = New System.Drawing.Size(392, 24)
		Me.iscrDefEngagement.TabIndex = 2
		Me.iscrDefEngagement.Tag = "Tendency to engage opposing team in their third (100) versus defensive third(0)."
		Me.tipLeague.SetToolTip(Me.iscrDefEngagement, "Tendency to engage opposing team in their third (100) versus defensive third(0).")
		'
		'Label8
		'
		Me.Label8.Location = New System.Drawing.Point(8, 64)
		Me.Label8.Name = "Label8"
		Me.Label8.Size = New System.Drawing.Size(120, 16)
		Me.Label8.TabIndex = 57
		Me.Label8.Text = "Def. Engagement:"
		'
		'iscrGoalieRoving
		'
		Me.iscrGoalieRoving.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.iscrGoalieRoving.Location = New System.Drawing.Point(104, 112)
		Me.iscrGoalieRoving.Name = "iscrGoalieRoving"
		Me.iscrGoalieRoving.Size = New System.Drawing.Size(392, 24)
		Me.iscrGoalieRoving.TabIndex = 4
		Me.iscrGoalieRoving.Tag = "Tendency for goalie to leave box and participate in offensive."
		Me.tipLeague.SetToolTip(Me.iscrGoalieRoving, "Tendency for goalie to leave box and participate in offensive.")
		'
		'Label7
		'
		Me.Label7.Location = New System.Drawing.Point(8, 112)
		Me.Label7.Name = "Label7"
		Me.Label7.Size = New System.Drawing.Size(88, 16)
		Me.Label7.TabIndex = 55
		Me.Label7.Text = "Goalie Roving:"
		'
		'iscrCrossPassing
		'
		Me.iscrCrossPassing.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.iscrCrossPassing.Location = New System.Drawing.Point(104, 40)
		Me.iscrCrossPassing.Name = "iscrCrossPassing"
		Me.iscrCrossPassing.Size = New System.Drawing.Size(392, 24)
		Me.iscrCrossPassing.TabIndex = 1
		Me.iscrCrossPassing.Tag = "Tendency to pass laterally across the field."
		Me.tipLeague.SetToolTip(Me.iscrCrossPassing, "Tendency to pass laterally across the field.")
		'
		'Label5
		'
		Me.Label5.Location = New System.Drawing.Point(8, 40)
		Me.Label5.Name = "Label5"
		Me.Label5.Size = New System.Drawing.Size(88, 16)
		Me.Label5.TabIndex = 53
		Me.Label5.Text = "Cross Passing:"
		'
		'iscrForwardPassing
		'
		Me.iscrForwardPassing.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.iscrForwardPassing.Location = New System.Drawing.Point(104, 88)
		Me.iscrForwardPassing.Name = "iscrForwardPassing"
		Me.iscrForwardPassing.Size = New System.Drawing.Size(392, 24)
		Me.iscrForwardPassing.TabIndex = 3
		Me.iscrForwardPassing.Tag = "Tendency to force forward passes (100) versus back passing (0)"
		Me.tipLeague.SetToolTip(Me.iscrForwardPassing, "Tendency to force forward passes (100) versus back passing (0)")
		'
		'lblFwd
		'
		Me.lblFwd.Location = New System.Drawing.Point(8, 88)
		Me.lblFwd.Name = "lblFwd"
		Me.lblFwd.Size = New System.Drawing.Size(96, 16)
		Me.lblFwd.TabIndex = 51
		Me.lblFwd.Text = "Forward Passing:"
		'
		'lstTactics
		'
		Me.lstTactics.ItemHeight = 14
		Me.lstTactics.Location = New System.Drawing.Point(16, 16)
		Me.lstTactics.Name = "lstTactics"
		Me.lstTactics.Size = New System.Drawing.Size(96, 396)
		Me.lstTactics.TabIndex = 14
		'
		'btnSave
		'
		Me.btnSave.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
		Me.btnSave.Location = New System.Drawing.Point(416, 464)
		Me.btnSave.Name = "btnSave"
		Me.btnSave.Size = New System.Drawing.Size(112, 24)
		Me.btnSave.TabIndex = 12
		Me.btnSave.Text = "&Save"
		'
		'hlpProvider
		'
		Me.hlpProvider.HelpNamespace = "..\help\league_tactics.html"
		'
		'frmTactics
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(654, 499)
		Me.ControlBox = False
		Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnSave, Me.btnOK, Me.grpFinish})
		Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
		Me.hlpProvider.SetHelpNavigator(Me, System.Windows.Forms.HelpNavigator.Topic)
		Me.Name = "frmTactics"
		Me.hlpProvider.SetShowHelp(Me, True)
		Me.ShowInTaskbar = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.grpFinish.ResumeLayout(False)
		Me.GroupBox2.ResumeLayout(False)
		Me.GroupBox1.ResumeLayout(False)
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		Me.Close()
	End Sub

#Region "CustomSetup"

	Private Sub SetScreen()
		Call InitializeDefaults()
		Call App.SkinForm(Me)

	End Sub

	Private Sub InitializeDefaults()
		Dim pobjItem As New Tactic()
		Me.lstTactics.Items.Clear()
		For Each pobjItem In gobjTacticSet
			Me.lstTactics.Items.Add(pobjItem)
		Next

		Call MakeAddItemEntry()
		Me.lstTactics.Sorted = True
		Me.lstTactics.SelectedIndex = 0
		mintLastIndex = 0
		Me.btnSave.Enabled = False
	End Sub

	Private Sub MakeAddItemEntry()


	End Sub

#End Region

	Private Sub LoadTactic()
		Dim pobjItem As New Tactic()
		pobjItem = CType(Me.lstTactics.SelectedItem, Tactic)

		With pobjItem
			mblnLoading = True
			Me.txtName.Text = .Name
			Me.txtAbbr.Text = .Abbreviation
			Me.txtDescription.Text = .Description

			Me.iscrCreasePlay.Value = .CreasePlay
			Me.iscrCrossPassing.Value = .CrossPassing
			Me.iscrDefEngagement.Value = .DefensiveEngagement
			Me.iscrForwardPassing.Value = .ForwardPassing
			Me.iscrGoalieRoving.Value = .GoalieRoving
			Me.iscrLongBall.Value = .LongBall
			Me.iscrParamShooting.Value = .Parameter
			Me.iscrPosture.Value = .Posture
			Me.iscrRegroup.Value = .Regroup
			Me.iscrZoneToMan.Value = .ZoneToMan
			mblnLoading = False


		End With

	End Sub


	Private Sub Scrollbarchanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles iscrCreasePlay.TextChanged, _
	iscrCrossPassing.TextChanged, iscrDefEngagement.TextChanged, iscrForwardPassing.TextChanged, iscrGoalieRoving.TextChanged, iscrLongBall.TextChanged, _
	iscrParamShooting.TextChanged, iscrPosture.TextChanged, iscrRegroup.TextChanged, iscrZoneToMan.TextChanged

		If Not mblnLoading Then
			mblnDirty = True
			Me.lblExplanation.Text = CType(sender, Control).Tag
			Me.btnSave.Enabled = True
		End If

	End Sub

	Private Sub ChangeDescription(ByVal sender As Object, ByVal e As System.EventArgs) Handles iscrCreasePlay.Enter, _
	iscrCrossPassing.Enter, iscrDefEngagement.Enter, iscrForwardPassing.Enter, iscrGoalieRoving.Enter, iscrLongBall.Enter, _
	iscrParamShooting.Enter, iscrPosture.Enter, iscrRegroup.Enter, iscrZoneToMan.Enter

		Me.lblExplanation.Text = CType(sender, Control).Tag

	End Sub

	Private Sub lstSublines_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstTactics.SelectedIndexChanged
		If Not mblnLoading Then
			CheckForSave()
			Call LoadTactic()
			mintLastIndex = Me.lstTactics.SelectedIndex
		End If
	End Sub

	Private Sub CheckForSave()
		If mblnDirty Then
			If MsgBox("Do you wish to save your changes?", MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton1, "ISM") = MsgBoxResult.Yes Then
				Call Save()
				mblnDirty = False
			End If
		End If
	End Sub

	Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
		If mblnDirty Then
			Call Save()
			mblnDirty = False
		End If
	End Sub

	Private Sub Save()
		App.SetCursor(True, Me)
		Dim pobjUpdateItem As New Tactic()
		pobjUpdateItem = CType(Me.lstTactics.Items(mintLastIndex), Tactic)

		With pobjUpdateItem
			.Abbreviation = Me.txtAbbr.Text
			.CreasePlay = Me.iscrCreasePlay.Value
			.CrossPassing = Me.iscrCrossPassing.Value
			.DefensiveEngagement = Me.iscrDefEngagement.Value
			.Description = Me.txtDescription.Text
			.ForwardPassing = Me.iscrForwardPassing.Value
			.GoalieRoving = Me.iscrGoalieRoving.Value
			.LongBall = Me.iscrLongBall.Value
			.Name = Me.txtName.Text
			.Parameter = Me.iscrParamShooting.Value
			.Posture = Me.iscrPosture.Value
			.Regroup = Me.iscrRegroup.Value
			.ZoneToMan = Me.iscrZoneToMan.Value
		End With

		pobjUpdateItem.Update()

		Dim pobjFindItem As Tactic
		For Each pobjFindItem In gobjTacticSet
			If pobjFindItem.TacticID = pobjUpdateItem.TacticID Then
				pobjFindItem = pobjUpdateItem.Clone
			End If
		Next
		Call ReloadList(pobjUpdateItem)
		App.SetCursor(False, Me)

	End Sub

	Friend Sub ReloadList(ByVal pobjUpdateItem As Tactic)
		'Reload list...
		Dim pobjItem As New Tactic()
		mblnLoading = True
		Me.lstTactics.Items.Clear()
		For Each pobjItem In gobjTacticSet
			Me.lstTactics.Items.Add(pobjItem)
			If pobjItem.TacticID = pobjUpdateItem.TacticID Then
				Me.lstTactics.SelectedItem = pobjItem
			End If
		Next
		Me.lstTactics.Sorted = True
		Me.btnSave.Enabled = False
		mblnLoading = False

	End Sub


	Private Sub TextDirty(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtName.TextChanged, txtAbbr.TextChanged, txtDescription.TextChanged
		If Not mblnLoading Then
			mblnDirty = True
			Me.btnSave.Enabled = True
		End If

	End Sub

	Private Sub txtName_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtName.Leave
		If Not mblnLoading Then
			If Not (IsStringValid(Me.txtName.Text, 1, 50)) Then
				MsgBox("Your Name for this tactic is either too short or too long.  Please change before saving.")
				Me.txtName.Focus()
			End If
		End If
	End Sub

	Private Sub txtAbbr_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtAbbr.Leave
		If Not mblnLoading Then
			If Not (IsStringValid(Me.txtAbbr.Text, 1, 5)) Then
				MsgBox("Your abbreviation for this tactic is either too short or too long.  Please change before saving.")
				Me.txtAbbr.Focus()
			End If
		End If
	End Sub

	Private Sub btnNewTactic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewTactic.Click
		Call AddNewTactic()
	End Sub

	Private Sub AddNewTactic()
		Dim pobjItem As New Tactic()
		pobjItem.SetDefault(gobjTacticSet.GetNewID)
		gobjTacticSet.Add(pobjItem)
		Call ReloadList(pobjItem)
		Me.lstTactics.SelectedItem = pobjItem
		Me.txtName.Focus()
	End Sub
End Class
