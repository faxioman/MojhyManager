
'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Public Class TeamCombo
    Inherits System.Windows.Forms.UserControl

    Friend TeamID As Integer
    Friend SelectedTeam As Teams.Team

    Friend Event SelectionChanged(ByVal sender As System.Object, ByVal e As TeamSelectedEventArgs)

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents cmbTeam As System.Windows.Forms.ComboBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cmbTeam = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'cmbTeam
        '
        Me.cmbTeam.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.cmbTeam.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbTeam.Name = "cmbTeam"
        Me.cmbTeam.Size = New System.Drawing.Size(256, 22)
        Me.cmbTeam.TabIndex = 0
        '
        'TeamCombo
        '
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmbTeam})
        Me.Name = "TeamCombo"
        Me.Size = New System.Drawing.Size(256, 24)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub cmbTeam_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbTeam.SelectedIndexChanged
        RaiseEvent SelectionChanged(Me, New TeamSelectedEventArgs(CType(Me.cmbTeam.SelectedItem, ComboItem).Value))
    End Sub

    Friend Sub LoadTeams()
        Call LoadTeams(-1)
    End Sub

    Friend Sub LoadTeams(ByVal TeamID As Integer)
        Me.cmbTeam.DropDownStyle = ComboBoxStyle.DropDownList
        Me.cmbTeam.Sorted = True
        Me.cmbTeam.DisplayMember = "Display"
        Me.cmbTeam.ValueMember = "Value"
        Me.cmbTeam.Items.Clear()

        Dim i As Integer
        For i = 0 To gobjLeague.Count - 1
            Me.cmbTeam.Items.Add(New ComboItem(gobjLeague.Item(i).ToString, gobjLeague.Item(i).TeamID))
            If gobjLeague.Item(i).TeamID = TeamID Then
                Me.cmbTeam.SelectedItem = Me.cmbTeam.Items(Me.cmbTeam.Items.Count - 1)
            End If
        Next
    End Sub



End Class
