'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.Windows.Forms.Control
Imports System.ComponentModel


Friend Class ISMScrollBar
	Inherits System.Windows.Forms.UserControl

	Shadows Event TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
	Shadows Event Enter(ByVal sender As Object, ByVal e As System.EventArgs)
	Shadows Event MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)
    Private m_Description As String


#Region " Windows Form Designer generated code "

    Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents scrLongBall As System.Windows.Forms.HScrollBar
    Friend WithEvents txtValue As System.Windows.Forms.TextBox
    Friend WithEvents pnlBack As System.Windows.Forms.Panel
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.scrLongBall = New System.Windows.Forms.HScrollBar()
        Me.txtValue = New System.Windows.Forms.TextBox()
        Me.pnlBack = New System.Windows.Forms.Panel()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'scrLongBall
        '
        Me.scrLongBall.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
           Or System.Windows.Forms.AnchorStyles.Right)
        Me.scrLongBall.LargeChange = 1
        Me.scrLongBall.Location = New System.Drawing.Point(8, 0)
        Me.scrLongBall.Name = "scrLongBall"
        Me.scrLongBall.Size = New System.Drawing.Size(336, 16)
        Me.scrLongBall.TabIndex = 20
        Me.scrLongBall.Value = 50
        '
        'txtValue
        '
        Me.txtValue.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.txtValue.Location = New System.Drawing.Point(352, 0)
        Me.txtValue.Name = "txtValue"
        Me.txtValue.Size = New System.Drawing.Size(32, 20)
        Me.txtValue.TabIndex = 21
        Me.txtValue.Text = "50"
        '
        'pnlBack
        '
        Me.pnlBack.BackColor = System.Drawing.Color.LightSeaGreen
        Me.pnlBack.Location = New System.Drawing.Point(144, 0)
        Me.pnlBack.Name = "pnlBack"
        Me.pnlBack.Size = New System.Drawing.Size(64, 48)
        Me.pnlBack.TabIndex = 22
        '
        'ISMScrollBar
        '
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtValue, Me.scrLongBall, Me.pnlBack})
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "ISMScrollBar"
        Me.Size = New System.Drawing.Size(392, 24)
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub scrLongBall_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles scrLongBall.ValueChanged
        Me.txtValue.Text = Me.scrLongBall.Value
    End Sub

    Private Sub txtValue_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtValue.TextChanged
        Dim Val As Integer
        Val = Int((Me.txtValue.Text))
        If Val < 0 Then Val = 0
        If Val > 100 Then Val = 100
        Me.scrLongBall.Value = Val
        RaiseEvent TextChanged(Me, e)
    End Sub

    Friend Property Value() As Integer
        Get
            Return Me.scrLongBall.Value
        End Get
        Set(ByVal Value As Integer)
            Me.scrLongBall.Value = Value
        End Set
    End Property

    <Browsable(True)> _
    Friend Property Description() As String
        Get
            Return m_Description
        End Get
        Set(ByVal Value As String)
            m_Description = Value
        End Set
    End Property

    Private Sub ISMScrollBar_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Enter, scrLongBall.Enter, txtValue.Enter
        RaiseEvent Enter(Me, e)
    End Sub


    Private Sub ISMScrollBar_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown, scrLongBall.MouseDown, txtValue.MouseDown

    End Sub
End Class
