'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Friend Class frmSignFA
    Inherits System.Windows.Forms.Form

    Friend TeamID As Integer

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents grpFinish As System.Windows.Forms.GroupBox
    Friend WithEvents cmbRatingType As System.Windows.Forms.ComboBox
    Friend WithEvents lblType As System.Windows.Forms.Label
    Friend WithEvents cmbPosition As System.Windows.Forms.ComboBox
    Friend WithEvents lblPosition As System.Windows.Forms.Label
    Friend WithEvents PlayerPicker As ISoccerSim.PlayerPicker
    Friend WithEvents btnOK As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.grpFinish = New System.Windows.Forms.GroupBox()
        Me.cmbRatingType = New System.Windows.Forms.ComboBox()
        Me.lblType = New System.Windows.Forms.Label()
        Me.cmbPosition = New System.Windows.Forms.ComboBox()
        Me.lblPosition = New System.Windows.Forms.Label()
        Me.PlayerPicker = New ISoccerSim.PlayerPicker()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.grpFinish.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpFinish
        '
        Me.grpFinish.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.grpFinish.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmbRatingType, Me.lblType, Me.cmbPosition, Me.lblPosition, Me.PlayerPicker})
        Me.grpFinish.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpFinish.Location = New System.Drawing.Point(8, 6)
        Me.grpFinish.Name = "grpFinish"
        Me.grpFinish.Size = New System.Drawing.Size(728, 346)
        Me.grpFinish.TabIndex = 12
        Me.grpFinish.TabStop = False
        Me.grpFinish.Text = "Player"
        '
        'cmbRatingType
        '
        Me.cmbRatingType.Items.AddRange(New Object() {"General", "Actuals", "Potentials"})
        Me.cmbRatingType.Location = New System.Drawing.Point(96, 40)
        Me.cmbRatingType.Name = "cmbRatingType"
        Me.cmbRatingType.Size = New System.Drawing.Size(80, 22)
        Me.cmbRatingType.TabIndex = 22
        '
        'lblType
        '
        Me.lblType.Location = New System.Drawing.Point(16, 40)
        Me.lblType.Name = "lblType"
        Me.lblType.Size = New System.Drawing.Size(64, 24)
        Me.lblType.TabIndex = 21
        Me.lblType.Text = "Information:"
        '
        'cmbPosition
        '
        Me.cmbPosition.Items.AddRange(New Object() {"All", "GK", "DEF", "FW", "MF"})
        Me.cmbPosition.Location = New System.Drawing.Point(96, 16)
        Me.cmbPosition.Name = "cmbPosition"
        Me.cmbPosition.Size = New System.Drawing.Size(80, 22)
        Me.cmbPosition.TabIndex = 20
        '
        'lblPosition
        '
        Me.lblPosition.Location = New System.Drawing.Point(16, 16)
        Me.lblPosition.Name = "lblPosition"
        Me.lblPosition.Size = New System.Drawing.Size(64, 24)
        Me.lblPosition.TabIndex = 19
        Me.lblPosition.Text = "Position:"
        '
        'PlayerPicker
        '
        Me.PlayerPicker.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.PlayerPicker.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PlayerPicker.Location = New System.Drawing.Point(8, 72)
        Me.PlayerPicker.Name = "PlayerPicker"
        Me.PlayerPicker.Size = New System.Drawing.Size(714, 266)
        Me.PlayerPicker.TabIndex = 14
        '
        'btnOK
        '
        Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnOK.Location = New System.Drawing.Point(624, 360)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(112, 24)
        Me.btnOK.TabIndex = 13
        Me.btnOK.Text = "&OK"
        '
        'frmSignFA
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(744, 389)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnOK, Me.grpFinish})
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmSignFA"
        Me.Text = "Sign Free Agent"
        Me.grpFinish.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Friend Sub SetScreen(ByVal TeamID As Integer, ByVal PositionID As Integer)
        Me.PlayerPicker.Mode = PlayerPicker.ISM_GridMode.FreeAgent
        Me.TeamID = TeamID
        Me.PlayerPicker.PositionID = PositionID
        Me.PlayerPicker.TeamID = TeamID
        Me.cmbPosition.SelectedIndex = PositionID
        Me.cmbRatingType.SelectedIndex = 0
        Me.PlayerPicker.SetScreen()
        Me.PlayerPicker.LoadRoster()
        Call App.SkinForm(Me)
    End Sub



    Private Sub cmbRatingType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbRatingType.SelectedIndexChanged
        Me.PlayerPicker.RosterView = Me.cmbRatingType.SelectedIndex
        Call Me.PlayerPicker.LoadRoster()
    End Sub

    Private Sub cmbPosition_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbPosition.SelectedIndexChanged
        Me.PlayerPicker.PositionID = Me.PlayerPicker.GetPositionToShow(Me.cmbPosition.Text)
        Call Me.PlayerPicker.LoadRoster()
    End Sub

    Private Sub PlayerPicker_PlayerSigned(ByVal sender As Object, ByVal e As System.EventArgs) Handles PlayerPicker.PlayerSigned
        Me.Close()
    End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Me.Close()
    End Sub
End Class
