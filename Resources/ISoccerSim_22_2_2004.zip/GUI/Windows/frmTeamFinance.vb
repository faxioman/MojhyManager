'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Public Class frmTeamFinance
    Inherits System.Windows.Forms.Form

    Dim mblnLoading As Boolean = False

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Call SetScreen()

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents cmbTeams As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents grpIncome As System.Windows.Forms.GroupBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblTicketEstimated As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lblSponsorshipEstimated As System.Windows.Forms.Label
    Friend WithEvents lblMerchendiseEstimated As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents lblConcessionsEstimated As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lblTotalEstimated As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents lblTotalActual As System.Windows.Forms.Label
    Friend WithEvents lblConcessionsActual As System.Windows.Forms.Label
    Friend WithEvents lblMerchendiseActual As System.Windows.Forms.Label
    Friend WithEvents lblSponsorshipActual As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents lblTicketActual As System.Windows.Forms.Label
    Friend WithEvents lblSoccerCampsEstimated As System.Windows.Forms.Label
    Friend WithEvents lblSoccerCampsActual As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents grpExpenses As System.Windows.Forms.GroupBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents lblTravelEstimated As System.Windows.Forms.Label
    Friend WithEvents lblInsuranceEstimated As System.Windows.Forms.Label
    Friend WithEvents lblSalariesEstimated As System.Windows.Forms.Label
    Friend WithEvents lblFrontOfficeEstimated As System.Windows.Forms.Label
    Friend WithEvents lblMarketingEstimated As System.Windows.Forms.Label
    Friend WithEvents lblLeagueDuesEstimated As System.Windows.Forms.Label
    Friend WithEvents lblOverheadEstimated As System.Windows.Forms.Label
    Friend WithEvents lblPromotionsEstimated As System.Windows.Forms.Label
    Friend WithEvents lblEventsEstimated As System.Windows.Forms.Label
    Friend WithEvents lblArenaRentalEstimated As System.Windows.Forms.Label
    Friend WithEvents lblTotalExpensesEstimated As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents lblNetIncomeEstimated As System.Windows.Forms.Label
    Friend WithEvents lblSoccerCamps As System.Windows.Forms.Label
    Friend WithEvents lblConcessionPC As System.Windows.Forms.Label
    Friend WithEvents lblSwagPC As System.Windows.Forms.Label
    Friend WithEvents lblAvgTicketPrice As System.Windows.Forms.Label
    Friend WithEvents lblConcessionPct As System.Windows.Forms.Label
    Friend WithEvents lblSwagPct As System.Windows.Forms.Label
    Friend WithEvents lblExpectedTicketPaid As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents btnMedia As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cmbTeams = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.grpIncome = New System.Windows.Forms.GroupBox()
        Me.lblConcessionPct = New System.Windows.Forms.Label()
        Me.lblSwagPct = New System.Windows.Forms.Label()
        Me.lblExpectedTicketPaid = New System.Windows.Forms.Label()
        Me.lblSoccerCamps = New System.Windows.Forms.Label()
        Me.lblConcessionPC = New System.Windows.Forms.Label()
        Me.lblSwagPC = New System.Windows.Forms.Label()
        Me.lblAvgTicketPrice = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.lblTotalActual = New System.Windows.Forms.Label()
        Me.lblSoccerCampsActual = New System.Windows.Forms.Label()
        Me.lblConcessionsActual = New System.Windows.Forms.Label()
        Me.lblMerchendiseActual = New System.Windows.Forms.Label()
        Me.lblSponsorshipActual = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.lblTicketActual = New System.Windows.Forms.Label()
        Me.lblTotalEstimated = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblSoccerCampsEstimated = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblConcessionsEstimated = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblMerchendiseEstimated = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblSponsorshipEstimated = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblTicketEstimated = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.grpExpenses = New System.Windows.Forms.GroupBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.lblNetIncomeEstimated = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.lblLeagueDuesEstimated = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.lblOverheadEstimated = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.lblPromotionsEstimated = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.lblEventsEstimated = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.lblArenaRentalEstimated = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.lblTotalExpensesEstimated = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.lblTravelEstimated = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.lblInsuranceEstimated = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.lblSalariesEstimated = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.lblFrontOfficeEstimated = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.lblMarketingEstimated = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.btnMedia = New System.Windows.Forms.Button()
        Me.grpIncome.SuspendLayout()
        Me.grpExpenses.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmbTeams
        '
        Me.cmbTeams.Location = New System.Drawing.Point(80, 8)
        Me.cmbTeams.Name = "cmbTeams"
        Me.cmbTeams.Size = New System.Drawing.Size(280, 22)
        Me.cmbTeams.TabIndex = 10
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 8)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 24)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Team:"
        '
        'grpIncome
        '
        Me.grpIncome.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblConcessionPct, Me.lblSwagPct, Me.lblExpectedTicketPaid, Me.lblSoccerCamps, Me.lblConcessionPC, Me.lblSwagPC, Me.lblAvgTicketPrice, Me.Label35, Me.Label36, Me.Label34, Me.Label32, Me.Label33, Me.Label31, Me.Label30, Me.lblTotalActual, Me.lblSoccerCampsActual, Me.lblConcessionsActual, Me.lblMerchendiseActual, Me.lblSponsorshipActual, Me.Label19, Me.lblTicketActual, Me.lblTotalEstimated, Me.Label13, Me.lblSoccerCampsEstimated, Me.Label12, Me.lblConcessionsEstimated, Me.Label10, Me.lblMerchendiseEstimated, Me.Label8, Me.lblSponsorshipEstimated, Me.Label5, Me.Label4, Me.lblTicketEstimated, Me.Label1})
        Me.grpIncome.Location = New System.Drawing.Point(8, 40)
        Me.grpIncome.Name = "grpIncome"
        Me.grpIncome.Size = New System.Drawing.Size(672, 192)
        Me.grpIncome.TabIndex = 12
        Me.grpIncome.TabStop = False
        Me.grpIncome.Text = "Income"
        '
        'lblConcessionPct
        '
        Me.lblConcessionPct.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblConcessionPct.Location = New System.Drawing.Point(560, 104)
        Me.lblConcessionPct.Name = "lblConcessionPct"
        Me.lblConcessionPct.Size = New System.Drawing.Size(48, 20)
        Me.lblConcessionPct.TabIndex = 49
        Me.lblConcessionPct.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSwagPct
        '
        Me.lblSwagPct.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSwagPct.Location = New System.Drawing.Point(560, 80)
        Me.lblSwagPct.Name = "lblSwagPct"
        Me.lblSwagPct.Size = New System.Drawing.Size(48, 20)
        Me.lblSwagPct.TabIndex = 48
        Me.lblSwagPct.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblExpectedTicketPaid
        '
        Me.lblExpectedTicketPaid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblExpectedTicketPaid.Location = New System.Drawing.Point(560, 32)
        Me.lblExpectedTicketPaid.Name = "lblExpectedTicketPaid"
        Me.lblExpectedTicketPaid.Size = New System.Drawing.Size(48, 20)
        Me.lblExpectedTicketPaid.TabIndex = 47
        Me.lblExpectedTicketPaid.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSoccerCamps
        '
        Me.lblSoccerCamps.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSoccerCamps.Location = New System.Drawing.Point(432, 128)
        Me.lblSoccerCamps.Name = "lblSoccerCamps"
        Me.lblSoccerCamps.Size = New System.Drawing.Size(56, 20)
        Me.lblSoccerCamps.TabIndex = 46
        Me.lblSoccerCamps.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblConcessionPC
        '
        Me.lblConcessionPC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblConcessionPC.Location = New System.Drawing.Point(432, 104)
        Me.lblConcessionPC.Name = "lblConcessionPC"
        Me.lblConcessionPC.Size = New System.Drawing.Size(56, 20)
        Me.lblConcessionPC.TabIndex = 45
        Me.lblConcessionPC.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSwagPC
        '
        Me.lblSwagPC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSwagPC.Location = New System.Drawing.Point(432, 80)
        Me.lblSwagPC.Name = "lblSwagPC"
        Me.lblSwagPC.Size = New System.Drawing.Size(56, 20)
        Me.lblSwagPC.TabIndex = 44
        Me.lblSwagPC.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblAvgTicketPrice
        '
        Me.lblAvgTicketPrice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAvgTicketPrice.Location = New System.Drawing.Point(432, 32)
        Me.lblAvgTicketPrice.Name = "lblAvgTicketPrice"
        Me.lblAvgTicketPrice.Size = New System.Drawing.Size(56, 20)
        Me.lblAvgTicketPrice.TabIndex = 43
        Me.lblAvgTicketPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label35
        '
        Me.Label35.Location = New System.Drawing.Point(496, 80)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(72, 16)
        Me.Label35.TabIndex = 39
        Me.Label35.Text = "Team Cut %:"
        '
        'Label36
        '
        Me.Label36.Location = New System.Drawing.Point(336, 80)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(96, 16)
        Me.Label36.TabIndex = 37
        Me.Label36.Text = "Swag/Fan:"
        '
        'Label34
        '
        Me.Label34.Location = New System.Drawing.Point(336, 128)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(96, 16)
        Me.Label34.TabIndex = 35
        Me.Label34.Text = "# of Camps:"
        '
        'Label32
        '
        Me.Label32.Location = New System.Drawing.Point(496, 104)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(72, 16)
        Me.Label32.TabIndex = 33
        Me.Label32.Text = "Team Cut %:"
        '
        'Label33
        '
        Me.Label33.Location = New System.Drawing.Point(336, 104)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(96, 16)
        Me.Label33.TabIndex = 31
        Me.Label33.Text = "Concession/Fan:"
        '
        'Label31
        '
        Me.Label31.Location = New System.Drawing.Point(496, 32)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(72, 16)
        Me.Label31.TabIndex = 29
        Me.Label31.Text = "Expected %:"
        '
        'Label30
        '
        Me.Label30.Location = New System.Drawing.Point(336, 32)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(96, 16)
        Me.Label30.TabIndex = 27
        Me.Label30.Text = "Avg. Ticket Price:"
        '
        'lblTotalActual
        '
        Me.lblTotalActual.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalActual.Location = New System.Drawing.Point(216, 160)
        Me.lblTotalActual.Name = "lblTotalActual"
        Me.lblTotalActual.Size = New System.Drawing.Size(112, 20)
        Me.lblTotalActual.TabIndex = 26
        Me.lblTotalActual.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSoccerCampsActual
        '
        Me.lblSoccerCampsActual.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSoccerCampsActual.Location = New System.Drawing.Point(216, 128)
        Me.lblSoccerCampsActual.Name = "lblSoccerCampsActual"
        Me.lblSoccerCampsActual.Size = New System.Drawing.Size(112, 20)
        Me.lblSoccerCampsActual.TabIndex = 25
        Me.lblSoccerCampsActual.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblConcessionsActual
        '
        Me.lblConcessionsActual.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblConcessionsActual.Location = New System.Drawing.Point(216, 104)
        Me.lblConcessionsActual.Name = "lblConcessionsActual"
        Me.lblConcessionsActual.Size = New System.Drawing.Size(112, 20)
        Me.lblConcessionsActual.TabIndex = 24
        Me.lblConcessionsActual.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblMerchendiseActual
        '
        Me.lblMerchendiseActual.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblMerchendiseActual.Location = New System.Drawing.Point(216, 80)
        Me.lblMerchendiseActual.Name = "lblMerchendiseActual"
        Me.lblMerchendiseActual.Size = New System.Drawing.Size(112, 20)
        Me.lblMerchendiseActual.TabIndex = 23
        Me.lblMerchendiseActual.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSponsorshipActual
        '
        Me.lblSponsorshipActual.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSponsorshipActual.Location = New System.Drawing.Point(216, 56)
        Me.lblSponsorshipActual.Name = "lblSponsorshipActual"
        Me.lblSponsorshipActual.Size = New System.Drawing.Size(112, 20)
        Me.lblSponsorshipActual.TabIndex = 22
        Me.lblSponsorshipActual.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(208, 16)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(120, 16)
        Me.Label19.TabIndex = 21
        Me.Label19.Text = "Actual"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTicketActual
        '
        Me.lblTicketActual.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTicketActual.Location = New System.Drawing.Point(216, 32)
        Me.lblTicketActual.Name = "lblTicketActual"
        Me.lblTicketActual.Size = New System.Drawing.Size(112, 20)
        Me.lblTicketActual.TabIndex = 20
        Me.lblTicketActual.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblTotalEstimated
        '
        Me.lblTotalEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalEstimated.Location = New System.Drawing.Point(96, 160)
        Me.lblTotalEstimated.Name = "lblTotalEstimated"
        Me.lblTotalEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblTotalEstimated.TabIndex = 15
        Me.lblTotalEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(16, 160)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(80, 16)
        Me.Label13.TabIndex = 14
        Me.Label13.Text = "TOTAL:"
        '
        'lblSoccerCampsEstimated
        '
        Me.lblSoccerCampsEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSoccerCampsEstimated.Location = New System.Drawing.Point(96, 128)
        Me.lblSoccerCampsEstimated.Name = "lblSoccerCampsEstimated"
        Me.lblSoccerCampsEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblSoccerCampsEstimated.TabIndex = 13
        Me.lblSoccerCampsEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(16, 128)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(80, 16)
        Me.Label12.TabIndex = 12
        Me.Label12.Text = "Youth Camps:"
        '
        'lblConcessionsEstimated
        '
        Me.lblConcessionsEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblConcessionsEstimated.Location = New System.Drawing.Point(96, 104)
        Me.lblConcessionsEstimated.Name = "lblConcessionsEstimated"
        Me.lblConcessionsEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblConcessionsEstimated.TabIndex = 11
        Me.lblConcessionsEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(16, 104)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(72, 16)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "Concessions:"
        '
        'lblMerchendiseEstimated
        '
        Me.lblMerchendiseEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblMerchendiseEstimated.Location = New System.Drawing.Point(96, 80)
        Me.lblMerchendiseEstimated.Name = "lblMerchendiseEstimated"
        Me.lblMerchendiseEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblMerchendiseEstimated.TabIndex = 9
        Me.lblMerchendiseEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(16, 80)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(72, 16)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Merchendise:"
        '
        'lblSponsorshipEstimated
        '
        Me.lblSponsorshipEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSponsorshipEstimated.Location = New System.Drawing.Point(96, 56)
        Me.lblSponsorshipEstimated.Name = "lblSponsorshipEstimated"
        Me.lblSponsorshipEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblSponsorshipEstimated.TabIndex = 7
        Me.lblSponsorshipEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(16, 56)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 16)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Sponsorship:"
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(96, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(120, 16)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Estimated"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTicketEstimated
        '
        Me.lblTicketEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTicketEstimated.Location = New System.Drawing.Point(96, 32)
        Me.lblTicketEstimated.Name = "lblTicketEstimated"
        Me.lblTicketEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblTicketEstimated.TabIndex = 4
        Me.lblTicketEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Ticket:"
        '
        'btnOK
        '
        Me.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnOK.Location = New System.Drawing.Point(570, 464)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(112, 24)
        Me.btnOK.TabIndex = 13
        Me.btnOK.Text = "&OK"
        '
        'grpExpenses
        '
        Me.grpExpenses.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label16, Me.lblNetIncomeEstimated, Me.Label21, Me.Label51, Me.lblLeagueDuesEstimated, Me.Label53, Me.Label42, Me.Label43, Me.Label44, Me.lblOverheadEstimated, Me.Label46, Me.lblPromotionsEstimated, Me.Label48, Me.lblEventsEstimated, Me.Label50, Me.Label40, Me.Label41, Me.Label37, Me.lblArenaRentalEstimated, Me.Label39, Me.Label2, Me.Label6, Me.Label7, Me.Label9, Me.Label11, Me.Label14, Me.Label15, Me.lblTotalExpensesEstimated, Me.Label17, Me.lblTravelEstimated, Me.Label20, Me.lblInsuranceEstimated, Me.Label22, Me.lblSalariesEstimated, Me.Label24, Me.lblFrontOfficeEstimated, Me.Label26, Me.Label27, Me.lblMarketingEstimated, Me.Label29, Me.Label18})
        Me.grpExpenses.Location = New System.Drawing.Point(8, 240)
        Me.grpExpenses.Name = "grpExpenses"
        Me.grpExpenses.Size = New System.Drawing.Size(672, 216)
        Me.grpExpenses.TabIndex = 16
        Me.grpExpenses.TabStop = False
        Me.grpExpenses.Text = "Expenses"
        '
        'Label16
        '
        Me.Label16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label16.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(544, 184)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(112, 20)
        Me.Label16.TabIndex = 46
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblNetIncomeEstimated
        '
        Me.lblNetIncomeEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNetIncomeEstimated.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNetIncomeEstimated.Location = New System.Drawing.Point(424, 184)
        Me.lblNetIncomeEstimated.Name = "lblNetIncomeEstimated"
        Me.lblNetIncomeEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblNetIncomeEstimated.TabIndex = 45
        Me.lblNetIncomeEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(344, 184)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(80, 16)
        Me.Label21.TabIndex = 44
        Me.Label21.Text = "NET INCOME:"
        '
        'Label51
        '
        Me.Label51.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label51.Location = New System.Drawing.Point(544, 128)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(112, 20)
        Me.Label51.TabIndex = 43
        Me.Label51.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblLeagueDuesEstimated
        '
        Me.lblLeagueDuesEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblLeagueDuesEstimated.Location = New System.Drawing.Point(424, 128)
        Me.lblLeagueDuesEstimated.Name = "lblLeagueDuesEstimated"
        Me.lblLeagueDuesEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblLeagueDuesEstimated.TabIndex = 42
        Me.lblLeagueDuesEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label53
        '
        Me.Label53.Location = New System.Drawing.Point(344, 128)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(80, 16)
        Me.Label53.TabIndex = 41
        Me.Label53.Text = "League Dues:"
        '
        'Label42
        '
        Me.Label42.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label42.Location = New System.Drawing.Point(544, 104)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(112, 20)
        Me.Label42.TabIndex = 40
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label43
        '
        Me.Label43.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label43.Location = New System.Drawing.Point(544, 80)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(112, 20)
        Me.Label43.TabIndex = 39
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label44
        '
        Me.Label44.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label44.Location = New System.Drawing.Point(544, 56)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(112, 20)
        Me.Label44.TabIndex = 38
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblOverheadEstimated
        '
        Me.lblOverheadEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOverheadEstimated.Location = New System.Drawing.Point(424, 104)
        Me.lblOverheadEstimated.Name = "lblOverheadEstimated"
        Me.lblOverheadEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblOverheadEstimated.TabIndex = 37
        Me.lblOverheadEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label46
        '
        Me.Label46.Location = New System.Drawing.Point(344, 104)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(80, 16)
        Me.Label46.TabIndex = 36
        Me.Label46.Text = "Overhead:"
        '
        'lblPromotionsEstimated
        '
        Me.lblPromotionsEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPromotionsEstimated.Location = New System.Drawing.Point(424, 80)
        Me.lblPromotionsEstimated.Name = "lblPromotionsEstimated"
        Me.lblPromotionsEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblPromotionsEstimated.TabIndex = 35
        Me.lblPromotionsEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label48
        '
        Me.Label48.Location = New System.Drawing.Point(344, 80)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(72, 16)
        Me.Label48.TabIndex = 34
        Me.Label48.Text = "Promotions:"
        '
        'lblEventsEstimated
        '
        Me.lblEventsEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEventsEstimated.Location = New System.Drawing.Point(424, 56)
        Me.lblEventsEstimated.Name = "lblEventsEstimated"
        Me.lblEventsEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblEventsEstimated.TabIndex = 33
        Me.lblEventsEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label50
        '
        Me.Label50.Location = New System.Drawing.Point(344, 56)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(72, 16)
        Me.Label50.TabIndex = 32
        Me.Label50.Text = "Events:"
        '
        'Label40
        '
        Me.Label40.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(536, 16)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(120, 16)
        Me.Label40.TabIndex = 31
        Me.Label40.Text = "Actual"
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label41
        '
        Me.Label41.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(424, 16)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(120, 16)
        Me.Label41.TabIndex = 30
        Me.Label41.Text = "Estimated"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label37
        '
        Me.Label37.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label37.Location = New System.Drawing.Point(544, 32)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(112, 20)
        Me.Label37.TabIndex = 29
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblArenaRentalEstimated
        '
        Me.lblArenaRentalEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblArenaRentalEstimated.Location = New System.Drawing.Point(424, 32)
        Me.lblArenaRentalEstimated.Name = "lblArenaRentalEstimated"
        Me.lblArenaRentalEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblArenaRentalEstimated.TabIndex = 28
        Me.lblArenaRentalEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label39
        '
        Me.Label39.Location = New System.Drawing.Point(344, 32)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(80, 16)
        Me.Label39.TabIndex = 27
        Me.Label39.Text = "Arena Rental:"
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Location = New System.Drawing.Point(544, 160)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(112, 20)
        Me.Label2.TabIndex = 26
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label6
        '
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label6.Location = New System.Drawing.Point(216, 128)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(112, 20)
        Me.Label6.TabIndex = 25
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label7
        '
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label7.Location = New System.Drawing.Point(216, 104)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(112, 20)
        Me.Label7.TabIndex = 24
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label9
        '
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label9.Location = New System.Drawing.Point(216, 80)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(112, 20)
        Me.Label9.TabIndex = 23
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label11
        '
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label11.Location = New System.Drawing.Point(216, 56)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(112, 20)
        Me.Label11.TabIndex = 22
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(208, 16)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(120, 16)
        Me.Label14.TabIndex = 21
        Me.Label14.Text = "Actual"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label15
        '
        Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label15.Location = New System.Drawing.Point(216, 32)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(112, 20)
        Me.Label15.TabIndex = 20
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblTotalExpensesEstimated
        '
        Me.lblTotalExpensesEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalExpensesEstimated.Location = New System.Drawing.Point(424, 160)
        Me.lblTotalExpensesEstimated.Name = "lblTotalExpensesEstimated"
        Me.lblTotalExpensesEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblTotalExpensesEstimated.TabIndex = 15
        Me.lblTotalExpensesEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label17
        '
        Me.Label17.Location = New System.Drawing.Point(344, 160)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(80, 16)
        Me.Label17.TabIndex = 14
        Me.Label17.Text = "TOTAL:"
        '
        'lblTravelEstimated
        '
        Me.lblTravelEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTravelEstimated.Location = New System.Drawing.Point(96, 128)
        Me.lblTravelEstimated.Name = "lblTravelEstimated"
        Me.lblTravelEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblTravelEstimated.TabIndex = 13
        Me.lblTravelEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(16, 128)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(80, 16)
        Me.Label20.TabIndex = 12
        Me.Label20.Text = "Travel:"
        '
        'lblInsuranceEstimated
        '
        Me.lblInsuranceEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblInsuranceEstimated.Location = New System.Drawing.Point(96, 104)
        Me.lblInsuranceEstimated.Name = "lblInsuranceEstimated"
        Me.lblInsuranceEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblInsuranceEstimated.TabIndex = 11
        Me.lblInsuranceEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label22
        '
        Me.Label22.Location = New System.Drawing.Point(16, 104)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(72, 16)
        Me.Label22.TabIndex = 10
        Me.Label22.Text = "Insurance:"
        '
        'lblSalariesEstimated
        '
        Me.lblSalariesEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSalariesEstimated.Location = New System.Drawing.Point(96, 80)
        Me.lblSalariesEstimated.Name = "lblSalariesEstimated"
        Me.lblSalariesEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblSalariesEstimated.TabIndex = 9
        Me.lblSalariesEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label24
        '
        Me.Label24.Location = New System.Drawing.Point(16, 80)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(72, 16)
        Me.Label24.TabIndex = 8
        Me.Label24.Text = "Salaries:"
        '
        'lblFrontOfficeEstimated
        '
        Me.lblFrontOfficeEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFrontOfficeEstimated.Location = New System.Drawing.Point(96, 56)
        Me.lblFrontOfficeEstimated.Name = "lblFrontOfficeEstimated"
        Me.lblFrontOfficeEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblFrontOfficeEstimated.TabIndex = 7
        Me.lblFrontOfficeEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label26
        '
        Me.Label26.Location = New System.Drawing.Point(16, 56)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(72, 16)
        Me.Label26.TabIndex = 6
        Me.Label26.Text = "Front Office:"
        '
        'Label27
        '
        Me.Label27.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(96, 16)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(120, 16)
        Me.Label27.TabIndex = 5
        Me.Label27.Text = "Estimated"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblMarketingEstimated
        '
        Me.lblMarketingEstimated.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblMarketingEstimated.Location = New System.Drawing.Point(96, 32)
        Me.lblMarketingEstimated.Name = "lblMarketingEstimated"
        Me.lblMarketingEstimated.Size = New System.Drawing.Size(104, 20)
        Me.lblMarketingEstimated.TabIndex = 4
        Me.lblMarketingEstimated.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label29
        '
        Me.Label29.Location = New System.Drawing.Point(16, 32)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(64, 16)
        Me.Label29.TabIndex = 0
        Me.Label29.Text = "Marketing:"
        '
        'Label18
        '
        Me.Label18.Location = New System.Drawing.Point(8, 168)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(304, 32)
        Me.Label18.TabIndex = 17
        Me.Label18.Text = "Note:  Most settings above are negotiated and determined in the offseason."
        '
        'btnMedia
        '
        Me.btnMedia.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnMedia.Location = New System.Drawing.Point(8, 464)
        Me.btnMedia.Name = "btnMedia"
        Me.btnMedia.Size = New System.Drawing.Size(112, 24)
        Me.btnMedia.TabIndex = 17
        Me.btnMedia.Text = "&Media"
        '
        'frmTeamFinance
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(690, 495)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnMedia, Me.grpExpenses, Me.btnOK, Me.grpIncome, Me.cmbTeams, Me.Label3})
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmTeamFinance"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Team Finances"
        Me.grpIncome.ResumeLayout(False)
        Me.grpExpenses.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub SetScreen()
        Call InitializeDefaults()
        Call App.SkinForm(Me)

    End Sub

    Private Sub InitializeDefaults()
        Call App.SetTeamCombo(Me.cmbTeams)
    End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Me.Close()
    End Sub

    Private Sub cmbTeams_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbTeams.SelectedIndexChanged
        If Not mblnLoading Then
            Call LoadTeamIncome(CType(Me.cmbTeams.SelectedItem, Teams.Team).TeamID)
        End If
    End Sub

    Private Sub LoadTeamIncome(ByVal TeamID)
        Dim tm As New Finances.TeamBudgets()
        tm.Load(TeamID)

        With tm
            Me.lblConcessionsEstimated.Text = Format(.Concessions, MONEY_FORMAT)
            Me.lblMerchendiseEstimated.Text = Format(.Merchendise, MONEY_FORMAT)
            Me.lblSponsorshipEstimated.Text = Format(.Sponsorship, MONEY_FORMAT)
            Me.lblSoccerCampsEstimated.Text = Format(.SoccerCamps, MONEY_FORMAT)
            Me.lblTicketEstimated.Text = Format(.Tickets, MONEY_FORMAT)
            Me.lblTotalEstimated.Text = Format(.TotalIncome, MONEY_FORMAT)

            Me.lblArenaRentalEstimated.Text = Format(.ArenaRental, MONEY_FORMAT)
            Me.lblEventsEstimated.Text = Format(.Events, MONEY_FORMAT)
            Me.lblFrontOfficeEstimated.Text = Format(.FrontOffice, MONEY_FORMAT)
            Me.lblInsuranceEstimated.Text = Format(.Insurance, MONEY_FORMAT)
            Me.lblLeagueDuesEstimated.Text = Format(.LeagueDues, MONEY_FORMAT)
            Me.lblMarketingEstimated.Text = Format(.Marketing, MONEY_FORMAT)
            Me.lblOverheadEstimated.Text = Format(.Overhead, MONEY_FORMAT)
            Me.lblPromotionsEstimated.Text = Format(.Promotions, MONEY_FORMAT)
            Me.lblSalariesEstimated.Text = Format(.Salaries, MONEY_FORMAT)
            Me.lblTravelEstimated.Text = Format(.Travel, MONEY_FORMAT)
            Me.lblTotalExpensesEstimated.Text = Format(.TotalExpenses, MONEY_FORMAT)

            Me.lblNetIncomeEstimated.Text = Format(.NetIncome, MONEY_FORMAT)

        End With

        Dim tf As New Finances.TeamFinance()
        tf.Load(TeamID)
        With tf
            Me.lblAvgTicketPrice.Text = Format(.AvgTicketPrice, "$0.00")
            Me.lblExpectedTicketPaid.Text = Format(.PaidTicketPercentage, "#00%")
            Me.lblSwagPC.Text = Format(.AvgMerchendisePerCapita, "$0.00")
            Me.lblConcessionPC.Text = Format(.ConcessionPerCapita, "$0.00")
            Me.lblConcessionPct.Text = Format(.ConcessionPercentage, "#00%")
            Me.lblSoccerCamps.Text = .SoccerCampsPerOffseason
            Me.lblSwagPct.Text = "100%"
        End With



    End Sub


    Private Sub btnMedia_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMedia.Click
        Dim frmMedia As New frmTeamMedia(CType(Me.cmbTeams.SelectedItem, Teams.Team).TeamID)
        frmMedia.ShowDialog()
    End Sub
End Class
