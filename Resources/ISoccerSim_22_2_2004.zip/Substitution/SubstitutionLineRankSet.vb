'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Positions
Imports ISoccerSim.Players

Namespace Substitution
	Friend Class SubstitutionLineRankSet
		Inherits System.Collections.CollectionBase
		Implements ICloneable

		Friend SubstitutionLineID As Integer
		Friend TeamID As Integer
		Friend SubLineTypeID As ISMSublineType

		Default Property Item(ByVal index As Integer) As SubstitutionLineRank
			Get
				Return CType(InnerList.Item(index), SubstitutionLineRank)
			End Get
			Set(ByVal Value As SubstitutionLineRank)
				InnerList.Item(index) = Value
			End Set
		End Property


		Sub Add(ByVal value As SubstitutionLineRank)
			InnerList.Add(value)
		End Sub

		Sub Sort()
			InnerList.Sort()
		End Sub

		Function Clone() As Object Implements ICloneable.Clone
			Dim pobjSubline As New SubstitutionLineRankSet()
			pobjSubline = Me
			Return pobjSubline
		End Function

		Function GetPlayersForLine(ByVal intPosition As ISMPlayerPosition, ByVal intSlot As Integer) As SubstitutionLineRankSet
			Return GetPlayersForLine(intPosition, intSlot, intSlot)
		End Function

		<Bugtrack(1, "Empty roster not expected when creating league", True, "Prefill database with 0's")> _
		Function GetPlayersForLine(ByVal intPosition As ISMPlayerPosition, ByVal intLowSlot As Integer, ByVal intHighSlot As Integer) As SubstitutionLineRankSet
			Dim pobjSubline As New SubstitutionLineRankSet()
			Dim pobjRank As SubstitutionLineRank
			Dim Count As Integer = intLowSlot - intHighSlot + 1
			Dim PlayersAtPosition As Integer = GetPlayersAtPosition(intPosition)

			Me.InnerList.Sort()
			If Count + intHighSlot > PlayersAtPosition Then
				intHighSlot = PlayersAtPosition - Count
				intLowSlot = intHighSlot + Count
			End If


			For Each pobjRank In Me.InnerList
				With pobjRank
					If .Position = intPosition Then
						If .PositionRank >= intHighSlot And .PositionRank <= intLowSlot Then
							pobjSubline.Add(pobjRank.Clone)
						End If
					End If
				End With
			Next
			pobjSubline.Sort()

			'FIX (1):  If no players are available at a position, then throw blanks.
			'This should also work for not having enough players on a roster.

			If PlayersAtPosition < pobjSubline.Count Then
				Dim i As Integer
				For i = 0 To Count

					Dim pobjPlayer As New Player()
					Dim pobjBlank As New SubstitutionLineRank()

					pobjPlayer.ID = 0
					pobjBlank.Player = pobjPlayer
					pobjSubline.Add(pobjBlank)
				Next
			End If

			Return pobjSubline
		End Function

		Private Function GetPlayersAtPosition(ByVal intPosition As ISMPlayerPosition) As Integer
			Dim pobjRank As SubstitutionLineRank
			Dim Out As Integer

			For Each pobjRank In Me.InnerList
				If pobjRank.Position = intPosition Then
					Out += 1
				End If
			Next
			Return Out
		End Function


	End Class
End Namespace