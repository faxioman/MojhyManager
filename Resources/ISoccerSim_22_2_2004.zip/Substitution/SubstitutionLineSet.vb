'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Substitution
    Friend Class SubstitutionLineSet
        Inherits System.Collections.CollectionBase
        Implements ICloneable

        Friend SubstitutionLineID As Integer
        Friend TeamID As Integer
        Friend SubLineTypeID As ISMSublineType

        Default Property Item(ByVal index As ISMSublineType) As SubstitutionLine
            Get
                Return CType(InnerList.Item(index), SubstitutionLine)
            End Get
            Set(ByVal Value As SubstitutionLine)
                InnerList.Item(index) = Value
            End Set
        End Property


        Sub Add(ByVal value As SubstitutionLine)
            InnerList.Add(value)
        End Sub

        Sub Create(ByVal SublinetypeID As ISMSublineType, ByVal SubstitutionLineID As Integer, ByVal TeamID As Integer)
            Dim pobjItem As New SubstitutionLine()
            With pobjItem
                .SubLineTypeID = SublinetypeID
                .SubstitutionLineID = SubstitutionLineID
                .TeamID = TeamID
            End With
            InnerList.Add(pobjItem)

        End Sub


        Sub Load(ByVal TeamID As Integer)
            Dim pobjDS As New DataServices.TeamTables()
            Dim pobjDR As OleDb.OleDbDataReader = pobjDS.GetSubstitutionSet(TeamID)
            Me.InnerList.Clear()

            Do While pobjDR.Read()
                With pobjDR
                    Call Create(.Item("SubLineTypeID"), .Item("SubstitutionLineID"), .Item("teamID"))
                End With
            Loop
            pobjDR.Close()
            pobjDS.Close()

            If Not InnerListValid() Then
                Throw New Exception("Substitution set does not meet minimum requirements.")
            Else
                Dim objLine As SubstitutionLine
                For Each objLine In Me.InnerList
                    objLine.Load(objLine.SubstitutionLineID)
                Next
            End If


        End Sub

        Sub Insert()
            Dim pobjSubline As SubstitutionLine
            Dim pobjSubSlot As SubstitutionSlot
            If InnerListValid() Then
                For Each pobjSubline In Me.InnerList
                    pobjSubline.TeamID = Me.TeamID
                    pobjSubline.Insert()
                    For Each pobjSubSlot In pobjSubline
                        pobjSubSlot.SublineID = pobjSubline.SubstitutionLineID
                        pobjSubSlot.Insert()
                    Next
                Next
            Else
                Throw New Exception("Substitution set does not meet minimum requirements.")
            End If
        End Sub

        Function Clone() As Object Implements ICloneable.Clone
            Dim pobjSubline As New SubstitutionLineSet()
            pobjSubline = Me
            Return pobjSubline
        End Function

        Private Function InnerListValid() As Boolean
            If Me.InnerList.Count >= 5 Then
                Return True
            Else
                Return False
            End If
        End Function

        Public Sub SwapPlayerAfterEjection(ByVal objTeam As Teams.Team, ByVal objPlayer As Players.Player)
            Dim pobjLine As SubstitutionLine
            Dim pobjSet As SimEngine.GamePlayerSet = objTeam.FieldManager.GetSubstitutionCandidates(objPlayer)
            Dim pobjSwapPlayer As Players.Player

            For Each pobjLine In Me.InnerList
                If pobjLine.IsPlayerOnLine(objPlayer) Then
                    For Each pobjSwapPlayer In pobjSet
                        If Not pobjLine.IsPlayerOnLine(pobjSwapPlayer) Then
                            pobjLine.SwapPlayer(objPlayer, pobjSwapPlayer)
                            Exit For
                        End If
                    Next
                End If
            Next
        End Sub


        Public Function IsLegal(ByVal TeamID As Integer) As Boolean
            Dim pblnValid As Boolean = True

            If Not Me.InnerListValid Then
                Try
                    Me.Load(TeamID)
                Catch
                    Return False
                End Try
            End If

            If Me.InnerListValid Then
                Dim pobjItem As SubstitutionLine
                For Each pobjItem In Me.InnerList
                    If pobjItem.Count <> 6 Then
                        pblnValid = False
                        Exit For
                    End If
                Next
            End If

            Return pblnValid
        End Function
    End Class
End Namespace