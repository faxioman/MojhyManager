'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.SimEngine
Imports ISoccerSim.Ratings
Imports ISoccerSim.Positions
Imports ISoccerSim.Rosters


Namespace Substitution
	Friend Class SubstitutionLineFactory


		Sub ClearSetForTeam(ByVal intTeamID As Integer)
			Dim pobjDS As New DataServices.TeamTables()
			pobjDS.DeleteSubstitutionSet(intTeamID)


		End Sub

		Function GenerateLines(ByVal objRoster As Roster) As SubstitutionLineSet

			Dim i As Integer
			Dim pobjRankSet As New SubstitutionLineRankSet()
			Dim pobjRank As New SubstitutionLineRank()
			Dim Rank(4) As Integer


			'Load players in...
			For i = 0 To objRoster.Count - 1
				pobjRank = New SubstitutionLineRank()
				With pobjRank
					.Player = objRoster.Item(i).Player
					.Position = .Player.Position
					.Rank = pobjRank.Player.Ratings.GetRatingSetValue(.Position, ISS_RatingType.Actual)
				End With
				pobjRankSet.Add(pobjRank)
			Next

			'Assign rank per position...
			For Each pobjRank In pobjRankSet
				Rank(pobjRank.Position) += 1
				pobjRank.PositionRank = Rank(pobjRank.Position)
			Next

			'Now, get players for starting line...
			Dim pobjSubLine As New SubstitutionLine()
			Dim pobjSet As New SubstitutionLineSet()

			pobjSubLine = Me.MakeLine(pobjRankSet, ISMSublineType.Starters)
			pobjSet.Add(pobjSubLine)

			pobjSubLine = Me.MakeLine(pobjRankSet, ISMSublineType.SecondLine)
			pobjSet.Add(pobjSubLine)

			pobjSubLine = Me.MakeLine(pobjRankSet, ISMSublineType.ThirdLine)
			pobjSet.Add(pobjSubLine)

			pobjSubLine = Me.MakeLine(pobjRankSet, ISMSublineType.PowerPlay)
			pobjSet.Add(pobjSubLine)

			pobjSubLine = Me.MakeLine(pobjRankSet, ISMSublineType.PenaltyKill)
			pobjSet.Add(pobjSubLine)

			Return pobjSet

		End Function

		Private Function MakeLine(ByRef pobjRankSet As SubstitutionLineRankSet, ByVal intType As ISMSublineType) As SubstitutionLine

			Dim pobjTempSet As New SubstitutionLineRankSet()
			Dim pobjRank As SubstitutionLineRank
			Dim pobjSubLine As New SubstitutionLine()

			Dim OneSlot As Integer
			Dim TwoSlotLow As Integer
			Dim TwoSlotHigh As Integer

			Select Case intType
				Case ISMSublineType.Starters
					OneSlot = 1
					TwoSlotHigh = 1
					TwoSlotLow = 2

				Case ISMSublineType.SecondLine
					OneSlot = 2
					TwoSlotHigh = 3
					TwoSlotLow = 4

				Case ISMSublineType.ThirdLine
					OneSlot = 3
					TwoSlotHigh = 5
					TwoSlotLow = 6

				Case ISMSublineType.PowerPlay
					OneSlot = 1
					TwoSlotHigh = 1
					TwoSlotLow = 2

				Case ISMSublineType.PenaltyKill
					OneSlot = 1
					TwoSlotHigh = 2
					TwoSlotLow = 3

			End Select

			'Grab sets...
			pobjTempSet = pobjRankSet.GetPlayersForLine(ISMPlayerPosition.Goalie, 1)
			With pobjTempSet
				pobjSubLine.Create(.Item(0).Player.ID, ISMGamePosition.GK)
			End With

			pobjTempSet = pobjRankSet.GetPlayersForLine(ISMPlayerPosition.Midfielder, OneSlot)
			With pobjTempSet
				pobjSubLine.Create(.Item(0).Player.ID, ISMGamePosition.MF)
			End With


			pobjTempSet = pobjRankSet.GetPlayersForLine(ISMPlayerPosition.Defenseman, TwoSlotLow, TwoSlotHigh)
			With pobjTempSet
				pobjSubLine.Create(.Item(0).Player.ID, ISMGamePosition.LD)
				pobjSubLine.Create(.Item(1).Player.ID, ISMGamePosition.RD)
			End With

			pobjTempSet = pobjRankSet.GetPlayersForLine(ISMPlayerPosition.Forward, TwoSlotLow, TwoSlotHigh)
			With pobjTempSet
				pobjSubLine.Create(.Item(0).Player.ID, ISMGamePosition.RF)
				pobjSubLine.Create(.Item(1).Player.ID, ISMGamePosition.LF)
			End With
			pobjSubLine.SubLineTypeID = intType
			Return pobjSubLine
		End Function
	End Class
End Namespace