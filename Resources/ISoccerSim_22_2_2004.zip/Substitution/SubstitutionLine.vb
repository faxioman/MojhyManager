'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.SimEngine

Namespace Substitution
	Friend Enum ISMSublineType
		Starters = 0
		SecondLine = 1
		ThirdLine = 2
		PowerPlay = 3
		PenaltyKill = 4
	End Enum

	Friend Class SubstitutionLine
		Inherits System.Collections.CollectionBase
		Implements ICloneable

		Friend SubstitutionLineID As Integer
		Friend TeamID As Integer
		Friend SubLineTypeID As ISMSublineType

		Default Property Item(ByVal index As ISMSublineType) As SubstitutionSlot
			Get
				Return CType(InnerList.Item(index), SubstitutionSlot)
			End Get
			Set(ByVal Value As SubstitutionSlot)
				InnerList.Item(index) = Value
			End Set
		End Property


		Sub Add(ByVal value As SubstitutionSlot)
			InnerList.Add(value)
		End Sub

		Sub Create(ByVal PlayerID As Integer, ByVal GamePositionID As Integer, ByVal SlotID As Integer)
			Dim pobjItem As New SubstitutionSlot()
			With pobjItem
				.PlayerID = PlayerID
				.GamePositionID = GamePositionID
				.SlotID = SlotID
				.SublineID = Me.SubstitutionLineID
			End With

			Me.InnerList.Add(pobjItem)
		End Sub

		Sub Create(ByVal PlayerID As Integer, ByVal GamePositionID As Integer)
			Dim pobjItem As New SubstitutionSlot()
			With pobjItem
				.PlayerID = PlayerID
				.GamePositionID = GamePositionID
				.SlotID = 0
				.SublineID = Me.SubstitutionLineID
			End With

			Me.InnerList.Add(pobjItem)
		End Sub



		Sub Load(ByVal SublineID As Integer)
			Dim pobjDS As New DataServices.TeamTables()
			Dim pobjDR As System.Data.OleDb.OleDbDataReader = pobjDS.GetSubstitutionSlot(SublineID)
			Me.InnerList.Clear()

			Do While pobjDR.Read()
				With pobjDR
					Call Create(.Item("PlayerID"), .Item("GamePositionID"), .Item("SlotID"))
				End With
			Loop
			pobjDR.Close()
			pobjDS.Close()
		End Sub

		Sub Update()

			Dim pobjDS As New DataServices.TeamTables()
			Dim pobjSlot As SubstitutionSlot
			For Each pobjSlot In Me.InnerList
				pobjDS.UpdateSubstitutionSlot(pobjSlot)
			Next

		End Sub


		Function Clone() As Object Implements ICloneable.Clone
			Dim pobjSubline As New SubstitutionLine()
			pobjSubline = Me
			Return pobjSubline
		End Function

		Sub Insert()
			Dim pobjData As New DataServices.TeamTables()
			Me.SubstitutionLineID = pobjData.InsertSubstitutionLine(Me)
			pobjData.Close()
		End Sub

		Function GetPlayerIDForPosition(ByVal intGamePositionID As ISMGamePosition) As Integer
			Dim pobjSlot As SubstitutionSlot
			For Each pobjSlot In Me.InnerList
				If pobjSlot.GamePositionID = intGamePositionID Then
					Return pobjSlot.PlayerID
				End If
			Next
			Return -1
        End Function

        Function IsPlayerOnLine(ByVal objPlayer As Players.Player) As Boolean
            Dim pobjSlot As SubstitutionSlot
            For Each pobjSlot In Me.InnerList
                If pobjSlot.PlayerID = objPlayer.ID Then Return True
            Next
        End Function

        Sub SwapPlayer(ByVal objPlayer As Players.Player, ByVal objSwapPlayer As Players.Player)
            Dim pobjSlot As SubstitutionSlot
            For Each pobjSlot In Me.InnerList
                If pobjSlot.PlayerID = objPlayer.ID Then
                    pobjSlot.PlayerID = objSwapPlayer.ID
                End If
            Next
        End Sub


    End Class
End Namespace