'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Rosters
    Friend Class Roster
        Inherits System.Collections.CollectionBase
        Implements ICloneable

        Default Property Item(ByVal index As Integer) As RosterSlot
            Get
                Return CType(InnerList.Item(index), RosterSlot)
            End Get
            Set(ByVal Value As RosterSlot)
                InnerList.Item(index) = Value
            End Set
        End Property

        Sub Add(ByVal value As RosterSlot)
            InnerList.Add(value)
        End Sub

        Sub Create(ByVal PlayerID As Integer, ByVal RosterSlotID As Integer, ByVal TeamID As Integer)
            Dim pobjItem As New RosterSlot()
            With pobjItem
                .PlayerID = PlayerID
                .RosterSlotID = RosterSlotID
                .TeamID = TeamID
            End With

            Me.InnerList.Add(pobjItem)
        End Sub

        Sub Load(ByVal TeamID As Integer)
            Dim pobjDS As New DataServices.TeamTables()
            Dim pobjDR As OleDb.OleDbDataReader = pobjDS.GetRoster(TeamID)
            Me.InnerList.Clear()

            Do While pobjDR.Read()
                With pobjDR
                    Call Create(.Item("PlayerID"), .Item("RosterID"), TeamID)
                End With
            Loop
            pobjDR.Close()
        End Sub

        Function Clone() As Object Implements ICloneable.Clone
            Dim pobjRoster As New Roster()
            pobjRoster = Me
            Return pobjRoster
        End Function

        Function IsPlayerOnRoster(ByVal PlayerID As Integer) As Boolean
            Dim p As Players.Player
            Dim rs As RosterSlot

            For Each rs In Me.InnerList
                If rs.PlayerID = PlayerID Then
                    Return True
                End If
            Next
        End Function

        Function IsLegalToAdd() As Boolean
            If Me.InnerList.Count <= 19 Then Return True
        End Function

        Function GetTradeablePositions(ByVal Position As Positions.ISMPlayerPosition, ByVal Number As Integer) As Integer

            Dim rs As RosterSlot
            Dim op As New Players.Player()
            Dim Result As Integer

            For Each rs In Me.InnerList
                op.Load(rs.PlayerID)
                If op.Position = Position Then
                    Result = Result + 1
                End If
            Next

            Select Case Position
                Case Positions.ISMPlayerPosition.Defenseman
                    Result = Result - 2
                Case Positions.ISMPlayerPosition.Forward
                    Result = Result - 2
                Case Positions.ISMPlayerPosition.Goalie
                    Result = Result - 1
                Case Positions.ISMPlayerPosition.Midfielder
                    Result = Result - 1
            End Select

            Return Result
        End Function

        Function IsLegalToRemove(ByVal PlayerID As Integer) As Boolean
            Dim p As New Players.Player()
            p.Load(PlayerID)

            Dim rs As RosterSlot
            Dim op As New Players.Player()
            Dim Result As Integer

            For Each rs In Me.InnerList
                op.Load(rs.PlayerID)
                If op.Position = p.Position Then
                    If op.ID <> p.ID Then
                        Result = Result + 1
                    End If
                End If
            Next

            Select Case p.Position
                Case Positions.ISMPlayerPosition.Defenseman
                    If Result >= 2 Then Return True
                Case Positions.ISMPlayerPosition.Forward
                    If Result >= 2 Then Return True
                Case Positions.ISMPlayerPosition.Goalie
                    If Result >= 1 Then Return True
                Case Positions.ISMPlayerPosition.Midfielder
                    If Result >= 1 Then Return True
            End Select
        End Function

        Friend Sub DropPlayer(ByVal TeamID As Integer, ByVal PlayerID As Integer)
            Dim ds As New DataServices.TeamTables()
            Dim rs As RosterSlot

            For Each rs In Me.InnerList
                If rs.PlayerID = PlayerID Then
                    ds.DeletePlayerFromRoster(rs.RosterSlotID)
                    Exit For
                End If
            Next

            Me.Load(TeamID)

        End Sub

        Friend Sub AddPlayer(ByVal PlayerID As Integer, ByVal TeamID As Integer)
            Dim ds As New DataServices.TeamTables()
            Dim rs As New RosterSlot()

            rs.Create(ds.InsertPlayerToRoster(PlayerID, TeamID), PlayerID, TeamID)
            Me.Add(rs)

        End Sub

        Friend Function GetNumberOfPlayersAtPosition(ByVal Position As Positions.ISMPlayerPosition)
            Dim p As New Players.Player()
            Dim r As RosterSlot
            Dim Result As Integer

            For Each r In Me.InnerList
                p.Load(r.PlayerID)
                If p.Position = Position Then
                    Result += 1
                End If
            Next

            Return Result
        End Function

        Friend Function GetNumberOfPlayersAtPosition(ByVal Position As Positions.ISMPlayerPosition, ByVal Players As ArrayList)
            Dim p As New Players.Player()
            Dim i As Integer
            Dim Result As Integer

            For i = 0 To Players.Count - 1
                p.Load(i)
                If p.Position = Position Then
                    Result += 1
                End If
            Next

            Return Result
        End Function









    End Class
End Namespace