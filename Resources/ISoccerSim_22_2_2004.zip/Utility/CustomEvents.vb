'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Players

Friend Enum ISMLoadMode
	Edit = 0
	AddNew = 1
End Enum

Friend Class ProgressEventEventArgs
	Inherits System.EventArgs

	Friend Message As String
	Friend PercentDone As Integer

	Sub New(ByVal strMessage As String, ByVal intPercentDone As Integer)
		Me.Message = strMessage
		Me.PercentDone = intPercentDone
	End Sub
End Class

Friend Class LeagueLoadedEventArgs
	Inherits System.EventArgs

	Friend Success As Boolean
	Sub New(ByVal blnSuccess As Boolean)
		Me.Success = blnSuccess
	End Sub
End Class

Friend Class CoachingDetailClosed
	Inherits System.EventArgs

	Friend TacticID As Integer
	Friend Probability As Integer
	Friend LoadMode As ISMLoadMode

	Sub New(ByVal TacticID As Integer, ByVal Probability As Integer, ByVal LoadMode As ISMLoadMode)
		Me.TacticID = TacticID
		Me.Probability = Probability
		Me.LoadMode = LoadMode
	End Sub
End Class

Friend Class PenaltyRaisedEventArgs
	Inherits System.EventArgs

	Friend Player As Player

	Sub New(ByVal Player As Player)
		Me.Player = Player
	End Sub

End Class


Friend Class PosessionChangedEventArgs
    Inherits System.EventArgs

    Sub New()

    End Sub
End Class

Friend Class TeamSelectedEventArgs
    Inherits System.EventArgs

    Friend TeamID As Integer
    Sub New(ByVal TeamID As Integer)
        Me.TeamID = TeamID
    End Sub
End Class

Friend Class PlayerSelectedEventArgs
    Inherits System.EventArgs

    Friend PlayerID As Integer
    Sub New(ByVal PlayerID As Integer)
        Me.PlayerID = PlayerID
    End Sub
End Class
