'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Friend Enum ISSimForm
    LeagueStandings = 1
    LeagueSettings = 2
    LeagueSchedule = 3
    LeagueImport = 4
    LeagueExport = 5
    LeagueDraft = 6
    CreateNewLeague = 7
    LoadLeague = 8
    SaveLeague = 9
    LeagueTactics = 10
    LeagueSituations = 11
    LeagueExhibition = 12
    LeagueStats = 13


    TeamSchedule = 16
    TeamRoster = 17
    TeamSubline = 18
    Testing = 19
    TeamCoaching = 20
    TeamSettings = 21
    TeamFinance = 22
    TeamTrade = 23

    OpenSkin = 100
    OpenProgramOptions = 101
    ProgramGuide = 102
    OptionsPlayByPlay = 103

End Enum

Friend Class Navigation
    Function GetLeagueMenu() As ListPicks

        Dim lstPicks As New ListPicks()
        With lstPicks

            .Create(ISSimForm.CreateNewLeague, "Create New League", False, False)
            .Create(ISSimForm.LoadLeague, "Open League", False, False)
            .Create(ISSimForm.SaveLeague, "Save League", False, False)

            .Create(ISSimForm.LeagueStandings, "Standings", True, False)
            .Create(ISSimForm.LeagueStats, "Statistics", True, True)
            .Create(ISSimForm.LeagueSchedule, "Schedule", True, False)
            .Create(ISSimForm.LeagueSettings, "Settings", True, False)

            .Create(ISSimForm.LeagueSituations, "Situations", True, False)
            .Create(ISSimForm.LeagueTactics, "Tactics", False, False)

            .Create(ISSimForm.LeagueImport, "Import", True, False)
            .Create(ISSimForm.LeagueExport, "Export", True, False)

            .Create(ISSimForm.LeagueExhibition, "Exhibition Game", True, True)

            .Text = "League Menu"
        End With
        Return lstPicks
    End Function

    Function GetTeamMenu() As ListPicks
        Dim lstPicks As New ListPicks()
        With lstPicks
            .Create(ISSimForm.TeamCoaching, "Coaching", True, False)
            .Create(ISSimForm.TeamFinance, "Finance", True, False)
            .Create(ISSimForm.TeamRoster, "Roster", True, False)
            .Create(ISSimForm.TeamSubline, "Substitution Lines", True, True)
            .Create(ISSimForm.TeamSettings, "Settings", True, False)
            .Create(ISSimForm.TeamTrade, "Trade", True, False)

            '.Create(ISSimForm.TeamSchedule, "Schedule", True)
            '.Create(ISSimForm.Testing, "Test Form", True)

            .Text = "Team Menu"
        End With
        Return lstPicks

    End Function

    Function GetOptionsMenu() As ListPicks
        Dim lstPicks As New ListPicks()
        With lstPicks
            .Create(ISSimForm.OpenSkin, "Active Skin", False, False)
            .Create(ISSimForm.OptionsPlayByPlay, "Play By Play", False, False)
            .Create(ISSimForm.OpenProgramOptions, "Program Options", False, False)
            .Create(ISSimForm.ProgramGuide, "Program Guide", False, False)
            .Text = "Options Menu"
        End With
        Return lstPicks

    End Function


End Class
