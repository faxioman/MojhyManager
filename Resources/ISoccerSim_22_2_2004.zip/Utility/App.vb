'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.IO
Imports System.Random
Imports ISoccerSim.SimEngine
Imports ISoccerSim.Ratings
Imports ISoccerSim.Positions
Imports ISoccerSim.Tactical
Imports ISoccerSim.Players
Imports ISoccerSim.Cities
Imports ISoccerSim.Leagues
Imports ISoccerSim.SimEngine.Results

Module App



    Friend Const WTD_SATURDAY = 2
    Friend Const WTD_WEDNESDAY = 0
    Friend Const WTD_FRIDAY = 1
    Friend Const WTD_FORMAT = "m/d/yyyy (ddd.)"

    Friend Const MONEY_FORMAT = "$#,###,###.00"

    Friend Const SE_HOMETEAM = 0
    Friend Const SE_AWAYTEAM = 1

    Friend Const GAME_STATUS_NOTPLAYED = 0
    Friend Const GAME_STATUS_PLAYED = 1
    Friend Const GAME_STATUS_NOTNEEDED = -1

    Friend Const GAME_PHASE_SEASON = 0
    Friend Const GAME_PHASE_PRESEASON = -1
    Friend Const GAME_PHASE_PLAYOFF = 1

    Friend IsUnitTesting As Boolean = True

    Friend DBConnect As New DatabaseConnection()
    Friend gApp As New Options()
    Friend gData As New DataServices.BaseTables()
    Friend gnavMainMenu As New Navigation()
    Friend mobjRandom As New Random(CInt(Date.Now.Ticks And Integer.MaxValue))

    'Base tables...
    Friend gsetFirstNames As New BaseSettingSet()
    Friend gsetLastNames As New BaseSettingSet()
    Friend gsetColleges As New BaseSettingSet()
    Friend gsetMascots As New BaseSettingSet()
    Friend gsetNicknames As New BaseSettingSet()
    Friend gsetTweaks As New BaseSettingSet()
    Friend gobjRateDistSet As New RatingDistributionSet()
    Friend gobjPlayerSkillSet As New PlayerSkillSet()
    Friend gobjPlayerAgeSet As New PlayerAging()
    Friend gobjPositionSet As New PositionSet()
    Friend gobjCities As New CitySet()
    Friend WithEvents gobjLeague As New League()
    Friend gobjOptions As New Options()
    Friend gobjPositionValues As New PositionValues()
    Friend gobjGamePositionSet As New GamePositionSet()
    Friend gobjTacticSet As New TacticSet()
    Friend gobjSituationSet As New SituationSet()
    Friend gobjUserSettings As New UserSettings()
    Friend gobjReferees As New RefereeSet()
    Friend gobjMediaSet As New Finances.MediaSet()

    Private IsLoaded As Boolean
    Private TestDirectory As String

    Sub LoadTestLeague()
        LoadGlobalAppSettings(False)
        gobjLeague.Load("My Soccer League")
    End Sub

    Sub ErrRtn(ByVal strModule As String, ByVal lngNumber As Long, ByVal strDescription As String)
        MsgBox(strModule & " - " & lngNumber & " - " & strDescription)
    End Sub

    Function RandomNumber(ByVal intLow As Integer, ByVal intHigh As Integer) As Integer
        If intLow > intHigh Then Return intHigh
        Return mobjRandom.Next(intLow, intHigh)
    End Function

    Sub LoadGlobalAppSettings(ByVal blnReloadSkin As Boolean)

        Try
            gsetFirstNames.Load(gData.GetFirstNames, "NameID", "FirstName")
            gsetLastNames.Load(gData.GetLastNames, "NameID", "LastName")
            gsetColleges.Load(gData.GetColleges, "CollegeID", "College")
            gsetMascots.Load(gData.GetMascots, "MascotID", "Mascot")
            gsetNicknames.Load(gData.GetNicknames, "NicknameID", "Nickname")
            gsetTweaks.Load(gData.GetTweaks, "Key", "Value")
            gobjRateDistSet.Load()
            gobjPlayerSkillSet.Load()
            gobjPlayerAgeSet.Load()
            gobjCities.Load()
            gobjPositionSet.Load()
            If blnReloadSkin = True Then gobjOptions.Load()
            gobjPositionValues.Load()
            gobjGamePositionSet.Load()
            gobjTacticSet.Load()
            gobjTacticSet.Sort()
            gobjSituationSet.Load()
            gobjUserSettings.Load()
            gobjReferees.Load()
            gobjMediaSet.Load()
        Catch ex As System.Exception
            '			ShowMessageBox("League Incompatability", "The league you are loading is not compatable " & _
            '			 " with the version of ISM you are using.  Please make sure you are running the latest " & _
            '			 " beta with leagues created from it.", Nothing)
            Call HandleException(Nothing, ex)

        End Try
    End Sub

    Function LoadDefaultLeague() As Boolean
        gobjUserSettings.Load()
        Try
            If gobjUserSettings.DefaultLeague.Trim.Length > 0 Then
                If Dir(GetCurrentDirectory() & "\leagues\" & gobjUserSettings.DefaultLeague & "\base.mdb") <> "" Then
                    Try
                        gobjLeague.Load(gobjUserSettings.DefaultLeague)
                        App.LoadGlobalAppSettings(True)
                    Catch ex As Exception
                        Call HandleException(Nothing, ex)
                    End Try
                    Return True
                Else
                    Return False
                End If
            End If
        Catch ex As Exception
            Call HandleException(Nothing, ex)
        End Try
    End Function

    'Utility stuff....
    Sub ErrRtn()

    End Sub

    Sub HandleException(ByVal Sender As Object, ByVal e As Exception)
        Dim tw As StreamWriter = File.AppendText(GetCurrentDirectory() & "\error.txt")

        With e
            tw.WriteLine("-----------")
            tw.WriteLine("Error:")
            tw.WriteLine(.Message)
            tw.WriteLine("Stack Trace:")
            tw.WriteLine(.StackTrace)
            tw.WriteLine("-----------")
            tw.Close()
        End With

        MsgBox("An error has occured.  An error.txt file has been created in the ISS directory.  Please email to the team!" & vbCrLf & vbCrLf & e.ToString)

    End Sub

    Sub HandleException(ByVal Sender As Object, ByVal t As ThreadExceptionEventArgs)
        Call HandleException(t, t.Exception)
    End Sub

    Friend Function GetOrdinal(ByVal intVal As Integer) As String
        Dim Out As String
        Select Case intVal
            Case 1
                Out = intVal & "st"
            Case 2
                Out = intVal & "nd"
            Case 3
                Out = intVal & "rd"
            Case Else
                Out = intVal & "th"
        End Select
        Return Out

    End Function

    Function GetCurrentDirectory() As String
        Dim strOut As String

        strOut = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly.Location)
        If Dir(strOut & "settings.xml") = "" Then
            If IsUnitTesting Then
                strOut = "C:\Work\ISM\ISoccerSim\bin"
            End If
        End If
        Return strOut
    End Function

    Function SetCurrentDirectory(ByVal strDirectory As String)
        TestDirectory = strDirectory
    End Function

    Function GetSkinDirectory() As String
        Dim Out As String = GetCurrentDirectory() & "\skins\" & gobjOptions.SkinDir & "\"
        Return Out
    End Function

    <STAThread()> _
    Sub Main()
        'Add standard error handler
        'AddHandler Application.ThreadException, New ThreadExceptionEventHandler(AddressOf HandleException)
        Dim f As New frmSplash()
        f.Show()
        If Not LoadDefaultLeague() Then
            Call SetupISS()
        End If

        f.Close()
        Application.Run(New frmMain())

    End Sub

    Private Sub Win98Trace(ByVal Message As String)
        Console.WriteLine(Message)
    End Sub

    Private Sub SetupISS()
        Dim gData As New DataServices.BaseTables()
        If IsLoaded = False Then
            LoadGlobalAppSettings(True)
            IsLoaded = True
        End If
    End Sub

    Sub ShowMessageBox(ByVal Title As String, ByVal Message As String, ByVal ParentForm As Form)
        Dim f As New frmDialog(Title, Message)
        f.ShowDialog(ParentForm)
    End Sub

    Sub SetCursor(ByVal ShowBusy As Boolean, ByVal ParentForm As Form)
        If ShowBusy Then
            ParentForm.Cursor = Windows.Forms.Cursors.WaitCursor
        Else
            ParentForm.Cursor = Windows.Forms.Cursors.Default
        End If
    End Sub

    Private Sub SetImage(ByVal f As Form)
        Dim Name As String = Mid(f.Name.Trim, 4)
        Dim FileImage As String
        If gobjOptions.Pictures.ContainsKey(Name) Then
            FileImage = gobjOptions.Pictures.Item(Name)
        Else
            FileImage = "default.png"
        End If

        FileImage = GetSkinDirectory() & FileImage

        If File.Exists(FileImage) Then
            f.SuspendLayout()
            f.BackgroundImage = Image.FromFile(FileImage)
            f.ResumeLayout()
        End If

    End Sub



    Sub SkinForm(ByVal f As Form)

        Call SetImage(f)

        With gobjOptions
            f.BackColor = .FormBackgroundColor
            f.ForeColor = .FormFontColor

            Dim pobjControl As Control
            For Each pobjControl In f.Controls
                If TypeOf pobjControl Is GroupBox Then
                    pobjControl.ForeColor = .FormFrameColor
                    pobjControl.BackColor = .FormBackgroundColor

                    Dim pobjChildControl As Control
                    For Each pobjChildControl In pobjControl.Controls
                        If TypeOf pobjChildControl Is DataGrid Then
                            Dim pobjGrid As DataGrid = CType(pobjChildControl, DataGrid)
                            pobjGrid.BackColor = .GridBackgroundColor
                            pobjGrid.HeaderForeColor = .GridHeadingColor
                            pobjGrid.CaptionBackColor = .GridCaptionColor
                            pobjGrid.CaptionForeColor = .GridCaptionFontColor
                            pobjGrid.ForeColor = .GridFontColor
                        End If

                        If (TypeOf pobjChildControl Is ComboBox) Or _
                         (TypeOf pobjChildControl Is ListBox) Or _
                         (TypeOf pobjChildControl Is TextBox) Or _
                         (TypeOf pobjChildControl Is TreeView) Or _
                         (TypeOf pobjChildControl Is ISMScrollBar) Then
                            pobjChildControl.BackColor = .InputBackColor
                            pobjChildControl.ForeColor = .InputFontColor
                        End If

                    Next
                End If

                If TypeOf pobjControl Is DataGrid Then
                    Dim pobjGrid As DataGrid = CType(pobjControl, DataGrid)
                    pobjGrid.BackColor = .GridBackgroundColor
                    pobjGrid.HeaderForeColor = .GridHeadingColor
                    pobjGrid.CaptionBackColor = .GridCaptionColor
                    pobjGrid.CaptionForeColor = .GridCaptionFontColor
                    pobjGrid.ForeColor = .GridFontColor
                End If


            Next
        End With
    End Sub

    Function IsFileNameLegal(ByVal strFileName As String) As Boolean

        Dim IllegalChars As String = "!@#$%^&*()';:{}[]"
        Dim c As Char

        For Each c In IllegalChars
            If strFileName.IndexOfAny(c.ToString) <> -1 Then
                Return False
            End If
        Next

        If strFileName.Trim.Replace(" ", "").Length = 0 Then
            Return False
        End If
        Return True

    End Function

    Friend Function GetTeamID(ByVal cmbGeneric As ComboBox) As Integer
        Return CType(cmbGeneric.SelectedItem, Teams.Team).TeamID
    End Function

    Friend Sub SetTeamCombo(ByRef cmbTeams As ComboBox)
        Dim pobjComboHelper As New DropDownUtility()
        Dim league As New Leagues.League()
        league = gobjLeague.Clone()

        With pobjComboHelper
            .DisplayMember = "City"
            .ValueMember = "City"
            .DataSource = league
            .Style = ComboBoxStyle.DropDownList    'DropDown
            .Sorted = True
            .Fill(cmbTeams)
        End With
    End Sub

    Friend Sub SetTeamCombo(ByRef cmbTeams As ComboBox, ByVal objTeam As Teams.Team)
        Call SetTeamCombo(cmbTeams)
        Call SetTeamInCombo(cmbTeams, objTeam.TeamID)
    End Sub

    Friend Sub SetTeamCombo(ByRef cmbTeams As ComboBox, ByVal TeamID As Integer)
        Call SetTeamCombo(cmbTeams)
        Call SetTeamInCombo(cmbTeams, TeamID)
    End Sub

    Friend Sub SetTeamInCombo(ByRef cmbTeams As ComboBox, ByVal TeamID As Integer)
        Dim pobjX As Teams.Team
        For Each pobjX In cmbTeams.Items
            If pobjX.TeamID = TeamID Then
                cmbTeams.SelectedItem = pobjX
                Exit Sub
            End If
        Next
    End Sub

    Friend Sub SetTeamInCombo(ByRef cmbTeams As ComboBox, ByVal objTeam As Teams.Team)
        Dim pobjX As Teams.Team
        For Each pobjX In cmbTeams.Items
            If pobjX.TeamID = objTeam.TeamID Then
                cmbTeams.SelectedItem = pobjX
                Exit Sub
            End If
        Next
    End Sub



End Module

