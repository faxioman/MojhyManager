Imports System
Imports NUnit.Framework

Namespace NUnit.Tests

    <TestFixture()> Public Class TestAttendanceManager

        Public Sub TestAttendanceMatchup()
            Dim obj As New Finances.AttendanceMatchup(0.05, 0)
            Dim i As Integer

            For i = 1 To 100
                Assertion.AssertEquals("Should be 0", 0, obj.GetRandomModifier)
            Next

            obj.Amount = 1
            For i = 1 To 100
                Assertion.AssertEquals("Should be <= max", IIf(obj.GetRandomModifier < 0.05, True, False), True)
            Next

            obj.Amount = 2
            For i = 1 To 100
                Assertion.AssertEquals("Should be <= max * 2", IIf(obj.GetRandomModifier < 0.1, True, False), True)
            Next

        End Sub

        Public Sub TestMediaObject()

            Dim obj As New Finances.MediaSet()
            obj.Load()
            Assertion.AssertEquals("Total items correct", 10, obj.Count)
            Assertion.AssertEquals("Booster name", "Booster", obj.Item(9).Name)
            Assertion.AssertEquals("Check total potential", 0.0451, obj.GetPotentialAttendanceBonus)

            Dim i As Integer
            For i = 1 To 100
                Console.WriteLine(obj.GetActualAttendanceBonus)
            Next

        End Sub

        Public Sub TestRanges()
            Dim ms As New Finances.MediaSet()
            ms.Load()
            Dim obj As New Finances.AttendanceManager(ms)
            Dim i As Integer
            For i = 1 To 100
                Assertion.AssertEquals("Nothing over capacity", True, IIf(obj.Compute <= obj.Capacity, True, False))
                Console.WriteLine(obj.Compute)
            Next
        End Sub

        Public Sub TestMatchups()
            Dim ms As New Finances.MediaSet()
            Dim i As Integer

            ms.Load()
            Dim am As New Finances.AttendanceManager(ms)

            am.SetAmounts(True, True, True, True, True, True, True, 10, Finances.AttendanceManager.HomeTeamRecord.Leading, 0)

            Console.WriteLine("All true - no stars")
            For i = 1 To 10
                Console.WriteLine(am.Compute)
            Next

            am.SetAmounts(True, True, True, True, True, True, True, 0, Finances.AttendanceManager.HomeTeamRecord.Leading, 0)

            Console.WriteLine("All true")
            For i = 1 To 10
                Console.WriteLine(am.Compute)
            Next

            'Typical season game... losing team...
            am.SetAmounts(False, False, True, False, False, False, False, 0, Finances.AttendanceManager.HomeTeamRecord.LosingTeam, 0)

            Console.WriteLine("Losers")
            For i = 1 To 10
                Console.WriteLine(am.Compute)
            Next

            'Typical season game... losing team in a nice new arena...
            am.SetAmounts(False, False, True, False, False, False, False, 0, Finances.AttendanceManager.HomeTeamRecord.LosingTeam, 0.2)

            Console.WriteLine("Losers")
            For i = 1 To 10
                Console.WriteLine(am.Compute)
            Next


            'Typical season game - two winning teams...
            am.SetAmounts(False, True, True, False, True, True, False, 4, Finances.AttendanceManager.HomeTeamRecord.Winning, 0)

            Console.WriteLine("Leaders")
            For i = 1 To 10
                Console.WriteLine(am.Compute)
            Next

            'Early season game - too close to tell...
            am.SetAmounts(False, True, True, False, True, False, False, 4, Finances.AttendanceManager.HomeTeamRecord.EarlySeason, 0)

            Console.WriteLine("Early game...")
            For i = 1 To 10
                Console.WriteLine(am.Compute)
            Next

            'Early season with tv coverage...
            For i = 0 To 9
                am.MediaSet.Item(i).Amount = am.MediaSet.Item(i).Maximum
            Next
            am.SetAmounts(False, True, True, False, True, False, False, 4, Finances.AttendanceManager.HomeTeamRecord.EarlySeason, 0)

            Console.WriteLine("Big fat contract...")
            For i = 1 To 10
                Console.WriteLine(am.Compute)
            Next
        End Sub

    End Class
End Namespace