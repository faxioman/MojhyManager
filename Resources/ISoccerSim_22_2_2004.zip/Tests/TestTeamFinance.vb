'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports NUnit.Framework

Namespace NUnit.Tests

    <TestFixture()> Public Class TestTeamFinance
        Public Sub TestDefaults()
            Dim obj As New Finances.TeamFinance()

            Assertion.AssertEquals("Check season attendance income", obj.GetTicketIncomeForSeason, 923400.0)
            Assertion.AssertEquals("Check fans per season", obj.TotalHomeFansForSeason, 97200)
            Assertion.AssertEquals("Check merchendise per season", obj.GetMerchendiseForSeason, 121500)
            Assertion.AssertEquals("Check concession income per season", obj.GetConcessionsForSeason, 155520)
            Assertion.AssertEquals("Check soccer camp income", obj.GetSoccerCampIncome, 520000)
            Assertion.AssertEquals("Check total income", obj.GetTotalIncome, 2720420)
            Assertion.AssertEquals("Check player salary", 300000, obj.GetPlayerSalaries)
            Assertion.AssertEquals("Check player housing", 120000, obj.GetPlayerHousingExpenses)
            Assertion.AssertEquals("Check player travel", 108000, obj.GetTravelExpenses)
            Assertion.AssertEquals("Check arena rental", 138000, obj.GetArenaRentalExpenses)
            Assertion.AssertEquals("Check halftime", 180000, obj.GetPromotionExpenses)
            Assertion.AssertEquals("Check community involvement", 180000, obj.GetCommunityExpenses)
            Assertion.AssertEquals("Check misc waste", 208600, obj.GetMiscExpenses)
            Assertion.AssertEquals("Check total expenses", 2494600.0, obj.GetTotalExpenses)
            Assertion.AssertEquals("Check profit", 225820, obj.GetNetIncome)

            obj.Attendance = 5000
            obj.PaidTicketPercentage = 1
            obj.ConcessionPercentage = 1

            Assertion.AssertEquals("Check game ticket stuff...", 50000, obj.GetTicketIncomeForGame)
            Assertion.AssertEquals("Check game concession stuff", 20000, obj.GetConcessionIncomeForGame)
            Assertion.AssertEquals("Check game merchandise...", 6250, obj.GetMerchendiseIncomeForGame)
            Assertion.AssertEquals("Check total income for game", 76250, obj.GetIncomeForGame)

            obj.PaidTicketPercentage = 0.5
            obj.ConcessionPercentage = 0.5

            Assertion.AssertEquals("Check game ticket stuff...", 25000, obj.GetTicketIncomeForGame)
            Assertion.AssertEquals("Check game concession stuff", 10000, obj.GetConcessionIncomeForGame)
            Assertion.AssertEquals("Check game merchandise...", 6250, obj.GetMerchendiseIncomeForGame)
            Assertion.AssertEquals("Check total income for game", 41250, obj.GetIncomeForGame)
            Assertion.AssertEquals("Expenses", 69294, obj.GetExpensesForGame)
        End Sub

    End Class
End Namespace