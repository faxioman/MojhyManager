'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Leagues
    Friend Class LeagueTree
        Inherits CollectionBase

        Default Property Item(ByVal index As Integer) As LeagueTreeNode
            Get
                Return CType(InnerList.Item(index), LeagueTreeNode)
            End Get
            Set(ByVal Value As LeagueTreeNode)
                InnerList.Item(index) = Value
            End Set
        End Property

        Sub Add(ByVal value As LeagueTreeNode)
            InnerList.Add(value)
        End Sub

        Friend Function GetTree() As LeagueTree
            Return GetTree(True)
        End Function

        Friend Function GetTree(ByVal IncludeTeams As Boolean) As LeagueTree
            Dim i As Integer
            Dim objConf As Conference
            Dim objDiv As Division
            Dim objTeam As Teams.Team

            Me.InnerList.Clear()

            Me.InnerList.Add(New LeagueTreeNode("League", gobjLeague.LeagueID, LeagueTreeNode.ISMIndentLevel.League))
            If gobjLeague.Conferences.Count > 1 Then
                For Each objConf In gobjLeague.Conferences
                    Me.InnerList.Add(New LeagueTreeNode(objConf.Name, objConf.ID, LeagueTreeNode.ISMIndentLevel.Conference, -1))
                    For Each objDiv In gobjLeague.GetDivisionsForConference(objConf.ID)
                        If gobjLeague.GetDivisionsForConference(objConf.ID).Count > 1 Then
                            Me.InnerList.Add(New LeagueTreeNode(" " & objDiv.Name, objDiv.ID, LeagueTreeNode.ISMIndentLevel.Division, objDiv.ID))
                        Else
                            Me.Item(Me.InnerList.Count - 1).DivisionID = objDiv.ID
                        End If

                        If IncludeTeams Then
                            For Each objTeam In gobjLeague.GetTeamsForDivision(objDiv.ID)
                                Me.InnerList.Add(New LeagueTreeNode(objTeam.Name, objTeam.TeamID, LeagueTreeNode.ISMIndentLevel.Team))
                            Next
                        End If
                    Next
                Next
            Else
                For Each objDiv In gobjLeague.Divisions
                    If gobjLeague.Divisions.Count > 1 Then
                        Me.InnerList.Add(New LeagueTreeNode(objDiv.Name, objDiv.ID, LeagueTreeNode.ISMIndentLevel.Division, objDiv.ID))
                    End If

                    If IncludeTeams Then
                        For Each objTeam In gobjLeague.GetTeamsForDivision(objDiv.ID)
                            Me.InnerList.Add(New LeagueTreeNode(objTeam.Name, objTeam.TeamID, LeagueTreeNode.ISMIndentLevel.Team))
                        Next
                    End If
                Next
            End If

            Call WashIndents()
            Return Me
        End Function

        Sub WashIndents()
            Dim pobjItem As LeagueTreeNode

            If Me.IsOneConferenceWithOneDivision Then
                Me.Item(0).DivisionID = 1
            End If
        End Sub

        Function IsOneConferenceWithOneDivision() As Boolean
            If gobjLeague.Divisions.Count = 1 And gobjLeague.Conferences.Count = 1 Then
                Return True
            End If
        End Function

    End Class

    Friend Class LeagueTreeNode

        Friend Name As String
        Friend ID As Integer
        Friend Indent As ISMIndentLevel
        Friend DivisionID As Integer

        Friend Enum ISMIndentLevel
            League = 0
            Conference = 1
            Division = 2
            Team = 3
        End Enum


        Friend Sub New(ByVal Name As String, ByVal ID As Integer, ByVal Indent As ISMIndentLevel)
            Call Create(Name, ID, Indent, -1)
        End Sub

        Friend Sub New(ByVal Name As String, ByVal ID As Integer, ByVal Indent As ISMIndentLevel, ByVal DivisionID As Integer)
            Call Create(Name, ID, Indent, DivisionID)
        End Sub

        Private Sub Create(ByVal Name As String, ByVal ID As Integer, ByVal Indent As ISMIndentLevel, ByVal DivisionID As Integer)
            Me.Name = Name
            Me.ID = ID
            Me.Indent = Indent
            Me.DivisionID = DivisionID
        End Sub

        Public Overrides Function ToString() As String
            Return New String(" ", 4 * Me.Indent) & Me.Name
        End Function


    End Class

End Namespace
