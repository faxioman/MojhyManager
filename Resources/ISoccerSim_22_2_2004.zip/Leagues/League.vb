'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.IO
Imports ISoccerSim.Substitution
Imports ISoccerSim.Positions
Imports ISoccerSim.Players
Imports ISoccerSim.Rosters
Imports ISoccerSim.Schedules
Imports ISoccerSim.Teams
Imports ISoccerSim.Cities
Imports ISoccerSim.Tactical

Namespace Leagues

	Friend Enum ISSLeaguePhase
		Preseason = 0
		RegularSeason = 1
		RegularSeasonNoTrade = 2
		Playoffs = 3
		EndOfSeason = 4
		FreeAgency = 5
		AmateurDraft = 6
		NewLeagueRegular = 7
		NewLeagueFreeAgency = 8
		Offseason = 9
	End Enum

	Friend Class League
		Inherits System.Collections.CollectionBase
		Implements ICloneable

		Friend Name As String
		Friend Championship As String
		Friend Abbreviation As String
		Friend PlayoffSeries As Integer
		Friend ChampionshipSeries As Integer
		Friend TeamsInPlayoff As Integer
		Friend InterdivisionMatchups As Integer
		Friend InterconferenceMatchups As Integer
		Friend IntraconferenceMatchups As Integer
		Private mintLeagueSize As Integer
		Friend LeagueID As Integer
		Friend Dir As New LeagueDir()
		Private TeamNames As New ArrayList()
		Friend Phase As ISSLeaguePhase

		Friend Season As Integer

		Friend MultiPoint As Boolean
		Friend DumpToFAPool As Boolean
		Friend Total As Integer
		Friend Conferences As New Conferences()
		Friend Divisions As New Divisions()
		Friend Schedule As New Schedule()
		Friend Standings As New Standings()

		Private mcolTeams As Collection

		Friend Event Progress(ByVal sender As Object, ByVal e As ProgressEventEventArgs)
		Friend Event Loaded(ByVal sender As Object, ByVal e As LeagueLoadedEventArgs)

		Friend Property LeagueSize() As Integer
			Get
				Return mintLeagueSize
			End Get
			Set(ByVal Value As Integer)
				mintLeagueSize = Value
			End Set
		End Property

		Default Property Item(ByVal index As Integer) As Team
			Get
				Return CType(InnerList.Item(index), Team)
			End Get
			Set(ByVal Value As Team)
				InnerList.Item(index) = Value
			End Set
		End Property

		Function GetTeamByID(ByVal index As Integer) As Team
			Dim pobjTeam As Team
			For Each pobjTeam In Me.InnerList
				If pobjTeam.TeamID = index Then
					Return pobjTeam
				End If
			Next
		End Function



		Sub Add(ByVal value As Team)
			InnerList.Add(value)
		End Sub

        Sub Create(ByVal TeamID As Integer, ByVal ConferenceID As Integer, ByVal DivisionID As Integer, ByVal Name As String, ByVal Nickname As String, _
           ByVal Logo As String, ByVal Mascot As String, ByVal OwnerEmail As String, ByVal OwnerName As String, _
           ByVal Abbreviation As String, ByVal IsCPUOwned As Boolean, ByVal CityID As Integer, ByVal FacilityID As Integer, _
           ByVal ExpectedAttendance As Integer)

            Dim pobjItem As New Team()
            With pobjItem
                .TeamID = TeamID
                .IsCPUOwned = IsCPUOwned
                .ConferenceID = ConferenceID
                .DivisionID = DivisionID
                .Logo = Logo
                .Mascot = Mascot
                .Name = Name
                .Nickname = Nickname
                .OwnerEmail = OwnerEmail
                .OwnerName = OwnerName
                .Abbreviation = Abbreviation
                .FacilityID = FacilityID
                .CityID = CityID
                .ExpectedAttendance = ExpectedAttendance
                Me.Total = Me.Total + 1
            End With

            InnerList.Add(pobjItem)
        End Sub

        Sub AddTeamName(ByVal strTeam As String, ByVal intConferenceID As Integer, ByVal intDivisionID As Integer)
            Dim pobjShell As New TeamShell()
            With pobjShell
                .ConferenceID = intConferenceID
                .DivisionID = intDivisionID
                .Name = strTeam
            End With
            Me.TeamNames.Add(pobjShell)
        End Sub


        Sub CreateNewLeague()

            gobjLeague = Nothing

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Cleaning database...", 5))
            Call Me.CleanDatabase()

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Setting up league file structure...", 10))
            Call Me.SetupLeagueFileStructure()

            gobjLeague = Me

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Setting up teams...", 15))
            Call Me.CreateRandomTeams()

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Creating league schedule...", 20))
            Call Me.SetupSchedule()

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Creating league players...", 25))
            Call Me.SetupPlayers()

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Creating team substitution sets...", 75))
            Call Me.CreateSubstitutionSets()

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Creating default team coaching profiles...", 85))
            Call Me.CreateCoachingProfiles()

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Creating default financial settings...", 90))
            Call Me.CreateMediaSettings()
            Call Me.CreateFinancialSettings()

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Creating referees...", 95))
            Call Me.CreateReferees()

            RaiseEvent Progress(Me, New ProgressEventEventArgs("Registering league settings...", 99))
            Call Me.InsertLeague()

            RaiseEvent Loaded(Me, New LeagueLoadedEventArgs(True))
            RaiseEvent Progress(Me, New ProgressEventEventArgs("Done.", 100))

            Exit Sub

ErrRtn:
            ErrRtn("League:CreateNewLeague", Err.Number, Err.Description)

        End Sub

        Private Sub CleanDatabase()
            Dim oDS As New DataServices.BaseTables()
            oDS.ClearDB()
        End Sub

        Private Sub CreateMediaSettings()
            Dim oDS As New DataServices.TeamTables()
            Dim TeamID As Integer
            Dim pobjItem As Finances.MediaItem
            Dim i As Integer

            For i = 0 To Me.Count - 1
                TeamID = CType(Me.InnerList.Item(i), Team).TeamID

                For Each pobjItem In gobjMediaSet
                    oDS.InsertTeamMedia(TeamID, pobjItem.MediaID, pobjItem.Default)
                Next
            Next
        End Sub

        Private Sub CreateFinancialSettings()
            Dim oDS As New DataServices.TeamTables()

            Dim i As Integer
            Dim tb As New Finances.TeamBudgets()

            For i = 0 To Me.Count - 1
                oDS.InsertTeamFinancesDefault(Me.Item(i).TeamID)
                tb.CalculateDefault(Me.Item(i).TeamID, Me.Schedule.GetHomeGamesForTeam(Me.Item(i).TeamID), Me.Item(i).ExpectedAttendance)
                tb.Insert()
            Next
        End Sub

        Private Sub CreateCoachingProfiles()
            Dim i As Integer
            Dim TeamID As Integer
            Dim pobjTeamSituationSet As TeamSituationSet
            Dim TeamSituationID As Integer

            For i = 0 To Me.Count - 1
                TeamID = CType(Me.InnerList.Item(i), Team).TeamID

                Dim pobjSituation As Situation
                For Each pobjSituation In App.gobjSituationSet
                    pobjTeamSituationSet = New TeamSituationSet(TeamID, pobjSituation.SituationID)
                    With pobjSituation
                        If .IsPenaltyKill Then
                            pobjTeamSituationSet.Create(ISMSublineType.PenaltyKill, ISMSublineType.SecondLine, 0, 90, 80)
                        ElseIf .IsPowerPlay Then
                            pobjTeamSituationSet.Create(ISMSublineType.PowerPlay, ISMSublineType.Starters, 0, 90, 80)
                        Else
                            pobjTeamSituationSet.Create(ISMSublineType.Starters, ISMSublineType.SecondLine, 0, 90, 80)
                        End If
                        TeamSituationID = pobjTeamSituationSet.Insert()
                    End With

                    Dim pobjTeamTactic As New TeamTactic()
                    With pobjTeamTactic
                        .Probability = 100
                        .TacticID = 0
                        .TeamSituationID = TeamSituationID
                        .Insert()
                    End With
                Next

            Next

        End Sub

        Private Sub CreateSubstitutionSets()
            Dim pobjRoster As New Roster()
            Dim pobjFactory As New SubstitutionLineFactory()
            Dim pobjSubSet As New SubstitutionLineSet()
            Dim TeamID As Integer
            Dim i As Integer

            If Me.DumpToFAPool Then Exit Sub
            Try
                For i = 0 To Me.Count - 1
                    TeamID = CType(Me.InnerList.Item(i), Team).TeamID
                    pobjRoster.Load(TeamID)

                    pobjSubSet = pobjFactory.GenerateLines(pobjRoster)
                    pobjSubSet.TeamID = TeamID
                    pobjSubSet.Insert()
                Next

            Catch ex As System.Exception
                Call HandleException(Me, ex)
            End Try



        End Sub

        Private Sub CreateRandomTeams()
            Dim i As Integer
            Dim pobjTeam As Team
            Dim pobjCity As City
            Dim pobjFacility As Facility
            Me.LeagueID = 1
            Me.Season = Date.Now.Year

            For i = 1 To Me.TeamNames.Count
                pobjTeam = New Team()
                pobjCity = New City()
                With pobjTeam
                    Dim pobjShell As TeamShell

                    'Set up faciliy/city stuff...
                    pobjShell = CType(Me.TeamNames(i - 1), TeamShell)
                    pobjCity = App.gobjCities.GetItemByKey(pobjShell.Name)
                    .CityID = pobjCity.CityID
                    pobjFacility = New Facility()
                    pobjFacility.InsertRandom(pobjCity)
                    .FacilityID = pobjFacility.FacilityID

                    'Set up base stuff...
                    .ConferenceID = pobjShell.ConferenceID
                    .DivisionID = pobjShell.DivisionID
                    .Abbreviation = pobjCity.GetAbbreviation
                    .IsCPUOwned = True
                    .Logo = ""
                    .Mascot = ""
                    .Name = pobjCity.City
                    .Nickname = GetRandomNickname()
                    .OwnerEmail = "cpu@ism.com"
                    .OwnerName = "CPU"
                    .ExpectedAttendance = pobjFacility.GetExpectedAttendance

                    .TeamID = i
                    Me.Create(.TeamID, .ConferenceID, .DivisionID, .Name, .Nickname, .Logo, .Mascot, .OwnerEmail, .OwnerName, .Abbreviation, .IsCPUOwned, .CityID, .FacilityID, .ExpectedAttendance)
                    .Save()
                    .Add(pobjTeam)
                End With
            Next


        End Sub

        Private Function GetRandomNickname() As String
            Dim pobjSetting As String
            Dim objTeam As Team
            Dim pblnUnique As Boolean

            Do
                pblnUnique = True
                pobjSetting = gsetNicknames.GetRandomItem().Value
                For Each objTeam In Me.InnerList
                    If objTeam.Nickname = pobjSetting Then pblnUnique = False
                Next
                If pblnUnique Then Exit Do
            Loop
            Return pobjSetting

        End Function

        Private Sub SetupSchedule()

            With Me.Schedule
                .mobjLeague = Me
                .CreateSchedule()
                .Save()
            End With

        End Sub

        Private Sub SetupPlayers()

            Dim i As Integer
            Dim x As Integer
            Dim intRosterID As Integer
            Dim pobjPlayer As New Player()
            Dim pobjRoster As New RosterSlot()
            Dim pobjFA As New FreeAgentSlot()
            Dim Msg As String
            Dim Progress As Integer


            'Generate base teams...
            For i = 1 To Me.Count
                For x = 1 To gsetTweaks.GetIntegerValueByKey("RosterSize")
                    intRosterID = intRosterID + 1

                    Msg = String.Format("Creating player #{3} for team {1} ({0} of {2})...", i, Me.TeamNames(i - 1), Me.Count, intRosterID)
                    Progress = ((((i / Me.Count) * 100) / 2) + 30)
                    RaiseEvent Progress(Me, New ProgressEventEventArgs(Msg, Progress))

                    'Distribute out somewhat evenly...
                    Select Case x
                        Case 1, 2
                            pobjPlayer.CreateByPosition(ISMPlayerPosition.Goalie, x)
                        Case 3, 5
                            pobjPlayer.CreateByPosition(ISMPlayerPosition.Defenseman, x)
                        Case 6, 7
                            pobjPlayer.CreateByPosition(ISMPlayerPosition.Midfielder, x)
                        Case 8, 10
                            pobjPlayer.CreateByPosition(ISMPlayerPosition.Forward, x)
                        Case Else
                            pobjPlayer.Create(x)
                    End Select

                    If Me.DumpToFAPool Then
                        With pobjFA
                            .Create(intRosterID, pobjPlayer.ID)
                            .Insert()
                        End With
                    Else
                        With pobjRoster
                            .Create(intRosterID, pobjPlayer.ID, i)
                            .Insert()
                        End With
                    End If
                Next
            Next

            'Generate random free agents...
            Msg = "Generating lower tier free agents..."
            RaiseEvent Progress(Me, New ProgressEventEventArgs(Msg, 85))
            For x = 1 To gsetTweaks.GetIntegerValueByKey("RosterSize")
                intRosterID = intRosterID + 1

                'Distribute out somewhat evenly...
                pobjPlayer.BuildWeak = True
                pobjPlayer.Create(0)

                With pobjFA
                    .Create(intRosterID, pobjPlayer.ID)
                    .Insert()
                End With
            Next

        End Sub

        Private Sub CreateReferees()
            Dim pobjR As Referee
            Dim i As Integer
            For i = 1 To (Me.Total * 3) + RandomNumber(1, 5)
                pobjR = New Referee()
                pobjR.Create()
                pobjR.Insert()
            Next

        End Sub

        Private Function GetRandomCity() As City
            Dim I As Integer
            Dim pblnOut As Boolean
            Dim Key As String
            Dim pobjCity As New City()


            pblnOut = False

            Do Until pblnOut = True
                pobjCity = gobjCities.GetRandomItemByProbability
                Key = pobjCity.City
                pblnOut = True

                For I = 0 To InnerList.Count - 1
                    If InnerList.Item(I).Name = Key Then
                        pblnOut = False
                    End If
                Next
            Loop
            Return pobjCity

        End Function

        Private Sub SetupLeagueFileStructure()


            Dim MainDir As String = GetCurrentDirectory() & "\leagues\"
            Dim MainCSSFile As String = GetCurrentDirectory() & "\data\ism.css"
            Dim Name As String = Me.Name
            Dim LeagueDir As String = GetCurrentDirectory() & "\leagues\" & Me.Name & "\"

            If Directory.Exists(LeagueDir) Then
                DBConnect.Pause()
                Directory.Delete(LeagueDir, True)
            End If

            Directory.CreateDirectory(MainDir)
            Directory.CreateDirectory(LeagueDir)
            Directory.CreateDirectory(LeagueDir & "box")
            Directory.CreateDirectory(LeagueDir & "games")
            Directory.CreateDirectory(LeagueDir & "log")
            Directory.CreateDirectory(LeagueDir & "remote")
            Directory.CreateDirectory(LeagueDir & "temp")
            File.Copy(MainCSSFile, LeagueDir & "ism.css")
            DBConnect.Pause()
            File.Copy(GetCurrentDirectory() & "\data\base.mdb", LeagueDir & "base.mdb")
            DBConnect.Connect(LeagueDir)
            Call SetupLeagueDirectoryLocations()

        End Sub

        Sub SetupLeagueDirectoryLocations()
            Dim LeagueDir As String = GetCurrentDirectory() & "\leagues\" & Me.Name & "\"
            Me.Dir.BoxScores = LeagueDir & "box"
            Me.Dir.Games = LeagueDir & "games"
            Me.Dir.Log = LeagueDir & "log"
            Me.Dir.Remote = LeagueDir & "remote"
            Me.Dir.Temp = LeagueDir & "temp"
        End Sub

        Sub Load(ByVal LeagueName As String)
            Me.Name = LeagueName
            Dim pobjDS As New DataServices.LeagueTables()
            Dim pobjDSTeams As New DataServices.TeamTables()
            pobjDS.Reconnect()
            pobjDSTeams.Reconnect()
            Dim pobjDR As OleDb.OleDbDataReader = pobjDS.GetLeague

            'Load base league information first...

            Do While pobjDR.Read()
                With Me
                    .InnerList.Clear()
                    .Abbreviation = pobjDR.Item("Abbreviation")
                    .Championship = pobjDR.Item("Championship")
                    .ChampionshipSeries = pobjDR.Item("ChampionshipSeries")
                    .InterconferenceMatchups = pobjDR.Item("InterconferenceMatchups")
                    .InterdivisionMatchups = pobjDR.Item("InterdivisionMatchups")
                    .IntraconferenceMatchups = pobjDR.Item("IntraconferenceMatchups")
                    .LeagueID = 1
                    .MultiPoint = pobjDR.Item("Multipoint")
                    .Name = pobjDR.Item("Name")
                    .PlayoffSeries = pobjDR.Item("PlayoffSeries")
                    .Season = pobjDR.Item("Season")
                    .TeamsInPlayoff = pobjDR.Item("TeamsInPlayoff")
                    .Phase = pobjDR.Item("Phase")
                End With
            Loop
            pobjDR.Close()

            'Load teams...
            Me.InnerList.Clear()

            pobjDR = pobjDSTeams.GetAllTeams

            Do While pobjDR.Read()
                Me.Create(pobjDR.Item("TeamID"), pobjDR.Item("ConferenceID"), _
                   pobjDR.Item("DivisionID"), pobjDR.Item("Name"), _
                   pobjDR.Item("Nickname"), pobjDR.Item("Logo"), _
                   pobjDR.Item("Mascot"), pobjDR.Item("OwnerEmail"), _
                   pobjDR.Item("OwnerName"), pobjDR.Item("Abbreviation"), pobjDR.Item("IsCPUOwned"), _
                pobjDR.Item("CityID"), pobjDR.Item("FacilityID"), pobjDR.Item("ExpectedAttendance"))
                Me.Total = Me.Count
            Loop
            pobjDR.Close()

            Me.Conferences.Load()
            Me.Divisions.Load()
            Me.Schedule.mobjLeague = Me
            Me.Schedule.Load()
            Me.Standings.mobjLeague = Me
            Me.Standings.Load()


            SetupLeagueDirectoryLocations()
            RaiseEvent Loaded(Me, New LeagueLoadedEventArgs(True))
        End Sub

        Sub InsertLeague()
            Dim pobjData As New DataServices.LeagueTables()
            If Me.DumpToFAPool = True Then
                Me.Phase = ISSLeaguePhase.NewLeagueFreeAgency
            Else
                Me.Phase = ISSLeaguePhase.NewLeagueRegular
            End If
            pobjData.InsertLeague(Me)
            pobjData.Close()

            Dim pobjConference As Conference
            For Each pobjConference In Me.Conferences
                pobjConference.Save()
            Next

            Dim pobjDivision As Division
            For Each pobjDivision In Me.Divisions
                pobjDivision.Save()
            Next
        End Sub

        Function Clone() Implements ICloneable.Clone
            Dim pobjLeague As New League()
            pobjLeague = Me
            pobjLeague.InnerList.Sort()
            Return pobjLeague
        End Function

        Private Function GetTempDirectory() As String
            Return GetCurrentDirectory() & "\leagues\" & Me.Name & "\temp\"
        End Function

        Function GetTempBoxScoreFilePath() As String
            Return Me.GetTempDirectory & "box.html"
        End Function

        Function GetTempGameLogFilePath() As String
            Return Me.GetTempDirectory & "log.html"
        End Function

        Function GetScheduledGameBoxFileName(ByVal ID As Integer) As String
            Return GetCurrentDirectory() & "\leagues\" & Me.Name & "\box\box" & Format(ID, "0000") & ".html"
        End Function

        Function GetScheduledEventLogFileName(ByVal ID As Integer) As String
            Return GetCurrentDirectory() & "\leagues\" & Me.Name & "\games\log" & Format(ID, "0000") & ".html"
        End Function

        Function GetScheduledPBPFileName(ByVal ID As Integer) As String
            Return GetCurrentDirectory() & "\leagues\" & Me.Name & "\log\pbp" & Format(ID, "0000") & ".html"
        End Function


        Function GetStyleSheetTemplateFilePath() As String
            Return GetCurrentDirectory() & "\leagues\" & Me.Name & "\ism.css"
        End Function

        Function GetTempGameEventLogFilePath() As String
            Return Me.GetTempDirectory & "event.html"
        End Function

        Function CanRunExhibition() As Boolean
            If Me.Phase = ISSLeaguePhase.NewLeagueRegular Or Me.Phase = ISSLeaguePhase.RegularSeason Or _
             Me.Phase = ISSLeaguePhase.RegularSeasonNoTrade Or Me.Phase = ISSLeaguePhase.Preseason Or _
             Me.Phase = ISSLeaguePhase.EndOfSeason Then
                Return True
            Else
                Return False
            End If
        End Function

        Function GetDivisionsForConference(ByVal intConferenceID As Integer) As ArrayList
            Dim pobjDiv As Division
            Dim parrOut As New ArrayList()

            For Each pobjDiv In Me.Divisions
                If pobjDiv.ConferenceID = intConferenceID Then
                    parrOut.Add(pobjDiv)
                End If
            Next
            parrOut.Sort()
            Return parrOut
        End Function

        Function GetTeamsForDivision(ByVal intDivisionID As Integer) As ArrayList
            Dim pobjTeam As Team
            Dim parrOut As New ArrayList()

            For Each pobjTeam In Me.InnerList
                If pobjTeam.DivisionID = intDivisionID Then
                    parrOut.Add(pobjTeam)
                End If
            Next
            parrOut.Sort()
            Return parrOut
        End Function


    End Class
End Namespace