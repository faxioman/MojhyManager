'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Reporting
    Friend Class TextReportFormatService
        Inherits ReportFormatService


        Public Overrides Sub Generate()
            Call WriteHeader()
            Call WriteBody()
            Call WriteFooter()
        End Sub

        Private Sub WriteBody()
            Dim pobjTable As ReportTable
            For Each pobjTable In Me.Report
                Me.Build("Title:" & pobjTable.Header)
                Call WriteTableColumns(pobjTable)
                Call WriteTableData(pobjTable)
                Me.Build(GetDivider())
            Next
        End Sub

        Private Function WriteTableColumns(ByVal objReportTable As ReportTable) As String
            Dim Out As New String(" ", Me.ReportWidth)
            Dim pobjCol As ReportColumn
            Dim Header As String
            Dim i As Integer = 1

            For Each pobjCol In objReportTable
                If pobjCol.Width > 0 Then
                    Header = Left(pobjCol.Column, pobjCol.Width - 1)
                    Mid(Out, i, Header.Length) = Header
                    i = i + pobjCol.Width
                End If
            Next
            Me.Build(Out)
        End Function

        Private Function WriteTableData(ByVal objReportTable As ReportTable) As String
            Dim pobjItem As ReportRow
            Dim Out As String

            For Each pobjItem In objReportTable.Data
                Out = Out & WriteTableRow(objReportTable, pobjItem)
            Next
            Me.Build(Out)
            Return Out
        End Function

        Private Function WriteTableRow(ByVal objTable As ReportTable, ByVal objRow As ReportRow) As String
            Dim intCols As Integer = objTable.Count - 1
            Dim i As Integer
            Dim pobjCol As ReportColumn
            Dim Out As New String(" ", Me.ReportWidth)
            Dim pobjValue As Object
            Dim x As Integer = 1

            For i = 0 To intCols
                pobjCol = objTable.Item(i)
                If pobjCol.Width > 0 Then
                    pobjValue = objRow.Data(i)
                    If Len(pobjValue) > pobjCol.Width - 1 Then
                        pobjValue = Left(pobjValue, pobjCol.Width - 1)
                    End If

                    If pobjCol.RightAlign Then
                        pobjValue = CStr(pobjValue)
                        Mid(Out, x, pobjCol.Width) = pobjValue.PadLeft(pobjCol.Width - Len(pobjValue), " ")
                    Else
                        Mid(Out, x, Len(pobjValue)) = pobjValue
                    End If

                    x = x + pobjCol.Width
                End If
            Next
            Out = Out & vbCrLf
            Return Out

        End Function

        Private Sub WriteHeader()
            Me.Build(Report.Header)
            Me.Build(GetDivider())
        End Sub

        Private Sub WriteFooter()
            Me.Build(GetDivider())
        End Sub

        Private Function GetDivider() As String
            Dim Out As New String(".", Me.ReportWidth)
            Return Out
        End Function

    End Class
End Namespace