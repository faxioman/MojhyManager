'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.SimEngine.Results


Namespace SimEngine.Reporting
	Friend Class ArrayListDelimiter

		Friend Delimiter As String = ","

		Function ArrayListToCommas(ByVal Title As String, ByVal objGameResultSet As GameResultSet, ByVal Sort As Boolean) As String

			Dim pobjArrayList As New ArrayList()
			Dim pobjItem As GameResultItem
			Dim Total As Integer
			Dim pblnTotalInSet As Boolean

			If Sort Then
				objGameResultSet.Sort()
			End If

			For Each pobjItem In objGameResultSet
				If pobjItem.Value <> -1 Then
					If pobjItem.Total Then
						Total = pobjItem.Value
						pblnTotalInSet = True
					Else
						pobjArrayList.Add(pobjItem.Value & " - " & pobjItem.Name)
					End If
				Else
					pobjArrayList.Add(pobjItem.Name)
				End If
			Next
			If pblnTotalInSet Then
				Return "<b>" & Title & " (" & Total & ")</b>: " & ArrayListToCommas(pobjArrayList)
			Else
				Return "<b>" & Title & "</b>: " & ArrayListToCommas(pobjArrayList)
			End If

		End Function

		Function ArrayListToCommas(ByVal objGameResultSet As GameResultSet) As String
			objGameResultSet.Sort()
			Dim pobjArrayList As New ArrayList()
			Dim pobjItem As GameResultItem
			For Each pobjItem In objGameResultSet
				pobjArrayList.Add(pobjItem.Value & " - " & pobjItem.Name)
			Next
			Return ArrayListToCommas(pobjArrayList)

		End Function

		Function ArrayListToCommas(ByVal objArrayList As ArrayList) As String
			Dim i As Integer
			Dim Out As String

			If objArrayList Is Nothing Then Return "None."

			With objArrayList
				If .Count = 0 Then Return "None."

				For i = 0 To .Count - 1
					Out = Out & .Item(i)
					If i < .Count - 1 Then
						Out = Out & Me.Delimiter & " "
					Else
						Out = Out & "."
					End If
				Next
				Return Out
			End With

		End Function
	End Class
End Namespace
