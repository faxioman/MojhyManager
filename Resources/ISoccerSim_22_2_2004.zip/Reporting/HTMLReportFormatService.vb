'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.IO

Namespace Reporting
	Friend Class HTMLReportFormatService
		Inherits ReportFormatService

		Public Overrides Sub Generate()
			Call WriteHeader()
			Call WriteBody()
			Call WriteFooter()
		End Sub

		Private Sub WriteBody()
			
			Dim pobjTable As ReportTable
			For Each pobjTable In Me.Report
				Me.Build("<p style=tableheading>" & pobjTable.Header & "</p>", 2)
				Me.Build("<table width=" & GetReportWidth() & " class=HxLinkTable>", 2)
				Call WriteTableColumns(pobjTable)
				Call WriteTableData(pobjTable)
				Me.Build("</table>", 2)
				'Me.Build(GetDivider(), 2)
			Next
			Me.Build("</div>", 1)
			Me.Build("</body>", 1)
		End Sub

		Private Function WriteTableColumns(ByVal objReportTable As ReportTable) As String
			Dim Out As String
			Dim pobjCol As ReportColumn
			Dim Header As String
			Dim i As Integer = 1

			Out = "<thead><tr>"

			For Each pobjCol In objReportTable
				If pobjCol.Width > 0 Then
					Out = Out & "<th>" & pobjCol.Column & "</th>"
				End If
			Next
			Out = Out & "</tr></thead>"
			Me.Build(Out)
		End Function

		Private Sub WriteTableData(ByVal objReportTable As ReportTable)
			Dim pobjItem As ReportRow

			For Each pobjItem In objReportTable.Data
				Me.Build(WriteTableRow(objReportTable, pobjItem))
			Next
		End Sub

		Private Function WriteTableRow(ByVal objTable As ReportTable, ByVal objRow As ReportRow) As String
			Dim intCols As Integer = objTable.Count - 1
			Dim i As Integer
			Dim pobjCol As ReportColumn
			'Dim Out As New String(" ", Me.ReportWidth)
			Dim pobjValue As Object
			Dim x As Integer = 1
			Dim Align As String
			Dim Out As New System.Text.StringBuilder()

			For i = 1 To Me.ReportWidth
				Out.Append(" ")
			Next
			Out.Append("<tr>")

			For i = 0 To intCols
				pobjCol = objTable.Item(i)
				If pobjCol.Width > 0 Then
					pobjValue = objRow.Data(i)

					If pobjCol.RightAlign Then
						Align = "right"
					Else
						Align = "left"
					End If

					pobjValue = CStr(pobjValue)
					Out.Append("<td align=")
					Out.Append(Align)
					Out.Append(" width=")
					Out.Append(GetColumnWidth(pobjCol.Width))
					Out.Append(">")
					Out.Append(pobjValue)
					Out.Append("</td>")

					'Out = Out & "<td align=" & Align & " width=" & GetColumnWidth(pobjCol.Width) & ">"
					'Out = Out & pobjValue
					'Out = Out & "</td>"

				End If
			Next
			Out.Append("</tr>")
			Out.Append(vbCrLf)

			Return Out.ToString

		End Function

		Private Function GetColumnWidth(ByVal intValue As Integer) As Integer
			Dim dblOut As Double
			If intValue > 0 Then
				dblOut = intValue / Me.ReportWidth
				dblOut = Int(dblOut * 640)
			End If
			Return dblOut
		End Function

		Private Function GetReportWidth() As Integer
			Dim dblOut As Integer

			dblOut = Int((Me.ReportWidth / 80) * 640)

			Return dblOut
		End Function

		Private Sub WriteHeader()
			Me.Build("<html>")
			Me.Build("<head>", 1)
			Me.Build("<title>" & Report.Header & "</title>", 2)
			Me.Build(Me.GetStyleSheet())
			'Me.Build("<link rel='stylesheet' type='text/css' href='..\ism.css'>", 2)
			Me.Build("</head>", 1)

			Me.Build("<body>", 1)
			Me.Build("<div id='nstext'>", 1)
			Me.Build("<h1>" & Me.Report.Header & "</h1>")
			Me.Build("<h4>" & Me.Report.Subheader & "</h4><hr>")

		End Sub

		Private Sub WriteFooter()
			Me.Build("</html>")
		End Sub

		Private Function GetDivider() As String
			Return "<hr>"
		End Function

		Private Function GetStyleSheet()
			Dim objReader As New StreamReader(gobjLeague.GetStyleSheetTemplateFilePath)
			Dim Out As String
			Out = "<style>" & objReader.ReadToEnd & "</style>"
			objReader.Close()
			Return Out
		End Function


	End Class
End Namespace
