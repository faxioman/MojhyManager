'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.Collections

Namespace Finances
	Friend Class MediaSet
        Inherits System.Collections.CollectionBase

        Friend Enum MediaType
            Basic = 1
            Radio = 2
            Newsprint = 3
            LocalTV = 4
            RegionalTV = 5
            NationalTV = 6
            PrimeTV = 7
            Internet = 8
            Outdoor = 9
            Booster = 10
        End Enum

        Default Property Item(ByVal index As MediaType) As MediaItem
            Get
                Return CType(InnerList.Item(index - 1), MediaItem)
            End Get
            Set(ByVal Value As MediaItem)
                InnerList.Item(index - 1) = Value
            End Set
        End Property

        Sub Add(ByVal value As MediaItem)
            InnerList.Add(value)
        End Sub

        Sub Create(ByVal Abbreviation As String, ByVal BonusPerGame As Double, ByVal Cost As Integer, ByVal [Default] As Integer, _
        ByVal Level As Integer, ByVal Maximum As Integer, ByVal Minimum As Integer, ByVal MediaID As Integer, ByVal Name As String, _
        ByVal Amount As Integer)

            Dim pobjItem As New MediaItem()
            With pobjItem
                .Abbreviation = Abbreviation
                .Amount = Amount
                .BonusPerGame = BonusPerGame
                .Cost = Cost
                .Default = [Default]
                .Level = Level
                .Maximum = Maximum
                .Minimum = Minimum
                .MediaID = MediaID
                .Name = Name
            End With
            Me.Add(pobjItem)
        End Sub

        Sub Load(ByVal TeamID As Integer)
            Dim pobjDS As New DataServices.TeamTables()
            Dim pobjDR As OleDb.OleDbDataReader

            pobjDR = pobjDS.GetMediaForTeam(TeamID)

            Me.Clear()
            With pobjDR
                Do While .Read()
                    Me.Create(.Item("Abbreviation"), .Item("BonusPerGame"), .Item("Cost"), .Item("DefaultAmount"), _
                     .Item("Level"), .Item("MaxAmount"), .Item("MinAmount"), .Item("MediaID"), .Item("Name"), .Item("Amount"))
                Loop
            End With
            pobjDR.Close()
        End Sub

        Sub Load()
            Dim pobjDS As New DataServices.BaseTables()
            Dim pobjDR As OleDb.OleDbDataReader

            pobjDR = pobjDS.GetMedia

            Me.Clear()
            With pobjDR
                Do While .Read()
                    Me.Create(.Item("Abbreviation"), .Item("BonusPerGame"), .Item("Cost"), .Item("DefaultAmount"), _
                     .Item("Level"), .Item("MaxAmount"), .Item("MinAmount"), .Item("MediaID"), .Item("Name"), .Item("DefaultAmount"))
                Loop
            End With
            pobjDR.Close()

        End Sub

        Friend Function GetActualAttendanceBonus()
            Return RandomNumber((Me.Item(MediaType.Basic).BonusPerGame * 100), (Me.GetPotentialAttendanceBonus * 100)) / 100
        End Function

        Friend Function GetPotentialAttendanceBonus()
            Dim objItem As MediaItem
            Dim Result As Double

            For Each objItem In Me
                If objItem.Amount > 0 Then
                    Result += objItem.BonusPerGame * objItem.Amount
                End If
            Next

            Return Result
        End Function


    End Class
End Namespace