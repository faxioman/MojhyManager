'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace Finances
    Friend Class TeamFinance
        Friend AvgAttendance As Integer = 5400
        Friend HomeGames As Integer = 18
        Friend Players As Integer = 20
        Friend Attendance As Integer = 5400

        Friend AvgTicketPrice As Double = 10.0
        Friend AvgMerchendisePerCapita As Double = 1.25
        Friend PaidTicketPercentage As Double = 0.95
        Friend ConcessionPercentage As Double = 0.4
        Friend ConcessionPerCapita As Double = 4.0

        Friend Sponsorship As Integer = 1000000
        Friend SoccerCampProfit As Integer = 40000
        Friend SoccerCampsPerOffseason As Integer = 13

        Friend AvgPlayerSalary As Integer = 15000
        Friend HousingCost As Integer = 15000
        Friend HousingPercentage As Double = 0.4

        Friend LeagueDues As Integer = 200000
        Friend AvgTravelCostPerPlayerPerGame As Double = 300.0
        Friend ArenaRentalPerGame As Integer = 6000
        Friend CommunityEventCost As Integer = 10000
        Friend PromotionCost As Integer = 10000
        Friend Overhead As Double = 0.1
        Friend ExtraNightsToRentFor As Integer = 5

        Friend MarketingAndMedia As Integer = 360000
        Friend FrontOffice As Integer = 700000

        'Income...

        Friend Function TotalHomeFansForSeason() As Integer
            Return Me.AvgAttendance * Me.HomeGames
        End Function

        Friend Function GetTicketIncomeForSeason() As Double
            Return Me.TotalHomeFansForSeason * Me.AvgTicketPrice * Me.PaidTicketPercentage
        End Function

        Friend Function GetMerchendiseForSeason() As Double
            Return Me.TotalHomeFansForSeason * Me.AvgMerchendisePerCapita
        End Function

        Friend Function GetConcessionsForSeason() As Double
            Return Me.TotalHomeFansForSeason * Me.ConcessionPerCapita * Me.ConcessionPercentage
        End Function

        Friend Function GetSoccerCampIncome() As Double
            Return Me.SoccerCampProfit * Me.SoccerCampsPerOffseason
        End Function

        Friend Function GetTotalIncome() As Double
            Return Me.GetConcessionsForSeason + Me.GetMerchendiseForSeason + _
                  Me.GetSoccerCampIncome + Me.GetTicketIncomeForSeason + Me.Sponsorship
        End Function

        'Expenses...
        Friend Function GetPlayerSalaries() As Double
            Return Me.AvgPlayerSalary * Me.Players
        End Function

        Friend Function GetPlayerHousingExpenses() As Double
            Return Me.Players * Me.HousingCost * Me.HousingPercentage
        End Function

        Friend Function GetTravelExpenses() As Double
            Return Me.Players * Me.HomeGames * Me.AvgTravelCostPerPlayerPerGame
        End Function

        Friend Function GetArenaRentalExpenses() As Double
            Return Me.ArenaRentalPerGame * (Me.HomeGames + Me.ExtraNightsToRentFor)
        End Function

        Friend Function GetCommunityExpenses() As Double
            Return Me.CommunityEventCost * Me.HomeGames
        End Function

        Friend Function GetPromotionExpenses() As Double
            Return Me.PromotionCost * Me.HomeGames
        End Function


        Friend Function GetMiscExpenses() As Double
            Return Me.GetItemizedExpenses * Me.Overhead
        End Function

        Friend Function GetItemizedExpenses() As Double
            Return (Me.GetArenaRentalExpenses + Me.GetCommunityExpenses + _
                    Me.GetPlayerHousingExpenses + Me.GetPlayerSalaries + _
                    Me.GetPromotionExpenses + Me.GetTravelExpenses + _
                    Me.MarketingAndMedia + Me.FrontOffice)
        End Function

        Friend Function GetTotalExpenses() As Double
            Return Me.GetMiscExpenses + Me.LeagueDues + Me.GetItemizedExpenses
        End Function

        Friend Function GetNetIncome() As Double
            Return Me.GetTotalIncome - Me.GetTotalExpenses
        End Function

        Friend Function GetTicketIncomeForGame()
            Return Attendance * (Me.AvgTicketPrice * Me.PaidTicketPercentage)
        End Function

        Friend Function GetConcessionIncomeForGame()
            Return Attendance * (Me.ConcessionPerCapita * Me.ConcessionPercentage)
        End Function

        Friend Function GetMerchendiseIncomeForGame()
            Return Attendance * Me.AvgMerchendisePerCapita
        End Function

        Friend Function GetIncomeForGame()
            Return Me.GetTicketIncomeForGame + Me.GetConcessionIncomeForGame + Me.GetMerchendiseIncomeForGame()
        End Function

        Friend Function GetExpensesForGame()
            Return Int(Me.GetTotalExpenses / (Me.HomeGames * 2))
        End Function

        Friend Function GetNetIncomeForGame()
            Return Me.GetIncomeForGame - Me.GetExpensesForGame
        End Function

        Friend Sub Load(ByVal TeamID As Integer)
            Dim ds As New DataServices.TeamTables()
            Dim dr As OleDb.OleDbDataReader

            dr = ds.GetTeamFinances(TeamID)
            Do While dr.Read()
                Me.AvgTicketPrice = dr("AvgTicketPrice")
                Me.AvgMerchendisePerCapita = dr("AvgMerchendisePC")
                Me.ArenaRentalPerGame = dr("ArenaRentalPerGame")
                Me.AvgPlayerSalary = dr("AvgPlayerSalary")
                Me.AvgTicketPrice = dr("AvgTicketPrice")
                Me.AvgTravelCostPerPlayerPerGame = dr("AvgTravelPerPlayerPerGame")
                Me.CommunityEventCost = dr("CommunityEventCost")
                Me.ConcessionPerCapita = dr("ConcessionPC")
                Me.ConcessionPercentage = dr("ConcessionPct")
                Me.ExtraNightsToRentFor = dr("ExtraNightsToRentFor")
                Me.FrontOffice = dr("FrontOffice")
                Me.HousingCost = dr("HousingCost")
                Me.HousingPercentage = dr("HousingPct")
                Me.LeagueDues = dr("LeagueDues")
                Me.Overhead = dr("Overhead")
                Me.PaidTicketPercentage = dr("PaidTicketPercentage")
                Me.PromotionCost = dr("PromotionCost")
                Me.SoccerCampProfit = dr("SoccerCampProfit")
                Me.SoccerCampsPerOffseason = dr("SoccerCamps")
                Me.Sponsorship = dr("Sponsorship")
            Loop

            dr.Close()

        End Sub
    End Class
End Namespace
