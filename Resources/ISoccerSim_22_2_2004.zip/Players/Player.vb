'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Ratings
Imports ISoccerSim.Positions
Imports ISoccerSim.Statistics


Namespace Players

	Friend Class Player
		Inherits Person
		Implements IComparable

        Friend Jersey As Byte
        Friend College As String
        Friend HighSchool As String
        Friend Position As ISMPlayerPosition
        Friend Foot As ISMPlayerFavors
        Friend BuildWeak As Boolean
        Friend Ratings As New RatingSet()
        Friend GamePosition As ISoccerSim.SimEngine.ISMGamePosition
        Friend Stats As New StatSet()
        Friend StarPlayer As Integer

        Friend CurrentEnergy As Integer = 100
        Friend Health As Integer = 0
        Friend FoulsPerHalf As Integer
        Friend TimePenaltyFoulsInGame As Integer
        Friend TimePenaltySet As New SimEngine.Penalty.TimePenaltySet()

        Friend Enum ISMPlayerFavors
            RightFoot = 0
            LeftFoot = 1
            BothFeet = 2
        End Enum


        Sub CreateByPosition(ByVal PositionID As ISMPlayerPosition, ByVal x As Integer)
            MyBase.Create()
            Call SetJersey(x)
            If Me.Age > 21 Then
                Me.College = gsetColleges.GetRandomItem.Value
            Else
                Me.College = "None"
            End If

            Dim R As Integer = RandomNumber(1, 10)
            Select Case R
                Case 1 To 5
                    Me.HighSchool = Me.Hometown
                Case 6 To 7
                    Me.HighSchool = gsetLastNames.GetRandomItem.Value
                Case 8 To 9
                    Me.HighSchool = gsetFirstNames.GetRandomItem.Value & " " & gsetLastNames.GetRandomItem.Value
                Case 10
                    Me.HighSchool = gsetLastNames.GetRandomItem.Value & " " & gsetLastNames.GetRandomItem.Value
            End Select
            Me.HighSchool = Me.HighSchool & " H.S."

            If RandomNumber(1, 10) < 8 Then
                Me.Foot = ISMPlayerFavors.RightFoot
            Else
                Me.Foot = ISMPlayerFavors.LeftFoot
            End If

            Me.Position = PositionID
            Me.Insert()

            'Set up player specific random details...
            'Pick up weak players if asked for by base class...
            Dim pobjRateSet As New RatingSet()
            Dim pobjAge As New PlayerAge()
            pobjAge = gobjPlayerAgeSet.GetRandomItemByProbability

            Dim pobjSkill As New PlayerSkillLevel()
            If Me.BuildWeak Then
                pobjSkill = gobjPlayerSkillSet.Item(0)
            Else
                pobjSkill = gobjPlayerSkillSet.GetRandomItemByProbability
            End If
            Call SetStarPlayer(pobjSkill)
            pobjRateSet.CreateSet(Me, pobjAge, pobjSkill)
            Me.Ratings = pobjRateSet

        End Sub

        Friend Sub SetStarPlayer(ByVal objSkill As PlayerSkillLevel)
            Select Case objSkill.PlayerSkillID
                Case 1
                    Me.StarPlayer = 3
                Case 2
                    Me.StarPlayer = 2
                Case 3
                    Me.StarPlayer = 1
                Case Else
                    Me.StarPlayer = 0
            End Select
        End Sub

        Shadows Sub Create(ByVal x As Integer)

            MyBase.Create()
            Me.Position = gobjPositionSet.GetRandomStockPositionByProbability.PositionID
            Call Me.CreateByPosition(Me.Position, x)

        End Sub

        Sub Insert()
            Dim pobjData As New DataServices.PlayerTables()
            Me.ID = pobjData.InsertPlayer(Me)
            pobjData.Close()
        End Sub

        Sub Save()
            Dim pobjData As New DataServices.PlayerTables()
            pobjData.InsertPlayer(Me)
            pobjData.Close()
        End Sub

        Sub Load(ByVal intPlayerID As Integer)
            Me.ID = intPlayerID
            Me.Load()
        End Sub

        Sub Update()
            Dim pobjData As New DataServices.PlayerTables()
            pobjData.UpdatePlayerCard(Me)
        End Sub

        Sub Load()
            Dim pobjData As New DataServices.PlayerTables()
            Dim pobjDR As OleDb.OleDbDataReader = pobjData.GetPlayer(Me.ID)
            Dim pobjPos As New Position()

            Do While pobjDR.Read()
                With pobjDR
                    Me.LastName = .Item("LastName")
                    Me.Age = .Item("Age")
                    Me.College = .Item("College") & ""
                    Me.FirstName = .Item("FirstName")
                    Me.HighSchool = .Item("HighSchool") & ""
                    Me.Jersey = .Item("Jersey")
                    Me.Position = .Item("PositionID")
                    Me.Hometown = .Item("Hometown") & ""
                    Me.StarPlayer = .Item("starPlayer")
                End With
            Loop
            pobjDR.Close()
            pobjData.Close()

            Me.Ratings.Load(Me.ID)


        End Sub

        Overrides Function DisplayName()
            Dim Out As New System.Text.StringBuilder(64)
            With Out
                .Append("#")
                .Append(Me.Jersey)
                .Append(" ")
                .Append(Me.LastName)
                .Append(", ")
                .Append(Me.FirstName)
                .Append(" (")
                .Append(Me.GetPositionText())
                .Append(")")
            End With

            Return Out.ToString
        End Function

        Function ShortName()
            Return Me.FirstName.Chars(0) & ". " & Me.LastName
        End Function

        Private Function GetPositionText() As String
            Select Case Me.Position
                Case ISMPlayerPosition.Defenseman
                    Return "DF"
                Case ISMPlayerPosition.Forward
                    Return "FW"
                Case ISMPlayerPosition.Goalie
                    Return "GK"
                Case ISMPlayerPosition.Midfielder
                    Return "MF"
            End Select
        End Function

        Friend Property DisplayMember() As String
            Get
                Return Me.DisplayName
            End Get
            Set(ByVal Value As String)

            End Set
        End Property

        Friend Property ValueMember() As Integer
            Get
                Return Me.ID
            End Get
            Set(ByVal Value As Integer)

            End Set
        End Property

        Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
            If obj Is Nothing Then Return 1

            Dim other As Player = CType(obj, Player)
            Return StrComp(Me.LastName & " " & Me.FirstName, other.LastName & " " & other.FirstName, CompareMethod.Text)
        End Function

        Private Sub SetJersey(ByVal x As Integer)
            If x = 0 Then
                Me.Jersey = 0
            Else
                Me.Jersey = RandomNumber((x - 1) * 5, ((x - 1) * 5) + 4)
            End If

        End Sub

        Public Overrides Function ToString() As String
            Return Me.DisplayName
        End Function

        Friend Function TooManyTimeFoulsInGame() As Boolean
            Return IIf(Me.TimePenaltyFoulsInGame >= 3, True, False)
        End Function

        Friend Function IsFourFoulsPerHalf() As Boolean
            Select Case Me.FoulsPerHalf
                Case 4, 8, 12, 16, 20, 24, 28, 32
                    Return True
                Case Else
                    Return False
            End Select
        End Function




        Sub Fatigue()

            If Me.Health = 0 Then
                If RandomNumber(0, 105) >= Me.Ratings.Item(ISS_Rating.Endurance).Value Then
                    Select Case Me.Position
                        Case ISMPlayerPosition.Goalie
                            If RandomNumber(0, 100) > 50 Then
                                ProcessFatigue()
                            End If
                        Case Else
                            ProcessFatigue()
                    End Select
                End If
            End If


        End Sub

        Private Sub ProcessFatigue()
            Dim pdblMultiplier As Double

            Me.CurrentEnergy = Me.CurrentEnergy - RandomNumber(0, 2)
            If Me.CurrentEnergy <= 0 Then Me.CurrentEnergy = 1
            pdblMultiplier = (Me.CurrentEnergy / 100)
            Me.Ratings.ChangeRatingBasedOnEnergy(pdblMultiplier)
        End Sub

        Sub Rejuvinate()
            Dim pdblMultiplier As Double

            If Me.Health = 0 Then
                If RandomNumber(0, 105) <= Me.Ratings.Item(ISS_Rating.Endurance).Value Then
                    Me.CurrentEnergy = Me.CurrentEnergy + 1
                    If Me.CurrentEnergy >= 100 Then Me.CurrentEnergy = 100
                    pdblMultiplier = (Me.CurrentEnergy / 100)
                    Me.Ratings.ChangeRatingBasedOnEnergy(pdblMultiplier)
                End If
            End If
        End Sub


    End Class
End Namespace