'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Positions

Namespace Players
	Friend Class RefereeSet
		Inherits System.Collections.CollectionBase
		Implements ICloneable

		Default Property Item(ByVal index As Integer) As Referee
			Get
				Return CType(InnerList.Item(index), Referee)
			End Get
			Set(ByVal Value As Referee)
				InnerList.Item(index) = Value
			End Set
		End Property

		Sub Add(ByVal value As Referee)
			InnerList.Add(value)
		End Sub

		Sub Create(ByVal Age As Integer, ByVal FirstName As String, ByVal Hometown As String, ByVal ID As Integer, _
		ByVal Knowledge As Integer, ByVal LastName As String, ByVal Respect As Integer, ByVal Vision As Integer)
			Dim pobjRef As New Referee()
			With pobjRef
				.Age = Age
				.FirstName = FirstName
				.Hometown = Hometown
				.ID = ID
				.Knowledge = Knowledge
				.LastName = LastName
				.Respect = Respect
				.Vision = Vision
			End With
			Me.Add(pobjRef)
		End Sub

		Sub Load()
			Dim pobjDS As New DataServices.PlayerTables()
			Dim pobjDR As OleDb.OleDbDataReader

			pobjDR = pobjDS.GetReferees()
			With pobjDR
				Do While pobjDR.Read
					Me.Create(.Item("Age"), .Item("FirstName"), .Item("Hometown"), .Item("RefereeID"), _
						.Item("Knowledge"), .Item("LastName"), .Item("Respect"), .Item("Vision"))
				Loop
			End With
			pobjDR.Close()
		End Sub

		Function GetRefsForGame() As RefereeSet
			Dim pobjRSet As New RefereeSet()
            Dim i As Integer = 0
			Dim iRandomRef As Integer

            Do Until i = 3
                iRandomRef = RandomNumber(0, Me.Count() - 1)
                If Not pobjRSet.InnerList.Contains(Me.Item(iRandomRef)) Then
                    pobjRSet.Add(Me.Item(iRandomRef))
                    i += 1
                End If
            Loop

            Return pobjRSet

        End Function

        Function DidRefSeeInfraction(ByVal Settings As SimEngine.Settings.GameEngineSettingService) As Boolean
            Dim i As Integer = RandomNumber(0, Me.Count - 1)
            Dim pobjRef As Referee = Me.Item(i)

            Return IIf(RandomNumber(-10, 10) + Settings.Settings.GetValue(SimEngine.Settings.ISM_GameSettingType.Penalty, SimEngine.Settings.ISM_GameSetting.GenericAdj) > pobjRef.Vision, False, True)

        End Function



        Function Clone() As Object Implements ICloneable.Clone
            Dim pobjRefereeSet As New RefereeSet()
            pobjRefereeSet = Me
            Return pobjRefereeSet
        End Function

    End Class
End Namespace
