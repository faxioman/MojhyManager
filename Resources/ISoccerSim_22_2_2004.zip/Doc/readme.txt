INDOOR SOCCER SIMULATOR
RELEASE NOTES
=======================

Welcome to the first alpha release of ISS.  Dennis and I are extremely excited to 
have the initial stages of the game out to the public for scrutiny and review.  
Given the recent developments in indoor soccer regarding the recent merger of the
MISL and WISL, interest in the sport is on the rise, and we are more than happy
to produce a stat-based simulation.  We're hoping that you enjoy looking at the 
game and watching it grow.  

MINIMUM REQUIREMENTS
--------------------
- Windows 95(with DCOM) or higher
- Pentium-II 350 MHz
- 64 MB RAM
- 40 MB HD space
- Internet Explorer 5.0 or greater
- 800 x 600 screen resolution, 256 colors

RECOMMENDED REQUIREMENTS
------------------------
- Windows 2000 or higher
- Pentium-III 500 MHz
- 128 MB RAM
- 40 MB HD space
- Internet Explorer 5.5 or greater
- 800 x 600 screen resolution, true color


INSTALLATION
------------
To install the game...

a)  Unzip the release.0.5.4.zip file into its own directory.
b)  Run Setup.exe
c)  Follow the instructions in the installation package.

Installation should install the program files for ISS and Microsoft Data Access
Components.  If you are running Windows 2000 and up, the Microsoft software you
have on your computer should be more than adequate.  

Please know that by installing the dogfood beta, you agree to the EULA as described
in the license.txt.

Please read below for features that are considered stable enough for evaluation and
testing.

FEATURES
--------

PLEASE SEE THE RELEASE FILE FOR A FULL HISTORY OF WHAT'S BEEN ADDED AND WHEN!

The areas of the program that are known to work reasonably well include....
- Simulating an exhibition matchup
- Loading, creating new leagues (with some caveats...see below...)
- Simulating games on the schedule
- Statistic grids should pull information.
- Changing all information on the team information.
- Some limited graphics such as team and league logos.
- Trades.
- Roster pickups/drops.

WHAT'S NOT THERE YET
--------------------
- Financial dynamics.
- Postseason
- Offseason
- player edits
- Multi-player
- Stat imports from real life soccer leagues

QUICK INSTRUCTIONS
------------------
The default league will load on the game starting.  Most areas are pretty self-
explanatory.  Some things that may not be obvious...

- To view a player on the grids, single or double-clicking usually works.
- To swap a player on the roster, first click on the player you want to move,
  mouse over the player you want to swap with, and right click.  A popup menu
  will appear that allows you to swap the player out.
- Single-clicking on a grid column should sort a grid
- The roster screen has three roster types - (A) for active, (B) for bench, and 
  (I) for inactive.  Active players are your starters.  Bench players can play
  in a game, but they do not start.  Inactive players are on your payroll, but 
  aren't playing in a game.
- To change the distribution of players (say, have two goalies active and make
  the other ones inactive), switch to "Bench" view and swap players as above.
- To make a new league, go to "Settings", enter in a new league name, select
  the number of teams, and the number of games to play.  Press "New"  A new
  random league will be created.
- To load a league, go to "Settings", press "Load" and search for a "league.dat"
  file in a league directory.
- Right-clicking on a grid brings up (or will bring up) all possible options for 
  that game, player, etc. 

BUGS
----

There are a fair number of bugs in the program that are known.  Areas deemed
too unstable have been disabled in this release.  Some things to watch out for...

- Do not change the number of games for a league after it is created.  
- Playbook scenarios are not fully tested, but do work in games.
- If a new league is created over an old one, the old game logs and play by play
  files are not deleted.
- Ingame soccer field graphic is extremely ugly.
- Sometimes if you simulate a game, it won't let you simulate a week ahead right
  away.
- Play by play window on scoreboard screen does not always show full play by play
  due to lack of space.
- No resizing of any screens designed at present.

SUPPORT
-------
Tech support by me will be accepted either through direct email to me (jneal1@rmrc.net)
or through the message board.  I would prefer everything go through the message board
so duplicate requests aren't created.


TWEAKS
------
A number of files are dumped into the \data folder for the game.  These files
are named somewhat descriptively, but for clarification...
- fname.dat - a list of first names
- lname.dat - a list of last names
- city.dat - a list of cities and their populations.
- pbp.dat - The play by play data file.  There are instructions in this file,
            however, this is the main file that creates game commentary.  It's
	    like a giant ad-lib machine.  Edit to your heart's content.  At
	    present, one PBP file is for the entire league, but the option later
 	    will be added for each team to have their own PBP file used when they
	    have a home game.
- tactics.dat - a list of valid tactics in the game and how each position gets
		a boost from the use of each one.  This will be expanded at some
		point.

A global tweak file for the behavior of the stat engine, player development, etc.
will be added at a later point.


DOGFOOD RELEASE/POLICY
----------------------

A dogfood release is a tech beta, released to the public to garner opinions and 
rough testing from the gaming public.  This is the first dogfood release, and as
such, we'd like to throw out some rules:

- Reverse engineering the code is not allowed.

- Distributing the program to anyone not registered on our mailing list is prohibited
  at this point.

- Bug reports and enhancements submitted to our message board at 
  http://www.indoorsoccersim.com are appreciated!

- League file formats can change from version to version to make the game inoperable
  with old league files.  Do not get too attached to leagues you have running.

- Once a stable set of features has been developed, public betas will be made
  available to the website.  

- Dogfood releases will be released every two weeks or sooner pending on the numbers
  of bugs found, significant features added, etc.

- A release.txt detailing fixed bugs and enhancements will be inside each release file.


ENJOY!
Jack Neal - ISS Lead Programmer
