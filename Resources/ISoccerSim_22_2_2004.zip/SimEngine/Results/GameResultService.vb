'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.IO
Imports ISoccerSim.Teams
Imports ISoccerSim.Reporting
Imports ISoccerSim.SimEngine.PlayByPlay

Namespace SimEngine.Results
	Friend Class GameResultService
		Friend GameEngine As GameEngine
		Dim [Structure] As New GameResultStructure()
		Dim Data As New GameResultDataService()


		Private Sub CreateEventLog()
			Dim Report As New Report()
			Dim EventLog As ReportTable = Me.Structure.GetEventLog()

			Report.Subheader = "EVENT LOG"
			Report.Header = Me.GameEngine.AwayTeam.ToString & " at " & Me.GameEngine.HomeTeam.ToString

			Dim EventLogData As New ReportData()
			Dim pobjItem As GameSummaryItem
			For Each pobjItem In Me.GameEngine.GameSummary
				With EventLogData
					.Fill(pobjItem.GetTimeDescription, pobjItem.Description)
				End With
			Next
			EventLog.Data = EventLogData

			Report.Add(EventLog)

			'Generate...
			Report.Generate()
			If Me.GameEngine.ScheduleID = 0 Then
				Me.Save(Report, gobjLeague.GetTempGameEventLogFilePath)
			Else
				Me.Save(Report, gobjLeague.GetScheduledEventLogFileName(Me.GameEngine.ScheduleID))
			End If


		End Sub

		Private Sub CreateBoxScore()
			Dim Report As New Report()
			Dim BoxScore As ReportTable = Me.Structure.GetBoxScoreStructure()
			Dim AwayTeamStats As ReportTable = Me.Structure.GetTeamDataBlock(Me.GameEngine.AwayTeam)
			Dim HomeTeamStats As ReportTable = Me.Structure.GetTeamDataBlock(Me.GameEngine.HomeTeam)
			Dim GameStats As ReportTable = Me.Structure.GetGameDataBlock()
			Dim pobjDelimiter As New Reporting.ArrayListDelimiter()

			Report.Subheader = "BOX SCORE"
			Report.Header = Me.GameEngine.AwayTeam.ToString & " at " & Me.GameEngine.HomeTeam.ToString

			'Add box score....
			Dim BoxScoreData As New ReportData()
			With BoxScoreData
				.Fill(Me.Data.GetBoxScoreArray(Me.GameEngine.AwayTeam))
				.Fill(Me.Data.GetBoxScoreArray(Me.GameEngine.HomeTeam))
			End With
			BoxScore.Data = BoxScoreData

			'AWAY TEAM DATA

			'Add shots made for away team...
			Dim AwayTeamData As New ReportData()
			With AwayTeamData
				If gobjLeague.MultiPoint Then
					.Fill(pobjDelimiter.ArrayListToCommas("POINTS", Me.Data.GetPointsMade(Me.GameEngine.AwayTeam), True))
				End If
				.Fill(pobjDelimiter.ArrayListToCommas("GOALS", Me.Data.GetShotsMade(Me.GameEngine.AwayTeam), True))
				.Fill(pobjDelimiter.ArrayListToCommas("SHOTS ATTEMPTED", Me.Data.GetShotsAttempted(Me.GameEngine.AwayTeam), True))
				.Fill(pobjDelimiter.ArrayListToCommas("ASSISTS", Me.Data.GetAssists(Me.GameEngine.AwayTeam), True))
				.Fill(pobjDelimiter.ArrayListToCommas("SAVES", Me.Data.GetSaves(Me.GameEngine.AwayTeam), True))
				.Fill(pobjDelimiter.ArrayListToCommas("BLOCKS", Me.Data.GetBlocks(Me.GameEngine.AwayTeam), True))
                .Fill(pobjDelimiter.ArrayListToCommas("FOULS", Me.Data.GetFouls(Me.GameEngine.AwayTeam), True))
                .Fill(pobjDelimiter.ArrayListToCommas("PENALTY MINUTES", Me.Data.GetPenaltyMinutes(Me.GameEngine.AwayTeam), True))
                .Fill(pobjDelimiter.ArrayListToCommas("POWER PLAY GOALS", Me.Data.GetPowerPlayGoals(Me.GameEngine.AwayTeam), True))
                .Fill(pobjDelimiter.ArrayListToCommas("SHORTHANDED GOALS", Me.Data.GetPenaltyKillGoals(Me.GameEngine.AwayTeam), True))
				.Fill(pobjDelimiter.ArrayListToCommas("PLAYERS IN GAME", Me.Data.GetPlayerArray(Me.GameEngine.AwayTeam), False))
				.Fill(pobjDelimiter.ArrayListToCommas("UNUSED PLAYERS", Me.Data.GetUnusedPlayers(Me.GameEngine.AwayTeam), False))

			End With
			AwayTeamStats.Data = AwayTeamData


			''''''''''''''''''''
			'Home TEAM DATA
			''''''''''''''''''''

			'Add stats...
			Dim HomeTeamData As New ReportData()
			With HomeTeamData
				If gobjLeague.MultiPoint Then
					.Fill(pobjDelimiter.ArrayListToCommas("POINTS", Me.Data.GetPointsMade(Me.GameEngine.HomeTeam), True))
				End If
				.Fill(pobjDelimiter.ArrayListToCommas("GOALS", Me.Data.GetShotsMade(Me.GameEngine.HomeTeam), True))
				.Fill(pobjDelimiter.ArrayListToCommas("SHOTS ATTEMPTED", Me.Data.GetShotsAttempted(Me.GameEngine.HomeTeam), True))
				.Fill(pobjDelimiter.ArrayListToCommas("ASSISTS", Me.Data.GetAssists(Me.GameEngine.HomeTeam), True))
				.Fill(pobjDelimiter.ArrayListToCommas("SAVES", Me.Data.GetSaves(Me.GameEngine.HomeTeam), True))
				.Fill(pobjDelimiter.ArrayListToCommas("BLOCKS", Me.Data.GetBlocks(Me.GameEngine.HomeTeam), True))
                .Fill(pobjDelimiter.ArrayListToCommas("FOULS", Me.Data.GetFouls(Me.GameEngine.HomeTeam), True))
                .Fill(pobjDelimiter.ArrayListToCommas("PENALTY MINUTES", Me.Data.GetPenaltyMinutes(Me.GameEngine.HomeTeam), True))
                .Fill(pobjDelimiter.ArrayListToCommas("POWER PLAY GOALS", Me.Data.GetPowerPlayGoals(Me.GameEngine.HomeTeam), True))
                .Fill(pobjDelimiter.ArrayListToCommas("SHORTHANDED GOALS", Me.Data.GetPenaltyKillGoals(Me.GameEngine.HomeTeam), True))
				.Fill(pobjDelimiter.ArrayListToCommas("PLAYERS IN GAME", Me.Data.GetPlayerArray(Me.GameEngine.HomeTeam), False))
				.Fill(pobjDelimiter.ArrayListToCommas("UNUSED PLAYERS", Me.Data.GetUnusedPlayers(Me.GameEngine.HomeTeam), False))
			End With
			HomeTeamStats.Data = HomeTeamData

			'''''''''''''''''''''''
			' GENERIC DATA 
			'''''''''''''''''''''''

            Dim GameData As New ReportData()
            Dim f As New Cities.Facility()
            f.Load(Me.GameEngine.HomeTeam.FacilityID)

            With GameData
                pobjDelimiter.Delimiter = ";"
                .Fill(pobjDelimiter.ArrayListToCommas("OFFICIALS", Me.Data.GetReferees(Me.GameEngine.Referees), True))
                .Fill("<B>ATTENDANCE:</B>" & Format(Me.GameEngine.Attendance, "#,000") & " - (" & Format(Me.GameEngine.Attendance / f.Capacity, "###.00%") & ")")
            End With
            GameStats.Data = GameData


            ''''''''''''''''''
            'Build tables...
            ''''''''''''''''''

            Report.Add(BoxScore)
            Report.Add(AwayTeamStats)
            Report.Add(HomeTeamStats)
            Report.Add(GameStats)

            'Generate...
            Report.Generate()
            If Me.GameEngine.ScheduleID = 0 Then
                Me.Save(Report, gobjLeague.GetTempBoxScoreFilePath)
            Else
                Me.Save(Report, gobjLeague.GetScheduledGameBoxFileName(Me.GameEngine.ScheduleID))
            End If
		End Sub



		Private Sub CreatePlayByPlay()
			Dim Report As New Report()
			Dim GamePlay As ReportTable = Me.Structure.GetPlayByPlay

			Report.Subheader = "PLAY BY PLAY"
			Report.Header = Me.GameEngine.AwayTeam.ToString & " at " & Me.GameEngine.HomeTeam.ToString

			Dim GamePlayData As New ReportData()
			With GamePlayData
				.FillRange(Me.Data.GetPlayByPlay(Me.GameEngine.GameLog))
			End With
			GamePlay.Data = GamePlayData
			Report.Add(GamePlay)

			'Generate...
			Report.Generate()
			If Me.GameEngine.ScheduleID = 0 Then
				Me.Save(Report, gobjLeague.GetTempGameLogFilePath)
			Else
				Me.Save(Report, gobjLeague.GetScheduledPBPFileName(Me.GameEngine.ScheduleID))
			End If

		End Sub

		Sub Create()
			Call CreateBoxScore()
			Call CreatePlayByPlay()
			Call CreateEventLog()
		End Sub


		Sub Save(ByVal Report As Report, ByVal Path As String)
			Dim pobjWriter As StreamWriter = File.CreateText(Path)
			pobjWriter.Write(Report.Output)
			pobjWriter.Close()
		End Sub

	End Class
End Namespace