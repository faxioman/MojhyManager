'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System.IO
Imports ISoccerSim.Teams
Imports ISoccerSim.Reporting
Imports ISoccerSim.SimEngine.PlayByPlay


Namespace SimEngine.Results
	Friend Class GameResultDataService
		Function GetPlayerArray(ByVal objTeam As Team) As GameResultSet
			Dim pobjArray As New GameResultSet()
			Dim pobjItem As Players.Player

			For Each pobjItem In objTeam.FieldManager.PlayerSet
				If pobjItem.Stats.GetValue(Statistics.ISMStat.Minutes) > 0 Then
					pobjArray.Create(pobjItem.DisplayName, -1, False)
				End If
			Next

			Return pobjArray

		End Function

		Function GetUnusedPlayers(ByVal objTeam As Team) As GameResultSet
			Dim pobjArray As New GameResultSet()
			Dim pobjItem As Players.Player

			For Each pobjItem In objTeam.FieldManager.PlayerSet
				If pobjItem.Stats.GetValue(Statistics.ISMStat.Minutes) = 0 Then
					pobjArray.Create(pobjItem.DisplayName, -1, False)
				End If
			Next

			Return pobjArray
		End Function

		Function GetReferees(ByVal objRefSet As Players.RefereeSet) As GameResultSet
			Dim pobjArray As New GameResultSet()
			Dim pobjItem As Players.Referee

			For Each pobjItem In objRefSet
				pobjArray.Create(pobjItem.DisplayName, -1, False)
			Next
			Return pobjArray
        End Function


        Function GetShotsMade(ByVal objTeam As Team) As GameResultSet
            Dim pobjResultSet As New GameResultSet()
            Dim pobjItem As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each pobjItem In objTeam.FieldManager.PlayerSet
                Value = pobjItem.Stats.GetValue(Statistics.ISMStat.ShotMade)
                If Value > 0 Then
                    pobjResultSet.Create(pobjItem.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            pobjResultSet.Create("Total", Total, True)
            Return pobjResultSet

        End Function


        Function GetPointsMade(ByVal objTeam As Team) As GameResultSet
            Dim pobjResultSet As New GameResultSet()
            Dim pobjItem As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each pobjItem In objTeam.FieldManager.PlayerSet
                Value = pobjItem.Stats.GetValue(Statistics.ISMStat.Points)
                If Value > 0 Then
                    pobjResultSet.Create(pobjItem.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            pobjResultSet.Create("Total", Total, True)
            Return pobjResultSet

        End Function

        Function GetAssists(ByVal objTeam As Team) As GameResultSet
            Dim pobjResultSet As New GameResultSet()
            Dim pobjItem As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each pobjItem In objTeam.FieldManager.PlayerSet
                Value = pobjItem.Stats.GetValue(Statistics.ISMStat.Assists)
                If Value > 0 Then
                    pobjResultSet.Create(pobjItem.DisplayName, Value, False)
                    Total = Total + 1
                End If
            Next
            pobjResultSet.Create("Total", Total, True)
            Return pobjResultSet
        End Function

        Function GetShotsAttempted(ByVal objTeam As Team) As GameResultSet
            Dim pobjResultSet As New GameResultSet()
            Dim pobjItem As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each pobjItem In objTeam.FieldManager.PlayerSet
                Value = pobjItem.Stats.GetValue(Statistics.ISMStat.ShotAttempted) + pobjItem.Stats.GetValue(Statistics.ISMStat.ShotMade)
                If Value > 0 Then
                    pobjResultSet.Create(pobjItem.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            pobjResultSet.Create("Total", Total, True)
            Return pobjResultSet
        End Function

        Function GetSaves(ByVal objTeam As Team) As GameResultSet
            Dim pobjResultSet As New GameResultSet()
            Dim pobjItem As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each pobjItem In objTeam.FieldManager.PlayerSet
                Value = pobjItem.Stats.GetValue(Statistics.ISMStat.ShotStopped)
                If Value > 0 Then
                    pobjResultSet.Create(pobjItem.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            pobjResultSet.Create("Total", Total, True)
            Return pobjResultSet
        End Function

        Function GetBlocks(ByVal objTeam As Team) As GameResultSet
            Dim pobjResultSet As New GameResultSet()
            Dim pobjItem As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each pobjItem In objTeam.FieldManager.PlayerSet
                Value = pobjItem.Stats.GetValue(Statistics.ISMStat.Block)
                If Value > 0 Then
                    pobjResultSet.Create(pobjItem.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            pobjResultSet.Create("Total", Total, True)
            Return pobjResultSet
        End Function

        Function GetFouls(ByVal objTeam As Team) As GameResultSet
            Dim pobjResultSet As New GameResultSet()
            Dim pobjItem As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each pobjItem In objTeam.FieldManager.PlayerSet
                Value = pobjItem.Stats.GetValue(Statistics.ISMStat.Fouls)
                If Value > 0 Then
                    pobjResultSet.Create(pobjItem.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            pobjResultSet.Create("Total", Total, True)
            Return pobjResultSet
        End Function

        Function GetPenaltyMinutes(ByVal objTeam As Team) As GameResultSet
            Dim pobjResultSet As New GameResultSet()
            Dim pobjItem As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each pobjItem In objTeam.FieldManager.PlayerSet
                Value = pobjItem.Stats.GetValue(Statistics.ISMStat.PenaltyMinutes)
                If Value > 0 Then
                    pobjResultSet.Create(pobjItem.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            pobjResultSet.Create("Total", Total, True)
            Return pobjResultSet
        End Function

        Function GetPowerPlayGoals(ByVal objTeam As Team) As GameResultSet
            Dim pobjResultSet As New GameResultSet()
            Dim pobjItem As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each pobjItem In objTeam.FieldManager.PlayerSet
                Value = pobjItem.Stats.GetValue(Statistics.ISMStat.PowerPlayGoal)
                If Value > 0 Then
                    pobjResultSet.Create(pobjItem.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            pobjResultSet.Create("Total", Total, True)
            Return pobjResultSet
        End Function

        Function GetPenaltyKillGoals(ByVal objTeam As Team) As GameResultSet
            Dim pobjResultSet As New GameResultSet()
            Dim pobjItem As Players.Player
            Dim Value As Integer
            Dim Total As Integer

            For Each pobjItem In objTeam.FieldManager.PlayerSet
                Value = pobjItem.Stats.GetValue(Statistics.ISMStat.ShortHandedGoal)
                If Value > 0 Then
                    pobjResultSet.Create(pobjItem.DisplayName, Value, False)
                    Total = Total + Value
                End If
            Next
            pobjResultSet.Create("Total", Total, True)
            Return pobjResultSet
        End Function

        Function GetBoxScoreArray(ByVal objTeam As Team) As ArrayList
            Dim pobjArray As New ArrayList()
            With pobjArray
                .Add(objTeam.Name)
                .Add(objTeam.Scoreboard.Q1Score)
                .Add(objTeam.Scoreboard.Q2Score)
                .Add(objTeam.Scoreboard.Q3Score)
                .Add(objTeam.Scoreboard.Q4Score)
                .Add(objTeam.Scoreboard.OTScore)
                .Add(objTeam.Scoreboard.Score)
            End With
            Return pobjArray

        End Function

        Function GetPlayByPlay(ByVal GameLog As GameLog) As ArrayList
            Dim pobjArray As New ArrayList()
            Dim pobjItem As GameLogItem

            With pobjArray
                For Each pobjItem In GameLog
                    .Add(pobjItem.Description)
                Next
            End With

            Return pobjArray
        End Function
    End Class
End Namespace
