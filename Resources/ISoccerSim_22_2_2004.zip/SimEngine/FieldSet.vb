'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports ISoccerSim.Rosters
Imports ISoccerSim.Players
Imports ISoccerSim.Substitution
Imports ISoccerSim.SimEngine
Imports Microsoft.VisualBasic

Namespace SimEngine
	Friend Class FieldSet
		Inherits GamePlayerSet

		Dim mobjSet As New BaseSettingSet()
		Friend ActivePlayer As Player
		Friend AssistPlayer As Player

		Sub New()
            Me.Minimum = 4
			Me.Maximum = 6
		End Sub

		Overloads Sub Add(ByVal objItem As Player)
			If Me.Count >= 6 Then
				Debug.Assert(False, "Too many people on the field.")
			Else
				MyBase.Add(objItem)
			End If
		End Sub

		Function GetPlayerByGamePosition(ByVal intGamePosition As ISMGamePosition) As Player
			Dim pobjItem As Player
			For Each pobjItem In Me.InnerList
				If pobjItem.GamePosition = intGamePosition Then
					Return pobjItem
				End If
			Next
		End Function

		Friend Function IsOffensiveFrontPlayer() As Boolean
			Select Case Me.ActivePlayer.GamePosition
				Case ISMGamePosition.MF, ISMGamePosition.LF, ISMGamePosition.RF
					Return True
				Case Else
					Return False
			End Select
		End Function

		Private Function IsGamePositionOnField(ByVal intGamePosition As ISMGamePosition) As Boolean
			Dim pobjItem As Player
			For Each pobjItem In Me.InnerList
				If pobjItem.GamePosition = intGamePosition Then
					Return True
				End If
			Next
			Return False
		End Function

		Private Function IsGamePositionOnField(ByVal intGamePosition As ISMGamePosition, ByVal blnAllowSamePlayer As Boolean, _
		   ByVal intCurrentPlayer As ISMGamePosition, ByVal Probability As Byte) As Boolean
			Dim pobjItem As Player
			For Each pobjItem In Me.InnerList
				If pobjItem.GamePosition = intGamePosition Then
					If blnAllowSamePlayer Then
						Return True
					End If

					If blnAllowSamePlayer = False And intCurrentPlayer = pobjItem.GamePosition Then
						Return False
					ElseIf Probability = 0 Then
						Return False
					Else
						Return True
					End If
				End If
			Next
			Return False
		End Function

		Function GetRandomPlayerOnField() As Player
			Return GetRandomPlayerOnField(0, 20, 20, 20, 20, 20, False, ISMGamePosition.GK)
		End Function

		Function GetRandomPlayerOnField(ByVal GK As Byte, ByVal LD As Byte, _
		  ByVal RD As Byte, ByVal LF As Byte, ByVal MF As Byte, ByVal RF As Byte) As Player
			Return GetRandomPlayerOnField(GK, LD, RD, LF, MF, RF, True, -1)
		End Function

		Function GetRandomPlayerOnField(ByVal GK As Byte, ByVal LD As Byte, _
		  ByVal RD As Byte, ByVal LF As Byte, ByVal MF As Byte, ByVal RF As Byte, _
		  ByVal AllowSamePlayer As Boolean, ByVal CurrentPlayer As ISMGamePosition) As Player

			Dim pobjItem As BaseSetting
            Dim pobjOut As Player

            Try

                With mobjSet
                    .Clear()
                    .Total = 0
                    If IsGamePositionOnField(ISMGamePosition.GK, AllowSamePlayer, CurrentPlayer, GK) Then .Create(ISMGamePosition.GK, GK)
                    If IsGamePositionOnField(ISMGamePosition.LD, AllowSamePlayer, CurrentPlayer, LD) Then .Create(ISMGamePosition.LD, LD)
                    If IsGamePositionOnField(ISMGamePosition.LF, AllowSamePlayer, CurrentPlayer, LF) Then .Create(ISMGamePosition.LF, LF)
                    If IsGamePositionOnField(ISMGamePosition.MF, AllowSamePlayer, CurrentPlayer, MF) Then .Create(ISMGamePosition.MF, MF)
                    If IsGamePositionOnField(ISMGamePosition.RD, AllowSamePlayer, CurrentPlayer, RD) Then .Create(ISMGamePosition.RD, RD)
                    If IsGamePositionOnField(ISMGamePosition.RF, AllowSamePlayer, CurrentPlayer, RF) Then .Create(ISMGamePosition.RF, RF)

                    pobjItem = .GetRandomItemByProbability
                    pobjOut = Me.GetPlayerByGamePosition(Val(pobjItem.Value))
                    Debug.Assert(Not (AllowSamePlayer = False And CurrentPlayer = pobjOut.GamePosition))
                    Return pobjOut

                End With

            Catch ex As Exception
                Call HandleException(Nothing, ex)
            End Try
		End Function

		Sub AddFieldMinutes(ByVal Seconds As Integer)
			Dim pobjItem As Player
			For Each pobjItem In Me.InnerList
				pobjItem.Stats.Augment(Statistics.ISMStat.Minutes, Seconds)
			Next
		End Sub

		Sub ManageGPI()
			Dim pobjItem As Player
			For Each pobjItem In Me.InnerList
				If pobjItem.Stats.GetValue(Statistics.ISMStat.GamesPlayed) = 0 Then
					pobjItem.Stats.Augment(Statistics.ISMStat.GamesPlayed, 1)
				End If
			Next
        End Sub

        Function CanRemoveManFromField() As Boolean
            Return IIf(Me.Count > 4, True, False)
        End Function

        Sub DebugOut()
            Dim pobjItem As Player
            For Each pobjItem In Me.InnerList
                Console.WriteLine(pobjItem.ID & " - " & pobjItem.GamePosition)
            Next
            Console.WriteLine("-----------------")
        End Sub



    End Class



End Namespace