'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports Microsoft.VisualBasic
Imports ISoccerSim.Players
Imports ISoccerSim.SimEngine

Namespace SimEngine.Actions
	Friend Class Action
		Implements IAction, ICloneable

        Dim mstrName As String
		Dim mintResult As ISMActionResult
		Dim mobjBall As Ball
		Dim mobjEndPlayer As Player
		Friend GameEngine As GameEngine
		Friend IsPenaltyCheck As Boolean

		Overridable Sub Execute(ByVal Player As Player) Implements IAction.Execute

		End Sub

		Friend Property Name() As String Implements IAction.Name
			Get
                Return mstrName
			End Get

			Set(ByVal value As String)
                mstrName = value
			End Set
		End Property

		Friend Property Result() As ISMActionResult Implements IAction.Result
			Get
				'If Me.IsPenaltyCheck Then
				Return mintResult
				'Else
				'Dim pobjPlay As New Actions.Plays.PenaltyAction(Me.GameEngine)
				'pobjPlay.IsPenaltyCheck = True
				'pobjPlay.Execute(Me.GameEngine.Posession.Defense.FieldManager.Field.ActivePlayer)
				'Return pobjPlay.Result

				'End If
			End Get

			Set(ByVal value As ISMActionResult)
				mintResult = value
			End Set
		End Property

		Friend Property Ball() As Ball Implements IAction.Ball
			Get
				Return mobjBall
			End Get

			Set(ByVal value As Ball)
				mobjBall = value
			End Set
		End Property

		Friend Property EndPlayer() As Player Implements IAction.EndPlayer
			Get
				Return mobjEndPlayer
			End Get

			Set(ByVal value As Player)
				mobjEndPlayer = value
			End Set
		End Property

		Function Clone() As Object Implements ICloneable.Clone
			Dim pobjItem As New Action()
			pobjItem = Me
			Return pobjItem
		End Function

		Function GetRatingRoll(ByVal OverallAdjustment As Integer, ByVal Rating As Integer, ByVal RatingModifier As Double) As Integer
			Dim x As Integer
			x = GetRoll(ISMRollType.Standard) + OverallAdjustment
			x = x + (Rating * RatingModifier)
			Return x
		End Function

		Function GetInverseRatingRoll(ByVal Rating As Integer, ByVal RatingModifier As Double, ByVal MaxAmount As Integer) As Integer
			Dim x As Integer
			x = GetRoll(ISMRollType.Standard)
			x = x + (Rating * RatingModifier)
			x = MaxAmount - x
			If x < 0 Then x = 0
			If x > MaxAmount Then x = MaxAmount
			Return x
		End Function


	End Class




End Namespace
