'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports Microsoft.VisualBasic
Imports ISoccerSim.SimEngine.Actions
Imports ISoccerSim.Players
Imports ISoccerSim.SimEngine

Namespace SimEngine.Actions.Plays

	Friend Class DribbleAction
		Inherits Action

		

		Shadows Sub Execute(ByVal OffPlayer As Player, ByVal DefPlayer As Player)

			If DefPlayer Is Nothing Then
				Me.Result = ISMActionResult.Success
				Exit Sub
			End If

			Dim OffRoll As Integer = GetOffensiveRoll(OffPlayer)
			Dim DefRoll As Integer = GetDefensiveRoll(DefPlayer)

			OffRoll = OffRoll - GetFieldPenalty()

			If OffRoll > DefRoll Then
				Me.Result = ISMActionResult.Success
			Else
				Me.Result = ISMActionResult.Failure
			End If

		End Sub

		'Support methods/functions...

		Private Function GetOffensiveRoll(ByVal pyr As Player) As Integer
			With Me.GameEngine.Settings.Settings
				Dim DribbleRating As Integer = pyr.Ratings(Ratings.ISS_Rating.Dribbling).Value
				Dim OffenseMultiplier As Double = .GetValue(Settings.ISM_GameSettingType.Dribble, Settings.ISM_GameSetting.OffensiveRatingMult)
				Dim OffenseAdjustment As Double = .GetValue(Settings.ISM_GameSettingType.Dribble, Settings.ISM_GameSetting.OffensiveAdj)
				Return Me.GetRatingRoll(OffenseAdjustment, DribbleRating, OffenseMultiplier)
			End With
		End Function

		Private Function GetDefensiveRoll(ByVal pyr As Player) As Integer
			If pyr Is Nothing Then
				Return 0
			Else
				With Me.GameEngine.Settings.Settings
					Dim DribbleRating As Integer = pyr.Ratings(Ratings.ISS_Rating.Positioning).Value
					Dim DefenseMultiplier As Double = .GetValue(Settings.ISM_GameSettingType.Dribble, Settings.ISM_GameSetting.DefensiveRatingMult)
					Dim DefenseAdjustment As Double = .GetValue(Settings.ISM_GameSettingType.Dribble, Settings.ISM_GameSetting.DefensiveAdj)
					Return Me.GetRatingRoll(DefenseAdjustment, DribbleRating, DefenseMultiplier)
				End With
			End If

		End Function



		Private Function GetFieldPenalty() As Byte
			With Me.GameEngine.Settings.Settings
				.GetFieldPenalty(Settings.ISM_GameSettingType.PassReception, Me.GameEngine.Ball.Y)
			End With
		End Function

		Sub New(ByVal GameEngine As GameEngine)
			Me.Name = "Dribble"
			Me.GameEngine = GameEngine
		End Sub


	End Class


End Namespace
