'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports Microsoft.VisualBasic
Imports ISoccerSim.Players
Imports ISoccerSim.SimEngine

Namespace SimEngine.Actions


	Interface IAction
		Sub Execute(ByVal Player As Player)

		Property Result() As ISMActionResult
		Property EndPlayer() As Player
		Property Ball() As Ball
		Property Name() As String

	End Interface

	Interface ISequence
		Sub Execute()
		Property Name() As String
	End Interface

	Friend Enum ISMRollType
		Standard = 50
		Percentage = 100
		PenaltyRoll = 10000
	End Enum

	Friend Enum ISMActionResult
		Success = 0
		Failure = 1
		OutOfBounds = 2
		Injury = 3
		Penalty = 4
		Bizarre = 99
		OptForPass = 5
		OptForDribble = 6
		OptForShot = 7
		GoalMade = 8
	End Enum

	Friend Enum ISMBallVertical
		OwnCrease = 0
		OwnShortRange = 1
		OwnThird = 2
		MidField = 3
		OppThird = 4
		OppShortRange = 5
        OppCrease = 6
        OverEndBoard = 7
		None = -1
	End Enum

	Friend Enum ISMBallLateral
		WallLeft = -3
		MidLeft = -2
		SlightLeft = -1
		Middle = 0
		SlightRight = 1
		MidRight = 2
		WallRight = 3
	End Enum

	Friend Enum ISMBallMoveSideways
		Left = -1
		None = 0
		Right = 1
	End Enum

	Friend Enum ISMBallOffTarget
		OnTarget = 0
		Left = 1
		Right = 2
		High = 3
		LeftBar = 4
		RightBar = 5
		Crossbar = 6
	End Enum

	Module Utility
		Function GetRoll(ByVal RollType As ISMRollType)
			Select Case RollType
				Case ISMRollType.Percentage
					Return RandomNumber(1, 100)
				Case ISMRollType.Standard
					Return RandomNumber(1, 50)
				Case ISMRollType.PenaltyRoll
					Return RandomNumber(1, 500)
			End Select
		End Function

		Function GetRoll(ByVal RollType As ISMRollType, ByVal Add As Integer)
			Return GetRoll(RollType) + Add
		End Function
	End Module



End Namespace
