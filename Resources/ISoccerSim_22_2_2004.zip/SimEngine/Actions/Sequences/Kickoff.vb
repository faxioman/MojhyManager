'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.SimEngine.Actions
Imports ISoccerSim.SimEngine.Actions.Plays
Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports Microsoft.VisualBasic
Imports ISoccerSim.Players
Imports ISoccerSim.SimEngine

Namespace SimEngine.Actions.Sequence
	Friend Class KickOff
		Inherits Sequence

		Friend Event Penalty(ByVal sender As Object, ByVal e As PenaltyRaisedEventArgs)

		Sub New(ByVal GameEngine As GameEngine)
			Me.GameEngine = GameEngine
			Me.Name = "KickOff"
		End Sub

		Overrides Sub Execute()
			With Me.GameEngine


				If .Clock.IsEndOfGame Or .Posession.Changed Then Exit Sub

				'Determine who is defending against an individual's upfield carry, if anyone...

                Dim pyrOffense As Player = GetKickOffPlayer()
				Dim pyrPassTo As Player = GetPassToPlayer(pyrOffense.GamePosition)
				Dim pyrDefense As Player = .Posession.Defense.FieldManager.Field.GetPlayerByGamePosition(ISMGamePosition.MF)
				Dim Result As ISMActionResult

                Dim pobjAction As New PassAction(Me.GameEngine)


				
				pobjAction.Execute(pyrOffense, pyrDefense)
				.PlayByPlay.SetPlayers(pyrOffense, pyrOffense, pyrDefense, Nothing, pyrPassTo)

				If pobjAction.Result = ISMActionResult.Success Then
					.Posession.Offense.FieldManager.Field.AssistPlayer = pyrOffense
					.Posession.Offense.FieldManager.Field.ActivePlayer = pyrPassTo
					.GameLog.Create(.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.Kickoff))
					Call SetBallMovement()
					.Clock.Tick(2, 6)
					Exit Sub
				Else
					.GameLog.Create(.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.PassSteal))
					.Posession.Offense.FieldManager.Field.ActivePlayer = pyrOffense
					.Posession.Defense.FieldManager.Field.AssistPlayer = Nothing
					.Posession.Defense.FieldManager.Field.ActivePlayer = pyrDefense
					Call SetBallMovement()
					.Clock.Tick(1, 4)
					.Posession.Switch()
				End If

			End With
		End Sub

		Private Function GetDefensivePlayer() As Player
			With Me.GameEngine.Posession.Defense.FieldManager.Field
				Select Case Me.GameEngine.Ball.Y
					Case ISMBallVertical.OppCrease
						Return .GetRandomPlayerOnField(15, 30, 30, 10, 10, 5)
					Case ISMBallVertical.OppShortRange
						Return .GetRandomPlayerOnField(10, 30, 30, 10, 10, 10)
					Case ISMBallVertical.OppThird
						Return .GetRandomPlayerOnField(0, 30, 30, 15, 15, 10)
					Case ISMBallVertical.MidField
						Return .GetRandomPlayerOnField(0, 20, 20, 20, 20, 20)
					Case Else
						Return .GetRandomPlayerOnField(0, 10, 10, 25, 25, 30)
				End Select
			End With
		End Function

		Private Function GetPassToPlayer(ByVal GamePosition As ISMGamePosition) As Player
			With Me.GameEngine.Posession.Offense.FieldManager.Field
				Return .GetRandomPlayerOnField(0, 20, 20, 20, 20, 20, False, GamePosition)
			End With
        End Function

        Private Function GetKickOffPlayer() As Player
            Dim objPlayer As Player = Me.GameEngine.Posession.Offense.FieldManager.Field.GetPlayerByGamePosition(ISMGamePosition.MF)

            If objPlayer Is Nothing Then
                Return Me.GameEngine.Posession.Offense.FieldManager.Field.GetRandomPlayerOnField(0, 15, 15, 35, 0, 35, False, ISMGamePosition.MF)
            Else
                Return objPlayer
            End If
        End Function

        Private Sub SetBallMovement()
            With Me.GameEngine.Ball
                Select Case .Y
                    Case ISMBallVertical.OppShortRange
                        .MoveUpfield(2, ISMBallVertical.OppCrease, 30)
                    Case ISMBallVertical.OppShortRange
                        .MoveUpfield(2, ISMBallVertical.OppCrease, 40)
                    Case ISMBallVertical.OppCrease
                        .MoveUpfield(-1, ISMBallVertical.MidField, 30)
                    Case ISMBallVertical.OppThird
                        .MoveUpfield(2, ISMBallVertical.OppCrease, 50)
                    Case Else
                        .MoveUpfield(2, ISMBallVertical.OppCrease, 70)
                End Select
                .MoveLateral(3, 40, 40)
            End With
        End Sub

    End Class
End Namespace


