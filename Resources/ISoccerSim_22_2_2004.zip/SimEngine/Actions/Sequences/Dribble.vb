'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.SimEngine.Actions
Imports ISoccerSim.SimEngine.Actions.Plays
Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports Microsoft.VisualBasic
Imports ISoccerSim.Players
Imports ISoccerSim.SimEngine

Namespace SimEngine.Actions.Sequence
	Friend Class Dribble
		Inherits Sequence

		Sub New(ByVal GameEngine As GameEngine)
			Me.GameEngine = GameEngine
			Me.Name = "Dribble"
		End Sub

		Overrides Sub Execute()
			With Me.GameEngine


				If .Clock.IsEndOfGame Or .Posession.Changed Then Exit Sub

				'Determine who is defending against an individual's upfield carry, if anyone...

				Dim pyrOffense As Player = .Posession.Offense.FieldManager.Field.ActivePlayer
				Dim pyrDefense As Player
				Dim Result As ISMActionResult
				Dim pobjAction As New DribbleAction(Me.GameEngine)

				If GetRoll(ISMRollType.Percentage) <= GetUnopposedPercentage() Then
					'Unopposed...
					.Clock.Tick(1, 6)
					.PlayByPlay.SetPlayers(pyrOffense, pyrOffense, Nothing, Nothing, Nothing)
					.GameLog.Create(.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.Dribble))
					Call SetBallMovement()
					Exit Sub
				Else
					'Opposed...
					pyrDefense = GetDefensivePlayer()
				End If

				pobjAction.Execute(pyrOffense, pyrDefense)
				.PlayByPlay.SetPlayers(pyrOffense, pyrOffense, pyrDefense, Nothing, Nothing)

				If pobjAction.Result = ISMActionResult.Success Then
					.Posession.Offense.FieldManager.Field.AssistPlayer = Nothing
					.GameLog.Create(.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.Dribble))
					Call SetBallMovement()
				Else
					.GameLog.Create(.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.DribbleSteal))
					Call SetBallMovement()
					.Posession.Switch()
				End If
				.Clock.Tick(2, 7)

			End With
		End Sub

		Private Function GetUnopposedPercentage() As Byte
			Return Me.GameEngine.Settings.Settings.GetFieldPenalty(Settings.ISM_GameSettingType.DribbleSequence, Me.GameEngine.Ball.Y)
		End Function

		Private Function GetDefensivePlayer() As Player
			With Me.GameEngine.Posession.Defense.FieldManager.Field
				Select Case Me.GameEngine.Ball.Y
					Case ISMBallVertical.OppCrease
						.GetRandomPlayerOnField(15, 30, 30, 10, 10, 5)
					Case ISMBallVertical.OppShortRange
						.GetRandomPlayerOnField(10, 30, 30, 10, 10, 10)
					Case ISMBallVertical.OppThird
						.GetRandomPlayerOnField(0, 30, 30, 15, 15, 10)
					Case ISMBallVertical.MidField
						.GetRandomPlayerOnField(0, 20, 20, 20, 20, 20)
					Case Else
						.GetRandomPlayerOnField(0, 10, 10, 25, 25, 30)
				End Select
			End With
		End Function

		Private Sub SetBallMovement()
			With Me.GameEngine.Ball
				Select Case .Y
					Case ISMBallVertical.OppShortRange
						.MoveUpfield(1, ISMBallVertical.OppCrease, 30)
					Case ISMBallVertical.OppShortRange
						.MoveUpfield(1, ISMBallVertical.OppCrease, 40)
					Case ISMBallVertical.OppCrease
						.MoveUpfield(-1, ISMBallVertical.MidField, 30)
					Case ISMBallVertical.OppThird
						.MoveUpfield(1, ISMBallVertical.OppCrease, 50)
					Case Else
						.MoveUpfield(1, ISMBallVertical.OppCrease, 70)
				End Select
				.MoveLateral(1, 25, 25)
			End With
		End Sub

	End Class
End Namespace

