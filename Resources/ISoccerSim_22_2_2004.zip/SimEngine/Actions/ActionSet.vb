'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports Microsoft.VisualBasic
Imports ISoccerSim.SimEngine.Actions.Plays

Namespace SimEngine.Actions
	Friend Class ActionSet
		Inherits CollectionBase

		Friend GameEngine As GameEngine

		Sub Add(ByVal objItem As Action)
			Me.InnerList.Add(objItem)
		End Sub

		Default Friend Property Item(ByVal Index As Integer) As Action
			Get
				Return CType(Me.InnerList.Item(Index), Action)
			End Get
			Set(ByVal Value As Action)
				Me.InnerList.Item(Index) = Value
			End Set
		End Property

		Sub New()
			Me.Add(New DribbleAction(Me.GameEngine))
			Me.Add(New BuzzAction(Me.GameEngine))
			Me.Add(New KickoffAction(Me.GameEngine))
			Me.Add(New PassAction(Me.GameEngine))
			Me.Add(New PassReceptionAction(Me.GameEngine))
			Me.Add(New PenaltyAction(Me.GameEngine))
			Me.Add(New ShotAttemptAction(Me.GameEngine))

		End Sub

		Function GetAction(ByVal ActionName As String) As Action
			Dim pobjItem As Action

			For Each pobjItem In Me.InnerList
				If pobjItem.Name = ActionName Then
					Return pobjItem.Clone()
				End If
			Next
		End Function

	End Class

End Namespace
