'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Leagues
Imports ISoccerSim.Players
Imports ISoccerSim.Positions
Imports ISoccerSim.Reporting
Imports ISoccerSim.Rosters
Imports ISoccerSim.Statistics
Imports ISoccerSim.Substitution
Imports ISoccerSim.SimEngine.PlayByPlay
Imports ISoccerSim.SimEngine.Settings
Imports ISoccerSim.SimEngine.Procedures
Imports ISoccerSim.Tactical
Imports ISoccerSim.Teams
Imports Microsoft.VisualBasic


Namespace SimEngine
	Friend Enum ISMGamePosition
		GK = 0
		LD = 1
		RD = 2
		LF = 3
		MF = 4
		RF = 5
	End Enum

	Friend Enum ISMGameStatus
		Normal = 0
		KickOff = 1
		KickIn = 2
		ThrowIn = 3
		GameOver = 4
		QuarterOver = 5
	End Enum

	Friend Enum ISMGameSituation
		Normal = 0
		PowerPlay = 1
		PenaltyKill = 2
	End Enum


	Friend Class GameEngine
		Friend HomeTeam As New Team()
		Friend AwayTeam As New Team()
        Friend WithEvents Posession As New Posession(Me)
		Friend WithEvents Clock As New Clock(Me)
		Friend Ball As New Ball()
		Friend GameLog As New GameLog()
		Friend PlayByPlay As New PlayByPlaySet()
		Friend Settings As New GameEngineSettingService()
        Friend Procedures As New ProcedureService(Me)
		Friend Coaching As New CoachingService(Me)
		Friend GameSummary As New GameSummary(Me)
		Friend StatSave As New StatSaveService(Me)
		Friend Status As ISMGameStatus
		Friend Referees As New RefereeSet()
        Friend PenaltyService As New PenaltyService(Me)
        Friend Attendance As Integer

		Friend Event QuarterOver()
		Friend Event GameOver()
		Friend Event PosessionChanged()
		Friend Event ScoreMade()

		Friend ScheduleID As Integer
		Friend SeasonID As Integer
		Friend GameDate As Date

		Private Sub LoadTeam(ByVal objTeam As Team)
			With objTeam
				.SubstitutionSets.Load(objTeam.TeamID)
				.Scoreboard = New Scoreboard()
				.Roster.Load(objTeam.TeamID)
				.CurrentLine = ISMSublineType.Starters
				.FieldManager.Reset()
				.FieldManager.Load(.Roster, .SubstitutionSets.Item(.CurrentLine))
				.TeamSituationSet.Load(.TeamID)
                .TeamTacticSet.Load()
            End With
        End Sub

        Sub Load(ByVal AwayTeamName As String, ByVal HomeTeamName As String)
            Dim pobjTeam As Team
            Dim AwayTeamID As Integer
            Dim HomeTeamID As Integer

            For Each pobjTeam In gobjLeague
                If pobjTeam.ToString = AwayTeamName Then
                    AwayTeamID = pobjTeam.TeamID
                End If

                If pobjTeam.ToString = HomeTeamName Then
                    HomeTeamID = pobjTeam.TeamID
                End If
            Next

            Me.Load(AwayTeamID, HomeTeamID)
        End Sub

        Sub Load(ByVal Game As Schedules.Game)
            Me.ScheduleID = Game.GameID
            Me.SeasonID = Game.Season
            Me.GameDate = Game.GameDate
            Call Load(Game.AwayTeamID, Game.HomeTeamID)
        End Sub

        Sub Load(ByVal AwayTeamID As Integer, ByVal HomeTeamID As Integer)

            Dim objTeam1 As New Team()
            Dim objTeam2 As New Team()

            objTeam1 = gobjLeague.GetTeamByID(HomeTeamID)
            objTeam2 = gobjLeague.GetTeamByID(AwayTeamID)

            Me.HomeTeam = objTeam1.Clone
            Me.AwayTeam = objTeam2.Clone

            Call LoadTeam(Me.HomeTeam)
            Call LoadTeam(Me.AwayTeam)

            Me.Settings.Load()

            Me.PlayByPlay.Load()
            Me.PlayByPlay.GameEngine = Me
            Me.GameLog.Clear()
            Me.Posession.Load(Me.AwayTeam, Me.HomeTeam)
            Me.Clock.Start()
            Me.Status = ISMGameStatus.KickOff
            Me.Referees = gobjReferees.GetRefsForGame()
            With Me.Posession
                .Offense.FieldManager.Field.ActivePlayer = .Offense.FieldManager.Field.GetPlayerByGamePosition(ISMGamePosition.MF)
                .Defense.FieldManager.Field.ActivePlayer = .Defense.FieldManager.Field.GetPlayerByGamePosition(ISMGamePosition.MF)
            End With


        End Sub

        Sub [Step]()
            If Me.Clock.IsEndOfGame Then
                Me.Status = ISMGameStatus.GameOver
                Me.FireEndOfGameEvent()
                Exit Sub
            End If

            If Me.Clock.IsEndOfQuarter Then
                Me.FireEndOfQuarterEvent()
                Me.Clock.Reset()
                Me.Posession.Switch()
                Me.Status = ISMGameStatus.KickOff
                Me.PenaltyService.ResetFoulsPerHalf()
                Me.Ball.PlaceAtMidField()
            End If

            Me.Procedures.GameSummaryToLog()
            Call RunPosession()

        End Sub

        Private Sub RunPosession()
            Me.Posession.Changed = False
            Me.PenaltyService.SetSituation()
            Me.PenaltyService.ResetCounters()

            If Me.Status = ISMGameStatus.KickOff Then
                Call Me.Procedures.Kickoff()
                Me.Status = ISMGameStatus.Normal
            End If

            If Me.Posession.Offense.FieldManager.Field.ActivePlayer.GamePosition = ISMGamePosition.GK Then
                If Me.Ball.Y = Actions.ISMBallVertical.OwnCrease And Me.Ball.X = Actions.ISMBallLateral.Middle Then
                    Call Me.Procedures.GoalieIn()
                Else
                    Call Me.Procedures.AdvanceToGoal()
                End If
            Else
                Call Me.Procedures.AdvanceToGoal()
            End If

            Call Me.Procedures.ManagePlayerEnergy()
            Call Me.Procedures.ManageGPI()
            Call Me.Procedures.ManageSubstitutions()
            Call Me.Procedures.ManagePlayersComingOutOfBox()

        End Sub

        Sub [End]()

        End Sub


        Private Sub FireEndOfQuarterEvent() Handles Clock.EndOfQuarter
            RaiseEvent QuarterOver()
        End Sub

        Private Sub FireEndOfGameEvent() Handles Clock.EndOfGame
            Me.Status = ISMGameStatus.GameOver
            RaiseEvent GameOver()
        End Sub

        Private Sub WriteDebugFile()
            FileOpen(1, "c:\dump.txt", OpenMode.Append, OpenAccess.Write, OpenShare.Shared)
            Write(1, Me.GameLog.DumpToConsole)
            FileClose(1)

        End Sub

        Sub FireScoreEvent()
            RaiseEvent ScoreMade()
        End Sub

    End Class
End Namespace