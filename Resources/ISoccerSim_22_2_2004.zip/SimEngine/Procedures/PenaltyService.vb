'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.SimEngine.Actions
Imports ISoccerSim.SimEngine.Actions.Plays
Imports ISoccerSim.SimEngine.Actions.Sequence
Imports ISOccerSim.SimEngine.Penalty
Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports Microsoft.VisualBasic
Imports ISoccerSim.Players
Imports ISoccerSim.SimEngine
Imports ISoccerSim.Teams
Imports ISoccerSim.Tactical
Imports ISoccerSim.Substitution


Namespace SimEngine.Procedures
	Friend Class PenaltyService
        Friend GameEngine As GameEngine
        Friend PenaltySet As New PenaltySet()
        Friend DelayedCardThrown As ISM_CardThrown
        Friend InterruptPlay As Boolean
        Friend SwitchPosession As Boolean
        Friend ShootOutSituation As Boolean


        Friend Sub New(ByVal GameEngine As GameEngine)
            Me.GameEngine = GameEngine
            Me.PenaltySet.Load()
        End Sub

        Friend Sub ResetFoulsPerHalf()
            If Me.GameEngine.Clock.IsEndOfHalf Then
                Dim pobjPlayer As Player
                For Each pobjPlayer In Me.GameEngine.AwayTeam.FieldManager.PlayerSet
                    pobjPlayer.FoulsPerHalf = 0
                Next

                For Each pobjPlayer In Me.GameEngine.HomeTeam.FieldManager.PlayerSet
                    pobjPlayer.FoulsPerHalf = 0
                Next
            End If

        End Sub

        Friend Sub ManageInfraction(ByVal pyrPenalty As Player)
            Dim pobjPlayer As Player
            Dim pobjPenalty As Penalty.Penalty
            If pyrPenalty.GamePosition = ISMGamePosition.GK Then
                pobjPenalty = Me.PenaltySet.GetPenalty(Penalty.ISM_PenaltyType.Goalie)
            Else
                pobjPenalty = Me.PenaltySet.GetPenalty(Penalty.ISM_PenaltyType.Player)
            End If

            pobjPenalty.SetSeverity(pyrPenalty)
            pyrPenalty.FoulsPerHalf += 1
            pyrPenalty.Stats.Augment(Statistics.ISMStat.Fouls)

            If pyrPenalty.IsFourFoulsPerHalf Then
                pobjPenalty.Severity = Penalty.ISM_CardThrown.Blue
            End If

            If pobjPenalty.IsTimePenalty Then
                SetShootoutSituation(pyrPenalty)
                pobjPenalty.AugmentPenaltyMinutes(pyrPenalty)
                pyrPenalty.TimePenaltyFoulsInGame += 1
                If pyrPenalty.TooManyTimeFoulsInGame Then
                    pobjPenalty.Severity = Penalty.ISM_CardThrown.Red
                End If
            End If


            Me.GameEngine.PlayByPlay.Penalty = pobjPenalty
            Me.GameEngine.PlayByPlay.PenaltyPlayer = pyrPenalty
            Me.GameEngine.GameLog.Create(Me.GameEngine.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.Penalty))
            Me.GameEngine.PlayByPlay.Penalty = Nothing
            Me.GameEngine.PlayByPlay.PenaltyPlayer = Nothing
            Call HandlePlayerRemoval(pobjPenalty, pyrPenalty)
            Call HandlePlayAfterInfraction(pobjPenalty, pyrPenalty)


        End Sub

        Friend Sub SetShootoutSituation(ByVal pyrPenalty As Player)
            If Me.GameEngine.Ball.Y = ISMBallVertical.OppCrease And _
                GetRoll(ISMRollType.Percentage) <= 10 And _
                Me.IsPenaltyCausedByDefense(pyrPenalty) Then

                Me.ShootOutSituation = True
            Else
                Me.ShootOutSituation = False
            End If
        End Sub

        Friend Sub ResetCounters()
            Me.DelayedCardThrown = Penalty.ISM_CardThrown.Regular
            Me.InterruptPlay = False
            Me.SwitchPosession = False
            Me.ShootOutSituation = False
        End Sub

        Friend Sub SetSituation()

            Dim intOffenseInBox As Integer = Me.GameEngine.Posession.Offense.FieldManager.Box.Count
            Dim intDefenseInBox As Integer = Me.GameEngine.Posession.Defense.FieldManager.Box.Count

            If intOffenseInBox > intDefenseInBox Then
                Me.GameEngine.Posession.Offense.CurrentGameSituation = ISMGameSituation.PenaltyKill
                Me.GameEngine.Posession.Defense.CurrentGameSituation = ISMGameSituation.PowerPlay
            ElseIf intOffenseInBox < intDefenseInBox Then
                Me.GameEngine.Posession.Offense.CurrentGameSituation = ISMGameSituation.PowerPlay
                Me.GameEngine.Posession.Defense.CurrentGameSituation = ISMGameSituation.PenaltyKill
            Else
                Me.GameEngine.Posession.Offense.CurrentGameSituation = ISMGameSituation.Normal
                Me.GameEngine.Posession.Defense.CurrentGameSituation = ISMGameSituation.Normal
            End If

        End Sub

        Private Sub HandlePlayAfterInfraction(ByVal Penalty As Penalty.Penalty, ByVal Player As Player)

            If Me.IsPenaltyCausedByDefense(Player) Then
                If Me.GameEngine.Ball.IsBallInPenaltyArea Then
                    If Me.ShootOutSituation Then
                        Call SetupShootout()
                    Else
                        Call SetUpPenaltyKick()
                    End If

                Else
                    Call SetupFreeKick()
                End If
            Else
                Me.GameEngine.Posession.Switch()
                Call SetupFreeKick()
            End If
        End Sub

        Private Sub HandlePlayerRemoval(ByVal objPenalty As Penalty.Penalty, ByVal Player As Player)
            If objPenalty.Severity = Penalty.ISM_CardThrown.Regular Then Exit Sub

            Dim pobjTeam As Team = GetTeamOfPenalizedPlayer(Player)

            If objPenalty.Severity = Penalty.ISM_CardThrown.Blue Then
                If pobjTeam.FieldManager.Field.CanRemoveManFromField Then
                    Player.TimePenaltySet.Create(objPenalty, Me.GameEngine.Clock)
                    pobjTeam.FieldManager.MovePlayerFromFieldToBox(Player)
                End If
            ElseIf objPenalty.Severity = Penalty.ISM_CardThrown.Red Then
                pobjTeam.FieldManager.EjectPlayer(Player)
                Me.GameEngine.Coaching.AdjustLinesAfterEjection(pobjTeam, Player)
            End If
        End Sub

        Private Function GetTeamOfPenalizedPlayer(ByVal objPlayer As Player) As Team
            Return IIf(Me.IsPenaltyCausedByDefense(objPlayer), Me.GameEngine.Posession.Defense, Me.GameEngine.Posession.Offense)

        End Function

        Public Sub HandlePlayerReturns()
            Call HandlePlayerReturns(Me.GameEngine.Posession.Defense)
            Call HandlePlayerReturns(Me.GameEngine.Posession.Offense)
        End Sub

        Public Sub HandlePlayerReturnAfterGoal(ByVal objTeam As Team)
            If objTeam.FieldManager.Box.Count = 0 Then Exit Sub

            Dim objBox As New ArrayList()
            Dim pobjPlayer As Player
            Dim i As Integer

            ' Repeated code.... so sorry...
            If objTeam.FieldManager.Box.Count = 2 Then
                pobjPlayer = objTeam.FieldManager.Box.Item(1)
                If objTeam.SubstitutionSets(objTeam.CurrentLine).IsPlayerOnLine(pobjPlayer) Then
                    objTeam.FieldManager.MovePlayerBackOnField(pobjPlayer)
                Else
                    objTeam.FieldManager.MovePlayerFromBoxToBench(pobjPlayer)
                End If
            End If

            If objTeam.FieldManager.Box.Count = 1 Then
                pobjPlayer = objTeam.FieldManager.Box.Item(0)
                If objTeam.SubstitutionSets(objTeam.CurrentLine).IsPlayerOnLine(pobjPlayer) Then
                    objTeam.FieldManager.MovePlayerBackOnField(pobjPlayer)
                Else
                    objTeam.FieldManager.MovePlayerFromBoxToBench(pobjPlayer)
                End If
            End If

        End Sub

        Private Sub HandlePlayerReturns(ByVal objTeam As Team)
            If objTeam.FieldManager.Box.Count = 0 Then Exit Sub

            Dim objBox As New ArrayList()
            Dim pobjPlayer As Player
            Dim i As Integer

            ' Repeated code.... so sorry...
            If objTeam.FieldManager.Box.Count = 2 Then
                pobjPlayer = objTeam.FieldManager.Box.Item(1)
                If pobjPlayer.TimePenaltySet.CanReturnToField(Me.GameEngine.Clock) Then
                    If objTeam.SubstitutionSets(objTeam.CurrentLine).IsPlayerOnLine(pobjPlayer) Then
                        objTeam.FieldManager.MovePlayerBackOnField(pobjPlayer)
                    Else
                        objTeam.FieldManager.MovePlayerFromBoxToBench(pobjPlayer)
                    End If
                End If
            End If

            If objTeam.FieldManager.Box.Count = 1 Then
                pobjPlayer = objTeam.FieldManager.Box.Item(0)
                If pobjPlayer.TimePenaltySet.CanReturnToField(Me.GameEngine.Clock) Then
                    If objTeam.SubstitutionSets(objTeam.CurrentLine).IsPlayerOnLine(pobjPlayer) Then
                        objTeam.FieldManager.MovePlayerBackOnField(pobjPlayer)
                    Else
                        objTeam.FieldManager.MovePlayerFromBoxToBench(pobjPlayer)
                    End If
                End If
            End If


        End Sub


        Private Function IsPenaltyCausedByDefense(ByVal Player As Player) As Boolean
            Return Me.GameEngine.Posession.Defense.FieldManager.IsPlayerOnTeam(Player)
        End Function

        Private Sub SetUpPenaltyKick()
            Dim pyrOffense As Player = Me.GameEngine.Posession.Offense.FieldManager.Field.ActivePlayer
            Dim pyrGoalie As Player = Me.GameEngine.Posession.Defense.FieldManager.Field.GetPlayerByGamePosition(ISMGamePosition.GK)
            Me.InterruptPlay = True
            Me.GameEngine.Ball.Y = ISMBallVertical.OppThird
            Me.GameEngine.Ball.X = ISMBallLateral.MidLeft
            Me.GameEngine.PlayByPlay.SetPlayers(pyrOffense, pyrOffense, Nothing, pyrGoalie, Nothing)
            Me.GameEngine.GameLog.Create(Me.GameEngine.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.PenaltyKickSetup))
            Me.GameEngine.Procedures.SetUpPenaltyShotSequence()

        End Sub

        Private Sub SetupFreeKick()
            Me.InterruptPlay = True
            Dim pyrOffense As Player = Me.GameEngine.Posession.Offense.FieldManager.Field.ActivePlayer
            Me.GameEngine.PlayByPlay.SetPlayers(pyrOffense, pyrOffense, Nothing, Nothing, Nothing)
            Me.GameEngine.GameLog.Create(Me.GameEngine.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.FreeKickSetup))
        End Sub

        Private Sub SetupShootout()
            Me.InterruptPlay = True
            Me.ShootOutSituation = True
            Me.GameEngine.Ball.Y = ISMBallVertical.OppShortRange
            Me.GameEngine.Ball.X = ISMBallLateral.Middle
            Me.GameEngine.Procedures.SetUpShootoutSequence()

            Dim pyrOffense As Player = Me.GameEngine.Posession.Offense.FieldManager.Field.ActivePlayer
            Dim pyrGoalie As Player = Me.GameEngine.Posession.Defense.FieldManager.Field.GetPlayerByGamePosition(ISMGamePosition.GK)

            Me.GameEngine.PlayByPlay.SetPlayers(pyrOffense, pyrOffense, Nothing, pyrGoalie, Nothing)
            Me.GameEngine.GameLog.Create(Me.GameEngine.PlayByPlay.Narrate(PlayByPlay.PlayByPlaySupport.ISM_PBPSituation.PenaltyKickSetup))
        End Sub

        Private Sub ActivateDelayedCard(ByVal Penalty As Penalty.Penalty)
            Me.DelayedCardThrown = Penalty.Severity
        End Sub


    End Class
End Namespace