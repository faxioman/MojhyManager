'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.SimEngine.Actions
Imports ISoccerSim.SimEngine.Actions.Plays
Imports ISoccerSim.SimEngine.Actions.Sequence
Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports Microsoft.VisualBasic
Imports ISoccerSim.Players
Imports ISoccerSim.SimEngine
Imports ISoccerSim.Teams
Imports ISoccerSim.Tactical
Imports ISoccerSim.Substitution

Namespace SimEngine.Procedures
	Friend Class CoachingService
		Friend WithEvents GameEngine As GameEngine

        Sub New(ByVal GameEngine As GameEngine)
            Me.GameEngine = GameEngine
        End Sub

        Sub SetLines()
            Call SelectTeamLine(Me.GameEngine.Posession.Offense)
            Call SelectTeamLine(Me.GameEngine.Posession.Defense)
        End Sub

        Sub AdjustLinesAfterEjection(ByVal objTeam As Team, ByVal objPlayer As Player)
            objTeam.SubstitutionSets.SwapPlayerAfterEjection(objTeam, objPlayer)
        End Sub

        Private Sub SelectTeamLine(ByVal objTeam As Team)
            Dim Line As Integer = objTeam.CurrentLine
            Dim pobjFinder As New SituationFinderService(Me.GameEngine, objTeam)
            Dim pobjSituation As TeamSituation = pobjFinder.GetSituation()
            Dim psetOtherLine As GamePlayerSet

            With pobjSituation
                'Keep line if situation matches...
                If Line = .PrimaryLineID Then
                    If objTeam.FieldManager.Field.GetAverageEnergy >= pobjSituation.SubOutPercentage Then
                        Exit Sub
                    End If
                End If

                'Keep line if secondary line is in, but primary is not rested...
                If Line = .SecondaryLineID Then
                    psetOtherLine = objTeam.FieldManager.GetGamePlayerSetFromLine(objTeam.SubstitutionSets.Item(ISMSublineType.Starters))
                    If psetOtherLine.GetAverageEnergy <= pobjSituation.SubInPercentage Then
                        Exit Sub
                    End If
                End If
            End With

            'Bring in first line if possible, otherwise, send in the reservists...
            psetOtherLine = objTeam.FieldManager.GetGamePlayerSetFromLine(objTeam.SubstitutionSets.Item(ISMSublineType.Starters))
            If psetOtherLine.GetAverageEnergy >= pobjSituation.SubOutPercentage Then
                objTeam.FieldManager.PutLineOnField(psetOtherLine)
                objTeam.CurrentLine = ISMSublineType.Starters
            Else
                psetOtherLine = objTeam.FieldManager.GetGamePlayerSetFromLine(objTeam.SubstitutionSets.Item(ISMSublineType.SecondLine))
                objTeam.FieldManager.PutLineOnField(psetOtherLine)
                objTeam.CurrentLine = ISMSublineType.SecondLine
            End If

        End Sub

    End Class
End Namespace
