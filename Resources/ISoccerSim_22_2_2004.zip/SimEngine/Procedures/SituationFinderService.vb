'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.SimEngine.Actions
Imports ISoccerSim.SimEngine.Actions.Plays
Imports ISoccerSim.SimEngine.Actions.Sequence
Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports Microsoft.VisualBasic
Imports ISoccerSim.Players
Imports ISoccerSim.SimEngine
Imports ISoccerSim.Teams
Imports ISoccerSim.Tactical

Namespace SimEngine.Procedures
	Friend Class SituationFinderService
		Friend WithEvents GameEngine As GameEngine
		Friend Situation As Situation
		Friend Team As Team


		Sub New(ByVal GameEngine As GameEngine, ByVal Team As Team)
			Me.GameEngine = GameEngine
			Me.Team = Team
		End Sub

		Function GetSituation() As TeamSituation
			Dim pobjItem As TeamSituation
			Dim pobjGameSituation As Situation
			Dim pblnMatch As Boolean = False

			For Each pobjItem In Me.Team.TeamSituationSet
				pobjGameSituation = GetMatchingSituation(pobjItem)
				With pobjGameSituation
					If IsRightHalf(pobjGameSituation) Then
						If IsRightTimeFrame(pobjGameSituation) Then
							If Me.IsRightScoringRange(pobjGameSituation) Then
								Return pobjItem
							End If
						End If
					End If
				End With
			Next

			'No situation applies, so we'll make one up...
			pobjItem = New TeamSituation()
			With pobjItem
				.PrimaryLineID = Me.Team.SubstitutionSets.Item(Substitution.ISMSublineType.Starters).SubstitutionLineID
				.SecondaryLineID = Me.Team.SubstitutionSets.Item(Substitution.ISMSublineType.SecondLine).SubstitutionLineID
				.SituationID = App.gobjSituationSet.Item(0).SituationID
				.TeamID = Me.Team.TeamID
				.TeamSituationID = 0
			End With
			Return pobjItem

		End Function


		Private Function GetMatchingSituation(ByVal objSituation As TeamSituation) As Situation
			Dim pobjSituation As Situation
			For Each pobjSituation In gobjSituationSet
				If pobjSituation.SituationID = objSituation.SituationID Then
					Return pobjSituation
				End If
			Next
			Return gobjSituationSet.Item(ISMDefaultSituation.Default)
		End Function

		Function IsRightHalf(ByVal objSituation As Situation) As Boolean
			With Me.GameEngine.Clock
				Select Case objSituation.Half
					Case 0				'Default...
						Return True
					Case 1
						If .Quarter = 1 Or .Quarter = 2 Then
							Return True
						Else
							Return False
						End If
					Case 2
						If .Quarter > 2 Then
							Return True
						Else
							Return False
						End If
				End Select
			End With
		End Function

		Private Function IsRightTimeFrame(ByVal objSituation As Situation) As Boolean
			With Me.GameEngine.Clock
				If objSituation.Half = 0 Then
					Return True
				Else
					If .GetSituationMinute > objSituation.MinuteFrom Then
						If .GetSituationMinute <= objSituation.MinuteTo Then
							Return True
						End If
					End If
				End If
				
			End With
			Return False
		End Function

		Private Function IsRightScoringRange(ByVal objSituation As Situation) As Boolean
			With Me.Team.Scoreboard
				If objSituation.Half = 0 Then
					Return True
				End If

				Select Case gobjLeague.MultiPoint
					Case True
						If .Score >= objSituation.MultiNetLow Then
							If .Score <= objSituation.MultiNetHigh Then
								Return True
							End If
						End If
						Return False
					Case False
						If .Score >= objSituation.MultiNetLow Then
							If .Score <= objSituation.MultiNetHigh Then
								Return True
							End If
						End If
						Return False
				End Select
			End With
			Debug.Assert(False, "Should not get to here.")
		End Function

		Private Function IsRightGameSituation(ByVal objSituation As Situation) As Boolean
			With objSituation
				Select Case Me.Team.CurrentGameSituation
					Case ISMGameSituation.Normal
						If Not (.IsPenaltyKill And .IsPowerPlay) Then
							Return True
						Else
							Return False
						End If

					Case ISMGameSituation.PenaltyKill
						If .IsPenaltyKill Then
							Return True
						Else
							Return False
						End If

					Case ISMGameSituation.PowerPlay
						If .IsPowerPlay Then
							Return True
						Else
							Return False
						End If
				End Select
			End With
		End Function

	End Class
End Namespace