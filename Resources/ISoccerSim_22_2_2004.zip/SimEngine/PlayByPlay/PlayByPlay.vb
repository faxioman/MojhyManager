'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports Microsoft.VisualBasic
Imports ISoccerSim.Players
Imports ISoccerSim.Teams

Namespace SimEngine.PlayByPlay

	Friend Class PlayByPlay
		Inherits CollectionBase
		Implements IComparable

		Friend Name As String
		Friend Abbreviation As String
		Friend PlayByPlayID As Integer
		Friend Total As Double
		Friend GameEngine As GameEngine

		Friend PlayerPassTo As Player
		Friend BallHandler As Player
		Friend Defender As Player
		Friend Goalie As Player
		Friend ActivePlayer As Player
		Friend Clock As Clock
		Friend Posession As Posession

		Sub Add(ByVal objItem As PlayByPlayComment)
			Me.InnerList.Add(objItem)
		End Sub

		Default Friend Property Item(ByVal Index As Integer) As PlayByPlayComment
			Get
				Return CType(Me.InnerList.Item(Index), PlayByPlayComment)
			End Get
			Set(ByVal Value As PlayByPlayComment)
				Me.InnerList.Item(Index) = Value
			End Set
		End Property

		Sub Create(ByVal PlayByPlayCommentID As Integer, ByVal Narrative As String, ByVal Probability As Double)
			Dim pobjItem As New PlayByPlayComment()
			With pobjItem
				.PlayByPlayID = Me.PlayByPlayID
				.PlayByPlayCommentID = PlayByPlayCommentID
				.Narrative = Narrative
				.Probability = Me.Total + Probability
			End With
			Me.Add(pobjItem)
			Me.Total = Me.Total + Probability
		End Sub

		Sub Load()
			Dim pobjData As New DataServices.BaseTables()
			Dim pobjDR As OleDb.OleDbDataReader = pobjData.GetPlayByPlayItems(Me.PlayByPlayID)
			Do While pobjDR.Read()
				Me.Create(pobjDR.Item("ItemID"), pobjDR.Item("Description"), pobjDR.Item("Probability"))
			Loop
			pobjDR.Close()
		End Sub

		Function GetNarrative() As String
			Dim pobjItem As PlayByPlayComment

			Dim i As Integer
			Dim r As Integer = App.RandomNumber(1, Me.Total)

			For i = 0 To Me.InnerList.Count - 1
				pobjItem = Me.InnerList.Item(i)
				If r <= pobjItem.Probability Then
					Return pobjItem.Narrative
				End If
			Next
			Debug.Assert(False)
		End Function

		Overrides Function ToString() As String
			Return Me.Name
		End Function

		Private Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
			If obj Is Nothing Then Return 1
			Dim other As PlayByPlay = CType(obj, PlayByPlay)
			Return StrComp(Me.ToString, other.ToString, CompareMethod.Text)
		End Function



	End Class




End Namespace