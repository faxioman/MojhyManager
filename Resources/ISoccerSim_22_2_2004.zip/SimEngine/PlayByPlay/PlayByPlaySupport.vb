'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Namespace SimEngine.PlayByPlay

    Friend Module PlayByPlaySupport
        'Play by play ad-lib constants...
        Friend Const PBP_PASSTO = "%PASSTO%"
        Friend Const PBP_BALLHANDLER = "%OFF%"
        Friend Const PBP_DEFENDER = "%DEF%"
        Friend Const PBP_GOALIE = "%GK%"
        Friend Const PBP_ACTIVE = "%ACTIVE%"

        Friend Const PBP_PASSTO_FULL = "%PASSTO_FULL%"
        Friend Const PBP_BALLHANDLER_FULL = "%OFF_FULL%"
        Friend Const PBP_DEFENDER_FULL = "%DEF_FULL%"
        Friend Const PBP_GOALIE_FULL = "%GK_FULL%"
        Friend Const PBP_ACTIVE_FULL = "%ACTIVE_FULL%"
        Friend Const PBP_PENALTY_FULL = "%PENALTY%"

        Friend Const PBP_RANDOMCROWDNAME = "%GUYINCROWD%"
        Friend Const PBP_RANDOMPLAYERNAME = "%GUYINGAME%"
        Friend Const PBP_HOMETEAMCITY = "%HOMECITY%"
        Friend Const PBP_HOMETEAMNICKNAME = "%HOMENICK%"
        Friend Const PBP_HOMETEAMSCORE = "%HOMESCORE%"
        Friend Const PBP_AWAYTEAMCITY = "%AWAYCITY%"
        Friend Const PBP_AWAYTEAMNICKNAME = "%AWAYNICK%"
        Friend Const PBP_AWAYTEAMSCORE = "%AWAYSCORE%"
        Friend Const PBP_ARENA = "%ARENA%"
        Friend Const PBP_HOMETEAMCOACH = "%HOMECOACH%"
        Friend Const PBP_AWAYTEAMCOACH = "%AWAYCOACH%"
        Friend Const PBP_OFFTEAM = "%TEAM_OFF%"
        Friend Const PBP_DEFTEAM = "%TEAM_DEF%"


        Friend Const PBP_QUARTER = "%Q%"
        Friend Const PBP_MINUTES = "%M%"
        Friend Const PBP_SECONDS = "%S%"
        Friend Const PBP_TIME = "%TIME%"
        Friend Const PBP_POSITION = "%BALLPOSITION%"


        Friend Enum ISM_PBPSituation
            Introduction = 1
            Kickoff = 2
            TwoOnOne = 3
            PlayerStop = 4
            ThreeOnOne = 5
            RegularGoal = 6
            CriticalGoal = 7
            CloseGame = 8
            BlowOut = 9
            Momentum = 10

            Inbound = 11
            BadPlayerPersonality = 12
            CrowdPersonality = 13
            Penalty = 14
            Exclamation = 15
            SideComment = 16
            PowerPlayGoal = 17
            PenaltyKillGoal = 18
            ShotOnGoal = 19
            MissedShotOnGoal = 20

            GoalieStopOnGoal = 21
            CoolGoalieStop = 22
            Ejection = 23
            GameSituation = 24
            PassSteal = 25
            PassBlock = 26
            PassBlown = 27
            Dribble = 28
            DribbleSteal = 29
            Bizarre = 30

            BadCall = 31
            OneOnOne = 32
            PassOutOfPlay = 33
            ShotOutOfPlay = 34
            Regroup = 35
            ReboundOff = 36
            ReboundDef = 37
            Pass = 38
            BlockedShotOnGoal = 39

            ShootoutSetup = 40
            PenaltyKickSetup = 41
            FreeKickSetup = 42
        End Enum

    End Module
End Namespace

