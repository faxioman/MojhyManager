'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Teams

Namespace SimEngine
	Friend Class Posession
		Friend Offense As Team
		Friend Defense As Team
		Friend HomeTeam As Team
		Friend AwayTeam As Team
		Friend Changed As Boolean
		Friend GameEngine As GameEngine

		Sub New(ByVal GameEngine As GameEngine)
			Me.GameEngine = GameEngine
		End Sub

		Friend Event PosessionChanged(ByVal sender As Object, ByVal e As PosessionChangedEventArgs)

		Sub Switch()
			Dim pobjTemp As New Team()
			Dim Dupe As String = Me.Offense.FieldManager.Field.ActivePlayer.DisplayName

			pobjTemp = Me.Offense
			Me.Offense = Me.Defense
			Me.Defense = pobjTemp
			Me.GameEngine.Ball.Flip()
			Me.Changed = True

			'RaiseEvent PosessionChanged(Me, New PosessionChangedEventArgs())
			If Dupe = Me.Offense.FieldManager.Field.ActivePlayer.DisplayName Then
				MsgBox("Something has gone wrong.")
			End If

		End Sub

		Sub SetKick(ByVal objTeam As Team)
			If objTeam.TeamID <> Me.Offense.TeamID Then
				Call Me.Switch()
			End If
		End Sub

		Sub Load(ByVal objAway As Team, ByVal objHome As Team)
			Me.HomeTeam = objHome
			Me.AwayTeam = objAway
            Me.Offense = objAway
            Me.Defense = objHome
		End Sub


	End Class
End Namespace