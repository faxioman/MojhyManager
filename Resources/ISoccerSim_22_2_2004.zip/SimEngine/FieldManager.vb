'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports System
Imports System.Collections
Imports System.Diagnostics.Debug
Imports ISoccerSim.Rosters
Imports ISoccerSim.Players
Imports ISoccerSim.Substitution
Imports ISoccerSim.SimEngine
Imports Microsoft.VisualBasic

Namespace SimEngine

	Friend Class FieldManager
		Friend Field As New FieldSet()
		Friend Bench As New GamePlayerSet()
		Friend Box As New GamePlayerSet()
		Friend LockerRoom As New GamePlayerSet()

		Friend PlayerSet As New GamePlayerSet()

		Friend GameWinningPlayer As Player
		Friend WinningGoalie As Player
		Friend LosingGoalie As Player

		Friend Enum ISMFieldServiceZone
			Field = 0
			Bench = 1
			Box = 2
			LockerRoom = 4
		End Enum

		Sub Reset()
			Me.Field.Clear()
			Me.Bench.Clear()
			Me.Box.Clear()
			Me.LockerRoom.Clear()
			Me.PlayerSet.Clear()
		End Sub

		Sub Load(ByVal intPlayerID As Integer, ByVal intLocation As ISMFieldServiceZone)
			Dim pobjItem As New Player()
			pobjItem.ID = intPlayerID

			Select Case intLocation
				Case ISMFieldServiceZone.Field
					Me.Field.Add(pobjItem)
				Case ISMFieldServiceZone.Bench
					Me.Bench.Add(pobjItem)
				Case ISMFieldServiceZone.Box
					Me.Box.Add(pobjItem)
				Case ISMFieldServiceZone.LockerRoom
					Me.LockerRoom.Add(pobjItem)
			End Select
		End Sub

		Sub Load(ByVal objRoster As Roster, ByVal objStartingLine As SubstitutionLine)
			Dim pobjItem As New RosterSlot()
			Dim pobjPlayer As Player
			Dim pblnStarter As Boolean


			For Each pobjItem In objRoster
				pblnStarter = False
				pobjPlayer = New Player()
				pobjPlayer = pobjItem.Player
				pobjPlayer.Stats.Load()

				Dim pobjSubItem As SubstitutionSlot
				For Each pobjSubItem In objStartingLine
					If pobjSubItem.PlayerID = pobjPlayer.ID Then
						pobjPlayer.GamePosition = pobjSubItem.GamePositionID
						Me.Field.Add(pobjPlayer)
						pblnStarter = True
					End If
				Next

				If Not pblnStarter Then
					Me.Bench.Add(pobjPlayer)
				End If

				'Add to global list...
				Me.PlayerSet.Add(pobjPlayer)
			Next
		End Sub

		Function GetGamePlayerSetFromLine(ByVal objSubline As SubstitutionLine) As GamePlayerSet
			Dim pobjItem As Player
			Dim pobjSlot As SubstitutionSlot
			Dim psetOut As New GamePlayerSet()

			For Each pobjSlot In objSubline
				For Each pobjItem In Me.PlayerSet
					If pobjSlot.PlayerID = pobjItem.ID Then
						pobjItem.GamePosition = pobjSlot.GamePositionID
						psetOut.Add(pobjItem)
					End If
				Next
			Next

			Return psetOut
		End Function

		Sub PutLineOnField(ByVal objGamePlayerSet As GamePlayerSet)
			Dim i As Integer
			Dim pobjItem As Player
			Dim pobjSlot As SubstitutionSlot
			Dim psetOut As New GamePlayerSet()

			Me.Field.Clear()
            For Each pobjItem In objGamePlayerSet
                If Not Me.Box.IsPlayerHere(pobjItem) Then
                    Me.Field.Add(pobjItem)
                End If
            Next

        End Sub

        Function IsPlayerOnTeam(ByVal objPlayer As Player) As Boolean
            Dim pobjItem As Player
            For Each pobjItem In Me.PlayerSet
                If pobjItem.ID = objPlayer.ID Then Return True
            Next
        End Function

        Sub MovePlayerFromFieldToBox(ByVal objPlayer As Player)
            If Me.Field.IsPlayerHere(objPlayer) Then
                Me.Box.Add(objPlayer)
                Me.Field.Remove(objPlayer)
            End If
        End Sub

        Sub MovePlayerFromBoxToBench(ByVal objPlayer As Player)
            If Me.Box.IsPlayerHere(objPlayer) Then
                Me.Bench.Add(objPlayer)
                Me.Box.Remove(objPlayer)
            End If
        End Sub

        Sub MovePlayerBackOnField(ByVal objPlayer As Player)
            If Me.Box.IsPlayerHere(objPlayer) Then
                Me.Field.Add(objPlayer)
                Me.Box.Remove(objPlayer)
            ElseIf Me.Bench.IsPlayerHere(objPlayer) Then
                Me.Field.Add(objPlayer)
                Me.Bench.Remove(objPlayer)
            End If
        End Sub

        Sub EjectPlayer(ByVal objPlayer As Player)
            If Me.Field.IsPlayerHere(objPlayer) Then
                Me.LockerRoom.Add(objPlayer)
                Me.Field.Remove(objPlayer)
            End If
        End Sub


        Function GetSubstitutionCandidates(ByVal objPlayer As Player) As GamePlayerSet
            Dim PositionID = objPlayer.Position
            Dim pobjItem As Player
            Dim pobjSet As New GamePlayerSet()

            For Each pobjItem In Me.PlayerSet
                If Not Me.LockerRoom.IsPlayerHere(pobjItem) Then
                    If pobjItem.Position = objPlayer.Position Then
                        If pobjItem.ID <> objPlayer.ID Then
                            pobjSet.Add(pobjItem)
                        End If
                    End If
                End If
            Next

            'pobjSet.Sort
            Debug.Assert(pobjSet.Count > 0, "Blank set")
            Return pobjSet
        End Function

        Sub MovePlayerFromFieldToBench(ByVal objPlayer As Player)
            If Me.Field.IsPlayerHere(objPlayer) Then
                Me.Box.Add(objPlayer)
                Me.Bench.Remove(objPlayer)
            End If
        End Sub


    End Class





End Namespace