'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.SimEngine
Imports ISoccerSim.Substitution
Imports ISoccerSim.Rosters
Imports ISoccerSim.Statistics
Imports ISoccerSim.Cities

Namespace Teams
	Friend Class Team
		Inherits System.Collections.CollectionBase
		Implements ICloneable
		Implements IComparable

		Friend TeamID As Integer
		Friend ConferenceID As Integer
		Friend DivisionID As Integer
		Friend CityID As Integer
		Friend Name As String
		Friend Nickname As String
		Friend Logo As String
		Friend Mascot As String
		Friend OwnerEmail As String
		Friend OwnerName As String
		Friend Abbreviation As String
		Friend IsCPUOwned As Boolean
		Friend Roster As New Roster()
		Friend FacilityID As Integer

		'Game engine specific stuff...
		Friend Scoreboard As New Scoreboard()
        Friend FieldManager As New FieldManager()

        Friend SubstitutionSets As New SubstitutionLineSet()
		Friend TeamTacticSet As New Tactical.TacticSet()
		Friend TeamSituationSet As New Tactical.TeamSituationSet()

		Friend CurrentLine As ISMSublineType
        Friend CurrentGameSituation As ISMGameSituation
        Friend MediaSet As Finances.MediaSet

        Private m_FacilityName As String
        Friend ExpectedAttendance As Integer

        Sub Save()
            Dim pobjData As New DataServices.TeamTables()
            pobjData.InsertTeam(Me)
            pobjData.Close()
        End Sub

        Sub UpdateSettingsOnly()
            Dim pobjData As New DataServices.TeamTables()
            pobjData.UpdateTeamSettings(Me)
            pobjData.Close()
        End Sub

        Public Overrides Function ToString() As String
            Return Me.Name & " " & Me.Nickname
        End Function

        Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
            If obj Is Nothing Then Return 1

            Dim other As Team = CType(obj, Team)
            Return StrComp(Me.Name & " " & Me.Nickname, other.Name & " " & other.Nickname, CompareMethod.Text)
        End Function

        Default Property Item(ByVal index As Integer) As Team
            Get
                Return CType(InnerList.Item(index), Team)
            End Get
            Set(ByVal Value As Team)
                InnerList.Item(index) = Value
            End Set
        End Property

        Sub Add(ByVal value As Team)
            InnerList.Add(value)
        End Sub

        Function Clone() As Object Implements ICloneable.Clone
            Dim pobjTeam As New Team()
            pobjTeam = Me.MemberwiseClone
            Return pobjTeam
        End Function

        Friend ReadOnly Property FacilityName() As String
            Get
                If FacilityName = "" Then
                    Dim pobjFacility As New Facility()
                    pobjFacility.Load(Me.FacilityID)
                    m_FacilityName = pobjFacility.Name
                End If
                Return m_FacilityName
            End Get

        End Property

        Friend Property DisplayMember() As String
            Get
                Return "  " & Me.Name
            End Get
            Set(ByVal Value As String)
                'Pass
            End Set
        End Property

        Friend Property ValueMember() As Integer
            Get
                Return Me.TeamID
            End Get
            Set(ByVal Value As Integer)
                'Pass
            End Set
        End Property

        Friend Function GetExpectedAttendancePct() As Double
            Dim f As New Facility()
            f.Load(Me.FacilityID)

            If Me.ExpectedAttendance > 0 Then
                Return Me.ExpectedAttendance / f.Capacity
            Else
                Return 0
            End If
        End Function

    End Class

    Friend Class TeamShell
        Friend TeamID As Integer
        Friend Name As String
        Friend DivisionID As Integer
        Friend ConferenceID As Integer
        Friend GamesScheduled As Integer

        Public Overrides Function ToString() As String
            Return Me.Name
        End Function
    End Class
End Namespace