'--------------------------------------------------------------------
'Copyright (c) 2003 To-Paw Software
'Author:  Jack Neal, Dennis Thomas
'All rights reserved.
'--------------------------------------------------------------------

'Redistribution and use in source and binary forms, with or without
'modification, are permitted provided that the following conditions
'are met:
'1. Redistributions of source code must retain the above copyright
'   notice, this list of conditions and the following disclaimer.
'2. Redistributions in binary form must reproduce the above copyright
'   notice, this list of conditions and the following disclaimer in the
'   documentation and/or other materials provided with the distribution.
'3. The name of the author may not be used to endorse or promote products
'   derived from this software without specific prior written permission.

'THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
'IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
'OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
'IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
'NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
'THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
'THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Imports ISoccerSim.Players

Namespace Positions
	Friend Class PositionSet
		Inherits System.Collections.CollectionBase
		Friend Total As Double

		Default Property Item(ByVal index As Integer) As PlayerAge
			Get
				Return CType(InnerList.Item(index), PlayerAge)
			End Get
			Set(ByVal Value As PlayerAge)
				InnerList.Item(index) = Value
			End Set
		End Property

		Sub Add(ByVal value As PlayerAge)
			InnerList.Add(value)
		End Sub

		Sub Create(ByVal Abbr As String, ByVal AIDraftLate As Single, ByVal AIDraftMid As Single, _
		 ByVal AIDraftStarters As Single, ByVal AutoStockProb As Single, ByVal Name As String, _
		 ByVal PositionID As ISMPlayerPosition, ByVal SalaryModifier As Single)

			Dim pobjItem As New Position()
			With pobjItem
				.Abbr = Abbr
				.AIDraftInitialLate = AIDraftLate
				.AIDraftInitialMid = AIDraftMid
				.AIDraftInitialStarters = AIDraftStarters
				.AutoStockProb = AutoStockProb
				.Name = Name
				.PositionID = PositionID
				.SalaryModifier = SalaryModifier
				Me.Total = Me.Total + .AutoStockProb
			End With

			InnerList.Add(pobjItem)
		End Sub

		Sub Load()
			Dim pobjDR As OleDb.OleDbDataReader = gData.GetPositions

			Me.Clear()
			With pobjDR
				Do While .Read()
					Me.Create(.Item("Abbr"), .Item("AIDraftInitialLate"), .Item("AIDraftINitialMid"), _
					  .Item("AIDraftInitialStarters"), .Item("AutoStockProb"), .Item("Name"), _
					  .Item("PositionID"), .Item("SalaryModifier"))
				Loop
			End With
			pobjDR.Close()

		End Sub

		Function GetRandomStockPositionByProbability() As Position
			Dim pobjItem As New Position()
			Dim pobjRandom As New Random()
			Dim i As Integer
			Dim pdblTotal As Double
			Dim pdblCheck As Double

			pdblCheck = pobjRandom.NextDouble() * Me.Total
			For i = 0 To Innerlist.Count - 1
				pobjItem = InnerList.Item(i)
				pdblTotal = pdblTotal + pobjItem.AutoStockProb
				If pdblTotal >= pdblCheck Then
					Return pobjItem
				End If
			Next
			Return pobjItem

		End Function

	End Class
End Namespace